from pathlib import Path
import subprocess,time,json
w=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty');s=(w/'runtime.s').read_text()
a='    call erist_rt_graph_prepare_index\n    movq $0,.Lgraph_exact_slot_ready(%rip)';assert s.count(a)==1
s=s.replace(a,'    movq $0,.Lgraph_interior_queries(%rip)\n    movq $0,.Lgraph_exact_slot_ready(%rip)',1)
a='.Lg_mark_interior:\n    pushq %r12\n    movq %rdi,%r12\n    call erist_rt_graph_owner';assert s.count(a)==1
s=s.replace(a,'''.Lg_mark_interior:
    pushq %r12
    movq %rdi,%r12
    cmpq $0,.Lgraph_index_dirty(%rip)
    je .Lg_mark_interior_lookup
    incq .Lgraph_interior_queries(%rip)
    cmpq $4,.Lgraph_interior_queries(%rip)
    jb .Lg_mark_interior_lookup
    call erist_rt_graph_prepare_index
    movq %r12,%rdi
.Lg_mark_interior_lookup:
    call erist_rt_graph_owner''',1)
s+='\n.bss\n.p2align 3\n.Lgraph_interior_queries:\n.quad 0\n'
(w/'adaptive-runtime.s').write_text(s)
subprocess.run(['as','--64',w/'adaptive-runtime.s','-o',w/'adaptive-runtime.o'],check=True)
subprocess.run(['ld','-nostdlib','-static','-e','_start',w/'baseline_b.o',w/'adaptive-runtime.o','-o',w/'adaptive_b'],check=True)
subprocess.run(['ld','-nostdlib','-static','-e','_start',w/'baseline-regression-owned.o',w/'adaptive-runtime.o','-o',w/'adaptive-regression-owned'],check=True)
p=subprocess.run([w/'adaptive-regression-owned'],capture_output=True,timeout=90);assert p.returncode==0 and not p.stderr and p.stdout==(w/'baseline-regression-owned.stdout').read_bytes()
print('adaptive full public verifier parity PASS',flush=True)
results={}
for module in ('typed_ir.eri','ir_verify.eri'):
 names=('baseline_b','adaptive_b') if module=='typed_ir.eri' else ('adaptive_b',)
 for name in names:
  out=w/(name+'.adaptive-'+module+'.s');start=time.monotonic()
  with out.open('wb') as f:
   try:
    p=subprocess.run([w/name,'emit-asm',w/'baseline_src/compiler'/module,'--source-root',w/'baseline_src','--trace-phases'],stdout=f,stderr=subprocess.PIPE,timeout=90)
    r={'status':'completed','wall':time.monotonic()-start};assert p.returncode==0
    assert out.read_bytes()==(w/('baseline-'+module+'.reference.s')).read_bytes();r['independent_C_parity']=True
    (w/(name+'.adaptive-'+module+'.stderr')).write_bytes(p.stderr)
   except subprocess.TimeoutExpired as e:
    r={'status':'censored','wall_lower_bound':time.monotonic()-start};(w/(name+'.adaptive-'+module+'.stderr')).write_bytes(e.stderr or b'')
  results[module+'/'+name]=r;print(module,name,r,flush=True)
  (w/'adaptive-pilot.json').write_text(json.dumps(results,indent=2)+'\n')
