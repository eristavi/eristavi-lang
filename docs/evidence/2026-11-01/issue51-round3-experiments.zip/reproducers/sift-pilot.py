from pathlib import Path
import subprocess,random,struct,json,hashlib,time,statistics
w=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty');s=(w/'runtime.s').read_text();a=s.index('.Lg_index_sift:\n');b=s.index('.globl erist_rt_graph_prepare_index',a);old=s[a:b]
new='''.Lg_index_sift:
    # Hold the original parent key while moving larger children into the hole.
    movq (%rdi,%rdx,8),%r10
.Lg_sift_hole:
    leaq 1(%rdx,%rdx),%r8
    cmpq %rsi,%r8
    jae .Lg_sift_done
    movq (%rdi,%r8,8),%r11
    leaq 1(%r8),%r9
    cmpq %rsi,%r9
    jae .Lg_sift_child
    cmpq (%rdi,%r9,8),%r11
    jae .Lg_sift_child
    movq %r9,%r8
    movq (%rdi,%r8,8),%r11
.Lg_sift_child:
    cmpq %r11,%r10
    jae .Lg_sift_done
    movq %r11,(%rdi,%rdx,8)
    movq %r8,%rdx
    jmp .Lg_sift_hole
.Lg_sift_done:
    movq %r10,(%rdi,%rdx,8)
    ret
'''
(w/'sift-runtime.s').write_text(s[:a]+new+s[b:]);(w/'sift-helper.s').write_text(new)
subprocess.run(['as','--64',w/'sift-runtime.s','-o',w/'sift-runtime.o'],check=True)
subprocess.run(['ld','-nostdlib','-static','-e','_start',w/'baseline_b.o',w/'sift-runtime.o','-o',w/'sift_b'],check=True)
# Mathematical unsigned sorted-key oracle, unrelated to either implementation.
rng=random.Random(51);cases=[]
for n in (0,1,2,3,4,7,8,15,16,31,32,63,64,127,128,255):
 for rep in range(8):
  keys=[rng.getrandbits(64) for _ in range(n)]
  if rep==0:keys=sorted(keys)
  if rep==1:keys=sorted(keys,reverse=True)
  if rep==2:keys=[0]*n
  if rep==3:keys=[(2**64-1) if i%2 else 0 for i in range(n)]
  cases.append(keys)
harness='''.text
.globl _start
_start:
''';data='.data\n';truth=b''
for i,keys in enumerate(cases):
 n=len(keys);data+=f'.Lkeys{i}:\n'+('    .quad '+','.join(str(k) for k in keys)+'\n' if n else '    .quad 0\n')
 truth+=b''.join(struct.pack('<Q',k) for k in sorted(keys))
 harness+=f'    leaq .Lkeys{i}(%rip),%r12\n    movq ${n},%r13\n    call .Lsort_probe\n'
 if n:harness+=f'    movq $1,%rax\n    movq $1,%rdi\n    movq %r12,%rsi\n    movq ${n*8},%rdx\n    syscall\n'
harness+='''    movq $60,%rax
    xorq %rdi,%rdi
    syscall
.Lsort_probe:
    subq $8,%rsp
    movq %r13,%r14
    shrq $1,%r14
.Lprobe_heap:
    testq %r14,%r14
    je .Lprobe_extract_start
    decq %r14
    movq %r12,%rdi
    movq %r13,%rsi
    movq %r14,%rdx
    call .Lg_index_sift
    jmp .Lprobe_heap
.Lprobe_extract_start:
    movq %r13,%r14
.Lprobe_extract:
    cmpq $1,%r14
    jbe .Lprobe_done
    decq %r14
    movq (%r12),%rax
    movq (%r12,%r14,8),%rcx
    movq %rcx,(%r12)
    movq %rax,(%r12,%r14,8)
    movq %r12,%rdi
    movq %r14,%rsi
    xorq %rdx,%rdx
    call .Lg_index_sift
    jmp .Lprobe_extract
.Lprobe_done:
    addq $8,%rsp
    ret
'''
for name,helper in [('baseline',old),('hole',new)]:
 asm=w/(name+'-sort-probe.s');asm.write_text(harness+helper+data)
 subprocess.run(['as','--64',asm,'-o',w/(name+'-sort-probe.o')],check=True)
 exe=w/(name+'-sort-probe');subprocess.run(['ld','-nostdlib','-static','-e','_start',w/(name+'-sort-probe.o'),'-o',exe],check=True)
 p=subprocess.run([exe],capture_output=True,timeout=5);assert(p.returncode,p.stdout,p.stderr)==(0,truth,b'')
print('128 independent unsigned sort cases PASS both implementations',flush=True)
results=[]
for i in range(1):
 pair={}
 for name in ('baseline_b','sift_b'):
  out=w/(name+f'.sift-pair{i}.s');start=time.monotonic()
  with out.open('wb') as f:p=subprocess.run([w/name,'emit-asm',w/'baseline_src/compiler/typed_ir.eri','--source-root',w/'baseline_src'],stdout=f,stderr=subprocess.PIPE,timeout=90)
  pair[name]=time.monotonic()-start
  assert p.returncode==0 and not p.stderr
  assert out.read_bytes()==(w/'baseline-typed_ir.eri.reference.s').read_bytes()
 results.append(pair);print('pilot',pair,flush=True)
(w/'sift-pilot.json').write_text(json.dumps({'sort_cases':128,'pairs':results},indent=2)+'\n')
