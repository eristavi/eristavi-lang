from pathlib import Path
import subprocess,time,json,statistics,hashlib,resource
w=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty');rows=[]
for i in range(5):
 pair={}
 for name in (('baseline_b','projection_b') if i%2==0 else ('projection_b','baseline_b')):
  out=w/(name+f'.five-{i}.s');start=time.monotonic();before=resource.getrusage(resource.RUSAGE_CHILDREN)
  with out.open('wb') as f:p=subprocess.run([w/name,'emit-asm',w/'baseline_src/compiler/typed_ir.eri','--source-root',w/'baseline_src'],stdout=f,stderr=subprocess.PIPE,timeout=90)
  after=resource.getrusage(resource.RUSAGE_CHILDREN);assert p.returncode==0 and not p.stderr and out.read_bytes()==(w/'baseline-typed_ir.eri.reference.s').read_bytes()
  pair[name]={'wall':time.monotonic()-start,'user':after.ru_utime-before.ru_utime,'system':after.ru_stime-before.ru_stime}
 rows.append(pair);print(i,pair,flush=True)
 r={'scope':'five uninstrumented same-host alternating production typed_ir compilations; baseline and candidate use identical target source path, root, runtime and oracle','pairs':rows,'compiler_sha256':{name:hashlib.sha256((w/name).read_bytes()).hexdigest() for name in ('baseline_b','projection_b')}}
 (w/'projection-five.json').write_text(json.dumps(r,indent=2)+'\n')
a=statistics.median(p['baseline_b']['wall'] for p in rows);b=statistics.median(p['projection_b']['wall'] for p in rows)
r.update(baseline_median=a,candidate_median=b,reduction_percent=100*(1-b/a),wins=sum(p['projection_b']['wall']<p['baseline_b']['wall'] for p in rows));(w/'projection-five.json').write_text(json.dumps(r,indent=2)+'\n');print('RESULT',a,b,r['reduction_percent'],r['wins'],flush=True)
