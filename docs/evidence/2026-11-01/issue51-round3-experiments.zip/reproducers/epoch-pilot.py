from pathlib import Path
import subprocess,time,json,statistics
w=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty');s=(w/'runtime.s').read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b,1)
rep('.data\n.Lgraph_mask:', '.data\n.Lgraph_mark_epoch:\n.quad 1\n.Lgraph_mask:')
rep('    cmpq $0,24(%rax)\n    jne .Lg_mark_object_done\n    movq $1,24(%rax)',
    '    movq .Lgraph_mark_epoch(%rip),%rcx\n    cmpq %rcx,24(%rax)\n    je .Lg_mark_object_done\n    movq %rcx,24(%rax)')
rep('    movq $0,.Lgraph_work(%rip)\n    movq .Lgraph_objects(%rip),%r12\n.Lg_clear_objects:',
    '    movq $0,.Lgraph_work(%rip)\n    incq .Lgraph_mark_epoch(%rip)\n    jne .Lg_clear_failures_start\n    movq $1,.Lgraph_mark_epoch(%rip)\n    movq .Lgraph_objects(%rip),%r12\n.Lg_clear_objects:')
rep('    cmpq $0,24(%r13)\n    je .Lg_sweep_dead',
    '    movq .Lgraph_mark_epoch(%rip),%rax\n    cmpq %rax,24(%r13)\n    jne .Lg_sweep_dead')
(w/'epoch-runtime.s').write_text(s)
subprocess.run(['as','--64',w/'epoch-runtime.s','-o',w/'epoch-runtime.o'],check=True)
subprocess.run(['ld','-nostdlib','-static','-e','_start',w/'baseline_b.o',w/'epoch-runtime.o','-o',w/'epoch_b'],check=True)
# Execute exactly the independent public verifier corpus, unchanged app assembly.
subprocess.run(['ld','-nostdlib','-static','-e','_start',w/'baseline-regression-owned.o',w/'epoch-runtime.o','-o',w/'epoch-regression-owned'],check=True)
p=subprocess.run([w/'epoch-regression-owned'],capture_output=True,timeout=90)
assert p.returncode==0 and not p.stderr and p.stdout==(w/'baseline-regression-owned.stdout').read_bytes()
print('epoch public verifier exact parity PASS',flush=True)
pairs=[]
for i in range(1):
 pair={}
 for name in ('baseline_b','epoch_b'):
  out=w/(name+f'.epoch-pair{i}.s');start=time.monotonic()
  with out.open('wb') as f:p=subprocess.run([w/name,'emit-asm',w/'baseline_src/compiler/typed_ir.eri','--source-root',w/'baseline_src'],stdout=f,stderr=subprocess.PIPE,timeout=90)
  pair[name]=time.monotonic()-start;assert p.returncode==0 and not p.stderr
  assert out.read_bytes()==(w/'baseline-typed_ir.eri.reference.s').read_bytes()
 pairs.append(pair);print('epoch pilot',pair,flush=True)
(w/'epoch-pilot.json').write_text(json.dumps({'pairs':pairs,'public_verifier_parity':True},indent=2)+'\n')
