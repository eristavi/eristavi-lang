from pathlib import Path
import subprocess,time,json,hashlib
w=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty');module='semantic_types.eri';source=w/'baseline_src/compiler'/module
ref=w/(module+'.runtime-reference.s')
with ref.open('wb') as f:p=subprocess.run([w/'baseline_c','emit-asm',source,'--source-root',w/'baseline_src'],stdout=f,stderr=subprocess.PIPE,timeout=90)
assert p.returncode==0 and not p.stderr
results={}
for name in ('baseline_b','epoch_b','sift_b'):
 out=w/(name+'.'+module+'.s');start=time.monotonic()
 with out.open('wb') as f:
  try:
   p=subprocess.run([w/name,'emit-asm',source,'--source-root',w/'baseline_src'],stdout=f,stderr=subprocess.PIPE,timeout=90)
   r={'status':'completed','wall':time.monotonic()-start}
   assert p.returncode==0 and not p.stderr and out.read_bytes()==ref.read_bytes()
  except subprocess.TimeoutExpired:r={'status':'censored','wall_lower_bound':time.monotonic()-start}
 results[name]=r;print(name,r,flush=True)
(w/'runtime-medium.json').write_text(json.dumps({'module':module,'results':results},indent=2)+'\n')
