from pathlib import Path
import subprocess,shutil,sys,time,json
repo=Path('/workspace/scratch/2de9edf3eb4e/eristavi-lang');w=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty')
sys.path[:0]=[str(repo),str(repo/'tests')]
from compiler.erist.cli import build_native
from universal_verifier_cases import regression_program
s=(w/'baseline_src/compiler/universal_verify.eri').read_text()
def rep(a,b):
 global s
 assert s.count(a)==1,a
 s=s.replace(a,b,1)
rep('type Word { value Int; }','''type Word { value Int; }
// Invocation-owned register projection; home=-2 means used in multiple blocks.
type Slot { home Int; index Int; ready Bool; }
function touch(slots,index Int,block Int) {
    if index>=0 and index<slots.count {
        let slot identity Slot be slots[index];
        if slot.home == -1 { slot.home=block; }
        else { if slot.home != block { slot.home=-2; } }
    }
}
function touchInstruction(slots,value identity u.Instruction,block Int,limit Int) {
    touch(slots,value.result,block);
    let cursor be value.arguments; let count be 0;
    while cursor != none { if count>=limit { return; } touch(slots,cursor.value,block); cursor=cursor.next; count=count+1; }
}
function track(count Int,flows maybe identity Flow) {
    let slots be []; let index be 0;
    while index<count { slots.add(identity Slot { home=-1; index=-1; ready=false; }); index=index+1; }
    let flow be flows;
    while flow != none {
        let cursor be flow.block.instructions; let scanned be 0;
        while cursor != none {
            let current be cursor;
            if scanned>=10*(count+1) { cursor=none; } else {
                touchInstruction(slots,current,flow.block.index,count+8);
                cursor=current.next; scanned=scanned+1;
            }
        }
        let terminal be flow.block.terminator;
        if terminal != none { touchInstruction(slots,terminal,flow.block.index,count+8); }
        flow=flow.next;
    }
    return slots;
}''')
rep('function defined(values,start Int,index Int,flags) returns Bool { let word identity Word be values[start+index/62]; return (word.value/flags[index%62])%2 == 1; }','''function defined(values,start Int,index Int,flags,slots) returns Bool {
    let slot identity Slot be slots[index];
    if slot.index<0 { return slot.ready; }
    let bit be slot.index; let word identity Word be values[start+bit/62]; return (word.value/flags[bit%62])%2 == 1;
}''')
rep('function define(values,start Int,index Int,flags) { let word identity Word be values[start+index/62]; let flag be flags[index%62]; if (word.value/flag)%2 == 0 { word.value=word.value+flag; } }','''function define(values,start Int,index Int,flags,slots,localDefinitions Bool) {
    let slot identity Slot be slots[index];
    if slot.index<0 { if localDefinitions { slot.ready=true; } return; }
    let bit be slot.index; let word identity Word be values[start+bit/62]; let flag be flags[bit%62]; if (word.value/flag)%2 == 0 { word.value=word.value+flag; }
}''')
# Thread private invocation-owned tracking through the existing verifier helpers.
s=s.replace('functions,checkDefinitions Bool)', 'functions,slots,checkDefinitions Bool)')
s=s.replace('flags,checkDefinitions Bool)', 'flags,slots,checkDefinitions Bool)')
s=s.replace('functions,validate Bool,checkDefinitions Bool)', 'functions,slots,validate Bool,checkDefinitions Bool)')
s=s.replace('defined(masks,0,cursor.value,flags)', 'defined(masks,0,cursor.value,flags,slots)')
s=s.replace('operands(program,value,classes,masks,flags,checkDefinitions)', 'operands(program,value,classes,masks,flags,slots,checkDefinitions)')
s=s.replace('operands(program,terminal,classes,masks,flags,checkDefinitions)', 'operands(program,terminal,classes,masks,flags,slots,checkDefinitions)')
s=s.replace('functions,checkDefinitions);', 'functions,slots,checkDefinitions);')
s=s.replace('define(masks,0,cursor.result,flags)', 'define(masks,0,cursor.result,flags,slots,checkDefinitions)')
rep('let wordCount be (classes.count+61)/62; let flows', 'let flows')
rep('    let masks be words((2*count+1)*wordCount);', '''    let slots be track(classes.count,flows); let tracked be 0; let registerIndex be 0;
    while registerIndex<slots.count {
        let slot identity Slot be slots[registerIndex];
        if slot.home == -2 { slot.index=tracked; tracked=tracked+1; }
        registerIndex=registerIndex+1;
    }
    let wordCount be (tracked+61)/62;
    // Offsets are assigned only after the compact tracked-register count exists.
    let position be flows; let ordinal be count-1;
    while position != none { let current be position; current.incoming=(2*ordinal+1)*wordCount; current.outgoing=(2*ordinal+2)*wordCount; ordinal=ordinal-1; position=current.next; }
    let masks be words((2*count+1)*wordCount);''')
# Constructor offsets cannot refer to the not-yet-computed word count.
s=s.replace('incoming=(2*count+1)*wordCount; outgoing=(2*count+2)*wordCount;', 'incoming=0; outgoing=0;')
s=s.replace('flags,functions,true,false)', 'flags,functions,slots,true,false)')
s=s.replace('flags,functions,false,false)', 'flags,functions,slots,false,false)')
s=s.replace('flags,functions,true,true)', 'flags,functions,slots,true,true)')
root=w/'projection_src';
if root.exists():shutil.rmtree(root)
shutil.copytree(w/'baseline_src',root,ignore=shutil.ignore_patterns('__*'))
(root/'compiler/universal_verify.eri').write_text(s)
assert build_native(root/'frontend.eri',w/'projection_c',root,cc='gcc')==0
with (w/'projection_b.s').open('wb') as f:p=subprocess.run([w/'projection_c','emit-asm',root/'frontend.eri','--source-root',root,'--trace-phases'],stdout=f,stderr=subprocess.PIPE,timeout=90)
(w/'projection_b.trace').write_bytes(p.stderr);assert p.returncode==0,p.stderr[-2000:]
subprocess.run(['as','--64',w/'projection_b.s','-o',w/'projection_b.o'],check=True)
subprocess.run(['ld','-nostdlib','-static','-e','_start',w/'projection_b.o',w/'runtime.o','-o',w/'projection_b'],check=True)
reg,truth=regression_program();source=root/'__projection-regression.eri';source.write_text(reg)
assert build_native(source,w/'projection-regression-c',root,cc='gcc')==0
p=subprocess.run([w/'projection-regression-c'],capture_output=True,timeout=90);assert (p.returncode,p.stdout,p.stderr)==(0,truth.encode(),b''),(p.returncode,p.stdout[-1200:],p.stderr)
with (w/'projection-regression.s').open('wb') as f:p=subprocess.run([w/'projection_c','emit-asm',source,'--source-root',root],stdout=f,stderr=subprocess.PIPE,timeout=90)
assert p.returncode==0,p.stderr
subprocess.run(['as','--64',w/'projection-regression.s','-o',w/'projection-regression.o'],check=True)
subprocess.run(['ld','-nostdlib','-static','-e','_start',w/'projection-regression.o',w/'runtime.o','-o',w/'projection-regression-owned'],check=True)
p=subprocess.run([w/'projection-regression-owned'],capture_output=True,timeout=90);assert (p.returncode,p.stdout,p.stderr)==(0,truth.encode(),b''),(p.returncode,p.stdout[-1500:],p.stderr)
print('projection full public verifier C+owned parity PASS',flush=True)
results={}
for module in ('typed_ir.eri','ir_verify.eri'):
 for name in (('baseline_b','projection_b') if module=='typed_ir.eri' else ('projection_b',)):
  out=w/(name+'.projection-'+module+'.s');start=time.monotonic()
  with out.open('wb') as f:
   try:
    p=subprocess.run([w/name,'emit-asm',w/'baseline_src/compiler'/module,'--source-root',w/'baseline_src','--trace-phases'],stdout=f,stderr=subprocess.PIPE,timeout=90)
    r={'status':'completed','wall':time.monotonic()-start};assert p.returncode==0,p.stderr[-1200:]
    assert out.read_bytes()==(w/('baseline-'+module+'.reference.s')).read_bytes();r['independent_C_parity']=True
    (w/(name+'.projection-'+module+'.stderr')).write_bytes(p.stderr)
   except subprocess.TimeoutExpired as e:r={'status':'censored','wall_lower_bound':time.monotonic()-start}
  results[module+'/'+name]=r;print(module,name,r,flush=True);(w/'projection-pilot.json').write_text(json.dumps(results,indent=2)+'\n')
