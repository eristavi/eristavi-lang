from pathlib import Path
import re,subprocess,struct,bisect,collections,json,time
repo=Path('/workspace/scratch/2de9edf3eb4e/eristavi-lang');work=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty')
doc=(repo/'docs/evidence/2026-10-31/owned-runtime-profile-evidence.md').read_text()
s=doc.split('## stat_profile.s',1)[1].split('```asm\n',1)[1].split('```',1)[0]
s=s.replace('.Ldiag_interval:', '.Ldiag_stop_action:\n.quad .Ldiag_stop\n.quad 0x04000004\n.quad .Ldiag_restore\n.quad 0\n.Ldiag_interval:')
s=s.replace('    movl $38,%eax\n    movl $2,%edi\n    leaq .Ldiag_interval', '    movl $13,%eax\n    movl $15,%edi\n    leaq .Ldiag_stop_action(%rip),%rsi\n    xorl %edx,%edx\n    movl $8,%r10d\n    syscall\n    testq %rax,%rax\n    jne .Ldiag_fail\n    movl $38,%eax\n    movl $2,%edi\n    leaq .Ldiag_interval')
s=s.replace('    movl $2,%edi\n    leaq .Ldiag_samples','    movl $3,%edi\n    leaq .Ldiag_samples')
s+='\n.Ldiag_stop:\n    call .Ldiag_dump\n    movl $60,%eax\n    movl $124,%edi\n    syscall\n    ud2\n'
runtime=(work/'runtime.s').read_text()
runtime,n=re.subn(r'(?m)^_start:\n','_start:\n    call .Ldiag_init\n',runtime);assert n==1
runtime,n=re.subn(r'(?m)^erist_rt_exit:\n','erist_rt_exit:\n    call .Ldiag_dump\n',runtime);assert n==1
runtime+=s;(work/'sample-runtime.s').write_text(runtime)
subprocess.run(['as','--64','-L',work/'sample-runtime.s','-o',work/'sample-runtime.o'],check=True)
subprocess.run(['as','--64','-L',work/'baseline_b.s','-o',work/'sample-app.o'],check=True)
subprocess.run(['ld','-nostdlib','-static','-e','_start',work/'sample-app.o',work/'sample-runtime.o','-o',work/'sampled_b'],check=True)
syms=subprocess.check_output(['nm','-n','-S',work/'sampled_b'],text=True);(work/'sample-symbols.txt').write_text(syms)
entries=set(re.findall(r'(?m)^\s*call\s+([.A-Za-z_][\w.]*)',runtime+(work/'baseline_b.s').read_text()))
entries|=set(re.findall(r'(?m)^\.globl\s+([.A-Za-z_][\w.]*)',runtime))
functions=[];blocks=[]
for line in syms.splitlines():
 a=line.split()
 if len(a)>=3 and a[-2].lower()=='t':
  blocks.append((int(a[0],16),a[-1]))
  if a[-1] in entries:functions.append((int(a[0],16),a[-1]))
assert blocks[-1][0]<0x800000
for module in ('typed_ir.eri','ir_verify.eri'):
 target=work/'baseline_src/compiler'/module
 with (work/(module+'.cpu.bin')).open('wb') as stream, (work/(module+'.cpu.s')).open('wb') as out, (work/(module+'.cpu.stderr')).open('wb') as err:
  assert stream.fileno()==3
  start=time.monotonic();p=subprocess.Popen([str(work/'sampled_b'),'emit-asm',str(target),'--source-root',str(work/'baseline_src')],stdout=out,stderr=err,pass_fds=(3,))
  try:p.wait(timeout=90)
  except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
 counts=struct.unpack('<'+'Q'*262144,(work/(module+'.cpu.bin')).read_bytes())
 result={'scope':'5ms SIGPROF CPU sample, diagnostic-only, no speedup claim','returncode':p.returncode,'wall':time.monotonic()-start,'samples':sum(counts)}
 for name,symbols in [('functions',functions),('blocks',blocks)]:
  c=collections.Counter();addresses=[x[0] for x in symbols]
  for i,count in enumerate(counts):
   if count:
    pos=bisect.bisect_right(addresses,0x400000+i*16+8)-1
    if pos>=0:c[symbols[pos][1]]+=count
  result[name]=[(n,v,round(100*v/sum(counts),2)) for n,v in c.most_common(35)]
 (work/(module+'.cpu.json')).write_text(json.dumps(result,indent=2)+'\n');print(module,json.dumps(result),flush=True)
