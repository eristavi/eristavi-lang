from pathlib import Path
import sys,subprocess,json
repo=Path('/workspace/scratch/2de9edf3eb4e/eristavi-lang');w=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty');sys.path[:0]=[str(repo),str(repo/'tests')]
from compiler.erist.cli import build_native
from universal_verifier_cases import HEADER
cases=[];expect=[]
for slot in (1,2,3,61,62,63,123,124,125,185,186,187):
 label='projected-word-'+str(slot)
 cases.append(f'let b be wide(187,64,{slot}); result("{label}",b,false);')
 expect.append(label+(':ir-verify:Universal IR: register is not initialized on every incoming path:probe.eri:3:7' if (slot-1)%3==2 else ':ok'))
for constructor in ('loop','handled'):
 for valid in (False,True):
  label=f'projected-{constructor}-{valid}'
  cases.append(f'let b be {constructor}({str(valid).lower()}); let pad be 0; while pad<64 {{ b.current=u.block(b); u.end(b,u.instruction(10)); pad=pad+1; }} result("{label}",b,false);')
  expect.append(label+(':ok' if valid else ':ir-verify:Universal IR: register is not initialized on every incoming path:probe.eri:3:7'))
# A block-local read before its sole definition must fail even though no global bit exists.
for before in (True,False):
 label=f'local-order-{before}'
 body='let b be fresh(); let value be u.allocate(b,1); '
 if not before:body+='put(b,value); '
 body+='let used be u.call(b,"copy",[value]); '
 if before:body+='put(b,value); '
 body+='u.returnValue(b,used); let pad be 0; while pad<64 { b.current=u.block(b); u.end(b,u.instruction(10)); pad=pad+1; } '
 cases.append(body+f'result("{label}",b,false);');expect.append(label+(':ir-verify:Universal IR: register is not initialized on every incoming path:probe.eri:3:7' if before else ':ok'))
# Zero projected registers plus a reachable cycle: no empty-mask access is allowed.
cases.append('let b be fresh(); u.end(b,u.instruction(10)); let pad be 0; while pad<64 { b.current=u.block(b); u.end(b,u.instruction(10)); pad=pad+1; } result("zero-projection",b,false);');expect.append('zero-projection:ok')
# Bounded prepass must leave malformed cyclic operands to the original diagnostic.
cases.append('let b be fresh(); let value be u.zero(b,"void"); let used be u.call(b,"copy",[value]); let tail be b.current.tail; if tail!=none { let arg be tail.arguments; if arg!=none { let item be arg; item.next=item; } } u.returnValue(b,used); let pad be 0; while pad<64 { b.current=u.block(b); u.end(b,u.instruction(10)); pad=pad+1; } result("cyclic-projection",b,false);');expect.append('cyclic-projection:ir-verify:Universal IR: cyclic/excess operand list:probe.eri:3:7')
source=HEADER+''.join(f'function probe{i}() {{ {body} }}\n' for i,body in enumerate(cases))+''.join(f'probe{i}();\n' for i in range(len(cases)))
truth=('\n'.join(expect)+'\n').encode();results={}
for variant,rootname,frontend in [('baseline','baseline_src','baseline_c'),('candidate','large_projection_src','large_projection_c')]:
 root=w/rootname;entry=root/'__projection_contracts.eri';entry.write_text(source)
 binary=w/(variant+'-projection-contracts-c');assert build_native(entry,binary,root,cc='gcc')==0
 p=subprocess.run([binary],capture_output=True,timeout=90);assert(p.returncode,p.stdout,p.stderr)==(0,truth,b''),(variant,p.returncode,p.stdout[-1500:],truth[-1500:],p.stderr)
 asm=w/(variant+'-projection-contracts.s')
 with asm.open('wb') as f:p=subprocess.run([w/frontend,'emit-asm',entry,'--source-root',root],stdout=f,stderr=subprocess.PIPE,timeout=90)
 assert p.returncode==0,p.stderr
 obj=w/(variant+'-projection-contracts.o');exe=w/(variant+'-projection-contracts-owned')
 subprocess.run(['as','--64',asm,'-o',obj],check=True);subprocess.run(['ld','-nostdlib','-static','-e','_start',obj,w/'runtime.o','-o',exe],check=True)
 p=subprocess.run([exe],capture_output=True,timeout=90);assert(p.returncode,p.stdout,p.stderr)==(0,truth,b''),(variant,p.returncode,p.stdout[-1500:],p.stderr)
 results[variant]='C+owned exact independent categories/messages/locations PASS';print(variant,results[variant],flush=True)
(w/'projection-contracts.json').write_text(json.dumps({'cases':len(cases),'results':results,'expected':expect},indent=2)+'\n')
