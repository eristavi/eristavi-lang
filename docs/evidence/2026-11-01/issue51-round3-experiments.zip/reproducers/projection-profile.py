from pathlib import Path
import sys,json
repo=Path('/workspace/scratch/2de9edf3eb4e/eristavi-lang');w=Path('/workspace/scratch/2de9edf3eb4e/round3-dirty');sys.path[:0]=[str(repo/'tools/probes')]
import production_issue51_profile as p
app,syms=p.profile_application((w/'projection_b.s').read_text(),(w/'projection_b.trace').read_text())
with (w/'projection-counter.bin').open('wb') as stream:
 runtime=p.profile_runtime((w/'runtime.s').read_text(),stream.fileno());exe=p.assemble_link(w,app,runtime,'projection-prof')
 r=p.invoke([exe,'emit-asm',w/'baseline_src/compiler/ir_verify.eri','--source-root',w/'baseline_src','--trace-phases'],w/'projection-profile-output.s',w/'projection-profile.stderr',90,pass_fds=(stream.fileno(),))
 stream.flush();rows=p.records_from(w/'projection-counter.bin');r.update(samples=rows,intervals=p.intervals(rows),fields=list(p.FIELDS));(w/'projection-profile.json').write_text(json.dumps(r,indent=2)+'\n');print(r['status'],[(a['from'],a['to'],round(a['wall_seconds_observed'],3),a['counters']['value_new'],a['counters']['graphs'],a['counters']['gc']) for a in r['intervals']],flush=True)
