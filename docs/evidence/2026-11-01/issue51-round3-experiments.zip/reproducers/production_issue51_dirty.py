#!/usr/bin/env python3
"""Private #51 dirty-flow pilot; never builds an owned compiler with itself.

Build immutable source copies once, compare independent C and owned oracles,
then alternate five uninstrumented runs. Each compilation retains the 90s cap.
The source candidate is an invocation-local dataflow scheduling change only.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import resource
from pathlib import Path
import shutil
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT/'tests'), str(Path(__file__).parent)]
from compiler.erist.cli import build_native
from u1_native_tools import shared_u1_compilers
from production_issue51_pairs import owned_link
from universal_verifier_cases import regression_program, benchmark_program


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def replace(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new, 1)


def candidate(source):
    source = replace(source, 'reachable Bool; incoming Int;',
                     'reachable Bool; dirty Bool; incoming Int;')
    source = replace(source, 'reachable=cursor.index == 0; incoming=',
                     'reachable=cursor.index == 0; dirty=true; incoming=')
    source = replace(source,
        'if intersect(masks,current.incoming,source.outgoing,wordCount) { changed=true; } return changed;',
        'if intersect(masks,current.incoming,source.outgoing,wordCount) { changed=true; }\n'
        '    if changed { current.dirty=true; } return changed;')
    source = replace(source,
        'if try transfer(program,routine,current,classes,masks,wordCount,flags,functions,false,false) { changed=true; }',
        'if current.dirty {\n'
        '                    if try transfer(program,routine,current,classes,masks,wordCount,flags,functions,false,false) { changed=true; }\n'
        '                    current.dirty=false;\n'
        '                }')
    return source


def run(cmd, out, cap=90):
    out=Path(out); start=time.monotonic(); before=resource.getrusage(resource.RUSAGE_CHILDREN)
    with out.open('wb') as f, out.with_suffix(out.suffix+'.stderr').open('wb') as err:
        try:
            p=subprocess.run(list(map(str,cmd)),stdout=f,stderr=err,timeout=cap)
            r={'status':'completed' if p.returncode==0 else 'failed',
               'returncode':p.returncode,'wall_seconds':time.monotonic()-start}
        except subprocess.TimeoutExpired:
            r={'status':'censored','cap_seconds':cap,'wall_seconds_lower_bound':time.monotonic()-start}
    after=resource.getrusage(resource.RUSAGE_CHILDREN)
    r['child_user_seconds']=after.ru_utime-before.ru_utime
    r['child_system_seconds']=after.ru_stime-before.ru_stime
    r['stdout_sha256']=sha(out)
    r['stderr_sha256']=sha(out.with_suffix(out.suffix+'.stderr'))
    return r


def require(result, out, truth=None):
    assert result['status']=='completed', result
    assert not Path(str(out)+'.stderr').read_bytes(), str(out)
    if truth is not None:
        assert Path(out).read_bytes()==truth, str(out)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--pairs',type=int,choices=(1,5),default=1)
    ap.add_argument('--large',action='store_true')
    ap.add_argument('--profile',choices=('baseline','candidate'))
    a=ap.parse_args(); work=a.output.resolve(); work.mkdir(parents=True,exist_ok=True)
    base=(ROOT/'src/compiler/universal_verify.eri').read_text()
    manifest={str(p.relative_to(ROOT/'src')):sha(p) for p in sorted((ROOT/'src').rglob('*.eri'))}
    summary={'scope':'private dirty-flow pilot, no owned full compiler self-build',
             'source_manifest':manifest,'pairs_requested':a.pairs,'workloads':{}}
    # A completed immutable build may be reused only with exact source/toolchain hashes.
    key={'manifest':manifest,'CC':os.environ.get('CC','gcc'),'CFLAGS':os.environ.get('CFLAGS','')}
    keyfile=work/'build-inputs.json'
    if keyfile.exists():
        assert json.loads(keyfile.read_text())==key, 'stale probe build'
    else:
        for name,source in [('baseline',base),('candidate',candidate(base))]:
            root=work/(name+'_src'); shutil.copytree(ROOT/'src',root)
            (root/'compiler/universal_verify.eri').write_text(source)
            c=work/(name+'_c')
            assert build_native(root/'frontend.eri',c,root,cc=key['CC'])==0
        _,generator=shared_u1_compilers()
        runtime=subprocess.check_output([str(generator)],timeout=90)
        (work/'runtime.s').write_bytes(runtime)
        for name in ('baseline','candidate'):
            root=work/(name+'_src'); asm=work/(name+'_b.s')
            r=run([work/(name+'_c'),'emit-asm',root/'frontend.eri','--source-root',root,
                   '--target','x86_64-linux','--trace-phases'],asm)
            assert r['status']=='completed',r
            # Trace is retained for private source-symbol attribution.
            owned_link(asm.read_bytes(),runtime,work,name+'_b')
        keyfile.write_text(json.dumps(key,indent=2)+'\n')
    summary['compiler_sha256']={name:sha(work/(name+'_b')) for name in ('baseline','candidate')}
    summary['runtime_sha256']=sha(work/'runtime.s')
    if a.profile:
        import production_issue51_profile as prof
        name=a.profile
        app=(work/(name+'_b.s')).read_text()
        app,symbols=prof.profile_application(app,(work/(name+'_b.s.stderr')).read_text())
        with (work/(name+'-counters.bin')).open('wb') as stream:
            runtime=prof.profile_runtime((work/'runtime.s').read_text(),stream.fileno())
            observed=prof.assemble_link(work,app,runtime,name+'-observed')
            target=work/(name+'_src/compiler/ir_verify.eri')
            # invoke() passes only the diagnostic descriptor to the child.
            r=prof.invoke([observed,'emit-asm',target,'--source-root',work/(name+'_src'),
                           '--target','x86_64-linux','--trace-phases'],work/(name+'-observed.s'),
                          work/(name+'-observed.stderr'),90,pass_fds=(stream.fileno(),))
            stream.flush(); rows=prof.records_from(work/(name+'-counters.bin'))
            r.update(samples=rows,intervals=prof.intervals(rows),symbols=symbols,
                     fields=list(prof.FIELDS),compiler_sha256=summary['compiler_sha256'][name])
            (work/(name+'-profile.json')).write_text(json.dumps(r,indent=2)+'\n')
            print('profile',name,r['status'],flush=True)
        return
    regression,truth=regression_program()
    for name in ('baseline','candidate'):
        root=work/(name+'_src'); source=root/'__regression.eri';source.write_text(regression)
        c=work/(name+'-regression-c')
        assert build_native(source,c,root,cc=key['CC'])==0
        out=work/(name+'-regression-c.stdout');require(run([c],out),out,truth.encode())
        asm=work/(name+'-regression.s')
        require(run([work/(name+'_c'),'emit-asm',source,'--source-root',root],asm),asm)
        exe=owned_link(asm.read_bytes(),(work/'runtime.s').read_bytes(),work,name+'-regression-owned')
        out=work/(name+'-regression-owned.stdout');require(run([exe],out),out,truth.encode())
    print('all public C+owned verifier oracles PASS',flush=True)
    summary['public_regression_oracle']='PASS: baseline/candidate C+owned exact stdout/stderr/exit'
    modules=['typed_ir.eri']+(['ir_verify.eri'] if a.large else [])
    for module in modules:
        refs={}
        for name in ('baseline','candidate'):
            root=work/(name+'_src'); out=work/(name+'-'+module+'.reference.s')
            require(run([work/(name+'_c'),'emit-asm',root/'compiler'/module,'--source-root',root],out),out)
            refs[name]=sha(out)
        pairs=[]
        for i in range(a.pairs):
            pair={}
            for name in (('baseline','candidate') if i%2==0 else ('candidate','baseline')):
                root=work/(name+'_src'); out=work/(name+'-'+module+f'-{i}.s')
                r=run([work/(name+'_b'),'emit-asm',root/'compiler'/module,'--source-root',root],out)
                if r['status']=='completed':
                    require(r,out); assert r['stdout_sha256']==refs[name],r
                    r['independent_C_assembly_parity']=True
                pair[name]=r
                print(module,i,name,r,flush=True)
            pairs.append(pair)
            summary['workloads'][module]={'pairs':pairs,'reference_sha256':refs}
            (work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
        if all(r['status']=='completed' for p in pairs for r in p.values()):
            before=statistics.median(p['baseline']['wall_seconds'] for p in pairs)
            after=statistics.median(p['candidate']['wall_seconds'] for p in pairs)
            summary['workloads'][module].update(baseline_median=before,candidate_median=after,
                 reduction_percent=100*(1-after/before))
    assert manifest=={str(p.relative_to(ROOT/'src')):sha(p) for p in sorted((ROOT/'src').rglob('*.eri'))}
    summary['source_snapshot_unchanged']=True
    (work/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')

if __name__=='__main__':main()
