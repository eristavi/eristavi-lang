"""Rebuild the compact summary from retained binary records and run metadata."""
import hashlib
import json
import sys
from pathlib import Path
sys.path.insert(0,str(Path(sys.argv[1]).resolve()/'tools/probes'))
from production_verifier_storage import records

HERE=Path(__file__).resolve().parent

def select(path):
    raw=path/'records.bin'
    rr=records(raw)
    metadata=json.loads((path/'observed.json').read_text())
    output={k:v for k,v in metadata.items() if k!='records'}
    output['record_count']=len(rr)
    output['records_sha256']=hashlib.sha256(raw.read_bytes()).hexdigest()
    output['captured_global_peak_bytes']=max(r['total_peak'] for r in rr)
    output['event_counts']={str(i):sum(r['event']==i for r in rr) for i in range(1,7)}
    output['global_exit_or_audit']=[{k:r[k] for k in ('event','aggregate','allocations')} for r in rr if r['id']==0]
    output['routine_endpoints']=[]
    for r in rr:
        if r['event']!=2:continue
        sem=r['semantic']
        output['routine_endpoints'].append({
            **{k:r[k] for k in ('id','pass','function','registers','blocks','words_per_mask','mask_words')},
            'mask_logical_u64_bytes':8*r['mask_words'],
            'mask_backing_bytes':sum(sem[k]['bytes'] for k in ('mask_list','word_body','word_identity')),
            'classes_backing_bytes':sem['register_classes']['bytes'],
            'flow_backing_bytes':sum(sem[k]['bytes'] for k in ('flow_body','flow_wrapper')),
            'semantic':sem,'aggregate':r['aggregate'],
            'categories':r['allocations']})
    return output

summary={
 'baseline_main':'4a07bc988cc57407635a4d81f21a92d5dfc74b55',
 'production_implementation':'qualified PR #110; src/ unchanged',
 'scope':'allocator capacity including 32-byte header for successful allocations made in Universal verification scopes; real free accounting outside scope too; semantic backing includes only current verifier-owned roots, not input IR; not whole-process heap or RSS',
 'observer_bss_bytes':18907552,
 'production':{name:select(HERE/'production'/name) for name in ('typed_ir.eri','ir_verify.eri')},
 'fixtures':{p.name:select(p) for p in sorted((HERE/'fixtures').glob('fixture-*'))},
 'negative_controls':json.loads((HERE/'fixtures/manifest.json').read_text())['negative_controls'],
 'plain_process_rss':json.loads((HERE/'production/plain-rss.json').read_text()),
 'caveats':[
  'Large compilation censored at unchanged 90-second cap; first pass and routine f161 completed, second pass partial; no large full-output or audit claim.',
  'Captured global peak is exact through the last record, and only a lower bound for the whole large run.',
  'Invocation peak is directly maintained, never a sum of category peaks. Shared runtime allocations are sid0; existing shared/static storage is excluded.',
  'Extra diagnostic GC audits happen after output, not during verification. Zero live after audit is not a production timing or process RSS result.',
  'Instrumentation changes binary layout and adds scopes/hooks. Allocator reuse capacities and observed peaks can vary slightly. Timings are not speed evidence.',
  'Register-class traffic covers table construction; per-read integer temporaries cannot all be uniquely separated from verification_other.',
  'Tool snapshots accompany evidence. Production run precedes removal of an unused C reporting function and stronger Python decoder checks/two exact boundary fixtures; instrumentation hooks are unchanged.'
 ]}
Path(HERE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('summary written')
