# Verifier storage measurement — 2026-11-01

Baseline `eristavi/eristavi-lang` main
`4a07bc988cc57407635a4d81f21a92d5dfc74b55`; production remains qualified PR #110.
Linux x86-64 6.18.57, Python 3.12.14, GCC 13.3.0 and binutils 2.42.
The cached C-bootstrap frontend and owned compiler B were built with GCC -O2;
all source file hashes were verified before use. No owned compiler self-build.

`production/` retains the bounded production source run. `fixtures/` retains
the final six independently sized, two-round fixtures, negative-control outcomes,
and a completed small production source run. Each workload has raw fixed-size
little-endian 4,400-byte records, decoded JSON, output/error streams and metadata.
Top-level records.bin is only the last copied workload; prefer workload copies.
No source compilation timing is acceptance evidence in this investigation.

Normal reproduction from a checkout of the published revision:

```sh
CC=gcc CFLAGS=-O2 python tools/probes/production_verifier_storage.py --output /tmp/storage-fixtures --fixtures
CC=gcc CFLAGS=-O2 python tools/probes/production_verifier_storage.py --output /tmp/storage-production --large --large-observer-only
python /path/to/extracted/summarize.py /path/to/checkout
python /path/to/extracted/plain_rss.py /path/to/owned-compiler-B /path/to/checkout /tmp/rss-result
```

The production large run used `--cached-tools` pointing at round-three's
source-hash-verified baseline C/B assembly/runtime cache. Fresh mode above builds
the bootstrap tools normally. Source paths and host allocator reuse can change
capacity details; do not expect identical wall times or byte peaks on another
layout. The unchanged per-command cap is 90 seconds. Large plain was deliberately
not rerun: prior round's unchanged plain workload was already censored at 90s.

The production run's observer still had an unused st_observer_bytes() function.
Final tool removes it; Python additionally checks category/aggregate ledgers and
adds exact R=62/63 fixtures. Hooks, ABI and the Record schema are unchanged.
The final fixtures were run with these final tools and all passed. The summary
re-decodes all production records using the stronger final decoder.

Successful allocator capacity includes the actual 32-byte physical allocator
header, graph header/cells, rounding and unsplittable reused remainder. It is not
just requested bytes or a stale documented 16-byte header. Graph snapshots follow
backing ownership and the current semantic roots, deduplicating physical objects.
The emitted compiler reverses nominal field declaration order; source schemas,
descriptor IDs, graph shapes, word counts and register/block formula are checked.

Ledger scope: allocations made while either Universal verification is active,
with matching frees tracked even after that scope ends. Existing input IR, earlier
shared allocations, fixed runtime scratch/BSS and allocator region slack are not
assigned to a verifier. Shared runtime growth is sid0 rather than an arbitrary
routine owner. The bounded observer itself uses 18,907,552 bytes BSS and no heap;
its pointer map is not registered as a GC root. Original routine native frame
is 4,192 bytes; hook/scoping stack space is diagnostic overhead. Whole stack use
and process RSS are distinct from the allocator ledger.

Events: 1=mask ready before fill; 2=routine end before scope cleanup;
3=verification end; 4=entry returned; 5/6=after two diagnostic-only post-output
collections; 99=observer refusal. The collections never change verification's
normal GC cadence. Negative controls deliberately corrupt graph-kind attribution
or exhaust the observer's own invocation bound: both exit 125 with event99.
These controls do not exercise or change production exhaustion limits.

Source-site retained objects include garbage awaiting collection. Semantic
snapshots exclude dead backing and ephemeral scalar slots. Per-category peaks
must not be added: aggregate peaks are maintained at every alloc/free event.
The large compilation is censored and has no exit/audit record; its recorded
global peak is only a lower bound on the entire run. Completed f161 first-pass
endpoint remains valid. Nothing here establishes a compiler speedup.

`files.sha256.json` pins every archived file other than itself. The outer JSON
summary pins the zip SHA-256. Diagnostic source files in this archive are recovery
material, not installed production compiler changes.
