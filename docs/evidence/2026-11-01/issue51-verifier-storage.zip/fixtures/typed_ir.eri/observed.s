.globl erist_entry
.text
.p2align 4
.type f0, @function
f0:
pushq %rbp
movq %rsp, %rbp
subq $336, %rsp
movq %rdi, -320(%rbp)
movq %rsi, -328(%rbp)
leaq -312(%rbp), %rdi
movq $39, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf0_b0
.Lf0_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $9, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -24(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -240(%rbp)
movabsq $3, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
call evn_void@PLT
movq %rax, -304(%rbp)
movq -8(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
leave
ret
.Lf0_b2:
jmp .Lf0_b3
.Lf0_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $9, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_store@PLT
movq %rax, -152(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
call evn_void@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.Lf0_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -328(%rbp), %rsi
leaq .Lroots_f0(%rip), %rdx
movq $41, %rcx
call evn_bind_roots@PLT
movq -320(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -328(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $1, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movabsq $9, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_none@PLT
movq %rax, -80(%rbp)
movabsq $5, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf0_b2
jmp .Lf0_b1
.size f0, .-f0
.text
.p2align 4
.type f1, @function
f1:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
leaq -288(%rbp), %rdi
movq $36, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf1_b0
.Lf1_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f1(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
movabsq $1, %rax
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_int@PLT
movq %rax, -32(%rbp)
movabsq $0, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
movq -32(%rbp), %rsi
call evn_unary@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $9, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_none@PLT
movq %rax, -80(%rbp)
movabsq $9, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_none@PLT
movq %rax, -96(%rbp)
movabsq $9, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_none@PLT
movq %rax, -112(%rbp)
leaq .Ldata_0(%rip), %rax
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_text@PLT
movq %rax, -136(%rbp)
movabsq $0, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_bool@PLT
movq %rax, -168(%rbp)
movq -48(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
movq -96(%rbp), %rcx
movq -112(%rbp), %r8
movq -136(%rbp), %r9
pushq -168(%rbp)
pushq -152(%rbp)
call f2@PLT
addq $16, %rsp
movq %rax, -176(%rbp)
movq -16(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
movabsq $6, %rax
movq %rax, -192(%rbp)
movabsq $2, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_object@PLT
movq %rax, -208(%rbp)
movabsq $9, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_none@PLT
movq %rax, -224(%rbp)
movabsq $1, %rax
movq %rax, -232(%rbp)
movq -208(%rbp), %rdi
movq -232(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_init@PLT
movq %rax, -240(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -208(%rbp), %rdi
movq -256(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_init@PLT
movq %rax, -264(%rbp)
movabsq $10, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -280(%rbp)
movq -8(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
leave
ret
.size f1, .-f1
.text
.p2align 4
.type f2, @function
f2:
pushq %rbp
movq %rsp, %rbp
subq $480, %rsp
movq %rdi, -416(%rbp)
movq %rsi, -424(%rbp)
movq %rdx, -432(%rbp)
movq %rcx, -440(%rbp)
movq %r8, -448(%rbp)
movq %r9, -456(%rbp)
movq 16(%rbp), %rax
movq %rax, -464(%rbp)
movq 24(%rbp), %rax
movq %rax, -472(%rbp)
leaq -408(%rbp), %rdi
movq $51, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf2_b0
.Lf2_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -472(%rbp), %rsi
leaq .Lroots_f2(%rip), %rdx
movq $59, %rcx
call evn_bind_roots@PLT
movq -416(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -424(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -432(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -440(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -448(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -456(%rbp), %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -464(%rbp), %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -472(%rbp), %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $7, %rax
movq %rax, -144(%rbp)
movabsq $9, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_object@PLT
movq %rax, -160(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $8, %rax
movq %rax, -176(%rbp)
movq -160(%rbp), %rdi
movq -176(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_init@PLT
movq %rax, -184(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $7, %rax
movq %rax, -200(%rbp)
movq -160(%rbp), %rdi
movq -200(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_init@PLT
movq %rax, -208(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $6, %rax
movq %rax, -224(%rbp)
movq -160(%rbp), %rdi
movq -224(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_init@PLT
movq %rax, -232(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $5, %rax
movq %rax, -248(%rbp)
movq -160(%rbp), %rdi
movq -248(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_init@PLT
movq %rax, -256(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $4, %rax
movq %rax, -272(%rbp)
movq -160(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $9, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_none@PLT
movq %rax, -296(%rbp)
movabsq $3, %rax
movq %rax, -304(%rbp)
movq -160(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movabsq $2, %rax
movq %rax, -328(%rbp)
movq -160(%rbp), %rdi
movq -328(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_init@PLT
movq %rax, -336(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $1, %rax
movq %rax, -352(%rbp)
movq -160(%rbp), %rdi
movq -352(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_init@PLT
movq %rax, -360(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -160(%rbp), %rdi
movq -376(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_init@PLT
movq %rax, -384(%rbp)
movabsq $8, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -400(%rbp)
movq -8(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
leave
ret
.size f2, .-f2
.text
.p2align 4
.type f3, @function
f3:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf3_b0
.Lf3_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f3(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $32, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f3, .-f3
.text
.p2align 4
.type f4, @function
f4:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf4_b0
.Lf4_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f4(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $31, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f4, .-f4
.text
.p2align 4
.type f5, @function
f5:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf5_b0
.Lf5_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f5(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $30, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f5, .-f5
.text
.p2align 4
.type f6, @function
f6:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf6_b0
.Lf6_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f6(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $29, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f6, .-f6
.text
.p2align 4
.type f7, @function
f7:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf7_b0
.Lf7_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f7(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $28, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f7, .-f7
.text
.p2align 4
.type f8, @function
f8:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf8_b0
.Lf8_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f8(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $27, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f8, .-f8
.text
.p2align 4
.type f9, @function
f9:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf9_b0
.Lf9_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f9(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $26, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f9, .-f9
.text
.p2align 4
.type f10, @function
f10:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf10_b0
.Lf10_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f10(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $25, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f10, .-f10
.text
.p2align 4
.type f11, @function
f11:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf11_b0
.Lf11_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f11(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $24, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f11, .-f11
.text
.p2align 4
.type f12, @function
f12:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf12_b0
.Lf12_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f12(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $23, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f12, .-f12
.text
.p2align 4
.type f13, @function
f13:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf13_b0
.Lf13_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f13(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $22, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f13, .-f13
.text
.p2align 4
.type f14, @function
f14:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf14_b0
.Lf14_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f14(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $21, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f14, .-f14
.text
.p2align 4
.type f15, @function
f15:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf15_b0
.Lf15_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f15(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $20, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f15, .-f15
.text
.p2align 4
.type f16, @function
f16:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf16_b0
.Lf16_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f16(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $19, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f16, .-f16
.text
.p2align 4
.type f17, @function
f17:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf17_b0
.Lf17_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f17(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $18, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f17, .-f17
.text
.p2align 4
.type f18, @function
f18:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf18_b0
.Lf18_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f18(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $17, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f18, .-f18
.text
.p2align 4
.type f19, @function
f19:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf19_b0
.Lf19_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f19(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $16, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f19, .-f19
.text
.p2align 4
.type f20, @function
f20:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf20_b0
.Lf20_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f20(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $15, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f20, .-f20
.text
.p2align 4
.type f21, @function
f21:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf21_b0
.Lf21_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f21(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $14, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f21, .-f21
.text
.p2align 4
.type f22, @function
f22:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf22_b0
.Lf22_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f22(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $13, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f22, .-f22
.text
.p2align 4
.type f23, @function
f23:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf23_b0
.Lf23_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f23(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $12, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f23, .-f23
.text
.p2align 4
.type f24, @function
f24:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf24_b0
.Lf24_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f24(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $11, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f24, .-f24
.text
.p2align 4
.type f25, @function
f25:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf25_b0
.Lf25_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f25(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $10, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f25, .-f25
.text
.p2align 4
.type f26, @function
f26:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf26_b0
.Lf26_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f26(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $9, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f26, .-f26
.text
.p2align 4
.type f27, @function
f27:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf27_b0
.Lf27_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f27(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $8, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f27, .-f27
.text
.p2align 4
.type f28, @function
f28:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf28_b0
.Lf28_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f28(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $7, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f28, .-f28
.text
.p2align 4
.type f29, @function
f29:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf29_b0
.Lf29_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f29(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $6, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f29, .-f29
.text
.p2align 4
.type f30, @function
f30:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf30_b0
.Lf30_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f30(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $5, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f30, .-f30
.text
.p2align 4
.type f31, @function
f31:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf31_b0
.Lf31_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f31(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $4, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f31, .-f31
.text
.p2align 4
.type f32, @function
f32:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf32_b0
.Lf32_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f32(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $3, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f32, .-f32
.text
.p2align 4
.type f33, @function
f33:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf33_b0
.Lf33_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f33(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $2, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f33, .-f33
.text
.p2align 4
.type f34, @function
f34:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf34_b0
.Lf34_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f34(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $1, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f34, .-f34
.text
.p2align 4
.type f35, @function
f35:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf35_b0
.Lf35_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_f35(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
movabsq $0, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size f35, .-f35
.text
.p2align 4
.type f36, @function
f36:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
movq %rdi, -304(%rbp)
movq %rsi, -312(%rbp)
leaq -296(%rbp), %rdi
movq $37, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf36_b0
.Lf36_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_get@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movq -48(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_store@PLT
movq %rax, -272(%rbp)
jmp .Lf36_b1
.Lf36_b5:
jmp .Lf36_b6
.Lf36_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_get@PLT
movq %rax, -208(%rbp)
movabsq $34, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -224(%rbp)
movq -8(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
leave
ret
.Lf36_b3:
movabsq $34, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_none@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf36_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_get@PLT
movq %rax, -144(%rbp)
movabsq $3, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf36_b5
jmp .Lf36_b4
.Lf36_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $34, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_none@PLT
movq %rax, -104(%rbp)
movabsq $6, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -128(%rbp)
cmpq $0, -128(%rbp)
je .Lf36_b3
jmp .Lf36_b2
.Lf36_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -312(%rbp), %rsi
leaq .Lroots_f36(%rip), %rdx
movq $39, %rcx
call evn_bind_roots@PLT
movq -304(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -312(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $6, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -48(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -80(%rbp)
jmp .Lf36_b1
.size f36, .-f36
.text
.p2align 4
.type f37, @function
f37:
pushq %rbp
movq %rsp, %rbp
subq $336, %rsp
movq %rdi, -320(%rbp)
movq %rsi, -328(%rbp)
leaq -312(%rbp), %rdi
movq $39, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf37_b0
.Lf37_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_get@PLT
movq %rax, -264(%rbp)
movabsq $0, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movq -48(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_store@PLT
movq %rax, -288(%rbp)
jmp .Lf37_b1
.Lf37_b5:
jmp .Lf37_b6
.Lf37_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_get@PLT
movq %rax, -224(%rbp)
movabsq $25, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -240(%rbp)
movq -8(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
leave
ret
.Lf37_b3:
movabsq $25, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_none@PLT
movq %rax, -304(%rbp)
movq -8(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
leave
ret
.Lf37_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_get@PLT
movq %rax, -144(%rbp)
movabsq $9, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movabsq $2, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $5, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -176(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf37_b5
jmp .Lf37_b4
.Lf37_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $25, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_none@PLT
movq %rax, -104(%rbp)
movabsq $6, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -128(%rbp)
cmpq $0, -128(%rbp)
je .Lf37_b3
jmp .Lf37_b2
.Lf37_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -328(%rbp), %rsi
leaq .Lroots_f37(%rip), %rdx
movq $41, %rcx
call evn_bind_roots@PLT
movq -320(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -328(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $5, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -48(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -80(%rbp)
jmp .Lf37_b1
.size f37, .-f37
.text
.p2align 4
.type f38, @function
f38:
pushq %rbp
movq %rsp, %rbp
subq $304, %rsp
movq %rdi, -288(%rbp)
movq %rsi, -296(%rbp)
leaq -280(%rbp), %rdi
movq $35, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf38_b0
.Lf38_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_get@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movq -48(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_store@PLT
movq %rax, -256(%rbp)
jmp .Lf38_b1
.Lf38_b5:
jmp .Lf38_b6
.Lf38_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_get@PLT
movq %rax, -192(%rbp)
movabsq $28, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -208(%rbp)
movq -8(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
leave
ret
.Lf38_b3:
movabsq $28, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_none@PLT
movq %rax, -272(%rbp)
movq -8(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rax
leave
ret
.Lf38_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_get@PLT
movq %rax, -128(%rbp)
movabsq $5, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $5, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -144(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf38_b5
jmp .Lf38_b4
.Lf38_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $28, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_none@PLT
movq %rax, -88(%rbp)
movabsq $6, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf38_b3
jmp .Lf38_b2
.Lf38_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -296(%rbp), %rsi
leaq .Lroots_f38(%rip), %rdx
movq $37, %rcx
call evn_bind_roots@PLT
movq -288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -296(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_store@PLT
movq %rax, -64(%rbp)
jmp .Lf38_b1
.size f38, .-f38
.text
.p2align 4
.type f39, @function
f39:
pushq %rbp
movq %rsp, %rbp
subq $352, %rsp
movq %rdi, -304(%rbp)
movq %rsi, -312(%rbp)
movq %rdx, -320(%rbp)
movq %rcx, -328(%rbp)
movq %r8, -336(%rbp)
movq %r9, -344(%rbp)
leaq -296(%rbp), %rdi
movq $37, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf39_b0
.Lf39_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -344(%rbp), %rsi
leaq .Lroots_f39(%rip), %rdx
movq $43, %rcx
call evn_bind_roots@PLT
movq -304(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -312(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -320(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -328(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -336(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -344(%rbp), %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $26, %rax
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_object@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $5, %rax
movq %rax, -144(%rbp)
movq -128(%rbp), %rdi
movq -144(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_init@PLT
movq %rax, -152(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $4, %rax
movq %rax, -168(%rbp)
movq -128(%rbp), %rdi
movq -168(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_init@PLT
movq %rax, -176(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $3, %rax
movq %rax, -192(%rbp)
movq -128(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $2, %rax
movq %rax, -216(%rbp)
movq -128(%rbp), %rdi
movq -216(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_init@PLT
movq %rax, -224(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -128(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $0, %rax
movq %rax, -264(%rbp)
movq -128(%rbp), %rdi
movq -264(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_init@PLT
movq %rax, -272(%rbp)
movabsq $27, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.size f39, .-f39
.text
.p2align 4
.type f40, @function
f40:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -280(%rbp)
movq %rsi, -288(%rbp)
leaq -272(%rbp), %rdi
movq $34, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf40_b0
.Lf40_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_get@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movq -48(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
jmp .Lf40_b1
.Lf40_b5:
jmp .Lf40_b6
.Lf40_b4:
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_bool@PLT
movq %rax, -200(%rbp)
movq -8(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
leave
ret
.Lf40_b3:
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_bool@PLT
movq %rax, -264(%rbp)
movq -8(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rax
leave
ret
.Lf40_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_get@PLT
movq %rax, -136(%rbp)
movabsq $1, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movq -120(%rbp), %rdi
movq -152(%rbp), %rsi
call f43@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_unary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_truth@PLT
movq %rax, -184(%rbp)
cmpq $0, -184(%rbp)
je .Lf40_b5
jmp .Lf40_b4
.Lf40_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $19, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_none@PLT
movq %rax, -88(%rbp)
movabsq $6, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf40_b3
jmp .Lf40_b2
.Lf40_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f40(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -280(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -288(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_store@PLT
movq %rax, -64(%rbp)
jmp .Lf40_b1
.size f40, .-f40
.text
.p2align 4
.type f41, @function
f41:
pushq %rbp
movq %rsp, %rbp
subq $352, %rsp
movq %rdi, -344(%rbp)
movq %rsi, -352(%rbp)
leaq -336(%rbp), %rdi
movq $42, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf41_b0
.Lf41_b6:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_get@PLT
movq %rax, -296(%rbp)
movabsq $0, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movq -56(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_store@PLT
movq %rax, -320(%rbp)
jmp .Lf41_b1
.Lf41_b5:
jmp .Lf41_b6
.Lf41_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_get@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movq -216(%rbp), %rdi
movq -248(%rbp), %rsi
call f42@PLT
movq %rax, -256(%rbp)
movabsq $19, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -272(%rbp)
movq -48(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_store@PLT
movq %rax, -280(%rbp)
jmp .Lf41_b6
.Lf41_b3:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -8(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rax
leave
ret
.Lf41_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_get@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -144(%rbp), %rdi
movq -176(%rbp), %rsi
call f43@PLT
movq %rax, -184(%rbp)
movabsq $1, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_unary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf41_b5
jmp .Lf41_b4
.Lf41_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $19, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_none@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf41_b3
jmp .Lf41_b2
.Lf41_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -352(%rbp), %rsi
leaq .Lroots_f41(%rip), %rdx
movq $44, %rcx
call evn_bind_roots@PLT
movq -344(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -352(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -48(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_store@PLT
movq %rax, -72(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -56(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_store@PLT
movq %rax, -88(%rbp)
jmp .Lf41_b1
.size f41, .-f41
.text
.p2align 4
.type f42, @function
f42:
pushq %rbp
movq %rsp, %rbp
subq $160, %rsp
movq %rdi, -144(%rbp)
movq %rsi, -152(%rbp)
leaq -136(%rbp), %rdi
movq $17, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf42_b0
.Lf42_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -152(%rbp), %rsi
leaq .Lroots_f42(%rip), %rdx
movq $19, %rcx
call evn_bind_roots@PLT
movq -144(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -152(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $17, %rax
movq %rax, -48(%rbp)
movabsq $2, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_object@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $1, %rax
movq %rax, -80(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_init@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -64(%rbp), %rdi
movq -104(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_init@PLT
movq %rax, -112(%rbp)
movabsq $18, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -128(%rbp)
movq -8(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
leave
ret
.size f42, .-f42
.text
.p2align 4
.type f43, @function
f43:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -272(%rbp)
movq %rsi, -280(%rbp)
leaq -264(%rbp), %rdi
movq $33, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf43_b0
.Lf43_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_get@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movq -48(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -240(%rbp)
jmp .Lf43_b1
.Lf43_b5:
jmp .Lf43_b6
.Lf43_b4:
movabsq $1, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_bool@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.Lf43_b3:
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_bool@PLT
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf43_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_get@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $5, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -144(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf43_b5
jmp .Lf43_b4
.Lf43_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $19, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_none@PLT
movq %rax, -88(%rbp)
movabsq $6, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf43_b3
jmp .Lf43_b2
.Lf43_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -280(%rbp), %rsi
leaq .Lroots_f43(%rip), %rdx
movq $35, %rcx
call evn_bind_roots@PLT
movq -272(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -280(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_store@PLT
movq %rax, -64(%rbp)
jmp .Lf43_b1
.size f43, .-f43
.text
.p2align 4
.type f44, @function
f44:
pushq %rbp
movq %rsp, %rbp
subq $272, %rsp
movq %rdi, -272(%rbp)
leaq -264(%rbp), %rdi
movq $33, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf44_b0
.Lf44_b3:
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_unary@PLT
movq %rax, -128(%rbp)
movabsq $0, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $9, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_none@PLT
movq %rax, -160(%rbp)
movabsq $9, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_none@PLT
movq %rax, -176(%rbp)
movabsq $9, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_none@PLT
movq %rax, -192(%rbp)
leaq .Ldata_1(%rip), %rax
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_text@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_bool@PLT
movq %rax, -248(%rbp)
movq -128(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
movq -176(%rbp), %rcx
movq -192(%rbp), %r8
movq -216(%rbp), %r9
pushq -248(%rbp)
pushq -232(%rbp)
call f2@PLT
addq $16, %rsp
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf44_b2:
jmp .Lf44_b3
.Lf44_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_get@PLT
movq %rax, -88(%rbp)
movq -8(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
leave
ret
.Lf44_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -272(%rbp), %rsi
leaq .Lroots_f44(%rip), %rdx
movq $34, %rcx
call evn_bind_roots@PLT
movq -272(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $9, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_none@PLT
movq %rax, -48(%rbp)
movabsq $6, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -72(%rbp)
cmpq $0, -72(%rbp)
je .Lf44_b2
jmp .Lf44_b1
.size f44, .-f44
.text
.p2align 4
.type f45, @function
f45:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -272(%rbp)
movq %rsi, -280(%rbp)
movq %rdx, -288(%rbp)
leaq -264(%rbp), %rdi
movq $33, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf45_b0
.Lf45_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f45(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -272(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -280(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -288(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $35, %rax
movq %rax, -64(%rbp)
movabsq $5, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_object@PLT
movq %rax, -80(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $4, %rax
movq %rax, -96(%rbp)
movq -80(%rbp), %rdi
movq -96(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_init@PLT
movq %rax, -104(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $3, %rax
movq %rax, -120(%rbp)
movq -80(%rbp), %rdi
movq -120(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_init@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $7, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movabsq $2, %rax
movq %rax, -160(%rbp)
movq -80(%rbp), %rdi
movq -160(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_init@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $6, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $1, %rax
movq %rax, -200(%rbp)
movq -80(%rbp), %rdi
movq -200(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_init@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $5, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -80(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $4, %rax
movq %rax, -256(%rbp)
movq -80(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_fail@PLT
movq %rax, -264(%rbp)
ud2
.size f45, .-f45
.text
.p2align 4
.type f46, @function
f46:
pushq %rbp
movq %rsp, %rbp
subq $576, %rsp
movq %rdi, -560(%rbp)
movq %rsi, -568(%rbp)
leaq -552(%rbp), %rdi
movq $69, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf46_b0
.Lf46_b12:
jmp .Lf46_b4
.Lf46_b11:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movabsq $0, %rax
movq %rax, -512(%rbp)
movq -504(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_member@PLT
movq %rax, -520(%rbp)
movq -56(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_store@PLT
movq %rax, -528(%rbp)
jmp .Lf46_b12
.Lf46_b10:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movabsq $1, %rax
movq %rax, -480(%rbp)
movq -472(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_member@PLT
movq %rax, -488(%rbp)
movq -56(%rbp), %rdi
movq -488(%rbp), %rsi
call evn_store@PLT
movq %rax, -496(%rbp)
jmp .Lf46_b12
.Lf46_b9:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $3, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movabsq $7, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -424(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_truth@PLT
movq %rax, -464(%rbp)
cmpq $0, -464(%rbp)
je .Lf46_b11
jmp .Lf46_b10
.Lf46_b8:
jmp .Lf46_b9
.Lf46_b7:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $16, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -392(%rbp)
movq -8(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rax
leave
ret
.Lf46_b6:
movabsq $16, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
call evn_none@PLT
movq %rax, -544(%rbp)
movq -8(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rax
leave
ret
.Lf46_b5:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_get@PLT
movq %rax, -304(%rbp)
movq -64(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -312(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movabsq $4, %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_member@PLT
movq %rax, -336(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $5, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -336(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_binary@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_truth@PLT
movq %rax, -368(%rbp)
cmpq $0, -368(%rbp)
je .Lf46_b8
jmp .Lf46_b7
.Lf46_b4:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movabsq $16, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_none@PLT
movq %rax, -264(%rbp)
movabsq $6, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
movq -248(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_binary@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_truth@PLT
movq %rax, -288(%rbp)
cmpq $0, -288(%rbp)
je .Lf46_b6
jmp .Lf46_b5
.Lf46_b3:
jmp .Lf46_b4
.Lf46_b2:
jmp .Lf46_b3
.Lf46_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $4, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movq -56(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -240(%rbp)
jmp .Lf46_b3
.Lf46_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -568(%rbp), %rsi
leaq .Lroots_f46(%rip), %rdx
movq $71, %rcx
call evn_bind_roots@PLT
movq -560(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -568(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movq -72(%rbp), %rdi
movq -96(%rbp), %rsi
call f48@PLT
movq %rax, -104(%rbp)
movq -48(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -56(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_store@PLT
movq %rax, -144(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $3, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movabsq $0, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $7, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf46_b2
jmp .Lf46_b1
.size f46, .-f46
.text
.p2align 4
.type f47, @function
f47:
pushq %rbp
movq %rsp, %rbp
subq $560, %rsp
movq %rdi, -536(%rbp)
movq %rsi, -544(%rbp)
movq %rdx, -552(%rbp)
leaq -528(%rbp), %rdi
movq $66, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf47_b0
.Lf47_b3:
call evn_void@PLT
movq %rax, -520(%rbp)
movq -8(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rax
leave
ret
.Lf47_b2:
jmp .Lf47_b3
.Lf47_b1:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movabsq $16, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -488(%rbp)
movabsq $0, %rax
movq %rax, -496(%rbp)
movq -64(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -488(%rbp), %rsi
call evn_store@PLT
movq %rax, -512(%rbp)
jmp .Lf47_b3
.Lf47_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -552(%rbp), %rsi
leaq .Lroots_f47(%rip), %rdx
movq $69, %rcx
call evn_bind_roots@PLT
movq -536(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -544(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -552(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $7, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movq -80(%rbp), %rdi
movq -104(%rbp), %rsi
call f48@PLT
movq %rax, -112(%rbp)
movq -64(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -120(%rbp)
movabsq $14, %rax
movq %rax, -128(%rbp)
movabsq $5, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_object@PLT
movq %rax, -144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $4, %rax
movq %rax, -160(%rbp)
movq -144(%rbp), %rdi
movq -160(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_init@PLT
movq %rax, -168(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $1, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $3, %rax
movq %rax, -200(%rbp)
movq -144(%rbp), %rdi
movq -200(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_init@PLT
movq %rax, -208(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movabsq $2, %rax
movq %rax, -240(%rbp)
movq -144(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $4, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -144(%rbp), %rdi
movq -280(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_init@PLT
movq %rax, -288(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $0, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -144(%rbp), %rdi
movq -320(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_init@PLT
movq %rax, -328(%rbp)
movabsq $15, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -344(%rbp)
movq -72(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $16, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -376(%rbp)
movabsq $4, %rax
movq %rax, -384(%rbp)
movq -24(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_store@PLT
movq %rax, -400(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $3, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movabsq $10, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -424(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_truth@PLT
movq %rax, -464(%rbp)
cmpq $0, -464(%rbp)
je .Lf47_b2
jmp .Lf47_b1
.size f47, .-f47
.text
.p2align 4
.type f48, @function
f48:
pushq %rbp
movq %rsp, %rbp
subq $704, %rsp
movq %rdi, -688(%rbp)
movq %rsi, -696(%rbp)
leaq -680(%rbp), %rdi
movq $85, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf48_b0
.Lf48_b9:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $1, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member@PLT
movq %rax, -344(%rbp)
movq -48(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
jmp .Lf48_b6
.Lf48_b8:
jmp .Lf48_b9
.Lf48_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movq -8(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rax
leave
ret
.Lf48_b6:
jmp .Lf48_b1
.Lf48_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $3, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movabsq $5, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -256(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_truth@PLT
movq %rax, -304(%rbp)
cmpq $0, -304(%rbp)
je .Lf48_b8
jmp .Lf48_b7
.Lf48_b4:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $2, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movq -48(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
jmp .Lf48_b6
.Lf48_b3:
movabsq $29, %rax
movq %rax, -360(%rbp)
movabsq $8, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_object@PLT
movq %rax, -376(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $10, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movabsq $7, %rax
movq %rax, -408(%rbp)
movq -376(%rbp), %rdi
movq -408(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_init@PLT
movq %rax, -416(%rbp)
movabsq $1, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $6, %rax
movq %rax, -440(%rbp)
movq -376(%rbp), %rdi
movq -440(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_init@PLT
movq %rax, -448(%rbp)
movabsq $1, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -376(%rbp), %rdi
movq -472(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_init@PLT
movq %rax, -480(%rbp)
movabsq $31, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_none@PLT
movq %rax, -496(%rbp)
movabsq $4, %rax
movq %rax, -504(%rbp)
movq -376(%rbp), %rdi
movq -504(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_init@PLT
movq %rax, -512(%rbp)
movabsq $1, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_int@PLT
movq %rax, -528(%rbp)
movabsq $0, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_unary@PLT
movq %rax, -544(%rbp)
movabsq $3, %rax
movq %rax, -552(%rbp)
movq -376(%rbp), %rdi
movq -552(%rbp), %rsi
movq -544(%rbp), %rdx
call evn_init@PLT
movq %rax, -560(%rbp)
movabsq $31, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
call evn_none@PLT
movq %rax, -576(%rbp)
movabsq $2, %rax
movq %rax, -584(%rbp)
movq -376(%rbp), %rdi
movq -584(%rbp), %rsi
movq -576(%rbp), %rdx
call evn_init@PLT
movq %rax, -592(%rbp)
movabsq $31, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
call evn_none@PLT
movq %rax, -608(%rbp)
movabsq $1, %rax
movq %rax, -616(%rbp)
movq -376(%rbp), %rdi
movq -616(%rbp), %rsi
movq -608(%rbp), %rdx
call evn_init@PLT
movq %rax, -624(%rbp)
movabsq $16, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call evn_none@PLT
movq %rax, -640(%rbp)
movabsq $0, %rax
movq %rax, -648(%rbp)
movq -376(%rbp), %rdi
movq -648(%rbp), %rsi
movq -640(%rbp), %rdx
call evn_init@PLT
movq %rax, -656(%rbp)
movabsq $30, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -672(%rbp)
movq -8(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
leave
ret
.Lf48_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_get@PLT
movq %rax, -152(%rbp)
movq -56(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_store@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $3, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $7, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -168(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf48_b5
jmp .Lf48_b4
.Lf48_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $31, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_none@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf48_b3
jmp .Lf48_b2
.Lf48_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -696(%rbp), %rsi
leaq .Lroots_f48(%rip), %rdx
movq $87, %rcx
call evn_bind_roots@PLT
movq -688(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -696(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $7, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -48(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_store@PLT
movq %rax, -88(%rbp)
jmp .Lf48_b1
.size f48, .-f48
.text
.p2align 4
.type f49, @function
f49:
pushq %rbp
movq %rsp, %rbp
subq $176, %rsp
movq %rdi, -160(%rbp)
movq %rsi, -168(%rbp)
leaq -152(%rbp), %rdi
movq $19, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf49_b0
.Lf49_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -168(%rbp), %rsi
leaq .Lroots_f49(%rip), %rdx
movq $21, %rcx
call evn_bind_roots@PLT
movq -160(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -168(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movabsq $37, %rax
movq %rax, -56(%rbp)
movabsq $1, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_object@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -72(%rbp), %rdi
movq -88(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_init@PLT
movq %rax, -96(%rbp)
movabsq $38, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -112(%rbp)
movq -48(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -120(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call f50@PLT
movq %rax, -144(%rbp)
movq -8(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
leave
ret
.size f49, .-f49
.text
.p2align 4
.type f50, @function
f50:
pushq %rbp
movq %rsp, %rbp
subq $544, %rsp
movq %rdi, -536(%rbp)
movq %rsi, -544(%rbp)
leaq -528(%rbp), %rdi
movq $66, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf50_b0
.Lf50_b6:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -8(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rax
leave
ret
.Lf50_b5:
jmp .Lf50_b6
.Lf50_b4:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_get@PLT
movq %rax, -320(%rbp)
movq -72(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $4, %rax
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_member@PLT
movq %rax, -352(%rbp)
movabsq $0, %rax
movq %rax, -360(%rbp)
movq -24(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_store@PLT
movq %rax, -376(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $2, %rax
movq %rax, -392(%rbp)
movq -72(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_store@PLT
movq %rax, -408(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $1, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -424(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movabsq $1, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $1, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
movq -448(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_binary@PLT
movq %rax, -480(%rbp)
movq -416(%rbp), %rdi
movq -480(%rbp), %rsi
call f50@PLT
movq %rax, -488(%rbp)
movabsq $1, %rax
movq %rax, -496(%rbp)
movq -72(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -488(%rbp), %rsi
call evn_store@PLT
movq %rax, -512(%rbp)
jmp .Lf50_b6
.Lf50_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $2, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $3, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -48(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call f50@PLT
movq %rax, -216(%rbp)
movq -56(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_store@PLT
movq %rax, -224(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movq -64(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_store@PLT
movq %rax, -256(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $31, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_none@PLT
movq %rax, -280(%rbp)
movabsq $6, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -264(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_truth@PLT
movq %rax, -304(%rbp)
cmpq $0, -304(%rbp)
je .Lf50_b5
jmp .Lf50_b4
.Lf50_b2:
jmp .Lf50_b3
.Lf50_b1:
movabsq $31, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_none@PLT
movq %rax, -136(%rbp)
movq -8(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
leave
ret
.Lf50_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -544(%rbp), %rsi
leaq .Lroots_f50(%rip), %rdx
movq $68, %rcx
call evn_bind_roots@PLT
movq -536(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -544(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movabsq $5, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_binary@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_truth@PLT
movq %rax, -120(%rbp)
cmpq $0, -120(%rbp)
je .Lf50_b2
jmp .Lf50_b1
.size f50, .-f50
.text
.p2align 4
.type f51, @function
f51:
pushq %rbp
movq %rsp, %rbp
subq $128, %rsp
movq %rdi, -120(%rbp)
leaq -112(%rbp), %rdi
movq $14, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf51_b0
.Lf51_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -120(%rbp), %rsi
leaq .Lroots_f51(%rip), %rdx
movq $15, %rcx
call evn_bind_roots@PLT
movq -120(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movabsq $36, %rax
movq %rax, -32(%rbp)
movabsq $2, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_object@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $1, %rax
movq %rax, -64(%rbp)
movq -48(%rbp), %rdi
movq -64(%rbp), %rsi
movq -56(%rbp), %rdx
call evn_init@PLT
movq %rax, -72(%rbp)
movabsq $19, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_none@PLT
movq %rax, -88(%rbp)
movabsq $0, %rax
movq %rax, -96(%rbp)
movq -48(%rbp), %rdi
movq -96(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_init@PLT
movq %rax, -104(%rbp)
movq -8(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rax
leave
ret
.size f51, .-f51
.text
.p2align 4
.type f52, @function
f52:
pushq %rbp
movq %rsp, %rbp
subq $176, %rsp
movq %rdi, -168(%rbp)
movq %rsi, -176(%rbp)
leaq -160(%rbp), %rdi
movq $20, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf52_b0
.Lf52_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -176(%rbp), %rsi
leaq .Lroots_f52(%rip), %rdx
movq $22, %rcx
call evn_bind_roots@PLT
movq -168(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -176(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
leaq .Ldata_2(%rip), %rax
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_text@PLT
movq %rax, -80(%rbp)
movq -56(%rbp), %rdi
movq -80(%rbp), %rsi
call f53@PLT
movq %rax, -88(%rbp)
movq -48(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $22, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -120(%rbp)
movabsq $4, %rax
movq %rax, -128(%rbp)
movq -48(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -144(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movq -8(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
leave
ret
.size f52, .-f52
.text
.p2align 4
.type f53, @function
f53:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
movq %rdi, -304(%rbp)
movq %rsi, -312(%rbp)
leaq -296(%rbp), %rdi
movq $37, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf53_b0
.Lf53_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -312(%rbp), %rsi
leaq .Lroots_f53(%rip), %rdx
movq $39, %rcx
call evn_bind_roots@PLT
movq -304(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -312(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $20, %rax
movq %rax, -48(%rbp)
movabsq $7, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_object@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $6, %rax
movq %rax, -80(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_init@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $5, %rax
movq %rax, -104(%rbp)
movq -64(%rbp), %rdi
movq -104(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_init@PLT
movq %rax, -112(%rbp)
movabsq $22, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_none@PLT
movq %rax, -128(%rbp)
movabsq $4, %rax
movq %rax, -136(%rbp)
movq -64(%rbp), %rdi
movq -136(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_init@PLT
movq %rax, -144(%rbp)
movabsq $22, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_none@PLT
movq %rax, -160(%rbp)
movabsq $3, %rax
movq %rax, -168(%rbp)
movq -64(%rbp), %rdi
movq -168(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_init@PLT
movq %rax, -176(%rbp)
movabsq $0, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movabsq $2, %rax
movq %rax, -200(%rbp)
movq -64(%rbp), %rdi
movq -200(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_init@PLT
movq %rax, -208(%rbp)
movabsq $0, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_bool@PLT
movq %rax, -224(%rbp)
movabsq $1, %rax
movq %rax, -232(%rbp)
movq -64(%rbp), %rdi
movq -232(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_init@PLT
movq %rax, -240(%rbp)
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_bool@PLT
movq %rax, -256(%rbp)
movabsq $0, %rax
movq %rax, -264(%rbp)
movq -64(%rbp), %rdi
movq -264(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_init@PLT
movq %rax, -272(%rbp)
movabsq $21, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.size f53, .-f53
.text
.p2align 4
.type f54, @function
f54:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -280(%rbp)
movq %rsi, -288(%rbp)
leaq -272(%rbp), %rdi
movq $34, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf54_b0
.Lf54_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_get@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movq -48(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
jmp .Lf54_b1
.Lf54_b5:
jmp .Lf54_b6
.Lf54_b4:
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_bool@PLT
movq %rax, -200(%rbp)
movq -8(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
leave
ret
.Lf54_b3:
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_bool@PLT
movq %rax, -264(%rbp)
movq -8(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rax
leave
ret
.Lf54_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_get@PLT
movq %rax, -136(%rbp)
movabsq $1, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movq -120(%rbp), %rdi
movq -152(%rbp), %rsi
call f55@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_unary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_truth@PLT
movq %rax, -184(%rbp)
cmpq $0, -184(%rbp)
je .Lf54_b5
jmp .Lf54_b4
.Lf54_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $41, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_none@PLT
movq %rax, -88(%rbp)
movabsq $6, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf54_b3
jmp .Lf54_b2
.Lf54_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f54(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -280(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -288(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_store@PLT
movq %rax, -64(%rbp)
jmp .Lf54_b1
.size f54, .-f54
.text
.p2align 4
.type f55, @function
f55:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -272(%rbp)
movq %rsi, -280(%rbp)
leaq -264(%rbp), %rdi
movq $33, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf55_b0
.Lf55_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_get@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movq -48(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -240(%rbp)
jmp .Lf55_b1
.Lf55_b5:
jmp .Lf55_b6
.Lf55_b4:
movabsq $1, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_bool@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.Lf55_b3:
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_bool@PLT
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf55_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_get@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $5, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -144(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf55_b5
jmp .Lf55_b4
.Lf55_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $41, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_none@PLT
movq %rax, -88(%rbp)
movabsq $6, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf55_b3
jmp .Lf55_b2
.Lf55_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -280(%rbp), %rsi
leaq .Lroots_f55(%rip), %rdx
movq $35, %rcx
call evn_bind_roots@PLT
movq -272(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -280(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_store@PLT
movq %rax, -64(%rbp)
jmp .Lf55_b1
.size f55, .-f55
.text
.p2align 4
.type f56, @function
f56:
pushq %rbp
movq %rsp, %rbp
subq $256, %rsp
movq %rdi, -248(%rbp)
movq %rsi, -256(%rbp)
leaq -240(%rbp), %rdi
movq $30, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf56_b0
.Lf56_b4:
movq -8(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rax
leave
ret
.Lf56_b3:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $10, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $6, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
movq -200(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
movq %rax, -184(%rbp)
jmp .Lf56_b4
.Lf56_b2:
movq -128(%rbp), %rax
movq %rax, -184(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf56_b4
jmp .Lf56_b3
.Lf56_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $5, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $6, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rax
movq %rax, -128(%rbp)
jmp .Lf56_b2
.Lf56_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -256(%rbp), %rsi
leaq .Lroots_f56(%rip), %rdx
movq $32, %rcx
call evn_bind_roots@PLT
movq -248(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -256(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call f59@PLT
movq %rax, -72(%rbp)
movq -48(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -80(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movabsq $10, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf56_b2
jmp .Lf56_b1
.size f56, .-f56
.text
.p2align 4
.type f57, @function
f57:
pushq %rbp
movq %rsp, %rbp
subq $432, %rsp
movq %rdi, -416(%rbp)
movq %rsi, -424(%rbp)
movq %rdx, -432(%rbp)
leaq -408(%rbp), %rdi
movq $51, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf57_b0
.Lf57_b9:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_get@PLT
movq %rax, -360(%rbp)
movabsq $0, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_member@PLT
movq %rax, -376(%rbp)
movq -72(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_store@PLT
movq %rax, -384(%rbp)
jmp .Lf57_b4
.Lf57_b8:
jmp .Lf57_b9
.Lf57_b7:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_get@PLT
movq %rax, -320(%rbp)
movabsq $48, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -336(%rbp)
movq -8(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rax
leave
ret
.Lf57_b6:
jmp .Lf57_b3
.Lf57_b5:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_get@PLT
movq %rax, -256(%rbp)
movabsq $4, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member@PLT
movq %rax, -272(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $5, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -272(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_truth@PLT
movq %rax, -304(%rbp)
cmpq $0, -304(%rbp)
je .Lf57_b8
jmp .Lf57_b7
.Lf57_b4:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $48, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_none@PLT
movq %rax, -216(%rbp)
movabsq $6, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
movq -200(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_truth@PLT
movq %rax, -240(%rbp)
cmpq $0, -240(%rbp)
je .Lf57_b6
jmp .Lf57_b5
.Lf57_b3:
movabsq $48, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_none@PLT
movq %rax, -400(%rbp)
movq -8(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
leave
ret
.Lf57_b2:
jmp .Lf57_b3
.Lf57_b1:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_get@PLT
movq %rax, -168(%rbp)
movabsq $2, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movq -72(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -192(%rbp)
jmp .Lf57_b4
.Lf57_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -432(%rbp), %rsi
leaq .Lroots_f57(%rip), %rdx
movq $54, %rcx
call evn_bind_roots@PLT
movq -416(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -424(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -432(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call f60@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $45, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_none@PLT
movq %rax, -128(%rbp)
movabsq $6, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf57_b2
jmp .Lf57_b1
.size f57, .-f57
.text
.p2align 4
.type f58, @function
f58:
pushq %rbp
movq %rsp, %rbp
subq $224, %rsp
movq %rdi, -216(%rbp)
movq %rsi, -224(%rbp)
leaq -208(%rbp), %rdi
movq $26, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf58_b0
.Lf58_b3:
movabsq $1, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_unary@PLT
movq %rax, -200(%rbp)
movq -8(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
leave
ret
.Lf58_b2:
jmp .Lf58_b3
.Lf58_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_get@PLT
movq %rax, -144(%rbp)
movabsq $3, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -8(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rax
leave
ret
.Lf58_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -224(%rbp), %rsi
leaq .Lroots_f58(%rip), %rdx
movq $28, %rcx
call evn_bind_roots@PLT
movq -216(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -224(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call f60@PLT
movq %rax, -72(%rbp)
movq -48(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -80(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $45, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_none@PLT
movq %rax, -104(%rbp)
movabsq $6, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -128(%rbp)
cmpq $0, -128(%rbp)
je .Lf58_b2
jmp .Lf58_b1
.size f58, .-f58
.text
.p2align 4
.type f59, @function
f59:
pushq %rbp
movq %rsp, %rbp
subq $352, %rsp
movq %rdi, -336(%rbp)
movq %rsi, -344(%rbp)
leaq -328(%rbp), %rdi
movq $41, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf59_b0
.Lf59_b8:
movabsq $1, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movabsq $0, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_unary@PLT
movq %rax, -320(%rbp)
movq -8(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rax
leave
ret
.Lf59_b7:
jmp .Lf59_b8
.Lf59_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_get@PLT
movq %rax, -264(%rbp)
movabsq $5, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movq -8(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
leave
ret
.Lf59_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call f60@PLT
movq %rax, -192(%rbp)
movq -48(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_store@PLT
movq %rax, -200(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $45, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_none@PLT
movq %rax, -224(%rbp)
movabsq $6, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf59_b7
jmp .Lf59_b6
.Lf59_b4:
jmp .Lf59_b5
.Lf59_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -8(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rax
leave
ret
.Lf59_b2:
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf59_b4
jmp .Lf59_b3
.Lf59_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $5, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $8, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
movq %rax, -96(%rbp)
jmp .Lf59_b2
.Lf59_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -344(%rbp), %rsi
leaq .Lroots_f59(%rip), %rdx
movq $43, %rcx
call evn_bind_roots@PLT
movq -336(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -344(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $1, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $10, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -56(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf59_b2
jmp .Lf59_b1
.size f59, .-f59
.text
.p2align 4
.type f60, @function
f60:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
movq %rdi, -304(%rbp)
movq %rsi, -312(%rbp)
leaq -296(%rbp), %rdi
movq $37, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf60_b0
.Lf60_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_get@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movq -48(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_store@PLT
movq %rax, -272(%rbp)
jmp .Lf60_b1
.Lf60_b5:
jmp .Lf60_b6
.Lf60_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_get@PLT
movq %rax, -208(%rbp)
movabsq $45, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -224(%rbp)
movq -8(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
leave
ret
.Lf60_b3:
movabsq $45, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_none@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf60_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_get@PLT
movq %rax, -144(%rbp)
movabsq $6, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf60_b5
jmp .Lf60_b4
.Lf60_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $45, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_none@PLT
movq %rax, -104(%rbp)
movabsq $6, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -128(%rbp)
cmpq $0, -128(%rbp)
je .Lf60_b3
jmp .Lf60_b2
.Lf60_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -312(%rbp), %rsi
leaq .Lroots_f60(%rip), %rdx
movq $39, %rcx
call evn_bind_roots@PLT
movq -304(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -312(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $0, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -48(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -80(%rbp)
jmp .Lf60_b1
.size f60, .-f60
.text
.p2align 4
.type f61, @function
f61:
pushq %rbp
movq %rsp, %rbp
subq $192, %rsp
movq %rdi, -176(%rbp)
movq %rsi, -184(%rbp)
movq %rdx, -192(%rbp)
leaq -168(%rbp), %rdi
movq $21, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf61_b0
.Lf61_b3:
movabsq $1, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_bool@PLT
movq %rax, -160(%rbp)
movq -8(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rax
leave
ret
.Lf61_b2:
jmp .Lf61_b3
.Lf61_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
leaq .Ldata_3(%rip), %rax
movq %rax, -104(%rbp)
movabsq $9, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_text@PLT
movq %rax, -120(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -96(%rbp), %rdi
movq -120(%rbp), %rsi
movq -128(%rbp), %rdx
call f45@PLT
movq %rax, -136(%rbp)
movq -8(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
leave
ret
.Lf61_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -192(%rbp), %rsi
leaq .Lroots_f61(%rip), %rdx
movq $24, %rcx
call evn_bind_roots@PLT
movq -176(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -184(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -192(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $1, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_unary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf61_b2
jmp .Lf61_b1
.size f61, .-f61
.text
.p2align 4
.type f62, @function
f62:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
movq %rdi, -304(%rbp)
movq %rsi, -312(%rbp)
leaq -296(%rbp), %rdi
movq $37, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf62_b0
.Lf62_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_get@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movq -48(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_store@PLT
movq %rax, -272(%rbp)
jmp .Lf62_b1
.Lf62_b5:
jmp .Lf62_b6
.Lf62_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_get@PLT
movq %rax, -208(%rbp)
movabsq $57, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -224(%rbp)
movq -8(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
leave
ret
.Lf62_b3:
movabsq $57, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_none@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf62_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_get@PLT
movq %rax, -144(%rbp)
movabsq $5, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf62_b5
jmp .Lf62_b4
.Lf62_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $57, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_none@PLT
movq %rax, -104(%rbp)
movabsq $6, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -128(%rbp)
cmpq $0, -128(%rbp)
je .Lf62_b3
jmp .Lf62_b2
.Lf62_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -312(%rbp), %rsi
leaq .Lroots_f62(%rip), %rdx
movq $39, %rcx
call evn_bind_roots@PLT
movq -304(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -312(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $3, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -48(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -80(%rbp)
jmp .Lf62_b1
.size f62, .-f62
.text
.p2align 4
.type f63, @function
f63:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
movq %rdi, -304(%rbp)
movq %rsi, -312(%rbp)
leaq -296(%rbp), %rdi
movq $37, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf63_b0
.Lf63_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_get@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movq -48(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_store@PLT
movq %rax, -272(%rbp)
jmp .Lf63_b1
.Lf63_b5:
jmp .Lf63_b6
.Lf63_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_get@PLT
movq %rax, -208(%rbp)
movabsq $51, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -224(%rbp)
movq -8(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
leave
ret
.Lf63_b3:
movabsq $51, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_none@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf63_b2:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_get@PLT
movq %rax, -144(%rbp)
movabsq $6, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf63_b5
jmp .Lf63_b4
.Lf63_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $51, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_none@PLT
movq %rax, -104(%rbp)
movabsq $6, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -128(%rbp)
cmpq $0, -128(%rbp)
je .Lf63_b3
jmp .Lf63_b2
.Lf63_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -312(%rbp), %rsi
leaq .Lroots_f63(%rip), %rdx
movq $39, %rcx
call evn_bind_roots@PLT
movq -304(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -312(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $2, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -48(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -80(%rbp)
jmp .Lf63_b1
.size f63, .-f63
.text
.p2align 4
.type f64, @function
f64:
pushq %rbp
movq %rsp, %rbp
subq $144, %rsp
movq %rdi, -136(%rbp)
leaq -128(%rbp), %rdi
movq $16, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf64_b0
.Lf64_b2:
movq -8(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
leave
ret
.Lf64_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $4, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movabsq $8, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rax
movq %rax, -72(%rbp)
jmp .Lf64_b2
.Lf64_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -136(%rbp), %rsi
leaq .Lroots_f64(%rip), %rdx
movq $17, %rcx
call evn_bind_roots@PLT
movq -136(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $1, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $10, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -80(%rbp)
cmpq $0, -80(%rbp)
je .Lf64_b2
jmp .Lf64_b1
.size f64, .-f64
.text
.p2align 4
.type f65, @function
f65:
pushq %rbp
movq %rsp, %rbp
subq $544, %rsp
movq %rdi, -528(%rbp)
movq %rsi, -536(%rbp)
movq %rdx, -544(%rbp)
leaq -520(%rbp), %rdi
movq $65, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf65_b0
.Lf65_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -544(%rbp), %rsi
leaq .Lroots_f65(%rip), %rdx
movq $68, %rcx
call evn_bind_roots@PLT
movq -528(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -536(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -544(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $52, %rax
movq %rax, -64(%rbp)
movabsq $13, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_object@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $12, %rax
movq %rax, -96(%rbp)
movq -80(%rbp), %rdi
movq -96(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_init@PLT
movq %rax, -104(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $11, %rax
movq %rax, -120(%rbp)
movq -80(%rbp), %rdi
movq -120(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_init@PLT
movq %rax, -128(%rbp)
leaq .Ldata_4(%rip), %rax
movq %rax, -136(%rbp)
movabsq $0, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_text@PLT
movq %rax, -152(%rbp)
movabsq $10, %rax
movq %rax, -160(%rbp)
movq -80(%rbp), %rdi
movq -160(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_init@PLT
movq %rax, -168(%rbp)
movabsq $0, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $9, %rax
movq %rax, -192(%rbp)
movq -80(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movabsq $1, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_unary@PLT
movq %rax, -232(%rbp)
movabsq $8, %rax
movq %rax, -240(%rbp)
movq -80(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_bool@PLT
movq %rax, -264(%rbp)
movabsq $7, %rax
movq %rax, -272(%rbp)
movq -80(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $54, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_none@PLT
movq %rax, -296(%rbp)
movabsq $6, %rax
movq %rax, -304(%rbp)
movq -80(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $54, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_none@PLT
movq %rax, -328(%rbp)
movabsq $5, %rax
movq %rax, -336(%rbp)
movq -80(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movabsq $54, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_none@PLT
movq %rax, -360(%rbp)
movabsq $4, %rax
movq %rax, -368(%rbp)
movq -80(%rbp), %rdi
movq -368(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_init@PLT
movq %rax, -376(%rbp)
movabsq $54, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_none@PLT
movq %rax, -392(%rbp)
movabsq $3, %rax
movq %rax, -400(%rbp)
movq -80(%rbp), %rdi
movq -400(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_init@PLT
movq %rax, -408(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $2, %rax
movq %rax, -424(%rbp)
movq -80(%rbp), %rdi
movq -424(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_init@PLT
movq %rax, -432(%rbp)
movabsq $41, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_none@PLT
movq %rax, -448(%rbp)
movabsq $1, %rax
movq %rax, -456(%rbp)
movq -80(%rbp), %rdi
movq -456(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_init@PLT
movq %rax, -464(%rbp)
movabsq $0, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_bool@PLT
movq %rax, -480(%rbp)
movabsq $0, %rax
movq %rax, -488(%rbp)
movq -80(%rbp), %rdi
movq -488(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_init@PLT
movq %rax, -496(%rbp)
movabsq $53, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -512(%rbp)
movq -8(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rax
leave
ret
.size f65, .-f65
.text
.p2align 4
.type erist_entry, @function
erist_entry:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -24(%rbp), %rdi
movq $3, %rcx
xorl %eax, %eax
rep stosq
jmp .Lerist_entry_b0
.Lerist_entry_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -24(%rbp), %rsi
leaq .Lroots_erist_entry(%rip), %rdx
movq $3, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
movq -8(%rbp), %rdi
movq -16(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rax
leave
ret
.size erist_entry, .-erist_entry
.section .rodata
.Lroots_f0:
.byte 1,1,1,1,0,1,2,1,0,1,2,1,2,1,2,1,1,1,0,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f1:
.byte 1,1,2,0,2,1,0,2,1,2,1,2,2,0,1,1,2,1,2,1,2,3,1,2,1,2,1,2,1,2,1,2,1,2,1,6,0
.section .rodata
.Ldata_0:
.byte 0
.section .rodata
.Lroots_f2:
.byte 1,1,1,1,1,1,1,1,1,1,2,0,2,1,0,2,1,0,2,1,0,2,1,2,0,2,1,0,2,1,0,2,1,0,2,1,0,2,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f3:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f4:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f5:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f6:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f7:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f8:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f9:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f10:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f11:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f12:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f13:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f14:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f15:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f16:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f17:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f18:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f19:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f20:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f21:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f22:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f23:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f24:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f25:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f26:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f27:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f28:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f29:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f30:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f31:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f32:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f33:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f34:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f35:
.byte 1,1,2,6,0
.section .rodata
.Lroots_f36:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f37:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f38:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f39:
.byte 1,1,1,1,1,1,1,1,2,0,2,1,0,2,1,0,2,1,0,2,1,0,2,1,0,2,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f40:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f41:
.byte 1,1,1,1,0,1,2,1,1,0,1,2,1,1,2,1,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,0,1,0,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f42:
.byte 1,1,1,1,2,0,2,1,0,2,1,1,2,2,1,1,1,1,6,0
.section .rodata
.Lroots_f43:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f44:
.byte 1,1,1,1,2,1,2,1,2,3,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Ldata_1:
.byte 0
.section .rodata
.Lroots_f45:
.byte 1,1,1,0,2,0,2,1,2,1,0,2,1,2,1,0,2,1,2,1,0,2,1,0,2,1,1,2,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f46:
.byte 1,1,1,1,2,0,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,2,1,2,1,1,2,1,0,1,1,2,1,2,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,0,1,2,1,0,1,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f47:
.byte 1,1,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,0,1,2,1,2,1,0,1,2,0,2,1,2,1,0,2,1,2,1,0,2,1,2,1,0,2,1,2,1,0,2,1,1,2,2,0,1,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f48:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,1,1,2,2,0,1,2,1,1,1,2,1,2,1,2,1,1,0,1,2,1,2,1,2,1,2,1,1,0,1,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f49:
.byte 1,1,1,1,1,1,0,1,2,0,2,1,1,2,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f50:
.byte 1,1,1,1,0,1,2,1,1,2,1,2,1,2,1,1,1,0,1,2,1,0,1,2,1,2,1,0,1,1,2,1,2,1,2,1,0,1,2,1,0,1,1,1,0,1,2,1,2,1,1,1,2,2,1,2,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f51:
.byte 1,1,0,2,1,2,0,2,1,1,2,2,1,1,6,0
.section .rodata
.Lroots_f52:
.byte 1,1,1,1,0,1,2,1,2,1,0,1,1,2,3,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_2:
.byte 0
.section .rodata
.Lroots_f53:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,1,2,2,1,1,1,1,6,0
.section .rodata
.Lroots_f54:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f55:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f56:
.byte 1,1,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,0,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f57:
.byte 1,1,1,1,1,2,0,1,2,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f58:
.byte 1,1,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f59:
.byte 1,1,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,1,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f60:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f61:
.byte 1,1,1,1,1,2,1,1,1,1,2,3,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_3:
.byte 105,114,45,118,101,114,105,102,121,0
.section .rodata
.Lroots_f62:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f63:
.byte 1,1,1,1,2,0,1,2,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f64:
.byte 1,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f65:
.byte 1,1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,0,2,1,1,2,2,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_4:
.byte 0
.section .rodata
.Lroots_erist_entry:
.byte 1,1,6,0
.section .data.rel.ro
.p2align 3
.globl ev_types
ev_types:
.long 0,0
.quad .Ltype_name_0
.quad 0
.quad 0
.long 1,0
.quad .Ltype_name_1
.quad 0
.quad 0
.long 2,0
.quad .Ltype_name_2
.quad 0
.quad 0
.long 3,0
.quad .Ltype_name_3
.quad 0
.quad 0
.long 4,0
.quad .Ltype_name_4
.quad 0
.quad 0
.long 5,0
.quad .Ltype_name_5
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_6
.quad 2
.quad .Ltype_fields_6
.long 6,-1
.quad .Ltype_name_7
.quad 9
.quad .Ltype_fields_7
.long 9,7
.quad .Ltype_name_8
.quad 0
.quad 0
.long 8,8
.quad .Ltype_name_9
.quad 0
.quad 0
.long 9,6
.quad .Ltype_name_10
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_11
.quad 12
.quad .Ltype_fields_11
.long 9,11
.quad .Ltype_name_12
.quad 0
.quad 0
.long 8,12
.quad .Ltype_name_13
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_14
.quad 5
.quad .Ltype_fields_14
.long 9,14
.quad .Ltype_name_15
.quad 0
.quad 0
.long 8,15
.quad .Ltype_name_16
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_17
.quad 2
.quad .Ltype_fields_17
.long 9,17
.quad .Ltype_name_18
.quad 0
.quad 0
.long 8,18
.quad .Ltype_name_19
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_20
.quad 7
.quad .Ltype_fields_20
.long 9,20
.quad .Ltype_name_21
.quad 0
.quad 0
.long 8,21
.quad .Ltype_name_22
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_23
.quad 10
.quad .Ltype_fields_23
.long 9,23
.quad .Ltype_name_24
.quad 0
.quad 0
.long 8,24
.quad .Ltype_name_25
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_26
.quad 6
.quad .Ltype_fields_26
.long 9,26
.quad .Ltype_name_27
.quad 0
.quad 0
.long 8,27
.quad .Ltype_name_28
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_29
.quad 8
.quad .Ltype_fields_29
.long 9,29
.quad .Ltype_name_30
.quad 0
.quad 0
.long 8,30
.quad .Ltype_name_31
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_32
.quad 4
.quad .Ltype_fields_32
.long 9,32
.quad .Ltype_name_33
.quad 0
.quad 0
.long 8,33
.quad .Ltype_name_34
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_35
.quad 5
.quad .Ltype_fields_35
.long 6,-1
.quad .Ltype_name_36
.quad 2
.quad .Ltype_fields_36
.long 6,-1
.quad .Ltype_name_37
.quad 1
.quad .Ltype_fields_37
.long 9,37
.quad .Ltype_name_38
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_39
.quad 2
.quad .Ltype_fields_39
.long 9,39
.quad .Ltype_name_40
.quad 0
.quad 0
.long 8,40
.quad .Ltype_name_41
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_42
.quad 3
.quad .Ltype_fields_42
.long 6,-1
.quad .Ltype_name_43
.quad 7
.quad .Ltype_fields_43
.long 9,43
.quad .Ltype_name_44
.quad 0
.quad 0
.long 8,44
.quad .Ltype_name_45
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_46
.quad 5
.quad .Ltype_fields_46
.long 9,46
.quad .Ltype_name_47
.quad 0
.quad 0
.long 8,47
.quad .Ltype_name_48
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_49
.quad 7
.quad .Ltype_fields_49
.long 9,49
.quad .Ltype_name_50
.quad 0
.quad 0
.long 8,50
.quad .Ltype_name_51
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_52
.quad 13
.quad .Ltype_fields_52
.long 9,52
.quad .Ltype_name_53
.quad 0
.quad 0
.long 8,53
.quad .Ltype_name_54
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_55
.quad 6
.quad .Ltype_fields_55
.long 9,55
.quad .Ltype_name_56
.quad 0
.quad 0
.long 8,56
.quad .Ltype_name_57
.quad 0
.quad 0
.long 9,42
.quad .Ltype_name_58
.quad 0
.quad 0
.globl ev_types_end
ev_types_end:
.Ltype_name_0:
.byte 0
.Ltype_name_1:
.byte 0
.Ltype_name_2:
.byte 0
.Ltype_name_3:
.byte 0
.Ltype_name_4:
.byte 0
.Ltype_name_5:
.byte 0
.Ltype_name_6:
.byte 99,111,109,112,105,108,101,114,46,97,115,116,46,67,104,97,105,110,0
.p2align 2
.Ltype_fields_6:
.long 8
.long 9
.Ltype_name_7:
.byte 99,111,109,112,105,108,101,114,46,97,115,116,46,78,111,100,101,0
.p2align 2
.Ltype_fields_7:
.long 3
.long 1
.long 4
.long 9
.long 9
.long 9
.long 9
.long 1
.long 1
.Ltype_name_8:
.byte 0
.Ltype_name_9:
.byte 0
.Ltype_name_10:
.byte 0
.Ltype_name_11:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,77,111,100,117,108,101,0
.p2align 2
.Ltype_fields_11:
.long 13
.long 3
.long 3
.long 1
.long 16
.long 25
.long 34
.long 31
.long 31
.long 8
.long 4
.long 4
.Ltype_name_12:
.byte 0
.Ltype_name_13:
.byte 0
.Ltype_name_14:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,70,97,99,116,0
.p2align 2
.Ltype_fields_14:
.long 16
.long 16
.long 19
.long 21
.long 8
.Ltype_name_15:
.byte 0
.Ltype_name_16:
.byte 0
.Ltype_name_17:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,78,97,109,101,0
.p2align 2
.Ltype_fields_17:
.long 19
.long 4
.Ltype_name_18:
.byte 0
.Ltype_name_19:
.byte 0
.Ltype_name_20:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,84,121,112,101,0
.p2align 2
.Ltype_fields_20:
.long 3
.long 3
.long 1
.long 22
.long 22
.long 4
.long 1
.Ltype_name_21:
.byte 0
.Ltype_name_22:
.byte 0
.Ltype_name_23:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,68,101,99,108,97,114,97,116,105,111,110,0
.p2align 2
.Ltype_fields_23:
.long 25
.long 1
.long 19
.long 3
.long 21
.long 28
.long 28
.long 21
.long 12
.long 8
.Ltype_name_24:
.byte 0
.Ltype_name_25:
.byte 0
.Ltype_name_26:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,66,105,110,100,105,110,103,0
.p2align 2
.Ltype_fields_26:
.long 28
.long 30
.long 3
.long 3
.long 21
.long 4
.Ltype_name_27:
.byte 0
.Ltype_name_28:
.byte 0
.Ltype_name_29:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,76,111,99,97,116,105,111,110,0
.p2align 2
.Ltype_fields_29:
.long 16
.long 31
.long 31
.long 1
.long 31
.long 1
.long 1
.long 4
.Ltype_name_30:
.byte 0
.Ltype_name_31:
.byte 0
.Ltype_name_32:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,73,109,112,111,114,116,0
.p2align 2
.Ltype_fields_32:
.long 34
.long 13
.long 4
.long 4
.Ltype_name_33:
.byte 0
.Ltype_name_34:
.byte 0
.Ltype_name_35:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,83,101,109,97,110,116,105,99,69,114,114,111,114,0
.p2align 2
.Ltype_fields_35:
.long 1
.long 1
.long 4
.long 4
.long 4
.Ltype_name_36:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,82,101,115,117,108,116,0
.p2align 2
.Ltype_fields_36:
.long 19
.long 21
.Ltype_name_37:
.byte 99,111,109,112,105,108,101,114,46,115,101,109,97,110,116,105,99,95,109,111,100,101,108,46,76,111,99,97,116,105,111,110,67,117,114,115,111,114,0
.p2align 2
.Ltype_fields_37:
.long 31
.Ltype_name_38:
.byte 0
.Ltype_name_39:
.byte 99,111,109,112,105,108,101,114,46,116,121,112,101,100,95,105,114,46,70,97,105,108,117,114,101,0
.p2align 2
.Ltype_fields_39:
.long 41
.long 1
.Ltype_name_40:
.byte 0
.Ltype_name_41:
.byte 0
.Ltype_name_42:
.byte 99,111,109,112,105,108,101,114,46,116,121,112,101,100,95,105,114,46,80,114,111,103,114,97,109,0
.p2align 2
.Ltype_fields_42:
.long 45
.long 50
.long 51
.Ltype_name_43:
.byte 99,111,109,112,105,108,101,114,46,116,121,112,101,100,95,105,114,46,84,121,112,101,0
.p2align 2
.Ltype_fields_43:
.long 45
.long 3
.long 48
.long 1
.long 4
.long 1
.long 1
.Ltype_name_44:
.byte 0
.Ltype_name_45:
.byte 0
.Ltype_name_46:
.byte 99,111,109,112,105,108,101,114,46,116,121,112,101,100,95,105,114,46,70,105,101,108,100,0
.p2align 2
.Ltype_fields_46:
.long 48
.long 3
.long 1
.long 4
.long 1
.Ltype_name_47:
.byte 0
.Ltype_name_48:
.byte 0
.Ltype_name_49:
.byte 99,111,109,112,105,108,101,114,46,116,121,112,101,100,95,105,114,46,70,117,110,99,116,105,111,110,0
.p2align 2
.Ltype_fields_49:
.long 51
.long 41
.long 53
.long 57
.long 1
.long 4
.long 1
.Ltype_name_50:
.byte 0
.Ltype_name_51:
.byte 0
.Ltype_name_52:
.byte 99,111,109,112,105,108,101,114,46,116,121,112,101,100,95,105,114,46,78,111,100,101,0
.p2align 2
.Ltype_fields_52:
.long 3
.long 41
.long 30
.long 54
.long 54
.long 54
.long 54
.long 3
.long 1
.long 1
.long 4
.long 1
.long 1
.Ltype_name_53:
.byte 0
.Ltype_name_54:
.byte 0
.Ltype_name_55:
.byte 99,111,109,112,105,108,101,114,46,116,121,112,101,100,95,105,114,46,76,111,99,97,108,0
.p2align 2
.Ltype_fields_55:
.long 57
.long 3
.long 3
.long 1
.long 4
.long 1
.Ltype_name_56:
.byte 0
.Ltype_name_57:
.byte 0
.Ltype_name_58:
.byte 0
.section .note.GNU-stack,"",@progbits

