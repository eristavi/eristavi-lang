"""Measure an independent plain process; never include observer RSS."""
import json,resource,subprocess,sys
from pathlib import Path
binary,root,out=map(Path,sys.argv[1:])
out.mkdir(parents=True,exist_ok=True)
with (out/'plain.s').open('wb') as f,(out/'plain.stderr').open('wb') as e:
    p=subprocess.run([str(binary.resolve()),'emit-asm',str(root.resolve()/'src/compiler/typed_ir.eri'),
                      '--source-root',str(root.resolve()/'src')],stdout=f,stderr=e,timeout=90)
assert p.returncode==0 and not (out/'plain.stderr').read_bytes()
(out/'rss.json').write_text(json.dumps({'maximum_resident_kib':resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
                                      'returncode':p.returncode,'scope':'whole plain compiler process, Linux KiB; not verifier-attributed'},indent=2)+'\n')
