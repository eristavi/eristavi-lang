"""Prepare/review U1a policy data. Does not implement or execute a compiler pass."""
import hashlib,json
from pathlib import Path

root=Path(__file__).resolve().parents[1]
u0=root/'uir-u0'
sources=json.loads((u0/'fixtures.json').read_text())+json.loads((u0/'graph-fixtures.json').read_text())
MiB=1024*1024
policy={
 'schema':'eristavi-uir-budget-policy-1',
 'profile':'uir-u1a-development-1',
 'status':'Selected initial engineering policy on 2026-10-29 under instruction to finalize U1a budgets; not candidate-validated or a measured optimum.',
 'scope':'UIR compiler-owned state only; no change to the current production compiler, source semantics, or public CLI.',
 'baseline':{'commit':'8af0ffe3350c737550c3ab0e6c3fa89f60f6f091',
             'report_library_file_id':'libfile_b3bae627ea0c8191bd2e500fdeed22e8',
             'evidence_library_file_id':'libfile_0e76f5ba02948191aeb8219bbcdb5d26'},
 'memory':{
   'unit':'bytes of owned backing capacity, including owned metadata and overlapping old/new allocations; allocator/runtime overhead reported separately unless charged by backing allocator',
   'function_peak_capacity_bytes':64*MiB,
   'function_allocation_traffic_bytes':256*MiB,
   'shared_metadata_peak_capacity_bytes':128*MiB,
   'request_peak_capacity_bytes':512*MiB,
   'request_allocation_traffic_bytes':2*1024*MiB,
   'qualification_function_peak_capacity_bytes':8*MiB,
   'qualification_function_allocation_traffic_bytes':64*MiB,
   'qualification_scope':'one function lifecycle: construction, promotion, and eight complete verifier calls; account all coexisting buffers and reuse scratch explicitly',
   'fresh_allocation_traffic':'sum of successfully acquired backing capacity; reserve prospective traffic before allocation and commit it only on success; growth charges the full new allocation; reuse is not a fresh allocation; traffic never decreases',
   'excluded_but_reported':['source snapshots and AST/semantic state owned by earlier stages','generated machine-code/backend storage','allocator reserved/free-pool bytes not owned by UIR','runtime GC retention and process/interpreter overhead'],
   'ownership_assignment':'function records/pools/scratch must be charged to their function owner; shared metadata is genuinely shared type/signature/constant/location data; moving function storage to shared ownership cannot evade its qualification gate',
   'rss_is_not_capacity':True},
 'count_ceiling_scope':'all stored function slots/entries, including terminators and un-compacted dead slots; limits are independent ceilings and need not all fit simultaneously in the byte/work limits',
 'input_count_ceiling_per_function':{
   'blocks':65536,'edges':262144,'instructions':1048576,'values':1048576,
   'cells':65536,'inserted_merge_parameters':1048576,'total_edge_arguments':4194304},
 'work':{
   'unit':'one entry visit/comparison/hash probe; bulk data charge ceil(bytes/64); exact consumption and prepaid unused credits reported separately',
   'verification_visit_limit_per_call':16777216,
   'promotion_visit_limit_per_function':33554432,
   'construction_visit_limit_per_function':16777216,
   'request_visit_limit':268435456,
   'structural_scan_multiplier':32,
   'dominator_visit_multiplier':128,
   'dominator_formula':'128*(B+E+1)*max(1,ceil(log2(max(2,B))))',
   'structural_formula':'32*(R+1), where R includes every encoded record, attribute, operand, result, edge argument, case and origin link checked in that verification scope',
   'promotion_unique_live_states_formula':'C*B',
   'promotion_live_predecessor_visits_formula':'C*E',
   'promotion_unique_placement_states_formula':'C*B',
   'promotion_frontier_entry_visits_formula':'C*D; D is the once-built CFG dominance-frontier entry count',
   'inserted_merge_parameters_formula':'C*B',
   'inserted_merge_arguments_formula':'C*E',
   'all_limits_apply':'A phase must satisfy its global visit limit, its applicable component formula limits, byte limits, and count ceilings; satisfying one does not waive another.'},
 'cancellation':{'maximum_visits_between_checks':1024,'maximum_bulk_bytes_between_checks':65536,
                 'check_at':['stage entry/exit','before allocation/growth','before publishing a verified result'],
                 'meaning':'bounded compiler work between polls; no promise of fixed wall-time latency in a blocking allocator or host syscall'},
 'qualification':{
   'canonical_remaining_cells':0,'fixture_sizes':[8,32,128],
   'candidate_ir_passes_implemented':False,'matched_adapters_implemented':False,
   'ordinary_verification_scope':'construction validation and canonical verification remain mandatory; eight verifier calls are the explicit stress workload, not an added production pipeline requirement',
   'cpu_watchdog_seconds_per_worker':60,
   'wall_watchdog_seconds_per_worker':120,
   'watchdogs_are_not_performance_claims':True,
   'comparative_timing':'informational for U1a; no 5-percent or other historical-median speed gate; same-host paired matched work and unchanged settings required for any comparison',
   'pairing':'five fresh-process baseline/candidate pairs per matched profile; reverse order between pairs; serialize benchmark jobs',
   'canonical_count_checkpoint':'after promotion and trivial-parameter cleanup; before optional constant/CFG transformations',
   'float_and_malformed_ir_correctness':'required before U1a acceptance; not established by U0 integer fixture timings'},
 'counter_api':[
   {'name':'reserveCapacity','arguments':['owner','backingCapacityBytes','reason'],'effect':'admit prospective live capacity and traffic against all ancestor budgets before allocation; include old/new overlap; track pending reservations separately'},
   {'name':'commitReservation','arguments':['reservation','allocationHandle'],'effect':'convert pending reservation into live capacity and successful allocation traffic'},
   {'name':'cancelReservation','arguments':['reservation'],'effect':'undo failed pending reservation; no successful allocation traffic is added and work already consumed is not undone'},
   {'name':'releaseCapacity','arguments':['allocationHandle'],'effect':'drop live ownership only after the backing storage is released or exclusively transferred; traffic never decreases'},
   {'name':'transferCapacity','arguments':['allocationHandle','destinationOwner'],'effect':'admit destination branch before atomic ownership transfer; common-ancestor capacity is unchanged and transfer adds no fresh allocation traffic'},
   {'name':'chargeWork','arguments':['phase','category','count'],'effect':'admit a bounded work batch before execution; no per-visit allocation or virtual dispatch'},
   {'name':'pollCancellation','arguments':['attempt'],'effect':'stop unfinished attempt; no partial/stale-ready publication'},
   {'name':'snapshotCounters','arguments':['owner'],'effect':'capture committed live/peak, pending/reserved peak, successful traffic, visit usage, unused prepaid credits and exhausted-limit identity'}],
 'failure':{'budget_exhaustion':'structured compiler resource-limit outcome, not a source type error or generated-program trap',
            'invalid_input':'structural/type failures remain invalid-IR outcomes; exceeded valid admission limits are resource-limit outcomes',
            'publication':'failed/cancelled attempt produces no ready UIR, verifier stamp, or committed artifact',
            'fallback':'no silent mutable-register fallback and no bypass of verification',
            'counters':'checked wide arithmetic; compare products against quota with division before multiplication when required',
            'retry':'function attempts are fresh; request-level consumed work/traffic survive retries; no automatic retry with enlarged quotas or cached ready result from failure',
            'overrides':'explicit internal request-profile values, recorded before execution; no new source syntax or CLI flag is selected'},
 'matched_stress_plans':[
   {'name':f'initialized_diamond_chain_{width}','width':width,'following_chain_blocks':16,
    'verifier_calls':8,'initial_values':'x[i]=i for every i in [0,width)',
    'branch':'input flag; true updates every x[i] by checked +1; false by checked +2',
    'observation':'return checked sum of all locals; evaluate both flag choices',
    'expected_results':[width*(width-1)//2+width,width*(width-1)//2+2*width],
    'inserted_merge_parameters':width,'inserted_merge_arguments':2*width,
    'adapters_implemented':False,
    'historical_native_probe_is_not_a_timing_pair':True}
   for width in [128,512,2000]],
 'fixtures':[]}
for f in sources:
 name=f['name'];family=f['family'];n=f['size']
 p,g={'diamond':(n,2*n),'loop':(n+1,2*(n+1)),
      'calls':(0,0),'cfg':(n,2*n)}[family]
 data=(u0/'fixtures'/f['file']).read_bytes()
 assert hashlib.sha256(data).hexdigest()==f['source_sha256']
 policy['fixtures'].append({
   'name':name,'family':family,'size':n,'source_sha256':f['source_sha256'],
   'expected_stdout':f['expected'],'arithmetic':'checked signed i64',
   'candidate_recipe':{'diamond':'N initialized mutable locals; branch on input flag; add 1 or 2; return sum; observe both flag choices',
                       'loop':'N initialized mutable locals plus index; eight iterations; add index to each local; increment index; return sum',
                       'calls':'one initialized mutable accumulator; N calls to step(x)=checked(x+1); observe accumulator',
                       'cfg':'one initialized mutable local; N sequential diamonds controlled by the same input flag; add 1 or 2; observe both flag choices'}[family],
   'remaining_cells':0,'inserted_merge_parameters':p,'inserted_merge_arguments':g,
   'function_parameters_and_call_arguments_excluded_from_merge_counts':True})
assert len(policy['fixtures'])==12
assert policy['memory']['qualification_function_peak_capacity_bytes']<=policy['memory']['function_peak_capacity_bytes']
assert policy['memory']['function_peak_capacity_bytes']<=policy['memory']['request_peak_capacity_bytes']
out=root/'Eristavi-UIR-U1a-Budgets-2026-10-29.json'
out.write_text(json.dumps(policy,indent=2,sort_keys=True)+'\n')
worksheet=[]
for f in policy['fixtures']:
 legacy=next(r for r in json.loads((u0/('graph-summary.json' if f['family']=='cfg' else 'bootstrap-summary.json')).read_text()) if r['fixture']==f['name'])
 B=legacy['structure']['blocks'];E=legacy['structure'].get('edges',0)
 # Context for policy review only: candidate block/edge counts must be measured independently.
 worksheet.append({'fixture':f['name'],'legacy_blocks':B,'legacy_edges':E,
                   'expected_merge_parameters':f['inserted_merge_parameters'],
                   'expected_merge_arguments':f['inserted_merge_arguments'],
                   'legacy_topology_dominator_visit_policy':128*(B+E+1)*max(1,(max(2,B)-1).bit_length())})
(root/'uir-u1a-budget/worksheet.json').write_text(json.dumps(worksheet,indent=2)+'\n')
print(json.dumps({'policy':str(out),'bytes':out.stat().st_size,'fixture_count':len(worksheet),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'candidate_passes_executed':False},indent=2))
