.globl erist_entry
.text
.p2align 4
.type f0, @function
f0:
pushq %rbp
movq %rsp, %rbp
subq $480, %rsp
movq %rdi, -472(%rbp)
leaq -464(%rbp), %rdi
movq $58, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf0_b0
.Lf0_b8:
movabsq $0, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movabsq $6, %rax
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movabsq $0, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $5, %rax
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -24(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_store@PLT
movq %rax, -408(%rbp)
movabsq $3, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movabsq $10, %rax
movq %rax, -432(%rbp)
movq -24(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_store@PLT
movq %rax, -448(%rbp)
call evn_void@PLT
movq %rax, -456(%rbp)
movq -8(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
leave
ret
.Lf0_b7:
jmp .Lf0_b8
.Lf0_b6:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_get@PLT
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call f1@PLT
movq %rax, -288(%rbp)
jmp .Lf0_b8
.Lf0_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $12, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movq -32(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $8, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_none@PLT
movq %rax, -232(%rbp)
movabsq $6, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_truth@PLT
movq %rax, -256(%rbp)
cmpq $0, -256(%rbp)
je .Lf0_b7
jmp .Lf0_b6
.Lf0_b4:
jmp .Lf0_b5
.Lf0_b3:
call f33@PLT
movq %rax, -176(%rbp)
jmp .Lf0_b5
.Lf0_b2:
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -168(%rbp)
cmpq $0, -168(%rbp)
je .Lf0_b4
jmp .Lf0_b3
.Lf0_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $12, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $8, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_none@PLT
movq %rax, -144(%rbp)
movabsq $5, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
movq %rax, -96(%rbp)
jmp .Lf0_b2
.Lf0_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -472(%rbp), %rsi
leaq .Lroots_f0(%rip), %rdx
movq $59, %rcx
call evn_bind_roots@PLT
movq -472(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $10, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_member@PLT
movq %rax, -56(%rbp)
movabsq $3, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $5, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -56(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf0_b1
jmp .Lf0_b2
.size f0, .-f0
.text
.p2align 4
.type f1, @function
f1:
pushq %rbp
movq %rsp, %rbp
subq $576, %rsp
movq %rdi, -568(%rbp)
movq %rsi, -576(%rbp)
leaq -560(%rbp), %rdi
movq $70, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf1_b0
.Lf1_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $6, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_member@PLT
movq %rax, -304(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movabsq $6, %rax
movq %rax, -320(%rbp)
movq -312(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_member@PLT
movq %rax, -328(%rbp)
movabsq $1, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -304(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movabsq $6, %rax
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -368(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $5, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $5, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movabsq $1, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -392(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_binary@PLT
movq %rax, -432(%rbp)
movabsq $5, %rax
movq %rax, -440(%rbp)
movq -24(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_store@PLT
movq %rax, -456(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $1, %rax
movq %rax, -472(%rbp)
movq -464(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_member@PLT
movq %rax, -480(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $1, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movabsq $1, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
movq -480(%rbp), %rsi
movq -504(%rbp), %rdx
call evn_binary@PLT
movq %rax, -520(%rbp)
movabsq $1, %rax
movq %rax, -528(%rbp)
movq -24(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_store@PLT
movq %rax, -544(%rbp)
call evn_void@PLT
movq %rax, -552(%rbp)
movq -8(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rax
leave
ret
.Lf1_b6:
jmp .Lf1_b7
.Lf1_b5:
call f33@PLT
movq %rax, -280(%rbp)
jmp .Lf1_b7
.Lf1_b4:
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf1_b6
jmp .Lf1_b5
.Lf1_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movabsq $9, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -224(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
movq %rax, -192(%rbp)
jmp .Lf1_b4
.Lf1_b2:
movq -112(%rbp), %rax
movq %rax, -192(%rbp)
movq -112(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf1_b3
jmp .Lf1_b4
.Lf1_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $5, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $5, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movabsq $9, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -144(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -112(%rbp)
jmp .Lf1_b2
.Lf1_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -576(%rbp), %rsi
leaq .Lroots_f1(%rip), %rdx
movq $72, %rcx
call evn_bind_roots@PLT
movq -568(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -576(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $6, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $6, %rax
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_member@PLT
movq %rax, -88(%rbp)
movabsq $9, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -64(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -120(%rbp)
cmpq $0, -120(%rbp)
je .Lf1_b1
jmp .Lf1_b2
.size f1, .-f1
.text
.p2align 4
.type f2, @function
f2:
pushq %rbp
movq %rsp, %rbp
subq $384, %rsp
movq %rdi, -376(%rbp)
leaq -368(%rbp), %rdi
movq $46, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf2_b0
.Lf2_b9:
movabsq $3, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $10, %rax
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
call evn_void@PLT
movq %rax, -360(%rbp)
movq -8(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
leave
ret
.Lf2_b8:
jmp .Lf2_b9
.Lf2_b7:
call f33@PLT
movq %rax, -312(%rbp)
jmp .Lf2_b9
.Lf2_b6:
movq -232(%rbp), %rdi
call evn_truth@PLT
movq %rax, -304(%rbp)
cmpq $0, -304(%rbp)
je .Lf2_b8
jmp .Lf2_b7
.Lf2_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movabsq $0, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_int@PLT
movq %rax, -280(%rbp)
movabsq $6, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -264(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
movq %rax, -232(%rbp)
jmp .Lf2_b6
.Lf2_b4:
movq -160(%rbp), %rax
movq %rax, -232(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -240(%rbp)
cmpq $0, -240(%rbp)
je .Lf2_b5
jmp .Lf2_b6
.Lf2_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $5, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $0, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movabsq $6, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rax
movq %rax, -160(%rbp)
jmp .Lf2_b4
.Lf2_b2:
movq -88(%rbp), %rax
movq %rax, -160(%rbp)
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -168(%rbp)
cmpq $0, -168(%rbp)
je .Lf2_b3
jmp .Lf2_b4
.Lf2_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $6, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $6, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
movq %rax, -88(%rbp)
jmp .Lf2_b2
.Lf2_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -376(%rbp), %rsi
leaq .Lroots_f2(%rip), %rdx
movq $47, %rcx
call evn_bind_roots@PLT
movq -376(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $10, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movabsq $3, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $5, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -96(%rbp)
cmpq $0, -96(%rbp)
je .Lf2_b1
jmp .Lf2_b2
.size f2, .-f2
.text
.p2align 4
.type f3, @function
f3:
pushq %rbp
movq %rsp, %rbp
subq $64, %rsp
movq %rdi, -64(%rbp)
leaq -56(%rbp), %rdi
movq $7, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf3_b0
.Lf3_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -64(%rbp), %rsi
leaq .Lroots_f3(%rip), %rdx
movq $8, %rcx
call evn_bind_roots@PLT
movq -64(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call f31@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -8(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rax
leave
ret
.size f3, .-f3
.text
.p2align 4
.type f4, @function
f4:
pushq %rbp
movq %rsp, %rbp
subq $160, %rsp
movq %rdi, -152(%rbp)
leaq -144(%rbp), %rdi
movq $18, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf4_b0
.Lf4_b3:
call evn_void@PLT
movq %rax, -136(%rbp)
movq -8(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
leave
ret
.Lf4_b2:
jmp .Lf4_b3
.Lf4_b1:
movabsq $2, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movabsq $10, %rax
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
jmp .Lf4_b3
.Lf4_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -152(%rbp), %rsi
leaq .Lroots_f4(%rip), %rdx
movq $19, %rcx
call evn_bind_roots@PLT
movq -152(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $10, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movabsq $3, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $6, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf4_b2
jmp .Lf4_b1
.size f4, .-f4
.text
.p2align 4
.type f5, @function
f5:
pushq %rbp
movq %rsp, %rbp
subq $336, %rsp
movq %rdi, -320(%rbp)
movq %rsi, -328(%rbp)
leaq -312(%rbp), %rdi
movq $39, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf5_b0
.Lf5_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call f6@PLT
movq %rax, -296(%rbp)
call evn_void@PLT
movq %rax, -304(%rbp)
movq -8(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
leave
ret
.Lf5_b7:
jmp .Lf5_b8
.Lf5_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -224(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -264(%rbp)
movq -216(%rbp), %rdi
movq -264(%rbp), %rsi
call f7@PLT
movq %rax, -272(%rbp)
jmp .Lf5_b8
.Lf5_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $7, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -176(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf5_b7
jmp .Lf5_b6
.Lf5_b4:
jmp .Lf5_b5
.Lf5_b3:
call f33@PLT
movq %rax, -152(%rbp)
jmp .Lf5_b5
.Lf5_b2:
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf5_b4
jmp .Lf5_b3
.Lf5_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $1024, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movabsq $9, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -104(%rbp), %rsi
movq -120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
movq %rax, -88(%rbp)
jmp .Lf5_b2
.Lf5_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -328(%rbp), %rsi
leaq .Lroots_f5(%rip), %rdx
movq $41, %rcx
call evn_bind_roots@PLT
movq -320(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -328(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $7, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -96(%rbp)
cmpq $0, -96(%rbp)
je .Lf5_b1
jmp .Lf5_b2
.size f5, .-f5
.text
.p2align 4
.type f6, @function
f6:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
movq %rdi, -488(%rbp)
movq %rsi, -496(%rbp)
leaq -480(%rbp), %rdi
movq $60, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf6_b0
.Lf6_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $1, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member@PLT
movq %rax, -344(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $1, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -344(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movabsq $1, %rax
movq %rax, -376(%rbp)
movq -24(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_store@PLT
movq %rax, -392(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $2, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -416(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movabsq $2, %rax
movq %rax, -448(%rbp)
movq -24(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_store@PLT
movq %rax, -464(%rbp)
call evn_void@PLT
movq %rax, -472(%rbp)
movq -8(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
leave
ret
.Lf6_b8:
jmp .Lf6_b9
.Lf6_b7:
call f33@PLT
movq %rax, -320(%rbp)
jmp .Lf6_b9
.Lf6_b6:
movq -248(%rbp), %rdi
call evn_truth@PLT
movq %rax, -312(%rbp)
cmpq $0, -312(%rbp)
je .Lf6_b8
jmp .Lf6_b7
.Lf6_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movabsq $9, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -264(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -248(%rbp)
jmp .Lf6_b6
.Lf6_b4:
movq -192(%rbp), %rax
movq %rax, -248(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -256(%rbp)
cmpq $0, -256(%rbp)
je .Lf6_b5
jmp .Lf6_b6
.Lf6_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1024, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $9, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rax
movq %rax, -192(%rbp)
jmp .Lf6_b4
.Lf6_b2:
movq -136(%rbp), %rax
movq %rax, -192(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf6_b3
jmp .Lf6_b4
.Lf6_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $7, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -136(%rbp)
jmp .Lf6_b2
.Lf6_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -496(%rbp), %rsi
leaq .Lroots_f6(%rip), %rdx
movq $62, %rcx
call evn_bind_roots@PLT
movq -488(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -496(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $4, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call f31@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf6_b1
jmp .Lf6_b2
.size f6, .-f6
.text
.p2align 4
.type f7, @function
f7:
pushq %rbp
movq %rsp, %rbp
subq $1392, %rsp
movq %rdi, -1376(%rbp)
movq %rsi, -1384(%rbp)
leaq -1368(%rbp), %rdi
movq $171, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf7_b0
.Lf7_b22:
call evn_void@PLT
movq %rax, -1360(%rbp)
movq -8(%rbp), %rdi
movq -1360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1368(%rbp)
movq -1368(%rbp), %rax
leave
ret
.Lf7_b21:
jmp .Lf7_b22
.Lf7_b20:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rdi
call evn_get@PLT
movq %rax, -1280(%rbp)
movabsq $0, %rax
movq %rax, -1288(%rbp)
movq -1280(%rbp), %rdi
movq -1288(%rbp), %rsi
call evn_member@PLT
movq %rax, -1296(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1304(%rbp)
movabsq $0, %rax
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
movq -1296(%rbp), %rsi
movq -1304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1320(%rbp)
movq -56(%rbp), %rdi
call evn_get_ref@PLT
movq %rax, -1328(%rbp)
movabsq $0, %rax
movq %rax, -1336(%rbp)
movq -1328(%rbp), %rdi
movq -1336(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1344(%rbp)
movq -1344(%rbp), %rdi
movq -1320(%rbp), %rsi
call evn_store@PLT
movq %rax, -1352(%rbp)
jmp .Lf7_b22
.Lf7_b19:
jmp .Lf7_b16
.Lf7_b18:
jmp .Lf7_b19
.Lf7_b17:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -984(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
call evn_get@PLT
movq %rax, -1000(%rbp)
movabsq $7, %rax
movq %rax, -1008(%rbp)
movq -1000(%rbp), %rdi
movq -1008(%rbp), %rsi
call evn_member@PLT
movq %rax, -1016(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movq -1024(%rbp), %rdi
call evn_get@PLT
movq %rax, -1032(%rbp)
movabsq $0, %rax
movq %rax, -1040(%rbp)
movq -1032(%rbp), %rdi
movq -1040(%rbp), %rsi
call evn_member@PLT
movq %rax, -1048(%rbp)
movabsq $1, %rax
movq %rax, -1056(%rbp)
movq -1056(%rbp), %rdi
movq -1016(%rbp), %rsi
movq -1048(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1064(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
movq -1064(%rbp), %rdx
call f30@PLT
movq %rax, -1072(%rbp)
jmp .Lf7_b19
.Lf7_b16:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1080(%rbp)
movabsq $1, %rax
movq %rax, -1088(%rbp)
movq -1080(%rbp), %rdi
movq -1088(%rbp), %rsi
call evn_member@PLT
movq %rax, -1096(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $0, %rax
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
movq -1096(%rbp), %rsi
movq -1104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1120(%rbp)
movabsq $1, %rax
movq %rax, -1128(%rbp)
movq -24(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1136(%rbp)
movq -1136(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_store@PLT
movq %rax, -1144(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1152(%rbp)
movabsq $0, %rax
movq %rax, -1160(%rbp)
movq -1152(%rbp), %rdi
movq -1160(%rbp), %rsi
call evn_member@PLT
movq %rax, -1168(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1176(%rbp)
movabsq $0, %rax
movq %rax, -1184(%rbp)
movq -1184(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1192(%rbp)
movabsq $0, %rax
movq %rax, -1200(%rbp)
movq -48(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1208(%rbp)
movq -1208(%rbp), %rdi
movq -1192(%rbp), %rsi
call evn_store@PLT
movq %rax, -1216(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1224(%rbp)
movabsq $8, %rax
movq %rax, -1232(%rbp)
movq -1232(%rbp), %rdi
call evn_none@PLT
movq %rax, -1240(%rbp)
movabsq $6, %rax
movq %rax, -1248(%rbp)
movq -1248(%rbp), %rdi
movq -1224(%rbp), %rsi
movq -1240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1264(%rbp)
cmpq $0, -1264(%rbp)
je .Lf7_b21
jmp .Lf7_b20
.Lf7_b15:
jmp .Lf7_b16
.Lf7_b14:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movq -872(%rbp), %rdi
call evn_get@PLT
movq %rax, -880(%rbp)
movabsq $7, %rax
movq %rax, -888(%rbp)
movq -880(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_member@PLT
movq %rax, -896(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_get@PLT
movq %rax, -912(%rbp)
movabsq $0, %rax
movq %rax, -920(%rbp)
movq -912(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_member@PLT
movq %rax, -928(%rbp)
movabsq $1, %rax
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
movq -896(%rbp), %rsi
movq -928(%rbp), %rdx
call evn_binary@PLT
movq %rax, -944(%rbp)
movabsq $9, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
movq -864(%rbp), %rsi
movq -944(%rbp), %rdx
call evn_binary@PLT
movq %rax, -960(%rbp)
movq -960(%rbp), %rdi
call evn_truth@PLT
movq %rax, -968(%rbp)
cmpq $0, -968(%rbp)
je .Lf7_b18
jmp .Lf7_b17
.Lf7_b13:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $12, %rax
movq %rax, -792(%rbp)
movq -784(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member@PLT
movq %rax, -800(%rbp)
movq -56(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_store@PLT
movq %rax, -808(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movabsq $8, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call evn_none@PLT
movq %rax, -832(%rbp)
movabsq $6, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
movq -816(%rbp), %rsi
movq -832(%rbp), %rdx
call evn_binary@PLT
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
call evn_truth@PLT
movq %rax, -856(%rbp)
cmpq $0, -856(%rbp)
je .Lf7_b15
jmp .Lf7_b14
.Lf7_b12:
jmp .Lf7_b13
.Lf7_b11:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movabsq $7, %rax
movq %rax, -720(%rbp)
movq -712(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_member@PLT
movq %rax, -728(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $0, %rax
movq %rax, -744(%rbp)
movq -736(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member@PLT
movq %rax, -752(%rbp)
movabsq $1, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
movq -728(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_binary@PLT
movq %rax, -768(%rbp)
movq -696(%rbp), %rdi
movq -704(%rbp), %rsi
movq -768(%rbp), %rdx
call f30@PLT
movq %rax, -776(%rbp)
jmp .Lf7_b13
.Lf7_b10:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $7, %rax
movq %rax, -616(%rbp)
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
call evn_member@PLT
movq %rax, -624(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $0, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_member@PLT
movq %rax, -648(%rbp)
movabsq $1, %rax
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
movq -624(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_binary@PLT
movq %rax, -664(%rbp)
movabsq $9, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
movq -600(%rbp), %rsi
movq -664(%rbp), %rdx
call evn_binary@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rdi
call evn_truth@PLT
movq %rax, -688(%rbp)
cmpq $0, -688(%rbp)
je .Lf7_b12
jmp .Lf7_b11
.Lf7_b9:
jmp .Lf7_b10
.Lf7_b8:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $3, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $2, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movabsq $1, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -504(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -552(%rbp)
movabsq $1, %rax
movq %rax, -560(%rbp)
movq -552(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_member@PLT
movq %rax, -568(%rbp)
movabsq $1, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
movq -544(%rbp), %rsi
movq -568(%rbp), %rdx
call evn_binary@PLT
movq %rax, -584(%rbp)
movq -472(%rbp), %rdi
movq -480(%rbp), %rsi
movq -584(%rbp), %rdx
call f30@PLT
movq %rax, -592(%rbp)
jmp .Lf7_b10
.Lf7_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $2, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -360(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $1, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -400(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movabsq $9, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -336(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_truth@PLT
movq %rax, -464(%rbp)
cmpq $0, -464(%rbp)
je .Lf7_b9
jmp .Lf7_b8
.Lf7_b6:
jmp .Lf7_b7
.Lf7_b5:
call f33@PLT
movq %rax, -328(%rbp)
jmp .Lf7_b7
.Lf7_b4:
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf7_b6
jmp .Lf7_b5
.Lf7_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $1024, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_int@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $1, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movabsq $1, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -256(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movabsq $9, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -240(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
movq %rax, -224(%rbp)
jmp .Lf7_b4
.Lf7_b2:
movq -168(%rbp), %rax
movq %rax, -224(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf7_b3
jmp .Lf7_b4
.Lf7_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $7, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -168(%rbp)
jmp .Lf7_b2
.Lf7_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1384(%rbp), %rsi
leaq .Lroots_f7(%rip), %rdx
movq $173, %rcx
call evn_bind_roots@PLT
movq -1376(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1384(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $4, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -48(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_store@PLT
movq %rax, -88(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call f31@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $0, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $6, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf7_b1
jmp .Lf7_b2
.size f7, .-f7
.text
.p2align 4
.type f8, @function
f8:
pushq %rbp
movq %rsp, %rbp
subq $160, %rsp
movq %rdi, -160(%rbp)
leaq -152(%rbp), %rdi
movq $19, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf8_b0
.Lf8_b3:
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -136(%rbp)
call evn_void@PLT
movq %rax, -144(%rbp)
movq -8(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
leave
ret
.Lf8_b2:
jmp .Lf8_b3
.Lf8_b1:
call f33@PLT
movq %rax, -96(%rbp)
jmp .Lf8_b3
.Lf8_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -160(%rbp), %rsi
leaq .Lroots_f8(%rip), %rdx
movq $20, %rcx
call evn_bind_roots@PLT
movq -160(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $0, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $6, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf8_b2
jmp .Lf8_b1
.size f8, .-f8
.text
.p2align 4
.type f9, @function
f9:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
movq %rdi, -72(%rbp)
leaq -64(%rbp), %rdi
movq $8, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf9_b0
.Lf9_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f9(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movq -72(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $33554432, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movq -32(%rbp), %rdi
movq -48(%rbp), %rsi
call f12@PLT
movq %rax, -56(%rbp)
movq -8(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
leave
ret
.size f9, .-f9
.text
.p2align 4
.type f10, @function
f10:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
movq %rdi, -72(%rbp)
leaq -64(%rbp), %rdi
movq $8, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf10_b0
.Lf10_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f10(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movq -72(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $16777216, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movq -32(%rbp), %rdi
movq -48(%rbp), %rsi
call f12@PLT
movq %rax, -56(%rbp)
movq -8(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
leave
ret
.size f10, .-f10
.text
.p2align 4
.type f11, @function
f11:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
movq %rdi, -72(%rbp)
leaq -64(%rbp), %rdi
movq $8, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf11_b0
.Lf11_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f11(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movq -72(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $16777216, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movq -32(%rbp), %rdi
movq -48(%rbp), %rsi
call f12@PLT
movq %rax, -56(%rbp)
movq -8(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
leave
ret
.size f11, .-f11
.text
.p2align 4
.type f12, @function
f12:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
movq %rdi, -312(%rbp)
movq %rsi, -320(%rbp)
leaq -304(%rbp), %rdi
movq $38, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf12_b0
.Lf12_b3:
movabsq $10, %rax
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_object@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $4, %rax
movq %rax, -152(%rbp)
movq -136(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $3, %rax
movq %rax, -176(%rbp)
movq -136(%rbp), %rdi
movq -176(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_init@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $2, %rax
movq %rax, -208(%rbp)
movq -136(%rbp), %rdi
movq -208(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_init@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -136(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movabsq $0, %rax
movq %rax, -272(%rbp)
movq -136(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $11, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -296(%rbp)
movq -8(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
leave
ret
.Lf12_b2:
jmp .Lf12_b3
.Lf12_b1:
call f33@PLT
movq %rax, -112(%rbp)
jmp .Lf12_b3
.Lf12_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -320(%rbp), %rsi
leaq .Lroots_f12(%rip), %rdx
movq $40, %rcx
call evn_bind_roots@PLT
movq -312(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -320(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call f31@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf12_b2
jmp .Lf12_b1
.size f12, .-f12
.text
.p2align 4
.type f13, @function
f13:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
movq %rdi, -488(%rbp)
movq %rsi, -496(%rbp)
leaq -480(%rbp), %rdi
movq $60, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf13_b0
.Lf13_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $1, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -288(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movabsq $1, %rax
movq %rax, -320(%rbp)
movq -24(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_store@PLT
movq %rax, -336(%rbp)
movabsq $12, %rax
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_object@PLT
movq %rax, -360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $2, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $2, %rax
movq %rax, -392(%rbp)
movq -360(%rbp), %rdi
movq -392(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_init@PLT
movq %rax, -400(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -360(%rbp), %rdi
movq -416(%rbp), %rsi
movq -408(%rbp), %rdx
call evn_init@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movabsq $0, %rax
movq %rax, -448(%rbp)
movq -360(%rbp), %rdi
movq -448(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_init@PLT
movq %rax, -456(%rbp)
movabsq $13, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -472(%rbp)
movq -8(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
leave
ret
.Lf13_b6:
jmp .Lf13_b7
.Lf13_b5:
call f33@PLT
movq %rax, -264(%rbp)
jmp .Lf13_b7
.Lf13_b4:
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -256(%rbp)
cmpq $0, -256(%rbp)
je .Lf13_b6
jmp .Lf13_b5
.Lf13_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movabsq $9, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -208(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -192(%rbp)
jmp .Lf13_b4
.Lf13_b2:
movq -136(%rbp), %rax
movq %rax, -192(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf13_b3
jmp .Lf13_b4
.Lf13_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $7, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -136(%rbp)
jmp .Lf13_b2
.Lf13_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -496(%rbp), %rsi
leaq .Lroots_f13(%rip), %rdx
movq $62, %rcx
call evn_bind_roots@PLT
movq -488(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -496(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $2, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call f31@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf13_b1
jmp .Lf13_b2
.size f13, .-f13
.text
.p2align 4
.type f14, @function
f14:
pushq %rbp
movq %rsp, %rbp
subq $1472, %rsp
movq %rdi, -1456(%rbp)
movq %rsi, -1464(%rbp)
leaq -1448(%rbp), %rdi
movq $181, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf14_b0
.Lf14_b27:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1408(%rbp)
movabsq $2, %rax
movq %rax, -1416(%rbp)
movq -24(%rbp), %rdi
movq -1416(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1424(%rbp)
movq -1424(%rbp), %rdi
movq -1408(%rbp), %rsi
call evn_store@PLT
movq %rax, -1432(%rbp)
call evn_void@PLT
movq %rax, -1440(%rbp)
movq -8(%rbp), %rdi
movq -1440(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1448(%rbp)
movq -1448(%rbp), %rax
leave
ret
.Lf14_b26:
jmp .Lf14_b27
.Lf14_b25:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1376(%rbp)
movabsq $3, %rax
movq %rax, -1384(%rbp)
movq -40(%rbp), %rdi
movq -1384(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1392(%rbp)
movq -1392(%rbp), %rdi
movq -1376(%rbp), %rsi
call evn_store@PLT
movq %rax, -1400(%rbp)
jmp .Lf14_b27
.Lf14_b24:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movabsq $6, %rax
movq %rax, -1256(%rbp)
movq -1248(%rbp), %rdi
movq -1256(%rbp), %rsi
call evn_member@PLT
movq %rax, -1264(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1272(%rbp)
movabsq $5, %rax
movq %rax, -1280(%rbp)
movq -1272(%rbp), %rdi
movq -1280(%rbp), %rsi
call evn_member@PLT
movq %rax, -1288(%rbp)
movabsq $0, %rax
movq %rax, -1296(%rbp)
movq -1296(%rbp), %rdi
movq -1264(%rbp), %rsi
movq -1288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1304(%rbp)
movq -72(%rbp), %rdi
movq -1304(%rbp), %rsi
call evn_store@PLT
movq %rax, -1312(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1320(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1328(%rbp)
movabsq $3, %rax
movq %rax, -1336(%rbp)
movq -1328(%rbp), %rdi
movq -1336(%rbp), %rsi
call evn_member@PLT
movq %rax, -1344(%rbp)
movabsq $9, %rax
movq %rax, -1352(%rbp)
movq -1352(%rbp), %rdi
movq -1320(%rbp), %rsi
movq -1344(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1360(%rbp)
movq -1360(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1368(%rbp)
cmpq $0, -1368(%rbp)
je .Lf14_b26
jmp .Lf14_b25
.Lf14_b23:
jmp .Lf14_b24
.Lf14_b22:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1200(%rbp)
movabsq $6, %rax
movq %rax, -1208(%rbp)
movq -1200(%rbp), %rdi
movq -1208(%rbp), %rsi
call evn_member@PLT
movq %rax, -1216(%rbp)
movabsq $4, %rax
movq %rax, -1224(%rbp)
movq -40(%rbp), %rdi
movq -1224(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1232(%rbp)
movq -1232(%rbp), %rdi
movq -1216(%rbp), %rsi
call evn_store@PLT
movq %rax, -1240(%rbp)
jmp .Lf14_b24
.Lf14_b21:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -952(%rbp)
movabsq $6, %rax
movq %rax, -960(%rbp)
movq -952(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_member@PLT
movq %rax, -968(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movabsq $1, %rax
movq %rax, -984(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_member@PLT
movq %rax, -992(%rbp)
movabsq $1, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
movq -968(%rbp), %rsi
movq -992(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1008(%rbp)
movabsq $6, %rax
movq %rax, -1016(%rbp)
movq -48(%rbp), %rdi
movq -1016(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1024(%rbp)
movq -1024(%rbp), %rdi
movq -1008(%rbp), %rsi
call evn_store@PLT
movq %rax, -1032(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1040(%rbp)
movabsq $6, %rax
movq %rax, -1048(%rbp)
movq -1040(%rbp), %rdi
movq -1048(%rbp), %rsi
call evn_member@PLT
movq %rax, -1056(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1064(%rbp)
movabsq $1, %rax
movq %rax, -1072(%rbp)
movq -1064(%rbp), %rdi
movq -1072(%rbp), %rsi
call evn_member@PLT
movq %rax, -1080(%rbp)
movabsq $0, %rax
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1080(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1096(%rbp)
movabsq $6, %rax
movq %rax, -1104(%rbp)
movq -40(%rbp), %rdi
movq -1104(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
movq -1096(%rbp), %rsi
call evn_store@PLT
movq %rax, -1120(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1128(%rbp)
movabsq $6, %rax
movq %rax, -1136(%rbp)
movq -1128(%rbp), %rdi
movq -1136(%rbp), %rsi
call evn_member@PLT
movq %rax, -1144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1152(%rbp)
movabsq $4, %rax
movq %rax, -1160(%rbp)
movq -1152(%rbp), %rdi
movq -1160(%rbp), %rsi
call evn_member@PLT
movq %rax, -1168(%rbp)
movabsq $9, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
movq -1144(%rbp), %rsi
movq -1168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1184(%rbp)
movq -1184(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1192(%rbp)
cmpq $0, -1192(%rbp)
je .Lf14_b23
jmp .Lf14_b22
.Lf14_b20:
jmp .Lf14_b21
.Lf14_b19:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movabsq $1, %rax
movq %rax, -824(%rbp)
movq -816(%rbp), %rdi
movq -824(%rbp), %rsi
call evn_member@PLT
movq %rax, -832(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -840(%rbp)
movabsq $9, %rax
movq %rax, -848(%rbp)
movq -840(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_member@PLT
movq %rax, -856(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movabsq $6, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_member@PLT
movq %rax, -880(%rbp)
movabsq $1, %rax
movq %rax, -888(%rbp)
movq -888(%rbp), %rdi
movq -856(%rbp), %rsi
movq -880(%rbp), %rdx
call evn_binary@PLT
movq %rax, -896(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movabsq $5, %rax
movq %rax, -912(%rbp)
movq -904(%rbp), %rdi
movq -912(%rbp), %rsi
call evn_member@PLT
movq %rax, -920(%rbp)
movabsq $1, %rax
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
movq -896(%rbp), %rsi
movq -920(%rbp), %rdx
call evn_binary@PLT
movq %rax, -936(%rbp)
movq -808(%rbp), %rdi
movq -832(%rbp), %rsi
movq -936(%rbp), %rdx
call f30@PLT
movq %rax, -944(%rbp)
jmp .Lf14_b21
.Lf14_b18:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $1, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -680(%rbp)
movabsq $9, %rax
movq %rax, -688(%rbp)
movq -680(%rbp), %rdi
movq -688(%rbp), %rsi
call evn_member@PLT
movq %rax, -696(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movabsq $6, %rax
movq %rax, -712(%rbp)
movq -704(%rbp), %rdi
movq -712(%rbp), %rsi
call evn_member@PLT
movq %rax, -720(%rbp)
movabsq $1, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
movq -696(%rbp), %rsi
movq -720(%rbp), %rdx
call evn_binary@PLT
movq %rax, -736(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movabsq $5, %rax
movq %rax, -752(%rbp)
movq -744(%rbp), %rdi
movq -752(%rbp), %rsi
call evn_member@PLT
movq %rax, -760(%rbp)
movabsq $1, %rax
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
movq -736(%rbp), %rsi
movq -760(%rbp), %rdx
call evn_binary@PLT
movq %rax, -776(%rbp)
movabsq $9, %rax
movq %rax, -784(%rbp)
movq -784(%rbp), %rdi
movq -672(%rbp), %rsi
movq -776(%rbp), %rdx
call evn_binary@PLT
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_truth@PLT
movq %rax, -800(%rbp)
cmpq $0, -800(%rbp)
je .Lf14_b20
jmp .Lf14_b19
.Lf14_b17:
jmp .Lf14_b18
.Lf14_b16:
call f33@PLT
movq %rax, -648(%rbp)
jmp .Lf14_b18
.Lf14_b15:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $1, %rax
movq %rax, -584(%rbp)
movq -576(%rbp), %rdi
movq -584(%rbp), %rsi
call evn_member@PLT
movq %rax, -592(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $6, %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_member@PLT
movq %rax, -616(%rbp)
movabsq $9, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
movq -592(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_binary@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call evn_truth@PLT
movq %rax, -640(%rbp)
cmpq $0, -640(%rbp)
je .Lf14_b17
jmp .Lf14_b16
.Lf14_b14:
jmp .Lf14_b15
.Lf14_b13:
call f33@PLT
movq %rax, -568(%rbp)
jmp .Lf14_b15
.Lf14_b12:
movq -480(%rbp), %rdi
call evn_truth@PLT
movq %rax, -560(%rbp)
cmpq $0, -560(%rbp)
je .Lf14_b14
jmp .Lf14_b13
.Lf14_b11:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $11, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_member@PLT
movq %rax, -512(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movabsq $11, %rax
movq %rax, -528(%rbp)
movq -520(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_member@PLT
movq %rax, -536(%rbp)
movabsq $6, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
movq -512(%rbp), %rsi
movq -536(%rbp), %rdx
call evn_binary@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rax
movq %rax, -480(%rbp)
jmp .Lf14_b12
.Lf14_b10:
movq -432(%rbp), %rax
movq %rax, -480(%rbp)
movq -432(%rbp), %rdi
call evn_truth@PLT
movq %rax, -488(%rbp)
cmpq $0, -488(%rbp)
je .Lf14_b11
jmp .Lf14_b12
.Lf14_b9:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $6, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -448(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rax
movq %rax, -432(%rbp)
jmp .Lf14_b10
.Lf14_b8:
movq -376(%rbp), %rax
movq %rax, -432(%rbp)
movq -376(%rbp), %rdi
call evn_truth@PLT
movq %rax, -440(%rbp)
cmpq $0, -440(%rbp)
je .Lf14_b9
jmp .Lf14_b10
.Lf14_b7:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $8, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call evn_none@PLT
movq %rax, -408(%rbp)
movabsq $5, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
movq -392(%rbp), %rsi
movq -408(%rbp), %rdx
call evn_binary@PLT
movq %rax, -424(%rbp)
movq -424(%rbp), %rax
movq %rax, -376(%rbp)
jmp .Lf14_b8
.Lf14_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $12, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -56(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $12, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movq -64(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $8, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_none@PLT
movq %rax, -352(%rbp)
movabsq $5, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -336(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -384(%rbp)
cmpq $0, -384(%rbp)
je .Lf14_b7
jmp .Lf14_b8
.Lf14_b5:
jmp .Lf14_b6
.Lf14_b4:
call evn_void@PLT
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf14_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $2, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movq -48(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_store@PLT
movq %rax, -176(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call f31@PLT
movq %rax, -192(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call f31@PLT
movq %rax, -208(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $5, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -216(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf14_b5
jmp .Lf14_b4
.Lf14_b2:
jmp .Lf14_b3
.Lf14_b1:
call f33@PLT
movq %rax, -144(%rbp)
jmp .Lf14_b3
.Lf14_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1464(%rbp), %rsi
leaq .Lroots_f14(%rip), %rdx
movq $183, %rcx
call evn_bind_roots@PLT
movq -1456(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1464(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf14_b2
jmp .Lf14_b1
.size f14, .-f14
.text
.p2align 4
.type f15, @function
f15:
pushq %rbp
movq %rsp, %rbp
subq $784, %rsp
movq %rdi, -784(%rbp)
leaq -776(%rbp), %rdi
movq $97, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf15_b0
.Lf15_b17:
movabsq $1, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_int@PLT
movq %rax, -736(%rbp)
movabsq $0, %rax
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_store@PLT
movq %rax, -760(%rbp)
call evn_void@PLT
movq %rax, -768(%rbp)
movq -8(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rax
leave
ret
.Lf15_b16:
jmp .Lf15_b17
.Lf15_b15:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
call evn_get@PLT
movq %rax, -632(%rbp)
movabsq $6, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_member@PLT
movq %rax, -648(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $1, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movabsq $1, %rax
movq %rax, -680(%rbp)
movq -680(%rbp), %rdi
movq -648(%rbp), %rsi
movq -672(%rbp), %rdx
call evn_binary@PLT
movq %rax, -688(%rbp)
movq -40(%rbp), %rdi
call evn_get_ref@PLT
movq %rax, -696(%rbp)
movabsq $6, %rax
movq %rax, -704(%rbp)
movq -696(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
call evn_store@PLT
movq %rax, -720(%rbp)
jmp .Lf15_b17
.Lf15_b14:
jmp .Lf15_b11
.Lf15_b13:
jmp .Lf15_b14
.Lf15_b12:
call f33@PLT
movq %rax, -480(%rbp)
jmp .Lf15_b14
.Lf15_b11:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $6, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $1, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movabsq $1, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -504(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movabsq $6, %rax
movq %rax, -552(%rbp)
movq -32(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_store@PLT
movq %rax, -568(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $8, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_none@PLT
movq %rax, -592(%rbp)
movabsq $6, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf15_b16
jmp .Lf15_b15
.Lf15_b10:
jmp .Lf15_b11
.Lf15_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $1, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_get@PLT
movq %rax, -432(%rbp)
movabsq $6, %rax
movq %rax, -440(%rbp)
movq -432(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_member@PLT
movq %rax, -448(%rbp)
movabsq $9, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -416(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_truth@PLT
movq %rax, -472(%rbp)
cmpq $0, -472(%rbp)
je .Lf15_b13
jmp .Lf15_b12
.Lf15_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $8, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_none@PLT
movq %rax, -368(%rbp)
movabsq $6, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_truth@PLT
movq %rax, -392(%rbp)
cmpq $0, -392(%rbp)
je .Lf15_b10
jmp .Lf15_b9
.Lf15_b7:
jmp .Lf15_b8
.Lf15_b6:
call f33@PLT
movq %rax, -344(%rbp)
jmp .Lf15_b8
.Lf15_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $2, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -32(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $12, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -40(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $6, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $9, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -288(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf15_b7
jmp .Lf15_b6
.Lf15_b4:
jmp .Lf15_b5
.Lf15_b3:
call f33@PLT
movq %rax, -200(%rbp)
jmp .Lf15_b5
.Lf15_b2:
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf15_b4
jmp .Lf15_b3
.Lf15_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $10, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movabsq $3, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf15_b2
.Lf15_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -784(%rbp), %rsi
leaq .Lroots_f15(%rip), %rdx
movq $98, %rcx
call evn_bind_roots@PLT
movq -784(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $6, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf15_b1
jmp .Lf15_b2
.size f15, .-f15
.text
.p2align 4
.type f16, @function
f16:
pushq %rbp
movq %rsp, %rbp
subq $848, %rsp
movq %rdi, -848(%rbp)
leaq -840(%rbp), %rdi
movq $105, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf16_b0
.Lf16_b21:
movabsq $2, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $0, %rax
movq %rax, -808(%rbp)
movq -24(%rbp), %rdi
movq -808(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_store@PLT
movq %rax, -824(%rbp)
call evn_void@PLT
movq %rax, -832(%rbp)
movq -8(%rbp), %rdi
movq -832(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -840(%rbp)
movq -840(%rbp), %rax
leave
ret
.Lf16_b20:
jmp .Lf16_b21
.Lf16_b19:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
call evn_get@PLT
movq %rax, -752(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movabsq $1, %rax
movq %rax, -768(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_member@PLT
movq %rax, -776(%rbp)
movq -752(%rbp), %rdi
movq -776(%rbp), %rsi
call f17@PLT
movq %rax, -784(%rbp)
jmp .Lf16_b21
.Lf16_b18:
jmp .Lf16_b13
.Lf16_b17:
jmp .Lf16_b18
.Lf16_b16:
call f33@PLT
movq %rax, -648(%rbp)
jmp .Lf16_b18
.Lf16_b15:
movq -552(%rbp), %rdi
call evn_truth@PLT
movq %rax, -640(%rbp)
cmpq $0, -640(%rbp)
je .Lf16_b17
jmp .Lf16_b16
.Lf16_b14:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movabsq $1, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_member@PLT
movq %rax, -584(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
call evn_get@PLT
movq %rax, -600(%rbp)
movabsq $1, %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_member@PLT
movq %rax, -616(%rbp)
movabsq $9, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
movq -584(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_binary@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rax
movq %rax, -552(%rbp)
jmp .Lf16_b15
.Lf16_b13:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movabsq $1, %rax
movq %rax, -672(%rbp)
movq -664(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_member@PLT
movq %rax, -680(%rbp)
movq -656(%rbp), %rdi
movq -680(%rbp), %rsi
call f17@PLT
movq %rax, -688(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movabsq $8, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call evn_none@PLT
movq %rax, -712(%rbp)
movabsq $6, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
movq -696(%rbp), %rsi
movq -712(%rbp), %rdx
call evn_binary@PLT
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_truth@PLT
movq %rax, -736(%rbp)
cmpq $0, -736(%rbp)
je .Lf16_b20
jmp .Lf16_b19
.Lf16_b12:
jmp .Lf16_b13
.Lf16_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movabsq $1, %rax
movq %rax, -488(%rbp)
movq -480(%rbp), %rdi
movq -488(%rbp), %rsi
call evn_member@PLT
movq %rax, -496(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_get@PLT
movq %rax, -512(%rbp)
movabsq $5, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movabsq $9, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -496(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movq -544(%rbp), %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
call evn_truth@PLT
movq %rax, -560(%rbp)
cmpq $0, -560(%rbp)
je .Lf16_b14
jmp .Lf16_b15
.Lf16_b10:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $8, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_none@PLT
movq %rax, -448(%rbp)
movabsq $6, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_truth@PLT
movq %rax, -472(%rbp)
cmpq $0, -472(%rbp)
je .Lf16_b12
jmp .Lf16_b11
.Lf16_b9:
jmp .Lf16_b10
.Lf16_b8:
call f33@PLT
movq %rax, -424(%rbp)
jmp .Lf16_b10
.Lf16_b7:
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
cmpq $0, -416(%rbp)
je .Lf16_b9
jmp .Lf16_b8
.Lf16_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $1, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $1, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
movabsq $9, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -368(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_binary@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
movq %rax, -336(%rbp)
jmp .Lf16_b7
.Lf16_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $2, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -32(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $12, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -40(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $9, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -288(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf16_b6
jmp .Lf16_b7
.Lf16_b4:
jmp .Lf16_b5
.Lf16_b3:
call f33@PLT
movq %rax, -200(%rbp)
jmp .Lf16_b5
.Lf16_b2:
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf16_b4
jmp .Lf16_b3
.Lf16_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $10, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movabsq $3, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf16_b2
.Lf16_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -848(%rbp), %rsi
leaq .Lroots_f16(%rip), %rdx
movq $106, %rcx
call evn_bind_roots@PLT
movq -848(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $6, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf16_b1
jmp .Lf16_b2
.size f16, .-f16
.text
.p2align 4
.type f17, @function
f17:
pushq %rbp
movq %rsp, %rbp
subq $224, %rsp
movq %rdi, -208(%rbp)
movq %rsi, -216(%rbp)
leaq -200(%rbp), %rdi
movq $25, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf17_b0
.Lf17_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -216(%rbp), %rsi
leaq .Lroots_f17(%rip), %rdx
movq $27, %rcx
call evn_bind_roots@PLT
movq -208(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -216(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $5, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $1, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -64(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movabsq $5, %rax
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $1, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -136(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
call evn_void@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.size f17, .-f17
.text
.p2align 4
.type f18, @function
f18:
pushq %rbp
movq %rsp, %rbp
subq $912, %rsp
movq %rdi, -904(%rbp)
leaq -896(%rbp), %rdi
movq $112, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf18_b0
.Lf18_b19:
movabsq $1, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_int@PLT
movq %rax, -728(%rbp)
movabsq $0, %rax
movq %rax, -736(%rbp)
movq -24(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_store@PLT
movq %rax, -752(%rbp)
movabsq $12, %rax
movq %rax, -760(%rbp)
movabsq $3, %rax
movq %rax, -768(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_object@PLT
movq %rax, -776(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $2, %rax
movq %rax, -792(%rbp)
movq -776(%rbp), %rdi
movq -792(%rbp), %rsi
movq -784(%rbp), %rdx
call evn_init@PLT
movq %rax, -800(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movabsq $1, %rax
movq %rax, -816(%rbp)
movq -808(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_member@PLT
movq %rax, -824(%rbp)
movabsq $1, %rax
movq %rax, -832(%rbp)
movq -776(%rbp), %rdi
movq -832(%rbp), %rsi
movq -824(%rbp), %rdx
call evn_init@PLT
movq %rax, -840(%rbp)
movabsq $0, %rax
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
call evn_int@PLT
movq %rax, -856(%rbp)
movabsq $0, %rax
movq %rax, -864(%rbp)
movq -776(%rbp), %rdi
movq -864(%rbp), %rsi
movq -856(%rbp), %rdx
call evn_init@PLT
movq %rax, -872(%rbp)
movabsq $13, %rax
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -888(%rbp)
movq -8(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -896(%rbp)
movq -896(%rbp), %rax
leave
ret
.Lf18_b18:
jmp .Lf18_b19
.Lf18_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_get@PLT
movq %rax, -680(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $1, %rax
movq %rax, -696(%rbp)
movq -688(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_member@PLT
movq %rax, -704(%rbp)
movq -680(%rbp), %rdi
movq -704(%rbp), %rsi
call f19@PLT
movq %rax, -712(%rbp)
jmp .Lf18_b19
.Lf18_b16:
jmp .Lf18_b11
.Lf18_b15:
jmp .Lf18_b16
.Lf18_b14:
call f33@PLT
movq %rax, -576(%rbp)
jmp .Lf18_b16
.Lf18_b13:
movq -480(%rbp), %rdi
call evn_truth@PLT
movq %rax, -568(%rbp)
cmpq $0, -568(%rbp)
je .Lf18_b15
jmp .Lf18_b14
.Lf18_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $1, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_member@PLT
movq %rax, -512(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_get@PLT
movq %rax, -528(%rbp)
movabsq $1, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movabsq $9, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
movq -512(%rbp), %rsi
movq -544(%rbp), %rdx
call evn_binary@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rax
movq %rax, -480(%rbp)
jmp .Lf18_b13
.Lf18_b11:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -584(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $1, %rax
movq %rax, -600(%rbp)
movq -592(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_member@PLT
movq %rax, -608(%rbp)
movq -584(%rbp), %rdi
movq -608(%rbp), %rsi
call f19@PLT
movq %rax, -616(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $8, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call evn_none@PLT
movq %rax, -640(%rbp)
movabsq $6, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
movq -624(%rbp), %rsi
movq -640(%rbp), %rdx
call evn_binary@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_truth@PLT
movq %rax, -664(%rbp)
cmpq $0, -664(%rbp)
je .Lf18_b18
jmp .Lf18_b17
.Lf18_b10:
jmp .Lf18_b11
.Lf18_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_get@PLT
movq %rax, -440(%rbp)
movabsq $5, %rax
movq %rax, -448(%rbp)
movq -440(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member@PLT
movq %rax, -456(%rbp)
movabsq $9, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -424(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rax
movq %rax, -480(%rbp)
movq -472(%rbp), %rdi
call evn_truth@PLT
movq %rax, -488(%rbp)
cmpq $0, -488(%rbp)
je .Lf18_b12
jmp .Lf18_b13
.Lf18_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $8, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_none@PLT
movq %rax, -376(%rbp)
movabsq $6, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_truth@PLT
movq %rax, -400(%rbp)
cmpq $0, -400(%rbp)
je .Lf18_b10
jmp .Lf18_b9
.Lf18_b7:
jmp .Lf18_b8
.Lf18_b6:
call f33@PLT
movq %rax, -352(%rbp)
jmp .Lf18_b8
.Lf18_b5:
movq -264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf18_b7
jmp .Lf18_b6
.Lf18_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $1, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $1, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movabsq $9, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -296(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rax
movq %rax, -264(%rbp)
jmp .Lf18_b5
.Lf18_b3:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $12, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movq -40(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $1, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_member@PLT
movq %rax, -216(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $5, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movabsq $9, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -216(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf18_b4
jmp .Lf18_b5
.Lf18_b2:
jmp .Lf18_b3
.Lf18_b1:
call f33@PLT
movq %rax, -160(%rbp)
jmp .Lf18_b3
.Lf18_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -904(%rbp), %rsi
leaq .Lroots_f18(%rip), %rdx
movq $113, %rcx
call evn_bind_roots@PLT
movq -904(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $2, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -32(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_store@PLT
movq %rax, -72(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call f31@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_member@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $6, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf18_b2
jmp .Lf18_b1
.size f18, .-f18
.text
.p2align 4
.type f19, @function
f19:
pushq %rbp
movq %rsp, %rbp
subq $480, %rsp
movq %rdi, -472(%rbp)
movq %rsi, -480(%rbp)
leaq -464(%rbp), %rdi
movq $58, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf19_b0
.Lf19_b3:
call evn_void@PLT
movq %rax, -456(%rbp)
movq -8(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
leave
ret
.Lf19_b2:
jmp .Lf19_b3
.Lf19_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $6, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $4, %rax
movq %rax, -432(%rbp)
movq -24(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_store@PLT
movq %rax, -448(%rbp)
jmp .Lf19_b3
.Lf19_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -480(%rbp), %rsi
leaq .Lroots_f19(%rip), %rdx
movq $60, %rcx
call evn_bind_roots@PLT
movq -472(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -480(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $5, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $1, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -64(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movabsq $5, %rax
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $1, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -136(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $6, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
movq -208(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -232(%rbp)
movabsq $6, %rax
movq %rax, -240(%rbp)
movq -24(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $2, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $0, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -280(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movabsq $2, %rax
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $6, %rax
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_member@PLT
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $4, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_member@PLT
movq %rax, -376(%rbp)
movabsq $9, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -352(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_truth@PLT
movq %rax, -400(%rbp)
cmpq $0, -400(%rbp)
je .Lf19_b2
jmp .Lf19_b1
.size f19, .-f19
.text
.p2align 4
.type f20, @function
f20:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -512(%rbp)
movq %rsi, -520(%rbp)
leaq -504(%rbp), %rdi
movq $63, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf20_b0
.Lf20_b9:
movabsq $14, %rax
movq %rax, -384(%rbp)
movabsq $3, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_object@PLT
movq %rax, -400(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $2, %rax
movq %rax, -416(%rbp)
movq -400(%rbp), %rdi
movq -416(%rbp), %rsi
movq -408(%rbp), %rdx
call evn_init@PLT
movq %rax, -424(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $1, %rax
movq %rax, -440(%rbp)
movq -400(%rbp), %rdi
movq -440(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_init@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $0, %rax
movq %rax, -472(%rbp)
movq -400(%rbp), %rdi
movq -472(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_init@PLT
movq %rax, -480(%rbp)
movabsq $15, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -496(%rbp)
movq -8(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rax
leave
ret
.Lf20_b8:
jmp .Lf20_b9
.Lf20_b7:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_get@PLT
movq %rax, -360(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call f22@PLT
movq %rax, -376(%rbp)
jmp .Lf20_b9
.Lf20_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call f22@PLT
movq %rax, -296(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $8, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_none@PLT
movq %rax, -320(%rbp)
movabsq $6, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf20_b8
jmp .Lf20_b7
.Lf20_b5:
jmp .Lf20_b6
.Lf20_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_get@PLT
movq %rax, -256(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -240(%rbp), %rdi
movq -256(%rbp), %rsi
movq -264(%rbp), %rdx
call f21@PLT
movq %rax, -272(%rbp)
jmp .Lf20_b6
.Lf20_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
movq -144(%rbp), %rdx
call f21@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $12, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -48(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $8, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_none@PLT
movq %rax, -208(%rbp)
movabsq $6, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf20_b5
jmp .Lf20_b4
.Lf20_b2:
jmp .Lf20_b3
.Lf20_b1:
call f33@PLT
movq %rax, -120(%rbp)
jmp .Lf20_b3
.Lf20_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -520(%rbp), %rsi
leaq .Lroots_f20(%rip), %rdx
movq $65, %rcx
call evn_bind_roots@PLT
movq -512(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -520(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call f31@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $0, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movabsq $7, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf20_b2
jmp .Lf20_b1
.size f20, .-f20
.text
.p2align 4
.type f21, @function
f21:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
movq %rdi, -472(%rbp)
movq %rsi, -480(%rbp)
movq %rdx, -488(%rbp)
leaq -464(%rbp), %rdi
movq $58, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf21_b0
.Lf21_b6:
call evn_void@PLT
movq %rax, -456(%rbp)
movq -8(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
leave
ret
.Lf21_b5:
jmp .Lf21_b6
.Lf21_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $8, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $2, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -360(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $1, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -400(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
movq -440(%rbp), %rdx
call f30@PLT
movq %rax, -448(%rbp)
jmp .Lf21_b6
.Lf21_b3:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $2, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_int@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -280(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf21_b5
jmp .Lf21_b4
.Lf21_b2:
jmp .Lf21_b3
.Lf21_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $9, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $6, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -184(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $5, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -224(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -264(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
movq -264(%rbp), %rdx
call f30@PLT
movq %rax, -272(%rbp)
jmp .Lf21_b3
.Lf21_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -488(%rbp), %rsi
leaq .Lroots_f21(%rip), %rdx
movq $61, %rcx
call evn_bind_roots@PLT
movq -472(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -480(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -488(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call f23@PLT
movq %rax, -88(%rbp)
movq -64(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $1, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -104(%rbp), %rsi
movq -120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf21_b2
jmp .Lf21_b1
.size f21, .-f21
.text
.p2align 4
.type f22, @function
f22:
pushq %rbp
movq %rsp, %rbp
subq $384, %rsp
movq %rdi, -376(%rbp)
movq %rsi, -384(%rbp)
leaq -368(%rbp), %rdi
movq $46, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf22_b0
.Lf22_b3:
call evn_void@PLT
movq %rax, -360(%rbp)
movq -8(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
leave
ret
.Lf22_b2:
jmp .Lf22_b3
.Lf22_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $3, %rax
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
jmp .Lf22_b3
.Lf22_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -384(%rbp), %rsi
leaq .Lroots_f22(%rip), %rdx
movq $48, %rcx
call evn_bind_roots@PLT
movq -376(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -384(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $5, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -72(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movabsq $5, %rax
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -144(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movabsq $1, %rax
movq %rax, -176(%rbp)
movq -24(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_store@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $6, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_member@PLT
movq %rax, -216(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $5, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -216(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -48(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $3, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movabsq $9, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -272(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf22_b2
jmp .Lf22_b1
.size f22, .-f22
.text
.p2align 4
.type f23, @function
f23:
pushq %rbp
movq %rsp, %rbp
subq $400, %rsp
movq %rdi, -392(%rbp)
movq %rsi, -400(%rbp)
leaq -384(%rbp), %rdi
movq $48, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf23_b0
.Lf23_b6:
movabsq $0, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movq -8(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rax
leave
ret
.Lf23_b5:
jmp .Lf23_b6
.Lf23_b4:
movabsq $2, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movq -8(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rax
leave
ret
.Lf23_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $8, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $2, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -232(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_binary@PLT
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $1, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movabsq $1, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -272(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movabsq $9, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -208(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf23_b5
jmp .Lf23_b4
.Lf23_b2:
jmp .Lf23_b3
.Lf23_b1:
movabsq $1, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.Lf23_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -400(%rbp), %rsi
leaq .Lroots_f23(%rip), %rdx
movq $50, %rcx
call evn_bind_roots@PLT
movq -392(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -400(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $9, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $6, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -72(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_binary@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $1, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -112(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movabsq $9, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -48(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf23_b2
jmp .Lf23_b1
.size f23, .-f23
.text
.p2align 4
.type f24, @function
f24:
pushq %rbp
movq %rsp, %rbp
subq $256, %rsp
movq %rdi, -240(%rbp)
movq %rsi, -248(%rbp)
leaq -232(%rbp), %rdi
movq $29, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf24_b0
.Lf24_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $2, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $67108864, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $268435456, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $268435456, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movq -152(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
movq -200(%rbp), %rcx
movq -216(%rbp), %r8
call f25@PLT
movq %rax, -224(%rbp)
movq -8(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
leave
ret
.Lf24_b2:
jmp .Lf24_b3
.Lf24_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $2, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $8388608, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movabsq $67108864, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $268435456, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
movq -112(%rbp), %rcx
movq -128(%rbp), %r8
call f25@PLT
movq %rax, -136(%rbp)
movq -8(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
leave
ret
.Lf24_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -248(%rbp), %rsi
leaq .Lroots_f24(%rip), %rdx
movq $31, %rcx
call evn_bind_roots@PLT
movq -240(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -248(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_truth@PLT
movq %rax, -56(%rbp)
cmpq $0, -56(%rbp)
je .Lf24_b2
jmp .Lf24_b1
.size f24, .-f24
.text
.p2align 4
.type f25, @function
f25:
pushq %rbp
movq %rsp, %rbp
subq $1008, %rsp
movq %rdi, -976(%rbp)
movq %rsi, -984(%rbp)
movq %rdx, -992(%rbp)
movq %rcx, -1000(%rbp)
movq %r8, -1008(%rbp)
leaq -968(%rbp), %rdi
movq $121, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf25_b0
.Lf25_b15:
movabsq $6, %rax
movq %rax, -536(%rbp)
movabsq $13, %rax
movq %rax, -544(%rbp)
movq -536(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_object@PLT
movq %rax, -552(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $8, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -576(%rbp)
movabsq $12, %rax
movq %rax, -584(%rbp)
movq -552(%rbp), %rdi
movq -584(%rbp), %rsi
movq -576(%rbp), %rdx
call evn_init@PLT
movq %rax, -592(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $11, %rax
movq %rax, -608(%rbp)
movq -552(%rbp), %rdi
movq -608(%rbp), %rsi
movq -600(%rbp), %rdx
call evn_init@PLT
movq %rax, -616(%rbp)
movabsq $0, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
call evn_int@PLT
movq %rax, -632(%rbp)
movabsq $10, %rax
movq %rax, -640(%rbp)
movq -552(%rbp), %rdi
movq -640(%rbp), %rsi
movq -632(%rbp), %rdx
call evn_init@PLT
movq %rax, -648(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $9, %rax
movq %rax, -664(%rbp)
movq -552(%rbp), %rdi
movq -664(%rbp), %rsi
movq -656(%rbp), %rdx
call evn_init@PLT
movq %rax, -672(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -680(%rbp)
movabsq $8, %rax
movq %rax, -688(%rbp)
movq -552(%rbp), %rdi
movq -688(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_init@PLT
movq %rax, -696(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -552(%rbp), %rdi
movq -712(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_init@PLT
movq %rax, -720(%rbp)
movabsq $0, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_int@PLT
movq %rax, -736(%rbp)
movabsq $6, %rax
movq %rax, -744(%rbp)
movq -552(%rbp), %rdi
movq -744(%rbp), %rsi
movq -736(%rbp), %rdx
call evn_init@PLT
movq %rax, -752(%rbp)
movabsq $0, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_int@PLT
movq %rax, -768(%rbp)
movabsq $5, %rax
movq %rax, -776(%rbp)
movq -552(%rbp), %rdi
movq -776(%rbp), %rsi
movq -768(%rbp), %rdx
call evn_init@PLT
movq %rax, -784(%rbp)
movabsq $0, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $4, %rax
movq %rax, -808(%rbp)
movq -552(%rbp), %rdi
movq -808(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_init@PLT
movq %rax, -816(%rbp)
movabsq $0, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call evn_int@PLT
movq %rax, -832(%rbp)
movabsq $3, %rax
movq %rax, -840(%rbp)
movq -552(%rbp), %rdi
movq -840(%rbp), %rsi
movq -832(%rbp), %rdx
call evn_init@PLT
movq %rax, -848(%rbp)
movabsq $0, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
call evn_int@PLT
movq %rax, -864(%rbp)
movabsq $2, %rax
movq %rax, -872(%rbp)
movq -552(%rbp), %rdi
movq -872(%rbp), %rsi
movq -864(%rbp), %rdx
call evn_init@PLT
movq %rax, -880(%rbp)
movabsq $0, %rax
movq %rax, -888(%rbp)
movq -888(%rbp), %rdi
call evn_int@PLT
movq %rax, -896(%rbp)
movabsq $1, %rax
movq %rax, -904(%rbp)
movq -552(%rbp), %rdi
movq -904(%rbp), %rsi
movq -896(%rbp), %rdx
call evn_init@PLT
movq %rax, -912(%rbp)
movabsq $0, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
call evn_int@PLT
movq %rax, -928(%rbp)
movabsq $0, %rax
movq %rax, -936(%rbp)
movq -552(%rbp), %rdi
movq -936(%rbp), %rsi
movq -928(%rbp), %rdx
call evn_init@PLT
movq %rax, -944(%rbp)
movabsq $7, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -960(%rbp)
movq -8(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -968(%rbp)
movq -968(%rbp), %rax
leave
ret
.Lf25_b14:
jmp .Lf25_b15
.Lf25_b13:
call f33@PLT
movq %rax, -528(%rbp)
jmp .Lf25_b15
.Lf25_b12:
movq -464(%rbp), %rdi
call evn_truth@PLT
movq %rax, -520(%rbp)
cmpq $0, -520(%rbp)
je .Lf25_b14
jmp .Lf25_b13
.Lf25_b11:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movabsq $0, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_int@PLT
movq %rax, -496(%rbp)
movabsq $7, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -480(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_binary@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rax
movq %rax, -464(%rbp)
jmp .Lf25_b12
.Lf25_b10:
movq -408(%rbp), %rax
movq %rax, -464(%rbp)
movq -408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -472(%rbp)
cmpq $0, -472(%rbp)
je .Lf25_b11
jmp .Lf25_b12
.Lf25_b9:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movabsq $7, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -424(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rax
movq %rax, -408(%rbp)
jmp .Lf25_b10
.Lf25_b8:
movq -352(%rbp), %rax
movq %rax, -408(%rbp)
movq -352(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
cmpq $0, -416(%rbp)
je .Lf25_b9
jmp .Lf25_b10
.Lf25_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $7, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -368(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rax
movq %rax, -352(%rbp)
jmp .Lf25_b8
.Lf25_b6:
movq -296(%rbp), %rax
movq %rax, -352(%rbp)
movq -296(%rbp), %rdi
call evn_truth@PLT
movq %rax, -360(%rbp)
cmpq $0, -360(%rbp)
je .Lf25_b7
jmp .Lf25_b8
.Lf25_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movabsq $2, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $9, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -312(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rax
movq %rax, -296(%rbp)
jmp .Lf25_b6
.Lf25_b4:
movq -240(%rbp), %rax
movq %rax, -296(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -304(%rbp)
cmpq $0, -304(%rbp)
je .Lf25_b5
jmp .Lf25_b6
.Lf25_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movabsq $7, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_binary@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
movq %rax, -240(%rbp)
jmp .Lf25_b4
.Lf25_b2:
movq -168(%rbp), %rax
movq %rax, -240(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf25_b3
jmp .Lf25_b4
.Lf25_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $11, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $6, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
movq -200(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
movq %rax, -168(%rbp)
jmp .Lf25_b2
.Lf25_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1008(%rbp), %rsi
leaq .Lroots_f25(%rip), %rdx
movq $126, %rcx
call evn_bind_roots@PLT
movq -976(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -984(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -992(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -1000(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -1008(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call f31@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $12, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $8, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_none@PLT
movq %rax, -144(%rbp)
movabsq $6, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf25_b1
jmp .Lf25_b2
.size f25, .-f25
.text
.p2align 4
.type f26, @function
f26:
pushq %rbp
movq %rsp, %rbp
subq $128, %rsp
movq %rdi, -120(%rbp)
leaq -112(%rbp), %rdi
movq $14, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf26_b0
.Lf26_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -120(%rbp), %rsi
leaq .Lroots_f26(%rip), %rdx
movq $15, %rcx
call evn_bind_roots@PLT
movq -120(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $1, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $134217728, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $2147483648, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $268435456, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -32(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
movq -80(%rbp), %rcx
movq -96(%rbp), %r8
call f25@PLT
movq %rax, -104(%rbp)
movq -8(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rax
leave
ret
.size f26, .-f26
.text
.p2align 4
.type f27, @function
f27:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
leaq -72(%rbp), %rdi
movq $9, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf27_b0
.Lf27_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f27(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movabsq $536870912, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movabsq $2147483648, %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_int@PLT
movq %rax, -40(%rbp)
movabsq $268435456, %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_int@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
movq -40(%rbp), %rsi
movq -56(%rbp), %rdx
call f28@PLT
movq %rax, -64(%rbp)
movq -8(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -72(%rbp)
movq -72(%rbp), %rax
leave
ret
.size f27, .-f27
.text
.p2align 4
.type f28, @function
f28:
pushq %rbp
movq %rsp, %rbp
subq $688, %rsp
movq %rdi, -672(%rbp)
movq %rsi, -680(%rbp)
movq %rdx, -688(%rbp)
leaq -664(%rbp), %rdi
movq $83, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf28_b0
.Lf28_b7:
movabsq $6, %rax
movq %rax, -232(%rbp)
movabsq $13, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_object@PLT
movq %rax, -248(%rbp)
movabsq $8, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_none@PLT
movq %rax, -264(%rbp)
movabsq $12, %rax
movq %rax, -272(%rbp)
movq -248(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $0, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_int@PLT
movq %rax, -296(%rbp)
movabsq $11, %rax
movq %rax, -304(%rbp)
movq -248(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $10, %rax
movq %rax, -336(%rbp)
movq -248(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $9, %rax
movq %rax, -360(%rbp)
movq -248(%rbp), %rdi
movq -360(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_init@PLT
movq %rax, -368(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $8, %rax
movq %rax, -384(%rbp)
movq -248(%rbp), %rdi
movq -384(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_init@PLT
movq %rax, -392(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $7, %rax
movq %rax, -408(%rbp)
movq -248(%rbp), %rdi
movq -408(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_init@PLT
movq %rax, -416(%rbp)
movabsq $0, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $6, %rax
movq %rax, -440(%rbp)
movq -248(%rbp), %rdi
movq -440(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_init@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -248(%rbp), %rdi
movq -472(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_init@PLT
movq %rax, -480(%rbp)
movabsq $0, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_int@PLT
movq %rax, -496(%rbp)
movabsq $4, %rax
movq %rax, -504(%rbp)
movq -248(%rbp), %rdi
movq -504(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_init@PLT
movq %rax, -512(%rbp)
movabsq $0, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_int@PLT
movq %rax, -528(%rbp)
movabsq $3, %rax
movq %rax, -536(%rbp)
movq -248(%rbp), %rdi
movq -536(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_init@PLT
movq %rax, -544(%rbp)
movabsq $0, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $2, %rax
movq %rax, -568(%rbp)
movq -248(%rbp), %rdi
movq -568(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_init@PLT
movq %rax, -576(%rbp)
movabsq $0, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $1, %rax
movq %rax, -600(%rbp)
movq -248(%rbp), %rdi
movq -600(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_init@PLT
movq %rax, -608(%rbp)
movabsq $0, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_int@PLT
movq %rax, -624(%rbp)
movabsq $0, %rax
movq %rax, -632(%rbp)
movq -248(%rbp), %rdi
movq -632(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_init@PLT
movq %rax, -640(%rbp)
movabsq $7, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -656(%rbp)
movq -8(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -664(%rbp)
movq -664(%rbp), %rax
leave
ret
.Lf28_b6:
jmp .Lf28_b7
.Lf28_b5:
call f33@PLT
movq %rax, -224(%rbp)
jmp .Lf28_b7
.Lf28_b4:
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf28_b6
jmp .Lf28_b5
.Lf28_b3:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $0, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movabsq $7, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -176(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
movq %rax, -160(%rbp)
jmp .Lf28_b4
.Lf28_b2:
movq -104(%rbp), %rax
movq %rax, -160(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -168(%rbp)
cmpq $0, -168(%rbp)
je .Lf28_b3
jmp .Lf28_b4
.Lf28_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $7, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf28_b2
.Lf28_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -688(%rbp), %rsi
leaq .Lroots_f28(%rip), %rdx
movq $86, %rcx
call evn_bind_roots@PLT
movq -672(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -680(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -688(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf28_b1
jmp .Lf28_b2
.size f28, .-f28
.text
.p2align 4
.type f29, @function
f29:
pushq %rbp
movq %rsp, %rbp
subq $128, %rsp
movq %rdi, -112(%rbp)
movq %rsi, -120(%rbp)
movq %rdx, -128(%rbp)
leaq -104(%rbp), %rdi
movq $13, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf29_b0
.Lf29_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -128(%rbp), %rsi
leaq .Lroots_f29(%rip), %rdx
movq $16, %rcx
call evn_bind_roots@PLT
movq -112(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -120(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -128(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
movq -80(%rbp), %rdx
call f30@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
movq -8(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rax
leave
ret
.size f29, .-f29
.text
.p2align 4
.type f30, @function
f30:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -272(%rbp)
movq %rsi, -280(%rbp)
movq %rdx, -288(%rbp)
leaq -264(%rbp), %rdi
movq $33, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf30_b0
.Lf30_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f30(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -272(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -280(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -288(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $1, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $10, %rax
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movabsq $9, %rax
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_object@PLT
movq %rax, -120(%rbp)
leaq .Ldata_0(%rip), %rax
movq %rax, -128(%rbp)
movabsq $27, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_text@PLT
movq %rax, -144(%rbp)
movabsq $3, %rax
movq %rax, -152(%rbp)
movq -120(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
leaq .Ldata_1(%rip), %rax
movq %rax, -168(%rbp)
movabsq $14, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movabsq $2, %rax
movq %rax, -192(%rbp)
movq -120(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -120(%rbp), %rdi
movq -216(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_init@PLT
movq %rax, -224(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -120(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $3, %rax
movq %rax, -256(%rbp)
movq -120(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_fail@PLT
movq %rax, -264(%rbp)
ud2
.size f30, .-f30
.text
.p2align 4
.type f31, @function
f31:
pushq %rbp
movq %rsp, %rbp
subq $656, %rsp
movq %rdi, -648(%rbp)
leaq -640(%rbp), %rdi
movq $80, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf31_b0
.Lf31_b13:
call evn_void@PLT
movq %rax, -632(%rbp)
movq -8(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -640(%rbp)
movq -640(%rbp), %rax
leave
ret
.Lf31_b12:
jmp .Lf31_b13
.Lf31_b11:
call f33@PLT
movq %rax, -624(%rbp)
jmp .Lf31_b13
.Lf31_b10:
movq -544(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf31_b12
jmp .Lf31_b11
.Lf31_b9:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $10, %rax
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_member@PLT
movq %rax, -576(%rbp)
movabsq $0, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $6, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rax
movq %rax, -544(%rbp)
jmp .Lf31_b10
.Lf31_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $10, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movabsq $0, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_int@PLT
movq %rax, -520(%rbp)
movabsq $6, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
movq -504(%rbp), %rsi
movq -520(%rbp), %rdx
call evn_binary@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
movq %rax, -544(%rbp)
movq -536(%rbp), %rdi
call evn_truth@PLT
movq %rax, -552(%rbp)
cmpq $0, -552(%rbp)
je .Lf31_b9
jmp .Lf31_b10
.Lf31_b7:
jmp .Lf31_b8
.Lf31_b6:
movabsq $9, %rax
movq %rax, -304(%rbp)
movabsq $4, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_object@PLT
movq %rax, -320(%rbp)
leaq .Ldata_2(%rip), %rax
movq %rax, -328(%rbp)
movabsq $21, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_text@PLT
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -320(%rbp), %rdi
movq -352(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_init@PLT
movq %rax, -360(%rbp)
leaq .Ldata_3(%rip), %rax
movq %rax, -368(%rbp)
movabsq $9, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_text@PLT
movq %rax, -384(%rbp)
movabsq $2, %rax
movq %rax, -392(%rbp)
movq -320(%rbp), %rdi
movq -392(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_init@PLT
movq %rax, -400(%rbp)
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movabsq $1, %rax
movq %rax, -424(%rbp)
movq -320(%rbp), %rdi
movq -424(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_init@PLT
movq %rax, -432(%rbp)
movabsq $0, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -320(%rbp), %rdi
movq -456(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_init@PLT
movq %rax, -464(%rbp)
movabsq $3, %rax
movq %rax, -472(%rbp)
movq -320(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_fail@PLT
movq %rax, -480(%rbp)
ud2
.Lf31_b5:
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -296(%rbp)
cmpq $0, -296(%rbp)
je .Lf31_b7
jmp .Lf31_b6
.Lf31_b4:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $10, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movabsq $2, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movabsq $5, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_binary@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
movq %rax, -224(%rbp)
jmp .Lf31_b5
.Lf31_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $10, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movabsq $2, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $5, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf31_b4
jmp .Lf31_b5
.Lf31_b2:
jmp .Lf31_b3
.Lf31_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_get@PLT
movq %rax, -152(%rbp)
movq -32(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_store@PLT
movq %rax, -160(%rbp)
jmp .Lf31_b3
.Lf31_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -648(%rbp), %rsi
leaq .Lroots_f31(%rip), %rdx
movq $81, %rcx
call evn_bind_roots@PLT
movq -648(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -32(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_store@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $12, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -40(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_store@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $8, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_none@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf31_b2
jmp .Lf31_b1
.size f31, .-f31
.text
.p2align 4
.type f32, @function
f32:
pushq %rbp
movq %rsp, %rbp
subq $208, %rsp
movq %rdi, -200(%rbp)
leaq -192(%rbp), %rdi
movq $24, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf32_b0
.Lf32_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -200(%rbp), %rsi
leaq .Lroots_f32(%rip), %rdx
movq $25, %rcx
call evn_bind_roots@PLT
movq -200(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movabsq $9, %rax
movq %rax, -32(%rbp)
movabsq $4, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_object@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $3, %rax
movq %rax, -64(%rbp)
movq -48(%rbp), %rdi
movq -64(%rbp), %rsi
movq -56(%rbp), %rdx
call evn_init@PLT
movq %rax, -72(%rbp)
leaq .Ldata_4(%rip), %rax
movq %rax, -80(%rbp)
movabsq $13, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_text@PLT
movq %rax, -96(%rbp)
movabsq $2, %rax
movq %rax, -104(%rbp)
movq -48(%rbp), %rdi
movq -104(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_init@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -48(%rbp), %rdi
movq -136(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_init@PLT
movq %rax, -144(%rbp)
movabsq $0, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -48(%rbp), %rdi
movq -168(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_init@PLT
movq %rax, -176(%rbp)
movabsq $3, %rax
movq %rax, -184(%rbp)
movq -48(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_fail@PLT
movq %rax, -192(%rbp)
ud2
.size f32, .-f32
.text
.p2align 4
.type f33, @function
f33:
pushq %rbp
movq %rsp, %rbp
subq $192, %rsp
leaq -192(%rbp), %rdi
movq $24, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf33_b0
.Lf33_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -192(%rbp), %rsi
leaq .Lroots_f33(%rip), %rdx
movq $24, %rcx
call evn_bind_roots@PLT
movabsq $9, %rax
movq %rax, -16(%rbp)
movabsq $4, %rax
movq %rax, -24(%rbp)
movq -16(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_object@PLT
movq %rax, -32(%rbp)
leaq .Ldata_5(%rip), %rax
movq %rax, -40(%rbp)
movabsq $28, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_text@PLT
movq %rax, -56(%rbp)
movabsq $3, %rax
movq %rax, -64(%rbp)
movq -32(%rbp), %rdi
movq -64(%rbp), %rsi
movq -56(%rbp), %rdx
call evn_init@PLT
movq %rax, -72(%rbp)
leaq .Ldata_6(%rip), %rax
movq %rax, -80(%rbp)
movabsq $13, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_text@PLT
movq %rax, -96(%rbp)
movabsq $2, %rax
movq %rax, -104(%rbp)
movq -32(%rbp), %rdi
movq -104(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_init@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -32(%rbp), %rdi
movq -136(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_init@PLT
movq %rax, -144(%rbp)
movabsq $0, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -32(%rbp), %rdi
movq -168(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_init@PLT
movq %rax, -176(%rbp)
movabsq $3, %rax
movq %rax, -184(%rbp)
movq -32(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_fail@PLT
movq %rax, -192(%rbp)
ud2
.size f33, .-f33
.text
.p2align 4
.type f34, @function
f34:
pushq %rbp
movq %rsp, %rbp
subq $400, %rsp
movq %rdi, -392(%rbp)
leaq -384(%rbp), %rdi
movq $48, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf34_b0
.Lf34_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $0, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call f15@PLT
movq %rax, -368(%rbp)
call evn_void@PLT
movq %rax, -376(%rbp)
movq -8(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rax
leave
ret
.Lf34_b5:
jmp .Lf34_b6
.Lf34_b4:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call evn_get@PLT
movq %rax, -312(%rbp)
movabsq $6, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movq -312(%rbp), %rdi
movq -328(%rbp), %rsi
call f35@PLT
movq %rax, -336(%rbp)
jmp .Lf34_b6
.Lf34_b3:
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_bool@PLT
movq %rax, -112(%rbp)
movabsq $2, %rax
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $5, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -32(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -168(%rbp)
movabsq $23, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_none@PLT
movq %rax, -184(%rbp)
movabsq $5, %rax
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
movabsq $0, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $4, %rax
movq %rax, -232(%rbp)
movq -24(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $23, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_none@PLT
movq %rax, -272(%rbp)
movabsq $6, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_binary@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_truth@PLT
movq %rax, -296(%rbp)
cmpq $0, -296(%rbp)
je .Lf34_b5
jmp .Lf34_b4
.Lf34_b2:
jmp .Lf34_b3
.Lf34_b1:
leaq .Ldata_7(%rip), %rax
movq %rax, -72(%rbp)
movabsq $30, %rax
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_text@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call f32@PLT
movq %rax, -96(%rbp)
jmp .Lf34_b3
.Lf34_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -392(%rbp), %rsi
leaq .Lroots_f34(%rip), %rdx
movq $49, %rcx
call evn_bind_roots@PLT
movq -392(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $2, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_member@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_truth@PLT
movq %rax, -64(%rbp)
cmpq $0, -64(%rbp)
je .Lf34_b2
jmp .Lf34_b1
.size f34, .-f34
.text
.p2align 4
.type f35, @function
f35:
pushq %rbp
movq %rsp, %rbp
subq $848, %rsp
movq %rdi, -840(%rbp)
movq %rsi, -848(%rbp)
leaq -832(%rbp), %rdi
movq $104, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf35_b0
.Lf35_b18:
call evn_void@PLT
movq %rax, -824(%rbp)
movq -8(%rbp), %rdi
movq -824(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -832(%rbp)
movq -832(%rbp), %rax
leave
ret
.Lf35_b17:
jmp .Lf35_b18
.Lf35_b16:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
call evn_get@PLT
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
call f15@PLT
movq %rax, -816(%rbp)
jmp .Lf35_b18
.Lf35_b15:
jmp .Lf35_b12
.Lf35_b14:
jmp .Lf35_b15
.Lf35_b13:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_get@PLT
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
call f15@PLT
movq %rax, -672(%rbp)
jmp .Lf35_b15
.Lf35_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -680(%rbp)
movabsq $0, %rax
movq %rax, -688(%rbp)
movq -680(%rbp), %rdi
movq -688(%rbp), %rsi
call evn_member@PLT
movq %rax, -696(%rbp)
movq -80(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_store@PLT
movq %rax, -704(%rbp)
movabsq $18, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
call evn_none@PLT
movq %rax, -720(%rbp)
movabsq $0, %rax
movq %rax, -728(%rbp)
movq -24(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_store@PLT
movq %rax, -744(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -752(%rbp)
movabsq $18, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_none@PLT
movq %rax, -768(%rbp)
movabsq $6, %rax
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
movq -752(%rbp), %rsi
movq -768(%rbp), %rdx
call evn_binary@PLT
movq %rax, -784(%rbp)
movq -784(%rbp), %rdi
call evn_truth@PLT
movq %rax, -792(%rbp)
cmpq $0, -792(%rbp)
je .Lf35_b17
jmp .Lf35_b16
.Lf35_b11:
jmp .Lf35_b12
.Lf35_b10:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_get@PLT
movq %rax, -528(%rbp)
movabsq $0, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movq -72(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_store@PLT
movq %rax, -552(%rbp)
movabsq $18, %rax
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
call evn_none@PLT
movq %rax, -568(%rbp)
movq -64(%rbp), %rdi
call evn_get_ref@PLT
movq %rax, -576(%rbp)
movabsq $0, %rax
movq %rax, -584(%rbp)
movq -576(%rbp), %rdi
movq -584(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_store@PLT
movq %rax, -600(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $18, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_none@PLT
movq %rax, -624(%rbp)
movabsq $6, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
movq -608(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_binary@PLT
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_truth@PLT
movq %rax, -648(%rbp)
cmpq $0, -648(%rbp)
je .Lf35_b14
jmp .Lf35_b13
.Lf35_b9:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $1, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -48(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_store@PLT
movq %rax, -392(%rbp)
jmp .Lf35_b4
.Lf35_b8:
jmp .Lf35_b9
.Lf35_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_get@PLT
movq %rax, -296(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $1, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $1, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -296(%rbp), %rdi
movq -336(%rbp), %rsi
call f35@PLT
movq %rax, -344(%rbp)
jmp .Lf35_b9
.Lf35_b6:
jmp .Lf35_b3
.Lf35_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call f42@PLT
movq %rax, -224(%rbp)
movq -56(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $23, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_none@PLT
movq %rax, -256(%rbp)
movabsq $6, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -240(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_binary@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_truth@PLT
movq %rax, -280(%rbp)
cmpq $0, -280(%rbp)
je .Lf35_b8
jmp .Lf35_b7
.Lf35_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $16, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $7, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf35_b6
jmp .Lf35_b5
.Lf35_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $1, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movq -64(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_store@PLT
movq %rax, -424(%rbp)
movabsq $21, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_none@PLT
movq %rax, -440(%rbp)
movabsq $1, %rax
movq %rax, -448(%rbp)
movq -24(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_store@PLT
movq %rax, -464(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movabsq $21, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_none@PLT
movq %rax, -488(%rbp)
movabsq $6, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_truth@PLT
movq %rax, -512(%rbp)
cmpq $0, -512(%rbp)
je .Lf35_b11
jmp .Lf35_b10
.Lf35_b2:
jmp .Lf35_b3
.Lf35_b1:
jmp .Lf35_b4
.Lf35_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -848(%rbp), %rsi
leaq .Lroots_f35(%rip), %rdx
movq $106, %rcx
call evn_bind_roots@PLT
movq -840(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -848(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -48(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $9, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf35_b2
jmp .Lf35_b1
.size f35, .-f35
.text
.p2align 4
.type f36, @function
f36:
pushq %rbp
movq %rsp, %rbp
subq $192, %rsp
movq %rdi, -184(%rbp)
leaq -176(%rbp), %rdi
movq $22, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf36_b0
.Lf36_b3:
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_bool@PLT
movq %rax, -136(%rbp)
movabsq $1, %rax
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_store@PLT
movq %rax, -160(%rbp)
call evn_void@PLT
movq %rax, -168(%rbp)
movq -8(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rax
leave
ret
.Lf36_b2:
jmp .Lf36_b3
.Lf36_b1:
leaq .Ldata_8(%rip), %rax
movq %rax, -96(%rbp)
movabsq $21, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_text@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call f32@PLT
movq %rax, -120(%rbp)
jmp .Lf36_b3
.Lf36_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -184(%rbp), %rsi
leaq .Lroots_f36(%rip), %rdx
movq $23, %rcx
call evn_bind_roots@PLT
movq -184(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $6, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call f3@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $2, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf36_b2
jmp .Lf36_b1
.size f36, .-f36
.text
.p2align 4
.type f37, @function
f37:
pushq %rbp
movq %rsp, %rbp
subq $544, %rsp
movq %rdi, -520(%rbp)
movq %rsi, -528(%rbp)
movq %rdx, -536(%rbp)
leaq -512(%rbp), %rdi
movq $64, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf37_b0
.Lf37_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $4, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_member@PLT
movq %rax, -304(%rbp)
movq -64(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $1, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_bool@PLT
movq %rax, -352(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
movq -336(%rbp), %rdx
movq -352(%rbp), %rcx
call f40@PLT
movq %rax, -360(%rbp)
movq -72(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_store@PLT
movq %rax, -368(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $16, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $4, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -376(%rbp), %rdi
movq -416(%rbp), %rsi
movq -424(%rbp), %rdx
call f43@PLT
movq %rax, -432(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movabsq $1, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $0, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -440(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movabsq $4, %rax
movq %rax, -480(%rbp)
movq -24(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_store@PLT
movq %rax, -496(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movq -8(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rax
leave
ret
.Lf37_b2:
jmp .Lf37_b3
.Lf37_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $6, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movabsq $1, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_int@PLT
movq %rax, -256(%rbp)
movabsq $0, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movq -240(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call f29@PLT
movq %rax, -280(%rbp)
jmp .Lf37_b3
.Lf37_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -536(%rbp), %rsi
leaq .Lroots_f37(%rip), %rdx
movq $67, %rcx
call evn_bind_roots@PLT
movq -520(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -528(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -536(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_bool@PLT
movq %rax, -104(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call f50@PLT
movq %rax, -112(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movq -120(%rbp), %rdi
movq -136(%rbp), %rsi
call f5@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $4, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $3, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $10, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -168(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf37_b2
jmp .Lf37_b1
.size f37, .-f37
.text
.p2align 4
.type f38, @function
f38:
pushq %rbp
movq %rsp, %rbp
subq $464, %rsp
movq %rdi, -440(%rbp)
movq %rsi, -448(%rbp)
movq %rdx, -456(%rbp)
movq %rcx, -464(%rbp)
leaq -432(%rbp), %rdi
movq $54, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf38_b0
.Lf38_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movq -272(%rbp), %rdi
movq -288(%rbp), %rsi
call f5@PLT
movq %rax, -296(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movabsq $0, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_bool@PLT
movq %rax, -336(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
movq -320(%rbp), %rdx
movq -336(%rbp), %rcx
call f40@PLT
movq %rax, -344(%rbp)
movq -80(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $16, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $4, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -368(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movq -360(%rbp), %rdi
movq -400(%rbp), %rsi
movq -408(%rbp), %rdx
call f43@PLT
movq %rax, -416(%rbp)
call evn_void@PLT
movq %rax, -424(%rbp)
movq -8(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rax
leave
ret
.Lf38_b4:
jmp .Lf38_b5
.Lf38_b3:
leaq .Ldata_9(%rip), %rax
movq %rax, -240(%rbp)
movabsq $27, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_text@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call f32@PLT
movq %rax, -264(%rbp)
jmp .Lf38_b5
.Lf38_b2:
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf38_b4
jmp .Lf38_b3
.Lf38_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $4, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movabsq $10, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -184(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rax
movq %rax, -168(%rbp)
jmp .Lf38_b2
.Lf38_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -464(%rbp), %rsi
leaq .Lroots_f38(%rip), %rdx
movq $58, %rcx
call evn_bind_roots@PLT
movq -440(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -448(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -456(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -464(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_bool@PLT
movq %rax, -112(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call f50@PLT
movq %rax, -120(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $0, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $7, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf38_b1
jmp .Lf38_b2
.size f38, .-f38
.text
.p2align 4
.type f39, @function
f39:
pushq %rbp
movq %rsp, %rbp
subq $432, %rsp
movq %rdi, -408(%rbp)
movq %rsi, -416(%rbp)
movq %rdx, -424(%rbp)
leaq -400(%rbp), %rdi
movq $50, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf39_b0
.Lf39_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movq -256(%rbp), %rdi
movq -272(%rbp), %rsi
call f5@PLT
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $0, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_bool@PLT
movq %rax, -320(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
movq -304(%rbp), %rdx
movq -320(%rbp), %rcx
call f40@PLT
movq %rax, -328(%rbp)
movq -64(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_store@PLT
movq %rax, -336(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $16, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movabsq $4, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -344(%rbp), %rdi
movq -384(%rbp), %rsi
call f44@PLT
movq %rax, -392(%rbp)
movq -8(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rax
leave
ret
.Lf39_b4:
jmp .Lf39_b5
.Lf39_b3:
leaq .Ldata_10(%rip), %rax
movq %rax, -224(%rbp)
movabsq $27, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_text@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call f32@PLT
movq %rax, -248(%rbp)
jmp .Lf39_b5
.Lf39_b2:
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf39_b4
jmp .Lf39_b3
.Lf39_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $4, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $10, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -168(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
movq %rax, -152(%rbp)
jmp .Lf39_b2
.Lf39_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -424(%rbp), %rsi
leaq .Lroots_f39(%rip), %rdx
movq $53, %rcx
call evn_bind_roots@PLT
movq -408(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -416(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -424(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_bool@PLT
movq %rax, -96(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call f50@PLT
movq %rax, -104(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $7, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf39_b1
jmp .Lf39_b2
.size f39, .-f39
.text
.p2align 4
.type f40, @function
f40:
pushq %rbp
movq %rsp, %rbp
subq $1088, %rsp
movq %rdi, -1056(%rbp)
movq %rsi, -1064(%rbp)
movq %rdx, -1072(%rbp)
movq %rcx, -1080(%rbp)
leaq -1048(%rbp), %rdi
movq $131, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf40_b0
.Lf40_b18:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1016(%rbp)
movabsq $1, %rax
movq %rax, -1024(%rbp)
movq -1016(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_member@PLT
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
call f45@PLT
movq %rax, -1040(%rbp)
movq -8(%rbp), %rdi
movq -1040(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1048(%rbp)
movq -1048(%rbp), %rax
leave
ret
.Lf40_b17:
jmp .Lf40_b18
.Lf40_b16:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -936(%rbp)
movabsq $6, %rax
movq %rax, -944(%rbp)
movq -936(%rbp), %rdi
movq -944(%rbp), %rsi
call evn_member@PLT
movq %rax, -952(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movq -952(%rbp), %rdi
movq -960(%rbp), %rsi
call f47@PLT
movq %rax, -968(%rbp)
movabsq $21, %rax
movq %rax, -976(%rbp)
movq -976(%rbp), %rdi
movq -968(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -984(%rbp)
movabsq $1, %rax
movq %rax, -992(%rbp)
movq -80(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_store@PLT
movq %rax, -1008(%rbp)
jmp .Lf40_b18
.Lf40_b15:
movq -856(%rbp), %rdi
call evn_truth@PLT
movq %rax, -928(%rbp)
cmpq $0, -928(%rbp)
je .Lf40_b17
jmp .Lf40_b16
.Lf40_b14:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movabsq $1, %rax
movq %rax, -880(%rbp)
movq -872(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_member@PLT
movq %rax, -888(%rbp)
movabsq $21, %rax
movq %rax, -896(%rbp)
movq -896(%rbp), %rdi
call evn_none@PLT
movq %rax, -904(%rbp)
movabsq $5, %rax
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
movq -888(%rbp), %rsi
movq -904(%rbp), %rdx
call evn_binary@PLT
movq %rax, -920(%rbp)
movq -920(%rbp), %rax
movq %rax, -856(%rbp)
jmp .Lf40_b15
.Lf40_b13:
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
call f46@PLT
movq %rax, -784(%rbp)
movq -80(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_store@PLT
movq %rax, -792(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -800(%rbp)
movabsq $16, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
call evn_int@PLT
movq %rax, -816(%rbp)
movabsq $3, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
movq -800(%rbp), %rsi
movq -816(%rbp), %rdx
call evn_binary@PLT
movq %rax, -832(%rbp)
movq -88(%rbp), %rdi
movq -832(%rbp), %rsi
call evn_store@PLT
movq %rax, -840(%rbp)
jmp .Lf40_b6
.Lf40_b12:
jmp .Lf40_b13
.Lf40_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movabsq $6, %rax
movq %rax, -672(%rbp)
movq -664(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_member@PLT
movq %rax, -680(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movq -680(%rbp), %rdi
movq -688(%rbp), %rsi
call f48@PLT
movq %rax, -696(%rbp)
movq -120(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_store@PLT
movq %rax, -704(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movq -712(%rbp), %rdi
movq -720(%rbp), %rsi
movq -728(%rbp), %rdx
call f41@PLT
movq %rax, -736(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movabsq $23, %rax
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -760(%rbp)
movq -112(%rbp), %rdi
movq -760(%rbp), %rsi
call evn_store@PLT
movq %rax, -768(%rbp)
jmp .Lf40_b13
.Lf40_b10:
movq -632(%rbp), %rdi
call evn_truth@PLT
movq %rax, -656(%rbp)
cmpq $0, -656(%rbp)
je .Lf40_b12
jmp .Lf40_b11
.Lf40_b9:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
movq %rax, -632(%rbp)
jmp .Lf40_b10
.Lf40_b8:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movq -848(%rbp), %rax
movq %rax, -856(%rbp)
movq -848(%rbp), %rdi
call evn_truth@PLT
movq %rax, -864(%rbp)
cmpq $0, -864(%rbp)
je .Lf40_b15
jmp .Lf40_b14
.Lf40_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $1, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_int@PLT
movq %rax, -472(%rbp)
movq -456(%rbp), %rdi
movq -472(%rbp), %rsi
call f5@PLT
movq %rax, -480(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $3, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -488(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_binary@PLT
movq %rax, -512(%rbp)
movabsq $16, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_int@PLT
movq %rax, -528(%rbp)
movabsq $4, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -512(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movq -104(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_store@PLT
movq %rax, -552(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call f42@PLT
movq %rax, -576(%rbp)
movq -112(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_store@PLT
movq %rax, -584(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $23, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
call evn_none@PLT
movq %rax, -608(%rbp)
movabsq $5, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
movq -592(%rbp), %rsi
movq -608(%rbp), %rdx
call evn_binary@PLT
movq %rax, -624(%rbp)
movq -624(%rbp), %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
call evn_truth@PLT
movq %rax, -640(%rbp)
cmpq $0, -640(%rbp)
je .Lf40_b10
jmp .Lf40_b9
.Lf40_b6:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movabsq $10, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -408(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -448(%rbp)
cmpq $0, -448(%rbp)
je .Lf40_b8
jmp .Lf40_b7
.Lf40_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call f46@PLT
movq %rax, -320(%rbp)
movq -80(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movabsq $1048576, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movq -88(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $16, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movabsq $3, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -96(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_store@PLT
movq %rax, -400(%rbp)
jmp .Lf40_b6
.Lf40_b4:
jmp .Lf40_b5
.Lf40_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $6, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call f48@PLT
movq %rax, -248(%rbp)
movabsq $23, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -264(%rbp)
movabsq $5, %rax
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_store@PLT
movq %rax, -288(%rbp)
jmp .Lf40_b5
.Lf40_b2:
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf40_b4
jmp .Lf40_b3
.Lf40_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $5, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movabsq $23, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_none@PLT
movq %rax, -184(%rbp)
movabsq $5, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
movq %rax, -136(%rbp)
jmp .Lf40_b2
.Lf40_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1080(%rbp), %rsi
leaq .Lroots_f40(%rip), %rdx
movq $135, %rcx
call evn_bind_roots@PLT
movq -1056(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1064(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1072(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -1080(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
call evn_void@PLT
movq %rax, -120(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf40_b2
jmp .Lf40_b1
.size f40, .-f40
.text
.p2align 4
.type f41, @function
f41:
pushq %rbp
movq %rsp, %rbp
subq $1840, %rsp
movq %rdi, -1824(%rbp)
movq %rsi, -1832(%rbp)
movq %rdx, -1840(%rbp)
leaq -1816(%rbp), %rdi
movq $227, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf41_b0
.Lf41_b44:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1744(%rbp)
movabsq $23, %rax
movq %rax, -1752(%rbp)
movq -1752(%rbp), %rdi
movq -1744(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1760(%rbp)
movabsq $2, %rax
movq %rax, -1768(%rbp)
movq -24(%rbp), %rdi
movq -1768(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1776(%rbp)
movq -1776(%rbp), %rdi
movq -1760(%rbp), %rsi
call evn_store@PLT
movq %rax, -1784(%rbp)
call evn_void@PLT
movq %rax, -1792(%rbp)
movq -8(%rbp), %rdi
movq -1792(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1800(%rbp)
movq -1800(%rbp), %rax
leave
ret
.Lf41_b43:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1680(%rbp)
movabsq $23, %rax
movq %rax, -1688(%rbp)
movq -1688(%rbp), %rdi
movq -1680(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1696(%rbp)
movabsq $3, %rax
movq %rax, -1704(%rbp)
movq -24(%rbp), %rdi
movq -1704(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1712(%rbp)
movq -1712(%rbp), %rdi
movq -1696(%rbp), %rsi
call evn_store@PLT
movq %rax, -1720(%rbp)
call evn_void@PLT
movq %rax, -1728(%rbp)
movq -8(%rbp), %rdi
movq -1728(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1736(%rbp)
movq -1736(%rbp), %rax
leave
ret
.Lf41_b41:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1568(%rbp)
movabsq $23, %rax
movq %rax, -1576(%rbp)
movq -1576(%rbp), %rdi
movq -1568(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1584(%rbp)
movabsq $4, %rax
movq %rax, -1592(%rbp)
movq -24(%rbp), %rdi
movq -1592(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1600(%rbp)
movq -1600(%rbp), %rdi
movq -1584(%rbp), %rsi
call evn_store@PLT
movq %rax, -1608(%rbp)
call evn_void@PLT
movq %rax, -1616(%rbp)
movq -8(%rbp), %rdi
movq -1616(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1624(%rbp)
movq -1624(%rbp), %rax
leave
ret
.Lf41_b40:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1504(%rbp)
movabsq $23, %rax
movq %rax, -1512(%rbp)
movq -1512(%rbp), %rdi
movq -1504(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1520(%rbp)
movabsq $5, %rax
movq %rax, -1528(%rbp)
movq -24(%rbp), %rdi
movq -1528(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1536(%rbp)
movq -1536(%rbp), %rdi
movq -1520(%rbp), %rsi
call evn_store@PLT
movq %rax, -1544(%rbp)
call evn_void@PLT
movq %rax, -1552(%rbp)
movq -8(%rbp), %rdi
movq -1552(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1560(%rbp)
movq -1560(%rbp), %rax
leave
ret
.Lf41_b38:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1632(%rbp)
movabsq $15, %rax
movq %rax, -1640(%rbp)
movq -1640(%rbp), %rdi
call evn_int@PLT
movq %rax, -1648(%rbp)
movabsq $7, %rax
movq %rax, -1656(%rbp)
movq -1656(%rbp), %rdi
movq -1632(%rbp), %rsi
movq -1648(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1672(%rbp)
cmpq $0, -1672(%rbp)
je .Lf41_b44
jmp .Lf41_b43
.Lf41_b37:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1456(%rbp)
movabsq $13, %rax
movq %rax, -1464(%rbp)
movq -1464(%rbp), %rdi
call evn_int@PLT
movq %rax, -1472(%rbp)
movabsq $7, %rax
movq %rax, -1480(%rbp)
movq -1480(%rbp), %rdi
movq -1456(%rbp), %rsi
movq -1472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1488(%rbp)
movq -1488(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1496(%rbp)
cmpq $0, -1496(%rbp)
je .Lf41_b41
jmp .Lf41_b40
.Lf41_b35:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1344(%rbp)
movabsq $23, %rax
movq %rax, -1352(%rbp)
movq -1352(%rbp), %rdi
movq -1344(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1360(%rbp)
movabsq $6, %rax
movq %rax, -1368(%rbp)
movq -24(%rbp), %rdi
movq -1368(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1376(%rbp)
movq -1376(%rbp), %rdi
movq -1360(%rbp), %rsi
call evn_store@PLT
movq %rax, -1384(%rbp)
call evn_void@PLT
movq %rax, -1392(%rbp)
movq -8(%rbp), %rdi
movq -1392(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1400(%rbp)
movq -1400(%rbp), %rax
leave
ret
.Lf41_b34:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1280(%rbp)
movabsq $23, %rax
movq %rax, -1288(%rbp)
movq -1288(%rbp), %rdi
movq -1280(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1296(%rbp)
movabsq $7, %rax
movq %rax, -1304(%rbp)
movq -24(%rbp), %rdi
movq -1304(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
movq -1296(%rbp), %rsi
call evn_store@PLT
movq %rax, -1320(%rbp)
call evn_void@PLT
movq %rax, -1328(%rbp)
movq -8(%rbp), %rdi
movq -1328(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1336(%rbp)
movq -1336(%rbp), %rax
leave
ret
.Lf41_b32:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $23, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
movq -1168(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1184(%rbp)
movabsq $8, %rax
movq %rax, -1192(%rbp)
movq -24(%rbp), %rdi
movq -1192(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
movq -1184(%rbp), %rsi
call evn_store@PLT
movq %rax, -1208(%rbp)
call evn_void@PLT
movq %rax, -1216(%rbp)
movq -8(%rbp), %rdi
movq -1216(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1224(%rbp)
movq -1224(%rbp), %rax
leave
ret
.Lf41_b31:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $23, %rax
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
movq -1104(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1120(%rbp)
movabsq $9, %rax
movq %rax, -1128(%rbp)
movq -24(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1136(%rbp)
movq -1136(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_store@PLT
movq %rax, -1144(%rbp)
call evn_void@PLT
movq %rax, -1152(%rbp)
movq -8(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rax
leave
ret
.Lf41_b29:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1232(%rbp)
movabsq $11, %rax
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rdi
call evn_int@PLT
movq %rax, -1248(%rbp)
movabsq $7, %rax
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
movq -1232(%rbp), %rsi
movq -1248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1264(%rbp)
movq -1264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1272(%rbp)
cmpq $0, -1272(%rbp)
je .Lf41_b35
jmp .Lf41_b34
.Lf41_b28:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movabsq $9, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_int@PLT
movq %rax, -1072(%rbp)
movabsq $7, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1072(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf41_b32
jmp .Lf41_b31
.Lf41_b26:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1408(%rbp)
movabsq $14, %rax
movq %rax, -1416(%rbp)
movq -1416(%rbp), %rdi
call evn_int@PLT
movq %rax, -1424(%rbp)
movabsq $7, %rax
movq %rax, -1432(%rbp)
movq -1432(%rbp), %rdi
movq -1408(%rbp), %rsi
movq -1424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1440(%rbp)
movq -1440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1448(%rbp)
cmpq $0, -1448(%rbp)
je .Lf41_b38
jmp .Lf41_b37
.Lf41_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1008(%rbp)
movabsq $10, %rax
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rdi
call evn_int@PLT
movq %rax, -1024(%rbp)
movabsq $7, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1024(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1048(%rbp)
cmpq $0, -1048(%rbp)
je .Lf41_b29
jmp .Lf41_b28
.Lf41_b23:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $23, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
movq -896(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -912(%rbp)
movabsq $10, %rax
movq %rax, -920(%rbp)
movq -24(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
movq -912(%rbp), %rsi
call evn_store@PLT
movq %rax, -936(%rbp)
call evn_void@PLT
movq %rax, -944(%rbp)
movq -8(%rbp), %rdi
movq -944(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -952(%rbp)
movq -952(%rbp), %rax
leave
ret
.Lf41_b22:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movabsq $23, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
movq -832(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -848(%rbp)
movabsq $11, %rax
movq %rax, -856(%rbp)
movq -24(%rbp), %rdi
movq -856(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -864(%rbp)
movq -864(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_store@PLT
movq %rax, -872(%rbp)
call evn_void@PLT
movq %rax, -880(%rbp)
movq -8(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rax
leave
ret
.Lf41_b20:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movabsq $23, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -736(%rbp)
movabsq $12, %rax
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_store@PLT
movq %rax, -760(%rbp)
call evn_void@PLT
movq %rax, -768(%rbp)
movq -8(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rax
leave
ret
.Lf41_b19:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $23, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -672(%rbp)
movabsq $13, %rax
movq %rax, -680(%rbp)
movq -24(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_store@PLT
movq %rax, -696(%rbp)
call evn_void@PLT
movq %rax, -704(%rbp)
movq -8(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -712(%rbp)
movq -712(%rbp), %rax
leave
ret
.Lf41_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $7, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $7, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
movq -784(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_truth@PLT
movq %rax, -824(%rbp)
cmpq $0, -824(%rbp)
je .Lf41_b23
jmp .Lf41_b22
.Lf41_b16:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $5, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_int@PLT
movq %rax, -624(%rbp)
movabsq $7, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
movq -608(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_binary@PLT
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_truth@PLT
movq %rax, -648(%rbp)
cmpq $0, -648(%rbp)
je .Lf41_b20
jmp .Lf41_b19
.Lf41_b14:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $23, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -512(%rbp)
movabsq $14, %rax
movq %rax, -520(%rbp)
movq -24(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_store@PLT
movq %rax, -536(%rbp)
call evn_void@PLT
movq %rax, -544(%rbp)
movq -8(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rax
leave
ret
.Lf41_b13:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $23, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -448(%rbp)
movabsq $15, %rax
movq %rax, -456(%rbp)
movq -24(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -472(%rbp)
call evn_void@PLT
movq %rax, -480(%rbp)
movq -8(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
leave
ret
.Lf41_b11:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movabsq $23, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -336(%rbp)
movabsq $16, %rax
movq %rax, -344(%rbp)
movq -24(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_store@PLT
movq %rax, -360(%rbp)
call evn_void@PLT
movq %rax, -368(%rbp)
movq -8(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
leave
ret
.Lf41_b10:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $23, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -272(%rbp)
movabsq $17, %rax
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
call evn_void@PLT
movq %rax, -304(%rbp)
movq -8(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
leave
ret
.Lf41_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $3, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $7, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_truth@PLT
movq %rax, -424(%rbp)
cmpq $0, -424(%rbp)
je .Lf41_b14
jmp .Lf41_b13
.Lf41_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $7, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf41_b11
jmp .Lf41_b10
.Lf41_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $6, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
call evn_int@PLT
movq %rax, -576(%rbp)
movabsq $7, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
movq -560(%rbp), %rsi
movq -576(%rbp), %rdx
call evn_binary@PLT
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
call evn_truth@PLT
movq %rax, -600(%rbp)
cmpq $0, -600(%rbp)
je .Lf41_b17
jmp .Lf41_b16
.Lf41_b4:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $2, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $7, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf41_b8
jmp .Lf41_b7
.Lf41_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movabsq $12, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
call evn_int@PLT
movq %rax, -976(%rbp)
movabsq $7, %rax
movq %rax, -984(%rbp)
movq -984(%rbp), %rdi
movq -960(%rbp), %rsi
movq -976(%rbp), %rdx
call evn_binary@PLT
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1000(%rbp)
cmpq $0, -1000(%rbp)
je .Lf41_b26
jmp .Lf41_b25
.Lf41_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $4, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $7, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf41_b5
jmp .Lf41_b4
.Lf41_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1840(%rbp), %rsi
leaq .Lroots_f41(%rip), %rdx
movq $230, %rcx
call evn_bind_roots@PLT
movq -1824(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1832(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1840(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $8, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf41_b2
jmp .Lf41_b1
.size f41, .-f41
.text
.p2align 4
.type f42, @function
f42:
pushq %rbp
movq %rsp, %rbp
subq $1312, %rsp
movq %rdi, -1296(%rbp)
movq %rsi, -1304(%rbp)
leaq -1288(%rbp), %rdi
movq $161, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf42_b0
.Lf42_b44:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movabsq $2, %rax
movq %rax, -1256(%rbp)
movq -1248(%rbp), %rdi
movq -1256(%rbp), %rsi
call evn_member@PLT
movq %rax, -1264(%rbp)
movq -8(%rbp), %rdi
movq -1264(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rax
leave
ret
.Lf42_b43:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movabsq $3, %rax
movq %rax, -1224(%rbp)
movq -1216(%rbp), %rdi
movq -1224(%rbp), %rsi
call evn_member@PLT
movq %rax, -1232(%rbp)
movq -8(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rax
leave
ret
.Lf42_b41:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1136(%rbp)
movabsq $4, %rax
movq %rax, -1144(%rbp)
movq -1136(%rbp), %rdi
movq -1144(%rbp), %rsi
call evn_member@PLT
movq %rax, -1152(%rbp)
movq -8(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rax
leave
ret
.Lf42_b40:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $5, %rax
movq %rax, -1112(%rbp)
movq -1104(%rbp), %rdi
movq -1112(%rbp), %rsi
call evn_member@PLT
movq %rax, -1120(%rbp)
movq -8(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1128(%rbp)
movq -1128(%rbp), %rax
leave
ret
.Lf42_b38:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $15, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
call evn_int@PLT
movq %rax, -1184(%rbp)
movabsq $7, %rax
movq %rax, -1192(%rbp)
movq -1192(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1208(%rbp)
cmpq $0, -1208(%rbp)
je .Lf42_b44
jmp .Lf42_b43
.Lf42_b37:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movabsq $13, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_int@PLT
movq %rax, -1072(%rbp)
movabsq $7, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1072(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf42_b41
jmp .Lf42_b40
.Lf42_b35:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movabsq $6, %rax
movq %rax, -984(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_member@PLT
movq %rax, -992(%rbp)
movq -8(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rax
leave
ret
.Lf42_b34:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $7, %rax
movq %rax, -952(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_member@PLT
movq %rax, -960(%rbp)
movq -8(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -968(%rbp)
movq -968(%rbp), %rax
leave
ret
.Lf42_b32:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movabsq $8, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_member@PLT
movq %rax, -880(%rbp)
movq -8(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rax
leave
ret
.Lf42_b31:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movabsq $9, %rax
movq %rax, -840(%rbp)
movq -832(%rbp), %rdi
movq -840(%rbp), %rsi
call evn_member@PLT
movq %rax, -848(%rbp)
movq -8(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -856(%rbp)
movq -856(%rbp), %rax
leave
ret
.Lf42_b29:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $11, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_int@PLT
movq %rax, -912(%rbp)
movabsq $7, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
movq -896(%rbp), %rsi
movq -912(%rbp), %rdx
call evn_binary@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
call evn_truth@PLT
movq %rax, -936(%rbp)
cmpq $0, -936(%rbp)
je .Lf42_b35
jmp .Lf42_b34
.Lf42_b28:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $9, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $7, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
movq -784(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_truth@PLT
movq %rax, -824(%rbp)
cmpq $0, -824(%rbp)
je .Lf42_b32
jmp .Lf42_b31
.Lf42_b26:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1008(%rbp)
movabsq $14, %rax
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rdi
call evn_int@PLT
movq %rax, -1024(%rbp)
movabsq $7, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1024(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1048(%rbp)
cmpq $0, -1048(%rbp)
je .Lf42_b38
jmp .Lf42_b37
.Lf42_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $10, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
call evn_int@PLT
movq %rax, -752(%rbp)
movabsq $7, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
movq -736(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_binary@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
call evn_truth@PLT
movq %rax, -776(%rbp)
cmpq $0, -776(%rbp)
je .Lf42_b29
jmp .Lf42_b28
.Lf42_b23:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $10, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movq -8(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
leave
ret
.Lf42_b22:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $11, %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_member@PLT
movq %rax, -640(%rbp)
movq -8(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
leave
ret
.Lf42_b20:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $12, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member@PLT
movq %rax, -560(%rbp)
movq -8(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -568(%rbp)
movq -568(%rbp), %rax
leave
ret
.Lf42_b19:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $13, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movq -8(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
leave
ret
.Lf42_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $7, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $7, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf42_b23
jmp .Lf42_b22
.Lf42_b16:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_int@PLT
movq %rax, -480(%rbp)
movabsq $7, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -464(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -504(%rbp)
cmpq $0, -504(%rbp)
je .Lf42_b20
jmp .Lf42_b19
.Lf42_b14:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $14, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movq -8(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
leave
ret
.Lf42_b13:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $15, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -8(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
leave
ret
.Lf42_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $16, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf42_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $17, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf42_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $3, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $7, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf42_b14
jmp .Lf42_b13
.Lf42_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $1, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movabsq $7, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf42_b11
jmp .Lf42_b10
.Lf42_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $6, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $7, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -416(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_truth@PLT
movq %rax, -456(%rbp)
cmpq $0, -456(%rbp)
je .Lf42_b17
jmp .Lf42_b16
.Lf42_b4:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $2, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $7, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_truth@PLT
movq %rax, -184(%rbp)
cmpq $0, -184(%rbp)
je .Lf42_b8
jmp .Lf42_b7
.Lf42_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $12, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_binary@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_truth@PLT
movq %rax, -728(%rbp)
cmpq $0, -728(%rbp)
je .Lf42_b26
jmp .Lf42_b25
.Lf42_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $4, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $7, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf42_b5
jmp .Lf42_b4
.Lf42_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1304(%rbp), %rsi
leaq .Lroots_f42(%rip), %rdx
movq $163, %rcx
call evn_bind_roots@PLT
movq -1296(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1304(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $8, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $7, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf42_b2
jmp .Lf42_b1
.size f42, .-f42
.text
.p2align 4
.type f43, @function
f43:
pushq %rbp
movq %rsp, %rbp
subq $1584, %rsp
movq %rdi, -1568(%rbp)
movq %rsi, -1576(%rbp)
movq %rdx, -1584(%rbp)
leaq -1560(%rbp), %rdi
movq $195, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf43_b0
.Lf43_b44:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1504(%rbp)
movabsq $1, %rax
movq %rax, -1512(%rbp)
movq -24(%rbp), %rdi
movq -1512(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1520(%rbp)
movq -1520(%rbp), %rdi
movq -1504(%rbp), %rsi
call evn_store@PLT
movq %rax, -1528(%rbp)
call evn_void@PLT
movq %rax, -1536(%rbp)
movq -8(%rbp), %rdi
movq -1536(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1544(%rbp)
movq -1544(%rbp), %rax
leave
ret
.Lf43_b43:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1456(%rbp)
movabsq $2, %rax
movq %rax, -1464(%rbp)
movq -24(%rbp), %rdi
movq -1464(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1472(%rbp)
movq -1472(%rbp), %rdi
movq -1456(%rbp), %rsi
call evn_store@PLT
movq %rax, -1480(%rbp)
call evn_void@PLT
movq %rax, -1488(%rbp)
movq -8(%rbp), %rdi
movq -1488(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1496(%rbp)
movq -1496(%rbp), %rax
leave
ret
.Lf43_b41:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1360(%rbp)
movabsq $3, %rax
movq %rax, -1368(%rbp)
movq -24(%rbp), %rdi
movq -1368(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1376(%rbp)
movq -1376(%rbp), %rdi
movq -1360(%rbp), %rsi
call evn_store@PLT
movq %rax, -1384(%rbp)
call evn_void@PLT
movq %rax, -1392(%rbp)
movq -8(%rbp), %rdi
movq -1392(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1400(%rbp)
movq -1400(%rbp), %rax
leave
ret
.Lf43_b40:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1312(%rbp)
movabsq $4, %rax
movq %rax, -1320(%rbp)
movq -24(%rbp), %rdi
movq -1320(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1328(%rbp)
movq -1328(%rbp), %rdi
movq -1312(%rbp), %rsi
call evn_store@PLT
movq %rax, -1336(%rbp)
call evn_void@PLT
movq %rax, -1344(%rbp)
movq -8(%rbp), %rdi
movq -1344(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1352(%rbp)
movq -1352(%rbp), %rax
leave
ret
.Lf43_b38:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1408(%rbp)
movabsq $15, %rax
movq %rax, -1416(%rbp)
movq -1416(%rbp), %rdi
call evn_int@PLT
movq %rax, -1424(%rbp)
movabsq $7, %rax
movq %rax, -1432(%rbp)
movq -1432(%rbp), %rdi
movq -1408(%rbp), %rsi
movq -1424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1440(%rbp)
movq -1440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1448(%rbp)
cmpq $0, -1448(%rbp)
je .Lf43_b44
jmp .Lf43_b43
.Lf43_b37:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1264(%rbp)
movabsq $13, %rax
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rdi
call evn_int@PLT
movq %rax, -1280(%rbp)
movabsq $7, %rax
movq %rax, -1288(%rbp)
movq -1288(%rbp), %rdi
movq -1264(%rbp), %rsi
movq -1280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1296(%rbp)
movq -1296(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1304(%rbp)
cmpq $0, -1304(%rbp)
je .Lf43_b41
jmp .Lf43_b40
.Lf43_b35:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $5, %rax
movq %rax, -1176(%rbp)
movq -24(%rbp), %rdi
movq -1176(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1184(%rbp)
movq -1184(%rbp), %rdi
movq -1168(%rbp), %rsi
call evn_store@PLT
movq %rax, -1192(%rbp)
call evn_void@PLT
movq %rax, -1200(%rbp)
movq -8(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1208(%rbp)
movq -1208(%rbp), %rax
leave
ret
.Lf43_b34:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1120(%rbp)
movabsq $6, %rax
movq %rax, -1128(%rbp)
movq -24(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1136(%rbp)
movq -1136(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_store@PLT
movq %rax, -1144(%rbp)
call evn_void@PLT
movq %rax, -1152(%rbp)
movq -8(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rax
leave
ret
.Lf43_b32:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movabsq $7, %rax
movq %rax, -1032(%rbp)
movq -24(%rbp), %rdi
movq -1032(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_store@PLT
movq %rax, -1048(%rbp)
call evn_void@PLT
movq %rax, -1056(%rbp)
movq -8(%rbp), %rdi
movq -1056(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rax
leave
ret
.Lf43_b31:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movabsq $8, %rax
movq %rax, -984(%rbp)
movq -24(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
movq -976(%rbp), %rsi
call evn_store@PLT
movq %rax, -1000(%rbp)
call evn_void@PLT
movq %rax, -1008(%rbp)
movq -8(%rbp), %rdi
movq -1008(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rax
leave
ret
.Lf43_b29:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movabsq $11, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
call evn_int@PLT
movq %rax, -1088(%rbp)
movabsq $7, %rax
movq %rax, -1096(%rbp)
movq -1096(%rbp), %rdi
movq -1072(%rbp), %rsi
movq -1088(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1104(%rbp)
movq -1104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1112(%rbp)
cmpq $0, -1112(%rbp)
je .Lf43_b35
jmp .Lf43_b34
.Lf43_b28:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -928(%rbp)
movabsq $9, %rax
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
call evn_int@PLT
movq %rax, -944(%rbp)
movabsq $7, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
movq -928(%rbp), %rsi
movq -944(%rbp), %rdx
call evn_binary@PLT
movq %rax, -960(%rbp)
movq -960(%rbp), %rdi
call evn_truth@PLT
movq %rax, -968(%rbp)
cmpq $0, -968(%rbp)
je .Lf43_b32
jmp .Lf43_b31
.Lf43_b26:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movabsq $14, %rax
movq %rax, -1224(%rbp)
movq -1224(%rbp), %rdi
call evn_int@PLT
movq %rax, -1232(%rbp)
movabsq $7, %rax
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rdi
movq -1216(%rbp), %rsi
movq -1232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1248(%rbp)
movq -1248(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1256(%rbp)
cmpq $0, -1256(%rbp)
je .Lf43_b38
jmp .Lf43_b37
.Lf43_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -880(%rbp)
movabsq $10, %rax
movq %rax, -888(%rbp)
movq -888(%rbp), %rdi
call evn_int@PLT
movq %rax, -896(%rbp)
movabsq $7, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
movq -880(%rbp), %rsi
movq -896(%rbp), %rdx
call evn_binary@PLT
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
call evn_truth@PLT
movq %rax, -920(%rbp)
cmpq $0, -920(%rbp)
je .Lf43_b29
jmp .Lf43_b28
.Lf43_b23:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $9, %rax
movq %rax, -792(%rbp)
movq -24(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_store@PLT
movq %rax, -808(%rbp)
call evn_void@PLT
movq %rax, -816(%rbp)
movq -8(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -824(%rbp)
movq -824(%rbp), %rax
leave
ret
.Lf43_b22:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $10, %rax
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_store@PLT
movq %rax, -760(%rbp)
call evn_void@PLT
movq %rax, -768(%rbp)
movq -8(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rax
leave
ret
.Lf43_b20:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -640(%rbp)
movabsq $11, %rax
movq %rax, -648(%rbp)
movq -24(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_store@PLT
movq %rax, -664(%rbp)
call evn_void@PLT
movq %rax, -672(%rbp)
movq -8(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
leave
ret
.Lf43_b19:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $12, %rax
movq %rax, -600(%rbp)
movq -24(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
movq -592(%rbp), %rsi
call evn_store@PLT
movq %rax, -616(%rbp)
call evn_void@PLT
movq %rax, -624(%rbp)
movq -8(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rax
leave
ret
.Lf43_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $7, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_binary@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_truth@PLT
movq %rax, -728(%rbp)
cmpq $0, -728(%rbp)
je .Lf43_b23
jmp .Lf43_b22
.Lf43_b16:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $5, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $7, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -544(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_truth@PLT
movq %rax, -584(%rbp)
cmpq $0, -584(%rbp)
je .Lf43_b20
jmp .Lf43_b19
.Lf43_b14:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movabsq $13, %rax
movq %rax, -456(%rbp)
movq -24(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -472(%rbp)
call evn_void@PLT
movq %rax, -480(%rbp)
movq -8(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
leave
ret
.Lf43_b13:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $14, %rax
movq %rax, -408(%rbp)
movq -24(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_store@PLT
movq %rax, -424(%rbp)
call evn_void@PLT
movq %rax, -432(%rbp)
movq -8(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rax
leave
ret
.Lf43_b11:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $15, %rax
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
call evn_void@PLT
movq %rax, -336(%rbp)
movq -8(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rax
leave
ret
.Lf43_b10:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $16, %rax
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -280(%rbp)
call evn_void@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf43_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $3, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movabsq $7, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_truth@PLT
movq %rax, -392(%rbp)
cmpq $0, -392(%rbp)
je .Lf43_b14
jmp .Lf43_b13
.Lf43_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $7, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf43_b11
jmp .Lf43_b10
.Lf43_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $6, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_int@PLT
movq %rax, -512(%rbp)
movabsq $7, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
movq -496(%rbp), %rsi
movq -512(%rbp), %rdx
call evn_binary@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call evn_truth@PLT
movq %rax, -536(%rbp)
cmpq $0, -536(%rbp)
je .Lf43_b17
jmp .Lf43_b16
.Lf43_b4:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $2, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $7, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf43_b8
jmp .Lf43_b7
.Lf43_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movabsq $12, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
call evn_int@PLT
movq %rax, -848(%rbp)
movabsq $7, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
movq -832(%rbp), %rsi
movq -848(%rbp), %rdx
call evn_binary@PLT
movq %rax, -864(%rbp)
movq -864(%rbp), %rdi
call evn_truth@PLT
movq %rax, -872(%rbp)
cmpq $0, -872(%rbp)
je .Lf43_b26
jmp .Lf43_b25
.Lf43_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $4, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $7, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf43_b5
jmp .Lf43_b4
.Lf43_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1584(%rbp), %rsi
leaq .Lroots_f43(%rip), %rdx
movq $198, %rcx
call evn_bind_roots@PLT
movq -1568(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1576(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1584(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $8, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf43_b2
jmp .Lf43_b1
.size f43, .-f43
.text
.p2align 4
.type f44, @function
f44:
pushq %rbp
movq %rsp, %rbp
subq $1312, %rsp
movq %rdi, -1296(%rbp)
movq %rsi, -1304(%rbp)
leaq -1288(%rbp), %rdi
movq $161, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf44_b0
.Lf44_b44:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movabsq $1, %rax
movq %rax, -1256(%rbp)
movq -1248(%rbp), %rdi
movq -1256(%rbp), %rsi
call evn_member@PLT
movq %rax, -1264(%rbp)
movq -8(%rbp), %rdi
movq -1264(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rax
leave
ret
.Lf44_b43:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movabsq $2, %rax
movq %rax, -1224(%rbp)
movq -1216(%rbp), %rdi
movq -1224(%rbp), %rsi
call evn_member@PLT
movq %rax, -1232(%rbp)
movq -8(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rax
leave
ret
.Lf44_b41:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1136(%rbp)
movabsq $3, %rax
movq %rax, -1144(%rbp)
movq -1136(%rbp), %rdi
movq -1144(%rbp), %rsi
call evn_member@PLT
movq %rax, -1152(%rbp)
movq -8(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rax
leave
ret
.Lf44_b40:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $4, %rax
movq %rax, -1112(%rbp)
movq -1104(%rbp), %rdi
movq -1112(%rbp), %rsi
call evn_member@PLT
movq %rax, -1120(%rbp)
movq -8(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1128(%rbp)
movq -1128(%rbp), %rax
leave
ret
.Lf44_b38:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $15, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
call evn_int@PLT
movq %rax, -1184(%rbp)
movabsq $7, %rax
movq %rax, -1192(%rbp)
movq -1192(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1208(%rbp)
cmpq $0, -1208(%rbp)
je .Lf44_b44
jmp .Lf44_b43
.Lf44_b37:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movabsq $13, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_int@PLT
movq %rax, -1072(%rbp)
movabsq $7, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1072(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf44_b41
jmp .Lf44_b40
.Lf44_b35:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movabsq $5, %rax
movq %rax, -984(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_member@PLT
movq %rax, -992(%rbp)
movq -8(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rax
leave
ret
.Lf44_b34:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $6, %rax
movq %rax, -952(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_member@PLT
movq %rax, -960(%rbp)
movq -8(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -968(%rbp)
movq -968(%rbp), %rax
leave
ret
.Lf44_b32:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movabsq $7, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_member@PLT
movq %rax, -880(%rbp)
movq -8(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rax
leave
ret
.Lf44_b31:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movabsq $8, %rax
movq %rax, -840(%rbp)
movq -832(%rbp), %rdi
movq -840(%rbp), %rsi
call evn_member@PLT
movq %rax, -848(%rbp)
movq -8(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -856(%rbp)
movq -856(%rbp), %rax
leave
ret
.Lf44_b29:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $11, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_int@PLT
movq %rax, -912(%rbp)
movabsq $7, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
movq -896(%rbp), %rsi
movq -912(%rbp), %rdx
call evn_binary@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
call evn_truth@PLT
movq %rax, -936(%rbp)
cmpq $0, -936(%rbp)
je .Lf44_b35
jmp .Lf44_b34
.Lf44_b28:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $9, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $7, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
movq -784(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_truth@PLT
movq %rax, -824(%rbp)
cmpq $0, -824(%rbp)
je .Lf44_b32
jmp .Lf44_b31
.Lf44_b26:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1008(%rbp)
movabsq $14, %rax
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rdi
call evn_int@PLT
movq %rax, -1024(%rbp)
movabsq $7, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1024(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1048(%rbp)
cmpq $0, -1048(%rbp)
je .Lf44_b38
jmp .Lf44_b37
.Lf44_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $10, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
call evn_int@PLT
movq %rax, -752(%rbp)
movabsq $7, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
movq -736(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_binary@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
call evn_truth@PLT
movq %rax, -776(%rbp)
cmpq $0, -776(%rbp)
je .Lf44_b29
jmp .Lf44_b28
.Lf44_b23:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $9, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movq -8(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
leave
ret
.Lf44_b22:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $10, %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_member@PLT
movq %rax, -640(%rbp)
movq -8(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
leave
ret
.Lf44_b20:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $11, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member@PLT
movq %rax, -560(%rbp)
movq -8(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -568(%rbp)
movq -568(%rbp), %rax
leave
ret
.Lf44_b19:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $12, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movq -8(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
leave
ret
.Lf44_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $7, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $7, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf44_b23
jmp .Lf44_b22
.Lf44_b16:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_int@PLT
movq %rax, -480(%rbp)
movabsq $7, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -464(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -504(%rbp)
cmpq $0, -504(%rbp)
je .Lf44_b20
jmp .Lf44_b19
.Lf44_b14:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $13, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movq -8(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
leave
ret
.Lf44_b13:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $14, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -8(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
leave
ret
.Lf44_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $15, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf44_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $16, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf44_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $3, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $7, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf44_b14
jmp .Lf44_b13
.Lf44_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $1, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movabsq $7, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf44_b11
jmp .Lf44_b10
.Lf44_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $6, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $7, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -416(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_truth@PLT
movq %rax, -456(%rbp)
cmpq $0, -456(%rbp)
je .Lf44_b17
jmp .Lf44_b16
.Lf44_b4:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $2, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $7, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_truth@PLT
movq %rax, -184(%rbp)
cmpq $0, -184(%rbp)
je .Lf44_b8
jmp .Lf44_b7
.Lf44_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $12, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_binary@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_truth@PLT
movq %rax, -728(%rbp)
cmpq $0, -728(%rbp)
je .Lf44_b26
jmp .Lf44_b25
.Lf44_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $4, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $7, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf44_b5
jmp .Lf44_b4
.Lf44_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1304(%rbp), %rsi
leaq .Lroots_f44(%rip), %rdx
movq $163, %rcx
call evn_bind_roots@PLT
movq -1296(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1304(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $8, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $7, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf44_b2
jmp .Lf44_b1
.size f44, .-f44
.text
.p2align 4
.type f45, @function
f45:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -288(%rbp)
leaq -280(%rbp), %rdi
movq $35, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf45_b0
.Lf45_b3:
movabsq $9, %rax
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_object@PLT
movq %rax, -120(%rbp)
leaq .Ldata_11(%rip), %rax
movq %rax, -128(%rbp)
movabsq $21, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_text@PLT
movq %rax, -144(%rbp)
movabsq $3, %rax
movq %rax, -152(%rbp)
movq -120(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
leaq .Ldata_12(%rip), %rax
movq %rax, -168(%rbp)
movabsq $13, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movabsq $2, %rax
movq %rax, -192(%rbp)
movq -120(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -120(%rbp), %rdi
movq -224(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_init@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -120(%rbp), %rdi
movq -256(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_init@PLT
movq %rax, -264(%rbp)
movabsq $3, %rax
movq %rax, -272(%rbp)
movq -120(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_fail@PLT
movq %rax, -280(%rbp)
ud2
.Lf45_b2:
jmp .Lf45_b3
.Lf45_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_get@PLT
movq %rax, -88(%rbp)
movq -8(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
leave
ret
.Lf45_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f45(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $21, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_none@PLT
movq %rax, -48(%rbp)
movabsq $6, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -72(%rbp)
cmpq $0, -72(%rbp)
je .Lf45_b2
jmp .Lf45_b1
.size f45, .-f45
.text
.p2align 4
.type f46, @function
f46:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -288(%rbp)
leaq -280(%rbp), %rdi
movq $35, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf46_b0
.Lf46_b3:
movabsq $9, %rax
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_object@PLT
movq %rax, -120(%rbp)
leaq .Ldata_13(%rip), %rax
movq %rax, -128(%rbp)
movabsq $22, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_text@PLT
movq %rax, -144(%rbp)
movabsq $3, %rax
movq %rax, -152(%rbp)
movq -120(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
leaq .Ldata_14(%rip), %rax
movq %rax, -168(%rbp)
movabsq $13, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movabsq $2, %rax
movq %rax, -192(%rbp)
movq -120(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -120(%rbp), %rdi
movq -224(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_init@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -120(%rbp), %rdi
movq -256(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_init@PLT
movq %rax, -264(%rbp)
movabsq $3, %rax
movq %rax, -272(%rbp)
movq -120(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_fail@PLT
movq %rax, -280(%rbp)
ud2
.Lf46_b2:
jmp .Lf46_b3
.Lf46_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_get@PLT
movq %rax, -88(%rbp)
movq -8(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
leave
ret
.Lf46_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f46(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $23, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_none@PLT
movq %rax, -48(%rbp)
movabsq $6, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -72(%rbp)
cmpq $0, -72(%rbp)
je .Lf46_b2
jmp .Lf46_b1
.size f46, .-f46
.text
.p2align 4
.type f47, @function
f47:
pushq %rbp
movq %rsp, %rbp
subq $816, %rsp
movq %rdi, -800(%rbp)
movq %rsi, -808(%rbp)
leaq -792(%rbp), %rdi
movq $99, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf47_b0
.Lf47_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -808(%rbp), %rsi
leaq .Lroots_f47(%rip), %rdx
movq $101, %rcx
call evn_bind_roots@PLT
movq -800(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -808(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $17, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
call f5@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $768, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movq -96(%rbp), %rdi
movq -112(%rbp), %rsi
call f20@PLT
movq %rax, -120(%rbp)
movq -48(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movabsq $19, %rax
movq %rax, -136(%rbp)
movabsq $17, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_object@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $16, %rax
movq %rax, -176(%rbp)
movq -152(%rbp), %rdi
movq -176(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_init@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $15, %rax
movq %rax, -208(%rbp)
movq -152(%rbp), %rdi
movq -208(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_init@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $14, %rax
movq %rax, -240(%rbp)
movq -152(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movabsq $13, %rax
movq %rax, -272(%rbp)
movq -152(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $0, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_int@PLT
movq %rax, -296(%rbp)
movabsq $12, %rax
movq %rax, -304(%rbp)
movq -152(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $11, %rax
movq %rax, -336(%rbp)
movq -152(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movabsq $0, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_int@PLT
movq %rax, -360(%rbp)
movabsq $10, %rax
movq %rax, -368(%rbp)
movq -152(%rbp), %rdi
movq -368(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_init@PLT
movq %rax, -376(%rbp)
movabsq $0, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_int@PLT
movq %rax, -392(%rbp)
movabsq $9, %rax
movq %rax, -400(%rbp)
movq -152(%rbp), %rdi
movq -400(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_init@PLT
movq %rax, -408(%rbp)
movabsq $0, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movabsq $8, %rax
movq %rax, -432(%rbp)
movq -152(%rbp), %rdi
movq -432(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_init@PLT
movq %rax, -440(%rbp)
movabsq $0, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $7, %rax
movq %rax, -464(%rbp)
movq -152(%rbp), %rdi
movq -464(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_init@PLT
movq %rax, -472(%rbp)
movabsq $0, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $6, %rax
movq %rax, -496(%rbp)
movq -152(%rbp), %rdi
movq -496(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_init@PLT
movq %rax, -504(%rbp)
movabsq $0, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_int@PLT
movq %rax, -520(%rbp)
movabsq $5, %rax
movq %rax, -528(%rbp)
movq -152(%rbp), %rdi
movq -528(%rbp), %rsi
movq -520(%rbp), %rdx
call evn_init@PLT
movq %rax, -536(%rbp)
movabsq $0, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call evn_int@PLT
movq %rax, -552(%rbp)
movabsq $4, %rax
movq %rax, -560(%rbp)
movq -152(%rbp), %rdi
movq -560(%rbp), %rsi
movq -552(%rbp), %rdx
call evn_init@PLT
movq %rax, -568(%rbp)
movabsq $0, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_int@PLT
movq %rax, -584(%rbp)
movabsq $3, %rax
movq %rax, -592(%rbp)
movq -152(%rbp), %rdi
movq -592(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_init@PLT
movq %rax, -600(%rbp)
movabsq $0, %rax
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_int@PLT
movq %rax, -616(%rbp)
movabsq $2, %rax
movq %rax, -624(%rbp)
movq -152(%rbp), %rdi
movq -624(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_init@PLT
movq %rax, -632(%rbp)
movabsq $0, %rax
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_int@PLT
movq %rax, -648(%rbp)
movabsq $1, %rax
movq %rax, -656(%rbp)
movq -152(%rbp), %rdi
movq -656(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_init@PLT
movq %rax, -664(%rbp)
movabsq $18, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_none@PLT
movq %rax, -680(%rbp)
movabsq $0, %rax
movq %rax, -688(%rbp)
movq -152(%rbp), %rdi
movq -688(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_init@PLT
movq %rax, -696(%rbp)
movabsq $20, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -712(%rbp)
movq -56(%rbp), %rdi
movq -712(%rbp), %rsi
call evn_store@PLT
movq %rax, -720(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call f18@PLT
movq %rax, -736(%rbp)
movabsq $18, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -752(%rbp)
movabsq $0, %rax
movq %rax, -760(%rbp)
movq -56(%rbp), %rdi
movq -760(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
movq -752(%rbp), %rsi
call evn_store@PLT
movq %rax, -776(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movq -8(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -792(%rbp)
movq -792(%rbp), %rax
leave
ret
.size f47, .-f47
.text
.p2align 4
.type f48, @function
f48:
pushq %rbp
movq %rsp, %rbp
subq $848, %rsp
movq %rdi, -832(%rbp)
movq %rsi, -840(%rbp)
leaq -824(%rbp), %rdi
movq $103, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf48_b0
.Lf48_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -840(%rbp), %rsi
leaq .Lroots_f48(%rip), %rdx
movq $105, %rcx
call evn_bind_roots@PLT
movq -832(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -840(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $18, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
call f5@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $800, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movq -96(%rbp), %rdi
movq -112(%rbp), %rsi
call f20@PLT
movq %rax, -120(%rbp)
movq -48(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movabsq $17, %rax
movq %rax, -136(%rbp)
movabsq $18, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_object@PLT
movq %rax, -152(%rbp)
movabsq $23, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_none@PLT
movq %rax, -168(%rbp)
movabsq $17, %rax
movq %rax, -176(%rbp)
movq -152(%rbp), %rdi
movq -176(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_init@PLT
movq %rax, -184(%rbp)
movabsq $23, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_none@PLT
movq %rax, -200(%rbp)
movabsq $16, %rax
movq %rax, -208(%rbp)
movq -152(%rbp), %rdi
movq -208(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_init@PLT
movq %rax, -216(%rbp)
movabsq $23, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_none@PLT
movq %rax, -232(%rbp)
movabsq $15, %rax
movq %rax, -240(%rbp)
movq -152(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $23, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_none@PLT
movq %rax, -264(%rbp)
movabsq $14, %rax
movq %rax, -272(%rbp)
movq -152(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $23, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_none@PLT
movq %rax, -296(%rbp)
movabsq $13, %rax
movq %rax, -304(%rbp)
movq -152(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $23, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_none@PLT
movq %rax, -328(%rbp)
movabsq $12, %rax
movq %rax, -336(%rbp)
movq -152(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movabsq $23, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_none@PLT
movq %rax, -360(%rbp)
movabsq $11, %rax
movq %rax, -368(%rbp)
movq -152(%rbp), %rdi
movq -368(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_init@PLT
movq %rax, -376(%rbp)
movabsq $23, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_none@PLT
movq %rax, -392(%rbp)
movabsq $10, %rax
movq %rax, -400(%rbp)
movq -152(%rbp), %rdi
movq -400(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_init@PLT
movq %rax, -408(%rbp)
movabsq $23, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_none@PLT
movq %rax, -424(%rbp)
movabsq $9, %rax
movq %rax, -432(%rbp)
movq -152(%rbp), %rdi
movq -432(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_init@PLT
movq %rax, -440(%rbp)
movabsq $23, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_none@PLT
movq %rax, -456(%rbp)
movabsq $8, %rax
movq %rax, -464(%rbp)
movq -152(%rbp), %rdi
movq -464(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_init@PLT
movq %rax, -472(%rbp)
movabsq $23, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_none@PLT
movq %rax, -488(%rbp)
movabsq $7, %rax
movq %rax, -496(%rbp)
movq -152(%rbp), %rdi
movq -496(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_init@PLT
movq %rax, -504(%rbp)
movabsq $23, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_none@PLT
movq %rax, -520(%rbp)
movabsq $6, %rax
movq %rax, -528(%rbp)
movq -152(%rbp), %rdi
movq -528(%rbp), %rsi
movq -520(%rbp), %rdx
call evn_init@PLT
movq %rax, -536(%rbp)
movabsq $23, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call evn_none@PLT
movq %rax, -552(%rbp)
movabsq $5, %rax
movq %rax, -560(%rbp)
movq -152(%rbp), %rdi
movq -560(%rbp), %rsi
movq -552(%rbp), %rdx
call evn_init@PLT
movq %rax, -568(%rbp)
movabsq $23, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_none@PLT
movq %rax, -584(%rbp)
movabsq $4, %rax
movq %rax, -592(%rbp)
movq -152(%rbp), %rdi
movq -592(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_init@PLT
movq %rax, -600(%rbp)
movabsq $23, %rax
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_none@PLT
movq %rax, -616(%rbp)
movabsq $3, %rax
movq %rax, -624(%rbp)
movq -152(%rbp), %rdi
movq -624(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_init@PLT
movq %rax, -632(%rbp)
movabsq $23, %rax
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_none@PLT
movq %rax, -648(%rbp)
movabsq $2, %rax
movq %rax, -656(%rbp)
movq -152(%rbp), %rdi
movq -656(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_init@PLT
movq %rax, -664(%rbp)
movabsq $21, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_none@PLT
movq %rax, -680(%rbp)
movabsq $1, %rax
movq %rax, -688(%rbp)
movq -152(%rbp), %rdi
movq -688(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_init@PLT
movq %rax, -696(%rbp)
movabsq $18, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call evn_none@PLT
movq %rax, -712(%rbp)
movabsq $0, %rax
movq %rax, -720(%rbp)
movq -152(%rbp), %rdi
movq -720(%rbp), %rsi
movq -712(%rbp), %rdx
call evn_init@PLT
movq %rax, -728(%rbp)
movabsq $22, %rax
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -744(%rbp)
movq -56(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_store@PLT
movq %rax, -752(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call f18@PLT
movq %rax, -768(%rbp)
movabsq $18, %rax
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -784(%rbp)
movabsq $0, %rax
movq %rax, -792(%rbp)
movq -56(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_store@PLT
movq %rax, -808(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movq -8(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -824(%rbp)
movq -824(%rbp), %rax
leave
ret
.size f48, .-f48
.text
.p2align 4
.type f49, @function
f49:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -512(%rbp)
movq %rsi, -520(%rbp)
leaq -504(%rbp), %rdi
movq $63, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf49_b0
.Lf49_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $512, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movq -200(%rbp), %rdi
movq -216(%rbp), %rsi
call f20@PLT
movq %rax, -224(%rbp)
movq -48(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movabsq $16, %rax
movq %rax, -240(%rbp)
movabsq $7, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_object@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $6, %rax
movq %rax, -272(%rbp)
movq -256(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $23, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_none@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -256(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $4, %rax
movq %rax, -336(%rbp)
movq -256(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $3, %rax
movq %rax, -360(%rbp)
movq -256(%rbp), %rdi
movq -360(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_init@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_bool@PLT
movq %rax, -384(%rbp)
movabsq $2, %rax
movq %rax, -392(%rbp)
movq -256(%rbp), %rdi
movq -392(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_init@PLT
movq %rax, -400(%rbp)
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_bool@PLT
movq %rax, -416(%rbp)
movabsq $1, %rax
movq %rax, -424(%rbp)
movq -256(%rbp), %rdi
movq -424(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_init@PLT
movq %rax, -432(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call f18@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -256(%rbp), %rdi
movq -456(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_init@PLT
movq %rax, -464(%rbp)
movabsq $24, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -480(%rbp)
movq -56(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_store@PLT
movq %rax, -488(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movq -8(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rax
leave
ret
.Lf49_b4:
jmp .Lf49_b5
.Lf49_b3:
leaq .Ldata_15(%rip), %rax
movq %rax, -168(%rbp)
movabsq $22, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call f32@PLT
movq %rax, -192(%rbp)
jmp .Lf49_b5
.Lf49_b2:
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf49_b4
jmp .Lf49_b3
.Lf49_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $33554432, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $9, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf49_b2
.Lf49_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -520(%rbp), %rsi
leaq .Lroots_f49(%rip), %rdx
movq $65, %rcx
call evn_bind_roots@PLT
movq -512(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -520(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf49_b1
jmp .Lf49_b2
.size f49, .-f49
.text
.p2align 4
.type f50, @function
f50:
pushq %rbp
movq %rsp, %rbp
subq $688, %rsp
movq %rdi, -664(%rbp)
movq %rsi, -672(%rbp)
movq %rdx, -680(%rbp)
leaq -656(%rbp), %rdi
movq $82, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf50_b0
.Lf50_b19:
jmp .Lf50_b14
.Lf50_b18:
jmp .Lf50_b19
.Lf50_b17:
leaq .Ldata_16(%rip), %rax
movq %rax, -616(%rbp)
movabsq $22, %rax
movq %rax, -624(%rbp)
movq -616(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_text@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call f32@PLT
movq %rax, -640(%rbp)
jmp .Lf50_b19
.Lf50_b16:
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -608(%rbp)
cmpq $0, -608(%rbp)
je .Lf50_b18
jmp .Lf50_b17
.Lf50_b15:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $6, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movabsq $12, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -552(%rbp)
movabsq $4, %rax
movq %rax, -560(%rbp)
movq -552(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_member@PLT
movq %rax, -568(%rbp)
movabsq $12, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_member@PLT
movq %rax, -584(%rbp)
movabsq $6, %rax
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -544(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_binary@PLT
movq %rax, -600(%rbp)
movq -600(%rbp), %rax
movq %rax, -496(%rbp)
jmp .Lf50_b16
.Lf50_b14:
jmp .Lf50_b6
.Lf50_b13:
jmp .Lf50_b14
.Lf50_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $6, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member@PLT
movq %rax, -440(%rbp)
movabsq $11, %rax
movq %rax, -448(%rbp)
movq -440(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member@PLT
movq %rax, -456(%rbp)
movabsq $1, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_int@PLT
movq %rax, -472(%rbp)
movabsq $6, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
movq -456(%rbp), %rsi
movq -472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
call evn_truth@PLT
movq %rax, -504(%rbp)
cmpq $0, -504(%rbp)
je .Lf50_b15
jmp .Lf50_b16
.Lf50_b11:
jmp .Lf50_b6
.Lf50_b10:
jmp .Lf50_b11
.Lf50_b9:
leaq .Ldata_17(%rip), %rax
movq %rax, -320(%rbp)
movabsq $35, %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_text@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call f32@PLT
movq %rax, -344(%rbp)
jmp .Lf50_b11
.Lf50_b8:
movq -232(%rbp), %rdi
call evn_truth@PLT
movq %rax, -312(%rbp)
cmpq $0, -312(%rbp)
je .Lf50_b10
jmp .Lf50_b9
.Lf50_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movabsq $6, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $4, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movabsq $6, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -264(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -232(%rbp)
jmp .Lf50_b8
.Lf50_b6:
call evn_void@PLT
movq %rax, -648(%rbp)
movq -8(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rax
leave
ret
.Lf50_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $6, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $4, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
movabsq $6, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -368(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_binary@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
cmpq $0, -416(%rbp)
je .Lf50_b13
jmp .Lf50_b12
.Lf50_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -240(%rbp)
cmpq $0, -240(%rbp)
je .Lf50_b7
jmp .Lf50_b8
.Lf50_b3:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf50_b5
jmp .Lf50_b4
.Lf50_b2:
jmp .Lf50_b3
.Lf50_b1:
leaq .Ldata_18(%rip), %rax
movq %rax, -160(%rbp)
movabsq $21, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_text@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call f32@PLT
movq %rax, -184(%rbp)
jmp .Lf50_b3
.Lf50_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -680(%rbp), %rsi
leaq .Lroots_f50(%rip), %rdx
movq $85, %rcx
call evn_bind_roots@PLT
movq -664(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -672(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -680(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $6, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call f3@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $4, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_member@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call f3@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $2, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf50_b2
jmp .Lf50_b1
.size f50, .-f50
.text
.p2align 4
.type f51, @function
f51:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
movq %rdi, -80(%rbp)
leaq -72(%rbp), %rdi
movq $9, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf51_b0
.Lf51_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -80(%rbp), %rsi
leaq .Lroots_f51(%rip), %rdx
movq $10, %rcx
call evn_bind_roots@PLT
movq -80(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $11, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call f34@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -8(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -72(%rbp)
movq -72(%rbp), %rax
leave
ret
.size f51, .-f51
.text
.p2align 4
.type f52, @function
f52:
pushq %rbp
movq %rsp, %rbp
subq $800, %rsp
movq %rdi, -776(%rbp)
movq %rsi, -784(%rbp)
movq %rdx, -792(%rbp)
leaq -768(%rbp), %rdi
movq $96, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf52_b0
.Lf52_b17:
movq -8(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rax
leave
ret
.Lf52_b16:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -672(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -680(%rbp)
movabsq $13, %rax
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
call evn_int@PLT
movq %rax, -696(%rbp)
movq -672(%rbp), %rdi
movq -680(%rbp), %rsi
movq -696(%rbp), %rdx
call f62@PLT
movq %rax, -704(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movabsq $13, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_int@PLT
movq %rax, -736(%rbp)
movq -712(%rbp), %rdi
movq -720(%rbp), %rsi
movq -736(%rbp), %rdx
call f62@PLT
movq %rax, -744(%rbp)
movabsq $8, %rax
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -704(%rbp), %rsi
movq -744(%rbp), %rdx
call evn_binary@PLT
movq %rax, -760(%rbp)
movq -760(%rbp), %rax
movq %rax, -656(%rbp)
jmp .Lf52_b17
.Lf52_b15:
movq -608(%rbp), %rax
movq %rax, -656(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -664(%rbp)
cmpq $0, -664(%rbp)
je .Lf52_b17
jmp .Lf52_b16
.Lf52_b14:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $8, %rax
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
movq -624(%rbp), %rsi
movq -632(%rbp), %rdx
call evn_binary@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
movq %rax, -608(%rbp)
jmp .Lf52_b15
.Lf52_b13:
movq -552(%rbp), %rax
movq %rax, -608(%rbp)
movq -552(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf52_b15
jmp .Lf52_b14
.Lf52_b12:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movabsq $0, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_int@PLT
movq %rax, -584(%rbp)
movabsq $6, %rax
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -568(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_binary@PLT
movq %rax, -600(%rbp)
movq -600(%rbp), %rax
movq %rax, -552(%rbp)
jmp .Lf52_b13
.Lf52_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $12, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movq -416(%rbp), %rdi
movq -424(%rbp), %rsi
movq -440(%rbp), %rdx
call f62@PLT
movq %rax, -448(%rbp)
movq -64(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -456(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movabsq $12, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movq -464(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call f62@PLT
movq %rax, -496(%rbp)
movq -72(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_store@PLT
movq %rax, -504(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $0, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_int@PLT
movq %rax, -528(%rbp)
movabsq $6, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -512(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movq -544(%rbp), %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
call evn_truth@PLT
movq %rax, -560(%rbp)
cmpq $0, -560(%rbp)
je .Lf52_b13
jmp .Lf52_b12
.Lf52_b10:
jmp .Lf52_b11
.Lf52_b9:
leaq .Ldata_19(%rip), %rax
movq %rax, -384(%rbp)
movabsq $23, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_text@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call f32@PLT
movq %rax, -408(%rbp)
jmp .Lf52_b11
.Lf52_b8:
movq -312(%rbp), %rdi
call evn_truth@PLT
movq %rax, -376(%rbp)
cmpq $0, -376(%rbp)
je .Lf52_b10
jmp .Lf52_b9
.Lf52_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $9, %rax
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_member@PLT
movq %rax, -352(%rbp)
movabsq $9, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -328(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
movq %rax, -312(%rbp)
jmp .Lf52_b8
.Lf52_b6:
movq -256(%rbp), %rax
movq %rax, -312(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf52_b7
jmp .Lf52_b8
.Lf52_b5:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movabsq $7, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -272(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -256(%rbp)
jmp .Lf52_b6
.Lf52_b4:
movq -192(%rbp), %rax
movq %rax, -256(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf52_b5
jmp .Lf52_b6
.Lf52_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $9, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movabsq $9, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -208(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -192(%rbp)
jmp .Lf52_b4
.Lf52_b2:
movq -136(%rbp), %rax
movq %rax, -192(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf52_b3
jmp .Lf52_b4
.Lf52_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $1, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $7, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -136(%rbp)
jmp .Lf52_b2
.Lf52_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -792(%rbp), %rsi
leaq .Lroots_f52(%rip), %rdx
movq $99, %rcx
call evn_bind_roots@PLT
movq -776(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -784(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -792(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $2, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf52_b1
jmp .Lf52_b2
.size f52, .-f52
.text
.p2align 4
.type f53, @function
f53:
pushq %rbp
movq %rsp, %rbp
subq $3808, %rsp
movq %rdi, -3808(%rbp)
leaq -3800(%rbp), %rdi
movq $475, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf53_b0
.Lf53_b41:
jmp .Lf53_b36
.Lf53_b40:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3416(%rbp)
movq -168(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3424(%rbp)
movabsq $15, %rax
movq %rax, -3432(%rbp)
movq -3432(%rbp), %rdi
call evn_int@PLT
movq %rax, -3440(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3448(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3456(%rbp)
movabsq $11, %rax
movq %rax, -3464(%rbp)
movq -3464(%rbp), %rdi
call evn_int@PLT
movq %rax, -3472(%rbp)
movq -3448(%rbp), %rdi
movq -3456(%rbp), %rsi
movq -3472(%rbp), %rdx
call f62@PLT
movq %rax, -3480(%rbp)
movq -3416(%rbp), %rdi
movq -3424(%rbp), %rsi
movq -3440(%rbp), %rdx
movq -3480(%rbp), %rcx
call f61@PLT
movq %rax, -3488(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3496(%rbp)
movabsq $1, %rax
movq %rax, -3504(%rbp)
movq -3504(%rbp), %rdi
call evn_int@PLT
movq %rax, -3512(%rbp)
movabsq $0, %rax
movq %rax, -3520(%rbp)
movq -3520(%rbp), %rdi
movq -3496(%rbp), %rsi
movq -3512(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3528(%rbp)
movq -152(%rbp), %rdi
movq -3528(%rbp), %rsi
call evn_store@PLT
movq %rax, -3536(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3544(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3552(%rbp)
movabsq $12, %rax
movq %rax, -3560(%rbp)
movq -3560(%rbp), %rdi
call evn_int@PLT
movq %rax, -3568(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3576(%rbp)
movq -3544(%rbp), %rdi
movq -3552(%rbp), %rsi
movq -3568(%rbp), %rdx
movq -3576(%rbp), %rcx
call f61@PLT
movq %rax, -3584(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3592(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3600(%rbp)
movabsq $15, %rax
movq %rax, -3608(%rbp)
movq -3608(%rbp), %rdi
call evn_int@PLT
movq %rax, -3616(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3624(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3632(%rbp)
movabsq $10, %rax
movq %rax, -3640(%rbp)
movq -3640(%rbp), %rdi
call evn_int@PLT
movq %rax, -3648(%rbp)
movq -3624(%rbp), %rdi
movq -3632(%rbp), %rsi
movq -3648(%rbp), %rdx
call f62@PLT
movq %rax, -3656(%rbp)
movq -3592(%rbp), %rdi
movq -3600(%rbp), %rsi
movq -3616(%rbp), %rdx
movq -3656(%rbp), %rcx
call f61@PLT
movq %rax, -3664(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3672(%rbp)
movabsq $1, %rax
movq %rax, -3680(%rbp)
movq -3680(%rbp), %rdi
call evn_int@PLT
movq %rax, -3688(%rbp)
movabsq $0, %rax
movq %rax, -3696(%rbp)
movq -3696(%rbp), %rdi
movq -3672(%rbp), %rsi
movq -3688(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3704(%rbp)
movq -160(%rbp), %rdi
movq -3704(%rbp), %rsi
call evn_store@PLT
movq %rax, -3712(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3720(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3728(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3736(%rbp)
movq -3720(%rbp), %rdi
movq -3728(%rbp), %rsi
movq -3736(%rbp), %rdx
call f58@PLT
movq %rax, -3744(%rbp)
jmp .Lf53_b41
.Lf53_b39:
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3272(%rbp)
movabsq $1, %rax
movq %rax, -3280(%rbp)
movq -3280(%rbp), %rdi
call evn_int@PLT
movq %rax, -3288(%rbp)
movabsq $0, %rax
movq %rax, -3296(%rbp)
movq -3296(%rbp), %rdi
movq -3272(%rbp), %rsi
movq -3288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3304(%rbp)
movq -152(%rbp), %rdi
movq -3304(%rbp), %rsi
call evn_store@PLT
movq %rax, -3312(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3320(%rbp)
movq -168(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3328(%rbp)
movabsq $13, %rax
movq %rax, -3336(%rbp)
movq -3336(%rbp), %rdi
call evn_int@PLT
movq %rax, -3344(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3352(%rbp)
movq -3320(%rbp), %rdi
movq -3328(%rbp), %rsi
movq -3344(%rbp), %rdx
movq -3352(%rbp), %rcx
call f61@PLT
movq %rax, -3360(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3368(%rbp)
movabsq $1, %rax
movq %rax, -3376(%rbp)
movq -3376(%rbp), %rdi
call evn_int@PLT
movq %rax, -3384(%rbp)
movabsq $1, %rax
movq %rax, -3392(%rbp)
movq -3392(%rbp), %rdi
movq -3368(%rbp), %rsi
movq -3384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3400(%rbp)
movq -160(%rbp), %rdi
movq -3400(%rbp), %rsi
call evn_store@PLT
movq %rax, -3408(%rbp)
jmp .Lf53_b41
.Lf53_b38:
movabsq $2, %rax
movq %rax, -3752(%rbp)
movq -3752(%rbp), %rdi
call evn_int@PLT
movq %rax, -3760(%rbp)
movabsq $0, %rax
movq %rax, -3768(%rbp)
movq -24(%rbp), %rdi
movq -3768(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -3776(%rbp)
movq -3776(%rbp), %rdi
movq -3760(%rbp), %rsi
call evn_store@PLT
movq %rax, -3784(%rbp)
call evn_void@PLT
movq %rax, -3792(%rbp)
movq -8(%rbp), %rdi
movq -3792(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -3800(%rbp)
movq -3800(%rbp), %rax
leave
ret
.Lf53_b37:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3144(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3152(%rbp)
movq -3144(%rbp), %rdi
movq -3152(%rbp), %rsi
call f57@PLT
movq %rax, -3160(%rbp)
movq -168(%rbp), %rdi
movq -3160(%rbp), %rsi
call evn_store@PLT
movq %rax, -3168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3176(%rbp)
movq -168(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3184(%rbp)
movabsq $15, %rax
movq %rax, -3192(%rbp)
movq -3192(%rbp), %rdi
call evn_int@PLT
movq %rax, -3200(%rbp)
movq -3176(%rbp), %rdi
movq -3184(%rbp), %rsi
movq -3200(%rbp), %rdx
call f62@PLT
movq %rax, -3208(%rbp)
movq -176(%rbp), %rdi
movq -3208(%rbp), %rsi
call evn_store@PLT
movq %rax, -3216(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3224(%rbp)
movabsq $0, %rax
movq %rax, -3232(%rbp)
movq -3232(%rbp), %rdi
call evn_int@PLT
movq %rax, -3240(%rbp)
movabsq $5, %rax
movq %rax, -3248(%rbp)
movq -3248(%rbp), %rdi
movq -3224(%rbp), %rsi
movq -3240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3256(%rbp)
movq -3256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -3264(%rbp)
cmpq $0, -3264(%rbp)
je .Lf53_b40
jmp .Lf53_b39
.Lf53_b36:
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3096(%rbp)
movabsq $0, %rax
movq %rax, -3104(%rbp)
movq -3104(%rbp), %rdi
call evn_int@PLT
movq %rax, -3112(%rbp)
movabsq $9, %rax
movq %rax, -3120(%rbp)
movq -3120(%rbp), %rdi
movq -3096(%rbp), %rsi
movq -3112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3128(%rbp)
movq -3128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -3136(%rbp)
cmpq $0, -3136(%rbp)
je .Lf53_b38
jmp .Lf53_b37
.Lf53_b35:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2680(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2688(%rbp)
movabsq $11, %rax
movq %rax, -2696(%rbp)
movq -2696(%rbp), %rdi
call evn_int@PLT
movq %rax, -2704(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2712(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2720(%rbp)
movabsq $10, %rax
movq %rax, -2728(%rbp)
movq -2728(%rbp), %rdi
call evn_int@PLT
movq %rax, -2736(%rbp)
movq -2712(%rbp), %rdi
movq -2720(%rbp), %rsi
movq -2736(%rbp), %rdx
call f62@PLT
movq %rax, -2744(%rbp)
movq -2680(%rbp), %rdi
movq -2688(%rbp), %rsi
movq -2704(%rbp), %rdx
movq -2744(%rbp), %rcx
call f61@PLT
movq %rax, -2752(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2760(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2768(%rbp)
movabsq $10, %rax
movq %rax, -2776(%rbp)
movq -2776(%rbp), %rdi
call evn_int@PLT
movq %rax, -2784(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2792(%rbp)
movq -2760(%rbp), %rdi
movq -2768(%rbp), %rsi
movq -2784(%rbp), %rdx
movq -2792(%rbp), %rcx
call f61@PLT
movq %rax, -2800(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2808(%rbp)
movabsq $1, %rax
movq %rax, -2816(%rbp)
movq -2816(%rbp), %rdi
call evn_int@PLT
movq %rax, -2824(%rbp)
movabsq $0, %rax
movq %rax, -2832(%rbp)
movq -2832(%rbp), %rdi
movq -2808(%rbp), %rsi
movq -2824(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2840(%rbp)
movq -48(%rbp), %rdi
movq -2840(%rbp), %rsi
call evn_store@PLT
movq %rax, -2848(%rbp)
jmp .Lf53_b30
.Lf53_b34:
jmp .Lf53_b35
.Lf53_b33:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2584(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2592(%rbp)
movabsq $7, %rax
movq %rax, -2600(%rbp)
movq -2600(%rbp), %rdi
call evn_int@PLT
movq %rax, -2608(%rbp)
movq -2584(%rbp), %rdi
movq -2592(%rbp), %rsi
movq -2608(%rbp), %rdx
call f62@PLT
movq %rax, -2616(%rbp)
movq -144(%rbp), %rdi
movq -2616(%rbp), %rsi
call evn_store@PLT
movq %rax, -2624(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2632(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2640(%rbp)
movabsq $7, %rax
movq %rax, -2648(%rbp)
movq -2648(%rbp), %rdi
call evn_int@PLT
movq %rax, -2656(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2664(%rbp)
movq -2632(%rbp), %rdi
movq -2640(%rbp), %rsi
movq -2656(%rbp), %rdx
movq -2664(%rbp), %rcx
call f61@PLT
movq %rax, -2672(%rbp)
jmp .Lf53_b35
.Lf53_b32:
movabsq $1, %rax
movq %rax, -2856(%rbp)
movq -2856(%rbp), %rdi
call evn_int@PLT
movq %rax, -2864(%rbp)
movq -152(%rbp), %rdi
movq -2864(%rbp), %rsi
call evn_store@PLT
movq %rax, -2872(%rbp)
movabsq $1, %rax
movq %rax, -2880(%rbp)
movq -2880(%rbp), %rdi
call evn_int@PLT
movq %rax, -2888(%rbp)
movq -160(%rbp), %rdi
movq -2888(%rbp), %rsi
call evn_store@PLT
movq %rax, -2896(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2904(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2912(%rbp)
movabsq $1, %rax
movq %rax, -2920(%rbp)
movq -2920(%rbp), %rdi
call evn_int@PLT
movq %rax, -2928(%rbp)
movq -2904(%rbp), %rdi
movq -2912(%rbp), %rsi
movq -2928(%rbp), %rdx
call f58@PLT
movq %rax, -2936(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2944(%rbp)
movabsq $1, %rax
movq %rax, -2952(%rbp)
movq -2952(%rbp), %rdi
call evn_int@PLT
movq %rax, -2960(%rbp)
movabsq $12, %rax
movq %rax, -2968(%rbp)
movq -2968(%rbp), %rdi
call evn_int@PLT
movq %rax, -2976(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2984(%rbp)
movq -2944(%rbp), %rdi
movq -2960(%rbp), %rsi
movq -2976(%rbp), %rdx
movq -2984(%rbp), %rcx
call f61@PLT
movq %rax, -2992(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3000(%rbp)
movabsq $1, %rax
movq %rax, -3008(%rbp)
movq -3008(%rbp), %rdi
call evn_int@PLT
movq %rax, -3016(%rbp)
movabsq $15, %rax
movq %rax, -3024(%rbp)
movq -3024(%rbp), %rdi
call evn_int@PLT
movq %rax, -3032(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3040(%rbp)
movabsq $1, %rax
movq %rax, -3048(%rbp)
movq -3048(%rbp), %rdi
call evn_int@PLT
movq %rax, -3056(%rbp)
movabsq $10, %rax
movq %rax, -3064(%rbp)
movq -3064(%rbp), %rdi
call evn_int@PLT
movq %rax, -3072(%rbp)
movq -3040(%rbp), %rdi
movq -3056(%rbp), %rsi
movq -3072(%rbp), %rdx
call f62@PLT
movq %rax, -3080(%rbp)
movq -3000(%rbp), %rdi
movq -3016(%rbp), %rsi
movq -3032(%rbp), %rdx
movq -3080(%rbp), %rcx
call f61@PLT
movq %rax, -3088(%rbp)
jmp .Lf53_b36
.Lf53_b31:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2384(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2392(%rbp)
movabsq $17, %rax
movq %rax, -2400(%rbp)
movq -2400(%rbp), %rdi
call evn_int@PLT
movq %rax, -2408(%rbp)
movq -2384(%rbp), %rdi
movq -2392(%rbp), %rsi
movq -2408(%rbp), %rdx
call f62@PLT
movq %rax, -2416(%rbp)
movq -136(%rbp), %rdi
movq -2416(%rbp), %rsi
call evn_store@PLT
movq %rax, -2424(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2432(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2440(%rbp)
movabsq $7, %rax
movq %rax, -2448(%rbp)
movq -2448(%rbp), %rdi
call evn_int@PLT
movq %rax, -2456(%rbp)
movq -2432(%rbp), %rdi
movq -2440(%rbp), %rsi
movq -2456(%rbp), %rdx
call f62@PLT
movq %rax, -2464(%rbp)
movq -144(%rbp), %rdi
movq -2464(%rbp), %rsi
call evn_store@PLT
movq %rax, -2472(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2480(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2488(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2496(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2504(%rbp)
movabsq $4, %rax
movq %rax, -2512(%rbp)
movq -2512(%rbp), %rdi
call evn_int@PLT
movq %rax, -2520(%rbp)
movq -2496(%rbp), %rdi
movq -2504(%rbp), %rsi
movq -2520(%rbp), %rdx
call f62@PLT
movq %rax, -2528(%rbp)
movabsq $17, %rax
movq %rax, -2536(%rbp)
movq -2536(%rbp), %rdi
call evn_int@PLT
movq %rax, -2544(%rbp)
movq -2488(%rbp), %rdi
movq -2528(%rbp), %rsi
movq -2544(%rbp), %rdx
call f62@PLT
movq %rax, -2552(%rbp)
movabsq $6, %rax
movq %rax, -2560(%rbp)
movq -2560(%rbp), %rdi
movq -2480(%rbp), %rsi
movq -2552(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2568(%rbp)
movq -2568(%rbp), %rdi
call evn_truth@PLT
movq %rax, -2576(%rbp)
cmpq $0, -2576(%rbp)
je .Lf53_b34
jmp .Lf53_b33
.Lf53_b30:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2328(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2336(%rbp)
movabsq $5, %rax
movq %rax, -2344(%rbp)
movq -2336(%rbp), %rdi
movq -2344(%rbp), %rsi
call evn_member@PLT
movq %rax, -2352(%rbp)
movabsq $8, %rax
movq %rax, -2360(%rbp)
movq -2360(%rbp), %rdi
movq -2328(%rbp), %rsi
movq -2352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2368(%rbp)
movq -2368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -2376(%rbp)
cmpq $0, -2376(%rbp)
je .Lf53_b32
jmp .Lf53_b31
.Lf53_b29:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2160(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2168(%rbp)
movabsq $7, %rax
movq %rax, -2176(%rbp)
movq -2176(%rbp), %rdi
call evn_int@PLT
movq %rax, -2184(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2192(%rbp)
movq -2160(%rbp), %rdi
movq -2168(%rbp), %rsi
movq -2184(%rbp), %rdx
movq -2192(%rbp), %rcx
call f61@PLT
movq %rax, -2200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2208(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2216(%rbp)
movabsq $9, %rax
movq %rax, -2224(%rbp)
movq -2224(%rbp), %rdi
call evn_int@PLT
movq %rax, -2232(%rbp)
movq -2208(%rbp), %rdi
movq -2216(%rbp), %rsi
movq -2232(%rbp), %rdx
call f62@PLT
movq %rax, -2240(%rbp)
movq -112(%rbp), %rdi
movq -2240(%rbp), %rsi
call evn_store@PLT
movq %rax, -2248(%rbp)
jmp .Lf53_b24
.Lf53_b28:
jmp .Lf53_b29
.Lf53_b27:
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2144(%rbp)
movq -128(%rbp), %rdi
movq -2144(%rbp), %rsi
call evn_store@PLT
movq %rax, -2152(%rbp)
jmp .Lf53_b29
.Lf53_b26:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2256(%rbp)
movabsq $1, %rax
movq %rax, -2264(%rbp)
movq -2264(%rbp), %rdi
call evn_int@PLT
movq %rax, -2272(%rbp)
movabsq $1, %rax
movq %rax, -2280(%rbp)
movq -2280(%rbp), %rdi
movq -2256(%rbp), %rsi
movq -2272(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2288(%rbp)
movq -48(%rbp), %rdi
movq -2288(%rbp), %rsi
call evn_store@PLT
movq %rax, -2296(%rbp)
jmp .Lf53_b12
.Lf53_b25:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1992(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2000(%rbp)
movq -1992(%rbp), %rdi
movq -2000(%rbp), %rsi
call f54@PLT
movq %rax, -2008(%rbp)
movq -120(%rbp), %rdi
movq -2008(%rbp), %rsi
call evn_store@PLT
movq %rax, -2016(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2024(%rbp)
movq -128(%rbp), %rdi
movq -2024(%rbp), %rsi
call evn_store@PLT
movq %rax, -2032(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2040(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2048(%rbp)
movabsq $4, %rax
movq %rax, -2056(%rbp)
movq -2056(%rbp), %rdi
call evn_int@PLT
movq %rax, -2064(%rbp)
movq -2040(%rbp), %rdi
movq -2048(%rbp), %rsi
movq -2064(%rbp), %rdx
call f62@PLT
movq %rax, -2072(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2080(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2088(%rbp)
movabsq $4, %rax
movq %rax, -2096(%rbp)
movq -2096(%rbp), %rdi
call evn_int@PLT
movq %rax, -2104(%rbp)
movq -2080(%rbp), %rdi
movq -2088(%rbp), %rsi
movq -2104(%rbp), %rdx
call f62@PLT
movq %rax, -2112(%rbp)
movabsq $7, %rax
movq %rax, -2120(%rbp)
movq -2120(%rbp), %rdi
movq -2072(%rbp), %rsi
movq -2112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2128(%rbp)
movq -2128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -2136(%rbp)
cmpq $0, -2136(%rbp)
je .Lf53_b28
jmp .Lf53_b27
.Lf53_b24:
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1944(%rbp)
movabsq $0, %rax
movq %rax, -1952(%rbp)
movq -1952(%rbp), %rdi
call evn_int@PLT
movq %rax, -1960(%rbp)
movabsq $6, %rax
movq %rax, -1968(%rbp)
movq -1968(%rbp), %rdi
movq -1944(%rbp), %rsi
movq -1960(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1976(%rbp)
movq -1976(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1984(%rbp)
cmpq $0, -1984(%rbp)
je .Lf53_b26
jmp .Lf53_b25
.Lf53_b23:
jmp .Lf53_b20
.Lf53_b22:
jmp .Lf53_b23
.Lf53_b21:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1440(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1448(%rbp)
movabsq $4, %rax
movq %rax, -1456(%rbp)
movq -1456(%rbp), %rdi
call evn_int@PLT
movq %rax, -1464(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1472(%rbp)
movq -1440(%rbp), %rdi
movq -1448(%rbp), %rsi
movq -1464(%rbp), %rdx
movq -1472(%rbp), %rcx
call f61@PLT
movq %rax, -1480(%rbp)
jmp .Lf53_b23
.Lf53_b20:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1488(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1496(%rbp)
movabsq $3, %rax
movq %rax, -1504(%rbp)
movq -1504(%rbp), %rdi
call evn_int@PLT
movq %rax, -1512(%rbp)
movq -1488(%rbp), %rdi
movq -1496(%rbp), %rsi
movq -1512(%rbp), %rdx
call f60@PLT
movq %rax, -1520(%rbp)
movq -64(%rbp), %rdi
movq -1520(%rbp), %rsi
call evn_store@PLT
movq %rax, -1528(%rbp)
jmp .Lf53_b15
.Lf53_b19:
jmp .Lf53_b20
.Lf53_b18:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1288(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1296(%rbp)
movq -1288(%rbp), %rdi
movq -1296(%rbp), %rsi
call f54@PLT
movq %rax, -1304(%rbp)
movq -80(%rbp), %rdi
movq -1304(%rbp), %rsi
call evn_store@PLT
movq %rax, -1312(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1320(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1328(%rbp)
movabsq $4, %rax
movq %rax, -1336(%rbp)
movq -1336(%rbp), %rdi
call evn_int@PLT
movq %rax, -1344(%rbp)
movq -1320(%rbp), %rdi
movq -1328(%rbp), %rsi
movq -1344(%rbp), %rdx
call f62@PLT
movq %rax, -1352(%rbp)
movq -88(%rbp), %rdi
movq -1352(%rbp), %rsi
call evn_store@PLT
movq %rax, -1360(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1368(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1376(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1384(%rbp)
movabsq $4, %rax
movq %rax, -1392(%rbp)
movq -1392(%rbp), %rdi
call evn_int@PLT
movq %rax, -1400(%rbp)
movq -1376(%rbp), %rdi
movq -1384(%rbp), %rsi
movq -1400(%rbp), %rdx
call f62@PLT
movq %rax, -1408(%rbp)
movabsq $7, %rax
movq %rax, -1416(%rbp)
movq -1416(%rbp), %rdi
movq -1368(%rbp), %rsi
movq -1408(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1424(%rbp)
movq -1424(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1432(%rbp)
cmpq $0, -1432(%rbp)
je .Lf53_b22
jmp .Lf53_b21
.Lf53_b17:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1536(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1544(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1552(%rbp)
movabsq $4, %rax
movq %rax, -1560(%rbp)
movq -1560(%rbp), %rdi
call evn_int@PLT
movq %rax, -1568(%rbp)
movq -1544(%rbp), %rdi
movq -1552(%rbp), %rsi
movq -1568(%rbp), %rdx
call f62@PLT
movq %rax, -1576(%rbp)
movabsq $17, %rax
movq %rax, -1584(%rbp)
movq -1584(%rbp), %rdi
call evn_int@PLT
movq %rax, -1592(%rbp)
movq -1536(%rbp), %rdi
movq -1576(%rbp), %rsi
movq -1592(%rbp), %rdx
call f62@PLT
movq %rax, -1600(%rbp)
movq -96(%rbp), %rdi
movq -1600(%rbp), %rsi
call evn_store@PLT
movq %rax, -1608(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1616(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1624(%rbp)
movabsq $9, %rax
movq %rax, -1632(%rbp)
movq -1632(%rbp), %rdi
call evn_int@PLT
movq %rax, -1640(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1648(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1656(%rbp)
movabsq $8, %rax
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rdi
call evn_int@PLT
movq %rax, -1672(%rbp)
movq -1648(%rbp), %rdi
movq -1656(%rbp), %rsi
movq -1672(%rbp), %rdx
call f62@PLT
movq %rax, -1680(%rbp)
movq -1616(%rbp), %rdi
movq -1624(%rbp), %rsi
movq -1640(%rbp), %rdx
movq -1680(%rbp), %rcx
call f61@PLT
movq %rax, -1688(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1696(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1704(%rbp)
movabsq $8, %rax
movq %rax, -1712(%rbp)
movq -1712(%rbp), %rdi
call evn_int@PLT
movq %rax, -1720(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1728(%rbp)
movq -1696(%rbp), %rdi
movq -1704(%rbp), %rsi
movq -1720(%rbp), %rdx
movq -1728(%rbp), %rcx
call f61@PLT
movq %rax, -1736(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1744(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1752(%rbp)
movabsq $3, %rax
movq %rax, -1760(%rbp)
movq -1760(%rbp), %rdi
call evn_int@PLT
movq %rax, -1768(%rbp)
movq -1744(%rbp), %rdi
movq -1752(%rbp), %rsi
movq -1768(%rbp), %rdx
call f62@PLT
movq %rax, -1776(%rbp)
movq -104(%rbp), %rdi
movq -1776(%rbp), %rsi
call evn_store@PLT
movq %rax, -1784(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1792(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1800(%rbp)
movabsq $5, %rax
movq %rax, -1808(%rbp)
movq -1808(%rbp), %rdi
call evn_int@PLT
movq %rax, -1816(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1824(%rbp)
movq -1792(%rbp), %rdi
movq -1800(%rbp), %rsi
movq -1816(%rbp), %rdx
movq -1824(%rbp), %rcx
call f61@PLT
movq %rax, -1832(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1840(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1848(%rbp)
movabsq $8, %rax
movq %rax, -1856(%rbp)
movq -1856(%rbp), %rdi
call evn_int@PLT
movq %rax, -1864(%rbp)
movq -1840(%rbp), %rdi
movq -1848(%rbp), %rsi
movq -1864(%rbp), %rdx
call f62@PLT
movq %rax, -1872(%rbp)
movq -112(%rbp), %rdi
movq -1872(%rbp), %rsi
call evn_store@PLT
movq %rax, -1880(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1888(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1896(%rbp)
movabsq $8, %rax
movq %rax, -1904(%rbp)
movq -1904(%rbp), %rdi
call evn_int@PLT
movq %rax, -1912(%rbp)
movabsq $0, %rax
movq %rax, -1920(%rbp)
movq -1920(%rbp), %rdi
call evn_int@PLT
movq %rax, -1928(%rbp)
movq -1888(%rbp), %rdi
movq -1896(%rbp), %rsi
movq -1912(%rbp), %rdx
movq -1928(%rbp), %rcx
call f61@PLT
movq %rax, -1936(%rbp)
jmp .Lf53_b24
.Lf53_b16:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1160(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $0, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
call evn_int@PLT
movq %rax, -1184(%rbp)
movq -1160(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1184(%rbp), %rdx
call f60@PLT
movq %rax, -1192(%rbp)
movq -72(%rbp), %rdi
movq -1192(%rbp), %rsi
call evn_store@PLT
movq %rax, -1200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1208(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movabsq $2, %rax
movq %rax, -1224(%rbp)
movq -1224(%rbp), %rdi
call evn_int@PLT
movq %rax, -1232(%rbp)
movq -1208(%rbp), %rdi
movq -1216(%rbp), %rsi
movq -1232(%rbp), %rdx
call f62@PLT
movq %rax, -1240(%rbp)
movabsq $0, %rax
movq %rax, -1248(%rbp)
movq -1248(%rbp), %rdi
call evn_int@PLT
movq %rax, -1256(%rbp)
movabsq $6, %rax
movq %rax, -1264(%rbp)
movq -1264(%rbp), %rdi
movq -1240(%rbp), %rsi
movq -1256(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1280(%rbp)
cmpq $0, -1280(%rbp)
je .Lf53_b19
jmp .Lf53_b18
.Lf53_b15:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1112(%rbp)
movabsq $0, %rax
movq %rax, -1120(%rbp)
movq -1120(%rbp), %rdi
call evn_int@PLT
movq %rax, -1128(%rbp)
movabsq $6, %rax
movq %rax, -1136(%rbp)
movq -1136(%rbp), %rdi
movq -1112(%rbp), %rsi
movq -1128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1144(%rbp)
movq -1144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1152(%rbp)
cmpq $0, -1152(%rbp)
je .Lf53_b17
jmp .Lf53_b16
.Lf53_b14:
movabsq $2, %rax
movq %rax, -2304(%rbp)
movq -2304(%rbp), %rdi
call evn_int@PLT
movq %rax, -2312(%rbp)
movq -48(%rbp), %rdi
movq -2312(%rbp), %rsi
call evn_store@PLT
movq %rax, -2320(%rbp)
jmp .Lf53_b30
.Lf53_b13:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1016(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movabsq $17, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
call evn_int@PLT
movq %rax, -1040(%rbp)
movq -1016(%rbp), %rdi
movq -1024(%rbp), %rsi
movq -1040(%rbp), %rdx
call f62@PLT
movq %rax, -1048(%rbp)
movq -56(%rbp), %rdi
movq -1048(%rbp), %rsi
call evn_store@PLT
movq %rax, -1056(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1064(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movabsq $1, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
call evn_int@PLT
movq %rax, -1088(%rbp)
movq -1064(%rbp), %rdi
movq -1072(%rbp), %rsi
movq -1088(%rbp), %rdx
call f62@PLT
movq %rax, -1096(%rbp)
movq -64(%rbp), %rdi
movq -1096(%rbp), %rsi
call evn_store@PLT
movq %rax, -1104(%rbp)
jmp .Lf53_b15
.Lf53_b12:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -968(%rbp)
movabsq $1, %rax
movq %rax, -976(%rbp)
movq -976(%rbp), %rdi
call evn_int@PLT
movq %rax, -984(%rbp)
movabsq $9, %rax
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
movq -968(%rbp), %rsi
movq -984(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1008(%rbp)
cmpq $0, -1008(%rbp)
je .Lf53_b14
jmp .Lf53_b13
.Lf53_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -936(%rbp)
movabsq $5, %rax
movq %rax, -944(%rbp)
movq -936(%rbp), %rdi
movq -944(%rbp), %rsi
call evn_member@PLT
movq %rax, -952(%rbp)
movq -48(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_store@PLT
movq %rax, -960(%rbp)
jmp .Lf53_b12
.Lf53_b10:
jmp .Lf53_b11
.Lf53_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -840(%rbp)
movabsq $10, %rax
movq %rax, -848(%rbp)
movq -840(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_member@PLT
movq %rax, -856(%rbp)
movabsq $4, %rax
movq %rax, -864(%rbp)
movq -856(%rbp), %rdi
movq -864(%rbp), %rsi
call evn_member@PLT
movq %rax, -872(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -880(%rbp)
movabsq $3, %rax
movq %rax, -888(%rbp)
movq -880(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_member@PLT
movq %rax, -896(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movabsq $2, %rax
movq %rax, -912(%rbp)
movq -904(%rbp), %rdi
movq -912(%rbp), %rsi
call evn_member@PLT
movq %rax, -920(%rbp)
movq -872(%rbp), %rdi
movq -896(%rbp), %rsi
movq -920(%rbp), %rdx
call f29@PLT
movq %rax, -928(%rbp)
jmp .Lf53_b11
.Lf53_b8:
movabsq $128, %rax
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
call evn_int@PLT
movq %rax, -600(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $5, %rax
movq %rax, -616(%rbp)
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
call evn_member@PLT
movq %rax, -624(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $4, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_member@PLT
movq %rax, -648(%rbp)
movabsq $0, %rax
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
movq -624(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_binary@PLT
movq %rax, -664(%rbp)
movabsq $1, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_int@PLT
movq %rax, -680(%rbp)
movabsq $0, %rax
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
movq -664(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_binary@PLT
movq %rax, -696(%rbp)
movabsq $2, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
movq -600(%rbp), %rsi
movq -696(%rbp), %rdx
call evn_binary@PLT
movq %rax, -712(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movabsq $2, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
movq -712(%rbp), %rsi
movq -720(%rbp), %rdx
call evn_binary@PLT
movq %rax, -736(%rbp)
movabsq $2, %rax
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_store@PLT
movq %rax, -760(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -768(%rbp)
movabsq $3, %rax
movq %rax, -776(%rbp)
movq -768(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_member@PLT
movq %rax, -784(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -792(%rbp)
movabsq $2, %rax
movq %rax, -800(%rbp)
movq -792(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_member@PLT
movq %rax, -808(%rbp)
movabsq $9, %rax
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
movq -784(%rbp), %rsi
movq -808(%rbp), %rdx
call evn_binary@PLT
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call evn_truth@PLT
movq %rax, -832(%rbp)
cmpq $0, -832(%rbp)
je .Lf53_b10
jmp .Lf53_b9
.Lf53_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $2, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_int@PLT
movq %rax, -512(%rbp)
movabsq $2, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
movq -496(%rbp), %rsi
movq -512(%rbp), %rdx
call evn_binary@PLT
movq %rax, -528(%rbp)
movq -40(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_store@PLT
movq %rax, -536(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $1, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $0, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -544(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movq -32(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_store@PLT
movq %rax, -584(%rbp)
jmp .Lf53_b6
.Lf53_b6:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movabsq $5, %rax
movq %rax, -456(%rbp)
movq -448(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member@PLT
movq %rax, -464(%rbp)
movabsq $7, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
movq -440(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_binary@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_truth@PLT
movq %rax, -488(%rbp)
cmpq $0, -488(%rbp)
je .Lf53_b8
jmp .Lf53_b7
.Lf53_b5:
movabsq $1, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $0, %rax
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -368(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call f55@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movq -32(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_store@PLT
movq %rax, -408(%rbp)
movabsq $2, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movq -40(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_store@PLT
movq %rax, -432(%rbp)
jmp .Lf53_b6
.Lf53_b4:
jmp .Lf53_b5
.Lf53_b3:
leaq .Ldata_20(%rip), %rax
movq %rax, -304(%rbp)
movabsq $32, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_text@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call f32@PLT
movq %rax, -328(%rbp)
jmp .Lf53_b5
.Lf53_b2:
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -296(%rbp)
cmpq $0, -296(%rbp)
je .Lf53_b4
jmp .Lf53_b3
.Lf53_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movabsq $0, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movabsq $6, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_binary@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
movq %rax, -224(%rbp)
jmp .Lf53_b2
.Lf53_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -3808(%rbp), %rsi
leaq .Lroots_f53(%rip), %rdx
movq $476, %rcx
call evn_bind_roots@PLT
movq -3808(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
call evn_void@PLT
movq %rax, -120(%rbp)
call evn_void@PLT
movq %rax, -128(%rbp)
call evn_void@PLT
movq %rax, -136(%rbp)
call evn_void@PLT
movq %rax, -144(%rbp)
call evn_void@PLT
movq %rax, -152(%rbp)
call evn_void@PLT
movq %rax, -160(%rbp)
call evn_void@PLT
movq %rax, -168(%rbp)
call evn_void@PLT
movq %rax, -176(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $1, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movabsq $1, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_unary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf53_b1
jmp .Lf53_b2
.size f53, .-f53
.text
.p2align 4
.type f54, @function
f54:
pushq %rbp
movq %rsp, %rbp
subq $1088, %rsp
movq %rdi, -1080(%rbp)
movq %rsi, -1088(%rbp)
leaq -1072(%rbp), %rdi
movq $134, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf54_b0
.Lf54_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -952(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movabsq $5, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
call evn_int@PLT
movq %rax, -976(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -984(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -992(%rbp)
movabsq $5, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
call evn_int@PLT
movq %rax, -1008(%rbp)
movq -984(%rbp), %rdi
movq -992(%rbp), %rsi
movq -1008(%rbp), %rdx
call f62@PLT
movq %rax, -1016(%rbp)
movq -952(%rbp), %rdi
movq -960(%rbp), %rsi
movq -976(%rbp), %rdx
movq -1016(%rbp), %rcx
call f61@PLT
movq %rax, -1024(%rbp)
jmp .Lf54_b7
.Lf54_b11:
jmp .Lf54_b12
.Lf54_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -912(%rbp)
movabsq $6, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
call evn_int@PLT
movq %rax, -928(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -936(%rbp)
movq -904(%rbp), %rdi
movq -912(%rbp), %rsi
movq -928(%rbp), %rdx
movq -936(%rbp), %rcx
call f61@PLT
movq %rax, -944(%rbp)
jmp .Lf54_b12
.Lf54_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1032(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1040(%rbp)
movabsq $6, %rax
movq %rax, -1048(%rbp)
movq -1048(%rbp), %rdi
call evn_int@PLT
movq %rax, -1056(%rbp)
movq -1032(%rbp), %rdi
movq -1040(%rbp), %rsi
movq -1056(%rbp), %rdx
call f62@PLT
movq %rax, -1064(%rbp)
movq -8(%rbp), %rdi
movq -1064(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1072(%rbp)
movq -1072(%rbp), %rax
leave
ret
.Lf54_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -584(%rbp)
movq -576(%rbp), %rdi
movq -584(%rbp), %rsi
call f57@PLT
movq %rax, -592(%rbp)
movq -48(%rbp), %rdi
movq -592(%rbp), %rsi
call evn_store@PLT
movq %rax, -600(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $1, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_int@PLT
movq %rax, -624(%rbp)
movabsq $1, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
movq -608(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_binary@PLT
movq %rax, -640(%rbp)
movq -56(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_store@PLT
movq %rax, -648(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movabsq $5, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_int@PLT
movq %rax, -680(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
movq -680(%rbp), %rdx
call f62@PLT
movq %rax, -688(%rbp)
movq -64(%rbp), %rdi
movq -688(%rbp), %rsi
call evn_store@PLT
movq %rax, -696(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movabsq $6, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_int@PLT
movq %rax, -728(%rbp)
movq -704(%rbp), %rdi
movq -712(%rbp), %rsi
movq -728(%rbp), %rdx
call f62@PLT
movq %rax, -736(%rbp)
movq -72(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_store@PLT
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -752(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movabsq $6, %rax
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
call evn_int@PLT
movq %rax, -776(%rbp)
movq -752(%rbp), %rdi
movq -760(%rbp), %rsi
movq -776(%rbp), %rdx
call f62@PLT
movq %rax, -784(%rbp)
movq -80(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_store@PLT
movq %rax, -792(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -800(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movabsq $4, %rax
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_int@PLT
movq %rax, -824(%rbp)
movq -800(%rbp), %rdi
movq -808(%rbp), %rsi
movq -824(%rbp), %rdx
call f62@PLT
movq %rax, -832(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -840(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movabsq $4, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
call evn_int@PLT
movq %rax, -864(%rbp)
movq -840(%rbp), %rdi
movq -848(%rbp), %rsi
movq -864(%rbp), %rdx
call f62@PLT
movq %rax, -872(%rbp)
movabsq $7, %rax
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
movq -832(%rbp), %rsi
movq -872(%rbp), %rdx
call evn_binary@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rdi
call evn_truth@PLT
movq %rax, -896(%rbp)
cmpq $0, -896(%rbp)
je .Lf54_b11
jmp .Lf54_b10
.Lf54_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $0, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
call evn_int@PLT
movq %rax, -544(%rbp)
movabsq $9, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
movq -528(%rbp), %rsi
movq -544(%rbp), %rdx
call evn_binary@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
call evn_truth@PLT
movq %rax, -568(%rbp)
cmpq $0, -568(%rbp)
je .Lf54_b9
jmp .Lf54_b8
.Lf54_b6:
jmp .Lf54_b7
.Lf54_b5:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -56(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_store@PLT
movq %rax, -424(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movq -432(%rbp), %rdi
movq -440(%rbp), %rsi
movq -448(%rbp), %rdx
call f58@PLT
movq %rax, -456(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movq -48(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_store@PLT
movq %rax, -472(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $5, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call evn_int@PLT
movq %rax, -504(%rbp)
movq -480(%rbp), %rdi
movq -488(%rbp), %rsi
movq -504(%rbp), %rdx
call f62@PLT
movq %rax, -512(%rbp)
movq -64(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_store@PLT
movq %rax, -520(%rbp)
jmp .Lf54_b4
.Lf54_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movabsq $5, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
movq -328(%rbp), %rdx
call f62@PLT
movq %rax, -336(%rbp)
movabsq $0, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movabsq $6, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -336(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -376(%rbp)
cmpq $0, -376(%rbp)
je .Lf54_b6
jmp .Lf54_b5
.Lf54_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -48(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_store@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movq -56(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $5, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_int@PLT
movq %rax, -280(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
movq -280(%rbp), %rdx
call f62@PLT
movq %rax, -288(%rbp)
movq -64(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
jmp .Lf54_b4
.Lf54_b2:
jmp .Lf54_b3
.Lf54_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $6, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
movq -192(%rbp), %rdx
call f62@PLT
movq %rax, -200(%rbp)
movq -8(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
leave
ret
.Lf54_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1088(%rbp), %rsi
leaq .Lroots_f54(%rip), %rdx
movq $136, %rcx
call evn_bind_roots@PLT
movq -1080(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1088(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $5, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call f62@PLT
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $5, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf54_b2
jmp .Lf54_b1
.size f54, .-f54
.text
.p2align 4
.type f55, @function
f55:
pushq %rbp
movq %rsp, %rbp
subq $816, %rsp
movq %rdi, -816(%rbp)
leaq -808(%rbp), %rdi
movq $101, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf55_b0
.Lf55_b9:
jmp .Lf55_b6
.Lf55_b8:
jmp .Lf55_b9
.Lf55_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movq -688(%rbp), %rdi
movq -696(%rbp), %rsi
movq -704(%rbp), %rdx
call f56@PLT
movq %rax, -712(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movabsq $1, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_int@PLT
movq %rax, -736(%rbp)
movabsq $0, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
movq -720(%rbp), %rsi
movq -736(%rbp), %rdx
call evn_binary@PLT
movq %rax, -752(%rbp)
movq -32(%rbp), %rdi
movq -752(%rbp), %rsi
call evn_store@PLT
movq %rax, -760(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -768(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -776(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movq -768(%rbp), %rdi
movq -776(%rbp), %rsi
movq -784(%rbp), %rdx
call f58@PLT
movq %rax, -792(%rbp)
jmp .Lf55_b9
.Lf55_b6:
jmp .Lf55_b1
.Lf55_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $4, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movabsq $1, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $0, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -416(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movabsq $4, %rax
movq %rax, -456(%rbp)
movq -24(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -472(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $15, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call evn_int@PLT
movq %rax, -504(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movabsq $2, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call evn_int@PLT
movq %rax, -536(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
movq -536(%rbp), %rdx
call f60@PLT
movq %rax, -544(%rbp)
movq -480(%rbp), %rdi
movq -488(%rbp), %rsi
movq -504(%rbp), %rdx
movq -544(%rbp), %rcx
call f61@PLT
movq %rax, -552(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movabsq $1, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_int@PLT
movq %rax, -584(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
movq -584(%rbp), %rdx
call f60@PLT
movq %rax, -592(%rbp)
movq -56(%rbp), %rdi
movq -592(%rbp), %rsi
call evn_store@PLT
movq %rax, -600(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movabsq $2, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
call evn_int@PLT
movq %rax, -632(%rbp)
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
movq -632(%rbp), %rdx
call f62@PLT
movq %rax, -640(%rbp)
movabsq $0, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
call evn_int@PLT
movq %rax, -656(%rbp)
movabsq $5, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
movq -640(%rbp), %rsi
movq -656(%rbp), %rdx
call evn_binary@PLT
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_truth@PLT
movq %rax, -680(%rbp)
cmpq $0, -680(%rbp)
je .Lf55_b8
jmp .Lf55_b7
.Lf55_b4:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $1, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movabsq $1, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -32(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_store@PLT
movq %rax, -392(%rbp)
jmp .Lf55_b6
.Lf55_b3:
call evn_void@PLT
movq %rax, -800(%rbp)
movq -8(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -808(%rbp)
movq -808(%rbp), %rax
leave
ret
.Lf55_b2:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call f57@PLT
movq %rax, -240(%rbp)
movq -40(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $15, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_int@PLT
movq %rax, -280(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
movq -280(%rbp), %rdx
call f62@PLT
movq %rax, -288(%rbp)
movq -48(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $0, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $5, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf55_b5
jmp .Lf55_b4
.Lf55_b1:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $0, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movabsq $9, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -176(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf55_b3
jmp .Lf55_b2
.Lf55_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -816(%rbp), %rsi
leaq .Lroots_f55(%rip), %rdx
movq $102, %rcx
call evn_bind_roots@PLT
movq -816(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $1, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call f56@PLT
movq %rax, -104(%rbp)
movabsq $1, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movq -32(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $1, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
call f58@PLT
movq %rax, -168(%rbp)
jmp .Lf55_b1
.size f55, .-f55
.text
.p2align 4
.type f56, @function
f56:
pushq %rbp
movq %rsp, %rbp
subq $544, %rsp
movq %rdi, -520(%rbp)
movq %rsi, -528(%rbp)
movq %rdx, -536(%rbp)
leaq -512(%rbp), %rdi
movq $64, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf56_b0
.Lf56_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -536(%rbp), %rsi
leaq .Lroots_f56(%rip), %rdx
movq $67, %rcx
call evn_bind_roots@PLT
movq -520(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -528(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -536(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $5, %rax
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_member@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movabsq $0, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $5, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movq -64(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_store@PLT
movq %rax, -176(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $2, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
movq -216(%rbp), %rcx
call f61@PLT
movq %rax, -224(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $3, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_int@PLT
movq %rax, -256(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
movq -256(%rbp), %rdx
movq -264(%rbp), %rcx
call f61@PLT
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $4, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
movq -304(%rbp), %rdx
movq -312(%rbp), %rcx
call f61@PLT
movq %rax, -320(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $6, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
movq -352(%rbp), %rdx
movq -360(%rbp), %rcx
call f61@PLT
movq %rax, -368(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $17, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
movq -408(%rbp), %rcx
call f61@PLT
movq %rax, -416(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $15, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $0, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_int@PLT
movq %rax, -480(%rbp)
movq -456(%rbp), %rdi
movq -464(%rbp), %rsi
movq -480(%rbp), %rdx
call f62@PLT
movq %rax, -488(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
movq -488(%rbp), %rcx
call f61@PLT
movq %rax, -496(%rbp)
call evn_void@PLT
movq %rax, -504(%rbp)
movq -8(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rax
leave
ret
.size f56, .-f56
.text
.p2align 4
.type f57, @function
f57:
pushq %rbp
movq %rsp, %rbp
subq $192, %rsp
movq %rdi, -176(%rbp)
movq %rsi, -184(%rbp)
leaq -168(%rbp), %rdi
movq $21, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf57_b0
.Lf57_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -184(%rbp), %rsi
leaq .Lroots_f57(%rip), %rdx
movq $23, %rcx
call evn_bind_roots@PLT
movq -176(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -184(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call f63@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $11, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $10, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $0, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -128(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -80(%rbp), %rdi
movq -104(%rbp), %rsi
movq -152(%rbp), %rdx
call f39@PLT
movq %rax, -160(%rbp)
movq -8(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rax
leave
ret
.size f57, .-f57
.text
.p2align 4
.type f58, @function
f58:
pushq %rbp
movq %rsp, %rbp
subq $224, %rsp
movq %rdi, -208(%rbp)
movq %rsi, -216(%rbp)
movq %rdx, -224(%rbp)
leaq -200(%rbp), %rdi
movq $25, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf58_b0
.Lf58_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -224(%rbp), %rsi
leaq .Lroots_f58(%rip), %rdx
movq $28, %rcx
call evn_bind_roots@PLT
movq -208(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -216(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -224(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call f63@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $11, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $10, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $6, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -144(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movq -96(%rbp), %rdi
movq -120(%rbp), %rsi
movq -168(%rbp), %rdx
movq -176(%rbp), %rcx
call f38@PLT
movq %rax, -184(%rbp)
call evn_void@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.size f58, .-f58
.text
.p2align 4
.type f59, @function
f59:
pushq %rbp
movq %rsp, %rbp
subq $1280, %rsp
movq %rdi, -1248(%rbp)
movq %rsi, -1256(%rbp)
movq %rdx, -1264(%rbp)
movq %rcx, -1272(%rbp)
leaq -1240(%rbp), %rdi
movq $155, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf59_b0
.Lf59_b17:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $7, %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_member@PLT
movq %rax, -616(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $4, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call evn_int@PLT
movq %rax, -640(%rbp)
movabsq $2, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
movq -624(%rbp), %rsi
movq -640(%rbp), %rdx
call evn_binary@PLT
movq %rax, -656(%rbp)
movabsq $0, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
movq -616(%rbp), %rsi
movq -656(%rbp), %rdx
call evn_binary@PLT
movq %rax, -672(%rbp)
movq -80(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_store@PLT
movq %rax, -680(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $11, %rax
movq %rax, -696(%rbp)
movq -688(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_member@PLT
movq %rax, -704(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movabsq $10, %rax
movq %rax, -720(%rbp)
movq -712(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_member@PLT
movq %rax, -728(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movq -704(%rbp), %rdi
movq -728(%rbp), %rsi
movq -736(%rbp), %rdx
movq -744(%rbp), %rcx
call f38@PLT
movq %rax, -752(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movabsq $11, %rax
movq %rax, -768(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_member@PLT
movq %rax, -776(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $10, %rax
movq %rax, -792(%rbp)
movq -784(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member@PLT
movq %rax, -800(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movabsq $1, %rax
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_int@PLT
movq %rax, -824(%rbp)
movabsq $0, %rax
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
movq -808(%rbp), %rsi
movq -824(%rbp), %rdx
call evn_binary@PLT
movq %rax, -840(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movq -776(%rbp), %rdi
movq -800(%rbp), %rsi
movq -840(%rbp), %rdx
movq -848(%rbp), %rcx
call f38@PLT
movq %rax, -856(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movabsq $11, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_member@PLT
movq %rax, -880(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -888(%rbp)
movabsq $10, %rax
movq %rax, -896(%rbp)
movq -888(%rbp), %rdi
movq -896(%rbp), %rsi
call evn_member@PLT
movq %rax, -904(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -912(%rbp)
movabsq $2, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
call evn_int@PLT
movq %rax, -928(%rbp)
movabsq $0, %rax
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
movq -912(%rbp), %rsi
movq -928(%rbp), %rdx
call evn_binary@PLT
movq %rax, -944(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -952(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movabsq $0, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
call evn_int@PLT
movq %rax, -976(%rbp)
movq -952(%rbp), %rdi
movq -960(%rbp), %rsi
movq -976(%rbp), %rdx
call f62@PLT
movq %rax, -984(%rbp)
movq -880(%rbp), %rdi
movq -904(%rbp), %rsi
movq -944(%rbp), %rdx
movq -984(%rbp), %rcx
call f38@PLT
movq %rax, -992(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1000(%rbp)
movabsq $11, %rax
movq %rax, -1008(%rbp)
movq -1000(%rbp), %rdi
movq -1008(%rbp), %rsi
call evn_member@PLT
movq %rax, -1016(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movabsq $10, %rax
movq %rax, -1032(%rbp)
movq -1024(%rbp), %rdi
movq -1032(%rbp), %rsi
call evn_member@PLT
movq %rax, -1040(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1048(%rbp)
movabsq $3, %rax
movq %rax, -1056(%rbp)
movq -1056(%rbp), %rdi
call evn_int@PLT
movq %rax, -1064(%rbp)
movabsq $0, %rax
movq %rax, -1072(%rbp)
movq -1072(%rbp), %rdi
movq -1048(%rbp), %rsi
movq -1064(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1080(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1088(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1096(%rbp)
movabsq $1, %rax
movq %rax, -1104(%rbp)
movq -1104(%rbp), %rdi
call evn_int@PLT
movq %rax, -1112(%rbp)
movq -1088(%rbp), %rdi
movq -1096(%rbp), %rsi
movq -1112(%rbp), %rdx
call f62@PLT
movq %rax, -1120(%rbp)
movq -1016(%rbp), %rdi
movq -1040(%rbp), %rsi
movq -1080(%rbp), %rdx
movq -1120(%rbp), %rcx
call f38@PLT
movq %rax, -1128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1136(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1144(%rbp)
movabsq $0, %rax
movq %rax, -1152(%rbp)
movq -1152(%rbp), %rdi
call evn_int@PLT
movq %rax, -1160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movq -1136(%rbp), %rdi
movq -1144(%rbp), %rsi
movq -1160(%rbp), %rdx
movq -1168(%rbp), %rcx
call f61@PLT
movq %rax, -1176(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1184(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1192(%rbp)
movabsq $1, %rax
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
call evn_int@PLT
movq %rax, -1208(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movq -1184(%rbp), %rdi
movq -1192(%rbp), %rsi
movq -1208(%rbp), %rdx
movq -1216(%rbp), %rcx
call f61@PLT
movq %rax, -1224(%rbp)
call evn_void@PLT
movq %rax, -1232(%rbp)
movq -8(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rax
leave
ret
.Lf59_b16:
jmp .Lf59_b17
.Lf59_b15:
leaq .Ldata_21(%rip), %rax
movq %rax, -568(%rbp)
movabsq $27, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_text@PLT
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call f32@PLT
movq %rax, -592(%rbp)
jmp .Lf59_b17
.Lf59_b14:
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -560(%rbp)
cmpq $0, -560(%rbp)
je .Lf59_b16
jmp .Lf59_b15
.Lf59_b13:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movabsq $9, %rax
movq %rax, -528(%rbp)
movq -520(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_member@PLT
movq %rax, -536(%rbp)
movabsq $9, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
movq -512(%rbp), %rsi
movq -536(%rbp), %rdx
call evn_binary@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rax
movq %rax, -496(%rbp)
jmp .Lf59_b14
.Lf59_b12:
movq -440(%rbp), %rax
movq %rax, -496(%rbp)
movq -440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -504(%rbp)
cmpq $0, -504(%rbp)
je .Lf59_b13
jmp .Lf59_b14
.Lf59_b11:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $1, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_int@PLT
movq %rax, -472(%rbp)
movabsq $7, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
movq -456(%rbp), %rsi
movq -472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
movq %rax, -440(%rbp)
jmp .Lf59_b12
.Lf59_b10:
movq -376(%rbp), %rax
movq %rax, -440(%rbp)
movq -376(%rbp), %rdi
call evn_truth@PLT
movq %rax, -448(%rbp)
cmpq $0, -448(%rbp)
je .Lf59_b11
jmp .Lf59_b12
.Lf59_b9:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $9, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movabsq $9, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -392(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_binary@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rax
movq %rax, -376(%rbp)
jmp .Lf59_b10
.Lf59_b8:
movq -320(%rbp), %rax
movq %rax, -376(%rbp)
movq -320(%rbp), %rdi
call evn_truth@PLT
movq %rax, -384(%rbp)
cmpq $0, -384(%rbp)
je .Lf59_b9
jmp .Lf59_b10
.Lf59_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $1, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movabsq $7, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -336(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
movq %rax, -320(%rbp)
jmp .Lf59_b8
.Lf59_b6:
movq -256(%rbp), %rax
movq %rax, -320(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -328(%rbp)
cmpq $0, -328(%rbp)
je .Lf59_b7
jmp .Lf59_b8
.Lf59_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $8, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movabsq $9, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -272(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
movq %rax, -256(%rbp)
jmp .Lf59_b6
.Lf59_b4:
movq -200(%rbp), %rax
movq %rax, -256(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf59_b5
jmp .Lf59_b6
.Lf59_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $7, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -200(%rbp)
jmp .Lf59_b4
.Lf59_b2:
movq -128(%rbp), %rax
movq %rax, -200(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf59_b3
jmp .Lf59_b4
.Lf59_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $0, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $6, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rax
movq %rax, -128(%rbp)
jmp .Lf59_b2
.Lf59_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1272(%rbp), %rsi
leaq .Lroots_f59(%rip), %rdx
movq $159, %rcx
call evn_bind_roots@PLT
movq -1248(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1256(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1264(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -1272(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movabsq $1, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_unary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf59_b1
jmp .Lf59_b2
.size f59, .-f59
.text
.p2align 4
.type f60, @function
f60:
pushq %rbp
movq %rsp, %rbp
subq $272, %rsp
movq %rdi, -248(%rbp)
movq %rsi, -256(%rbp)
movq %rdx, -264(%rbp)
leaq -240(%rbp), %rdi
movq $30, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf60_b0
.Lf60_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -264(%rbp), %rsi
leaq .Lroots_f60(%rip), %rdx
movq $33, %rcx
call evn_bind_roots@PLT
movq -248(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -256(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -264(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call f63@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $11, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $10, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $7, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $4, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $2, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -144(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $0, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -200(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -96(%rbp), %rdi
movq -120(%rbp), %rsi
movq -224(%rbp), %rdx
call f39@PLT
movq %rax, -232(%rbp)
movq -8(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rax
leave
ret
.size f60, .-f60
.text
.p2align 4
.type f61, @function
f61:
pushq %rbp
movq %rsp, %rbp
subq $272, %rsp
movq %rdi, -240(%rbp)
movq %rsi, -248(%rbp)
movq %rdx, -256(%rbp)
movq %rcx, -264(%rbp)
leaq -232(%rbp), %rdi
movq $29, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf61_b0
.Lf61_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -264(%rbp), %rsi
leaq .Lroots_f61(%rip), %rdx
movq $33, %rcx
call evn_bind_roots@PLT
movq -240(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -248(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -256(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -264(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call f63@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $11, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_member@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $10, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $18, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $2, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -176(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -112(%rbp), %rdi
movq -136(%rbp), %rsi
movq -200(%rbp), %rdx
movq -208(%rbp), %rcx
call f38@PLT
movq %rax, -216(%rbp)
call evn_void@PLT
movq %rax, -224(%rbp)
movq -8(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
leave
ret
.size f61, .-f61
.text
.p2align 4
.type f62, @function
f62:
pushq %rbp
movq %rsp, %rbp
subq $224, %rsp
movq %rdi, -208(%rbp)
movq %rsi, -216(%rbp)
movq %rdx, -224(%rbp)
leaq -200(%rbp), %rdi
movq $25, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf62_b0
.Lf62_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -224(%rbp), %rsi
leaq .Lroots_f62(%rip), %rdx
movq $28, %rcx
call evn_bind_roots@PLT
movq -208(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -216(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -224(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call f63@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $11, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $10, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $18, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $2, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $0, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -96(%rbp), %rdi
movq -120(%rbp), %rsi
movq -184(%rbp), %rdx
call f39@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.size f62, .-f62
.text
.p2align 4
.type f63, @function
f63:
pushq %rbp
movq %rsp, %rbp
subq $352, %rsp
movq %rdi, -344(%rbp)
leaq -336(%rbp), %rdi
movq $42, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf63_b0
.Lf63_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movabsq $3, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movabsq $1, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_int@PLT
movq %rax, -280(%rbp)
movabsq $0, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -264(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movabsq $3, %rax
movq %rax, -304(%rbp)
movq -24(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_store@PLT
movq %rax, -320(%rbp)
jmp .Lf63_b3
.Lf63_b5:
jmp .Lf63_b6
.Lf63_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $10, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movabsq $4, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movabsq $1, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movq -200(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call f29@PLT
movq %rax, -240(%rbp)
jmp .Lf63_b6
.Lf63_b3:
call evn_void@PLT
movq %rax, -328(%rbp)
movq -8(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rax
leave
ret
.Lf63_b2:
jmp .Lf63_b3
.Lf63_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $3, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_member@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $10, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -112(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf63_b5
jmp .Lf63_b4
.Lf63_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -344(%rbp), %rsi
leaq .Lroots_f63(%rip), %rdx
movq $43, %rcx
call evn_bind_roots@PLT
movq -344(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $0, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movabsq $1, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $5, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf63_b2
jmp .Lf63_b1
.size f63, .-f63
.text
.p2align 4
.type f64, @function
f64:
pushq %rbp
movq %rsp, %rbp
subq $1216, %rsp
movq %rdi, -1200(%rbp)
movq %rsi, -1208(%rbp)
movq %rdx, -1216(%rbp)
leaq -1192(%rbp), %rdi
movq $149, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf64_b0
.Lf64_b16:
movabsq $128, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
call evn_int@PLT
movq %rax, -1008(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1016(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movabsq $0, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
movq -1016(%rbp), %rsi
movq -1024(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1040(%rbp)
movabsq $1, %rax
movq %rax, -1048(%rbp)
movq -1048(%rbp), %rdi
call evn_int@PLT
movq %rax, -1056(%rbp)
movabsq $0, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
movq -1040(%rbp), %rsi
movq -1056(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1072(%rbp)
movabsq $2, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1072(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1088(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1096(%rbp)
movabsq $2, %rax
movq %rax, -1104(%rbp)
movq -1104(%rbp), %rdi
movq -1088(%rbp), %rsi
movq -1096(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1112(%rbp)
movabsq $2, %rax
movq %rax, -1120(%rbp)
movq -24(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1128(%rbp)
movq -1128(%rbp), %rdi
movq -1112(%rbp), %rsi
call evn_store@PLT
movq %rax, -1136(%rbp)
movabsq $1, %rax
movq %rax, -1144(%rbp)
movq -1144(%rbp), %rdi
call evn_bool@PLT
movq %rax, -1152(%rbp)
movabsq $1, %rax
movq %rax, -1160(%rbp)
movq -24(%rbp), %rdi
movq -1160(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1168(%rbp)
movq -1168(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_store@PLT
movq %rax, -1176(%rbp)
call evn_void@PLT
movq %rax, -1184(%rbp)
movq -8(%rbp), %rdi
movq -1184(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1192(%rbp)
movq -1192(%rbp), %rax
leave
ret
.Lf64_b15:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movabsq $2, %rax
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
call evn_int@PLT
movq %rax, -920(%rbp)
movabsq $2, %rax
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
movq -904(%rbp), %rsi
movq -920(%rbp), %rdx
call evn_binary@PLT
movq %rax, -936(%rbp)
movq -80(%rbp), %rdi
movq -936(%rbp), %rsi
call evn_store@PLT
movq %rax, -944(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -952(%rbp)
movabsq $1, %rax
movq %rax, -960(%rbp)
movq -960(%rbp), %rdi
call evn_int@PLT
movq %rax, -968(%rbp)
movabsq $0, %rax
movq %rax, -976(%rbp)
movq -976(%rbp), %rdi
movq -952(%rbp), %rsi
movq -968(%rbp), %rdx
call evn_binary@PLT
movq %rax, -984(%rbp)
movq -72(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_store@PLT
movq %rax, -992(%rbp)
jmp .Lf64_b14
.Lf64_b14:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movabsq $7, %rax
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
movq -864(%rbp), %rsi
movq -872(%rbp), %rdx
call evn_binary@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rdi
call evn_truth@PLT
movq %rax, -896(%rbp)
cmpq $0, -896(%rbp)
je .Lf64_b16
jmp .Lf64_b15
.Lf64_b13:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $9, %rax
movq %rax, -472(%rbp)
movq -24(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_store@PLT
movq %rax, -488(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $8, %rax
movq %rax, -504(%rbp)
movq -24(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_store@PLT
movq %rax, -520(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -536(%rbp)
movabsq $1, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call evn_int@PLT
movq %rax, -552(%rbp)
movabsq $0, %rax
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
movq -536(%rbp), %rsi
movq -552(%rbp), %rdx
call evn_binary@PLT
movq %rax, -568(%rbp)
movabsq $18, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_int@PLT
movq %rax, -584(%rbp)
movabsq $2, %rax
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -568(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_binary@PLT
movq %rax, -600(%rbp)
movq -528(%rbp), %rdi
movq -600(%rbp), %rsi
call f65@PLT
movq %rax, -608(%rbp)
movq -64(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_store@PLT
movq %rax, -616(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $1, %rax
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_int@PLT
movq %rax, -648(%rbp)
movabsq $0, %rax
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
movq -632(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_binary@PLT
movq %rax, -664(%rbp)
movabsq $4, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_int@PLT
movq %rax, -680(%rbp)
movabsq $2, %rax
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
movq -664(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_binary@PLT
movq %rax, -696(%rbp)
movq -624(%rbp), %rdi
movq -696(%rbp), %rsi
call f65@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -24(%rbp), %rdi
movq -712(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_store@PLT
movq %rax, -728(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movabsq $1, %rax
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
call evn_int@PLT
movq %rax, -760(%rbp)
movabsq $0, %rax
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
movq -744(%rbp), %rsi
movq -760(%rbp), %rdx
call evn_binary@PLT
movq %rax, -776(%rbp)
movq -736(%rbp), %rdi
movq -776(%rbp), %rsi
call f65@PLT
movq %rax, -784(%rbp)
movabsq $6, %rax
movq %rax, -792(%rbp)
movq -24(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_store@PLT
movq %rax, -808(%rbp)
movabsq $1, %rax
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_int@PLT
movq %rax, -824(%rbp)
movq -72(%rbp), %rdi
movq -824(%rbp), %rsi
call evn_store@PLT
movq %rax, -832(%rbp)
movabsq $2, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
call evn_int@PLT
movq %rax, -848(%rbp)
movq -80(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_store@PLT
movq %rax, -856(%rbp)
jmp .Lf64_b14
.Lf64_b12:
jmp .Lf64_b13
.Lf64_b11:
leaq .Ldata_22(%rip), %rax
movq %rax, -432(%rbp)
movabsq $29, %rax
movq %rax, -440(%rbp)
movq -432(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_text@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call f32@PLT
movq %rax, -456(%rbp)
jmp .Lf64_b13
.Lf64_b10:
movq -368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -424(%rbp)
cmpq $0, -424(%rbp)
je .Lf64_b12
jmp .Lf64_b11
.Lf64_b9:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $262144, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $9, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -416(%rbp), %rax
movq %rax, -368(%rbp)
jmp .Lf64_b10
.Lf64_b8:
movq -312(%rbp), %rax
movq %rax, -368(%rbp)
movq -312(%rbp), %rdi
call evn_truth@PLT
movq %rax, -376(%rbp)
cmpq $0, -376(%rbp)
je .Lf64_b9
jmp .Lf64_b10
.Lf64_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $0, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $7, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -328(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_binary@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rax
movq %rax, -312(%rbp)
jmp .Lf64_b8
.Lf64_b6:
movq -256(%rbp), %rax
movq %rax, -312(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf64_b7
jmp .Lf64_b8
.Lf64_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $65536, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movabsq $9, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -272(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -256(%rbp)
jmp .Lf64_b6
.Lf64_b4:
movq -200(%rbp), %rax
movq %rax, -256(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf64_b5
jmp .Lf64_b6
.Lf64_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $7, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -200(%rbp)
jmp .Lf64_b4
.Lf64_b2:
movq -112(%rbp), %rax
movq %rax, -200(%rbp)
movq -112(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf64_b3
jmp .Lf64_b4
.Lf64_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $11, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movabsq $4, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $6, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rax
movq %rax, -112(%rbp)
jmp .Lf64_b2
.Lf64_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1216(%rbp), %rsi
leaq .Lroots_f64(%rip), %rdx
movq $152, %rcx
call evn_bind_roots@PLT
movq -1200(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1208(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1216(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -120(%rbp)
cmpq $0, -120(%rbp)
je .Lf64_b1
jmp .Lf64_b2
.size f64, .-f64
.text
.p2align 4
.type f65, @function
f65:
pushq %rbp
movq %rsp, %rbp
subq $672, %rsp
movq %rdi, -664(%rbp)
movq %rsi, -672(%rbp)
leaq -656(%rbp), %rdi
movq $82, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf65_b0
.Lf65_b8:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -648(%rbp)
movq -8(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rax
leave
ret
.Lf65_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movabsq $11, %rax
movq %rax, -528(%rbp)
movq -520(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_member@PLT
movq %rax, -536(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $10, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member@PLT
movq %rax, -560(%rbp)
movabsq $0, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
call evn_int@PLT
movq %rax, -576(%rbp)
movq -536(%rbp), %rdi
movq -560(%rbp), %rsi
movq -576(%rbp), %rdx
call f37@PLT
movq %rax, -584(%rbp)
movq -64(%rbp), %rdi
movq -584(%rbp), %rsi
call evn_store@PLT
movq %rax, -592(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $1, %rax
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_int@PLT
movq %rax, -616(%rbp)
movabsq $0, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
movq -600(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_binary@PLT
movq %rax, -632(%rbp)
movq -56(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_store@PLT
movq %rax, -640(%rbp)
jmp .Lf65_b6
.Lf65_b6:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $7, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -480(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_truth@PLT
movq %rax, -512(%rbp)
cmpq $0, -512(%rbp)
je .Lf65_b8
jmp .Lf65_b7
.Lf65_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $11, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $4, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member@PLT
movq %rax, -440(%rbp)
movq -48(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_store@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movq -56(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_store@PLT
movq %rax, -472(%rbp)
jmp .Lf65_b6
.Lf65_b4:
jmp .Lf65_b5
.Lf65_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $10, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member@PLT
movq %rax, -272(%rbp)
movabsq $4, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $11, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movabsq $3, %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_member@PLT
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $11, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movabsq $4, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_member@PLT
movq %rax, -376(%rbp)
movabsq $1, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -336(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
movq -392(%rbp), %rdx
call f29@PLT
movq %rax, -400(%rbp)
jmp .Lf65_b5
.Lf65_b2:
movq -112(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf65_b4
jmp .Lf65_b3
.Lf65_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $11, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movabsq $3, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $11, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $4, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -168(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movabsq $9, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -128(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rax
movq %rax, -112(%rbp)
jmp .Lf65_b2
.Lf65_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -672(%rbp), %rsi
leaq .Lroots_f65(%rip), %rdx
movq $84, %rcx
call evn_bind_roots@PLT
movq -664(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -672(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $0, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movabsq $7, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -120(%rbp)
cmpq $0, -120(%rbp)
je .Lf65_b1
jmp .Lf65_b2
.size f65, .-f65
.text
.p2align 4
.type f66, @function
f66:
pushq %rbp
movq %rsp, %rbp
subq $592, %rsp
movq %rdi, -576(%rbp)
movq %rsi, -584(%rbp)
leaq -568(%rbp), %rdi
movq $71, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf66_b0
.Lf66_b3:
movabsq $25, %rax
movq %rax, -136(%rbp)
movabsq $12, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_object@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $33554432, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movq -160(%rbp), %rdi
movq -176(%rbp), %rsi
call f49@PLT
movq %rax, -184(%rbp)
movabsq $11, %rax
movq %rax, -192(%rbp)
movq -152(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $10, %rax
movq %rax, -216(%rbp)
movq -152(%rbp), %rdi
movq -216(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_init@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movabsq $9, %rax
movq %rax, -248(%rbp)
movq -152(%rbp), %rdi
movq -248(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_init@PLT
movq %rax, -256(%rbp)
movabsq $0, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movabsq $8, %rax
movq %rax, -280(%rbp)
movq -152(%rbp), %rdi
movq -280(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_init@PLT
movq %rax, -288(%rbp)
movabsq $0, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movabsq $7, %rax
movq %rax, -312(%rbp)
movq -152(%rbp), %rdi
movq -312(%rbp), %rsi
movq -304(%rbp), %rdx
call evn_init@PLT
movq %rax, -320(%rbp)
movabsq $0, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_int@PLT
movq %rax, -336(%rbp)
movabsq $6, %rax
movq %rax, -344(%rbp)
movq -152(%rbp), %rdi
movq -344(%rbp), %rsi
movq -336(%rbp), %rdx
call evn_init@PLT
movq %rax, -352(%rbp)
movabsq $0, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movabsq $5, %rax
movq %rax, -376(%rbp)
movq -152(%rbp), %rdi
movq -376(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_init@PLT
movq %rax, -384(%rbp)
movabsq $0, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $4, %rax
movq %rax, -408(%rbp)
movq -152(%rbp), %rdi
movq -408(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_init@PLT
movq %rax, -416(%rbp)
movabsq $0, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $3, %rax
movq %rax, -440(%rbp)
movq -152(%rbp), %rdi
movq -440(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_init@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $2, %rax
movq %rax, -472(%rbp)
movq -152(%rbp), %rdi
movq -472(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_init@PLT
movq %rax, -480(%rbp)
movabsq $0, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_bool@PLT
movq %rax, -496(%rbp)
movabsq $1, %rax
movq %rax, -504(%rbp)
movq -152(%rbp), %rdi
movq -504(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_init@PLT
movq %rax, -512(%rbp)
movabsq $0, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_int@PLT
movq %rax, -528(%rbp)
movabsq $0, %rax
movq %rax, -536(%rbp)
movq -152(%rbp), %rdi
movq -536(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_init@PLT
movq %rax, -544(%rbp)
movabsq $26, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -560(%rbp)
movq -8(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -568(%rbp)
movq -568(%rbp), %rax
leave
ret
.Lf66_b2:
jmp .Lf66_b3
.Lf66_b1:
leaq .Ldata_23(%rip), %rax
movq %rax, -104(%rbp)
movabsq $23, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_text@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call f32@PLT
movq %rax, -128(%rbp)
jmp .Lf66_b3
.Lf66_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -584(%rbp), %rsi
leaq .Lroots_f66(%rip), %rdx
movq $73, %rcx
call evn_bind_roots@PLT
movq -576(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -584(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $4, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $6, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -64(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -96(%rbp)
cmpq $0, -96(%rbp)
je .Lf66_b2
jmp .Lf66_b1
.size f66, .-f66
.text
.p2align 4
.type f67, @function
f67:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
leaq -312(%rbp), %rdi
movq $39, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf67_b0
.Lf67_b5:
movq -72(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -288(%rbp)
ud2
.Lf67_b4:
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_error@PLT
movq %rax, -96(%rbp)
movq -16(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $2, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
leaq .Ldata_24(%rip), %rax
movq %rax, -136(%rbp)
movabsq $1, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_text@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -128(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $3, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $0, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -168(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_output@PLT
movq %rax, -216(%rbp)
call evn_void@PLT
movq %rax, -224(%rbp)
movabsq $1, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
leaq .Ldata_25(%rip), %rax
movq %rax, -248(%rbp)
movabsq $5, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_builtin1@PLT
movq %rax, -264(%rbp)
call evn_void@PLT
movq %rax, -272(%rbp)
movq -8(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rax
leave
ret
.Lf67_b3:
movq -24(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
call evn_void@PLT
movq %rax, -304(%rbp)
movq -8(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
leave
ret
.Lf67_b2:
movq -32(%rbp), %rdi
call evn_pop@PLT
movq %rax, -64(%rbp)
call evn_saved@PLT
movq %rax, -72(%rbp)
movabsq $9, %rax
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_match@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf67_b5
jmp .Lf67_b4
.Lf67_b1:
call f68@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
call evn_pop@PLT
movq %rax, -56(%rbp)
jmp .Lf67_b3
.Lf67_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -312(%rbp), %rsi
leaq .Lroots_f67(%rip), %rdx
movq $39, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_frame@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf67_b2
jmp .Lf67_b1
.size f67, .-f67
.text
.p2align 4
.type f68, @function
f68:
pushq %rbp
movq %rsp, %rbp
subq $64, %rsp
leaq -56(%rbp), %rdi
movq $7, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf68_b0
.Lf68_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -56(%rbp), %rsi
leaq .Lroots_f68(%rip), %rdx
movq $7, %rcx
call evn_bind_roots@PLT
movabsq $128, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call f69@PLT
movq %rax, -32(%rbp)
movabsq $1, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_bool@PLT
movq %rax, -48(%rbp)
movq -8(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rax
leave
ret
.size f68, .-f68
.text
.p2align 4
.type f69, @function
f69:
pushq %rbp
movq %rsp, %rbp
subq $832, %rsp
movq %rdi, -824(%rbp)
leaq -816(%rbp), %rdi
movq $102, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf69_b0
.Lf69_b8:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_output@PLT
movq %rax, -728(%rbp)
call evn_void@PLT
movq %rax, -736(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
call f51@PLT
movq %rax, -752(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call f8@PLT
movq %rax, -768(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
call f2@PLT
movq %rax, -784(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call f2@PLT
movq %rax, -800(%rbp)
call evn_void@PLT
movq %rax, -808(%rbp)
movq -8(%rbp), %rdi
movq -808(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rax
leave
ret
.Lf69_b7:
jmp .Lf69_b8
.Lf69_b6:
movabsq $1, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movq -72(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_store@PLT
movq %rax, -712(%rbp)
jmp .Lf69_b8
.Lf69_b5:
movq -616(%rbp), %rdi
call evn_truth@PLT
movq %rax, -688(%rbp)
cmpq $0, -688(%rbp)
je .Lf69_b7
jmp .Lf69_b6
.Lf69_b4:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -640(%rbp)
movabsq $1, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
call evn_int@PLT
movq %rax, -656(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
movq -656(%rbp), %rdx
call f52@PLT
movq %rax, -664(%rbp)
movabsq $1, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_unary@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
movq %rax, -616(%rbp)
jmp .Lf69_b5
.Lf69_b3:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call f53@PLT
movq %rax, -448(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $5, %rax
movq %rax, -464(%rbp)
movq -456(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_member@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_output@PLT
movq %rax, -480(%rbp)
call evn_void@PLT
movq %rax, -488(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movabsq $7, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_int@PLT
movq %rax, -520(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
movq -520(%rbp), %rdx
call f62@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call evn_output@PLT
movq %rax, -536(%rbp)
call evn_void@PLT
movq %rax, -544(%rbp)
movabsq $0, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movq -72(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_store@PLT
movq %rax, -568(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $1, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movq -576(%rbp), %rdi
movq -592(%rbp), %rsi
movq -600(%rbp), %rdx
call f52@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rax
movq %rax, -616(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -624(%rbp)
cmpq $0, -624(%rbp)
je .Lf69_b5
jmp .Lf69_b4
.Lf69_b2:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $1, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_int@PLT
movq %rax, -360(%rbp)
movabsq $0, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
movq -344(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_binary@PLT
movq %rax, -376(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
movq -336(%rbp), %rdx
movq -376(%rbp), %rcx
call f59@PLT
movq %rax, -384(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $1, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call evn_int@PLT
movq %rax, -408(%rbp)
movabsq $0, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
movq -392(%rbp), %rsi
movq -408(%rbp), %rdx
call evn_binary@PLT
movq %rax, -424(%rbp)
movq -64(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_store@PLT
movq %rax, -432(%rbp)
jmp .Lf69_b1
.Lf69_b1:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $7, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -280(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call evn_truth@PLT
movq %rax, -312(%rbp)
cmpq $0, -312(%rbp)
je .Lf69_b3
jmp .Lf69_b2
.Lf69_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -824(%rbp), %rsi
leaq .Lroots_f69(%rip), %rdx
movq $103, %rcx
call evn_bind_roots@PLT
movq -824(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call f27@PLT
movq %rax, -80(%rbp)
movq -32(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_store@PLT
movq %rax, -88(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_bool@PLT
movq %rax, -112(%rbp)
movq -96(%rbp), %rdi
movq -112(%rbp), %rsi
call f24@PLT
movq %rax, -120(%rbp)
movq -40(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call f10@PLT
movq %rax, -144(%rbp)
movq -48(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_store@PLT
movq %rax, -152(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call f66@PLT
movq %rax, -176(%rbp)
movq -56(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $1, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
movq -240(%rbp), %rdx
call f64@PLT
movq %rax, -248(%rbp)
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movq -64(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_store@PLT
movq %rax, -272(%rbp)
jmp .Lf69_b1
.size f69, .-f69
.text
.p2align 4
.type f70, @function
f70:
pushq %rbp
movq %rsp, %rbp
subq $1136, %rsp
movq %rdi, -1120(%rbp)
movq %rsi, -1128(%rbp)
movq %rdx, -1136(%rbp)
leaq -1112(%rbp), %rdi
movq $139, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf70_b0
.Lf70_b15:
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
call evn_output@PLT
movq %rax, -928(%rbp)
call evn_void@PLT
movq %rax, -936(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $1, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
call evn_int@PLT
movq %rax, -960(%rbp)
movabsq $0, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
movq -944(%rbp), %rsi
movq -960(%rbp), %rdx
call evn_binary@PLT
movq %rax, -976(%rbp)
movq -112(%rbp), %rdi
movq -976(%rbp), %rsi
call evn_store@PLT
movq %rax, -984(%rbp)
jmp .Lf70_b10
.Lf70_b14:
jmp .Lf70_b15
.Lf70_b13:
movabsq $1, %rax
movq %rax, -896(%rbp)
movq -896(%rbp), %rdi
call evn_int@PLT
movq %rax, -904(%rbp)
movq -120(%rbp), %rdi
movq -904(%rbp), %rsi
call evn_store@PLT
movq %rax, -912(%rbp)
jmp .Lf70_b15
.Lf70_b12:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -992(%rbp)
movabsq $1, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
call evn_int@PLT
movq %rax, -1008(%rbp)
movabsq $0, %rax
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rdi
movq -992(%rbp), %rsi
movq -1008(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1024(%rbp)
movq -104(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_store@PLT
movq %rax, -1032(%rbp)
jmp .Lf70_b7
.Lf70_b11:
movabsq $0, %rax
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
call evn_int@PLT
movq %rax, -840(%rbp)
movq -120(%rbp), %rdi
movq -840(%rbp), %rsi
call evn_store@PLT
movq %rax, -848(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -856(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movq -856(%rbp), %rdi
movq -864(%rbp), %rsi
movq -872(%rbp), %rdx
call f52@PLT
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
call evn_truth@PLT
movq %rax, -888(%rbp)
cmpq $0, -888(%rbp)
je .Lf70_b14
jmp .Lf70_b13
.Lf70_b10:
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -792(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -800(%rbp)
movabsq $8, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
movq -792(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_truth@PLT
movq %rax, -824(%rbp)
cmpq $0, -824(%rbp)
je .Lf70_b12
jmp .Lf70_b11
.Lf70_b9:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
call f51@PLT
movq %rax, -1048(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movq -1056(%rbp), %rdi
call f8@PLT
movq %rax, -1064(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movq -1072(%rbp), %rdi
call f2@PLT
movq %rax, -1080(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
call f2@PLT
movq %rax, -1096(%rbp)
call evn_void@PLT
movq %rax, -1104(%rbp)
movq -8(%rbp), %rdi
movq -1104(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rax
leave
ret
.Lf70_b8:
movabsq $1, %rax
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
call evn_int@PLT
movq %rax, -776(%rbp)
movq -112(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_store@PLT
movq %rax, -784(%rbp)
jmp .Lf70_b10
.Lf70_b7:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $8, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
movq -728(%rbp), %rsi
movq -736(%rbp), %rdx
call evn_binary@PLT
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
call evn_truth@PLT
movq %rax, -760(%rbp)
cmpq $0, -760(%rbp)
je .Lf70_b9
jmp .Lf70_b8
.Lf70_b6:
movabsq $1, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call evn_int@PLT
movq %rax, -712(%rbp)
movq -104(%rbp), %rdi
movq -712(%rbp), %rsi
call evn_store@PLT
movq %rax, -720(%rbp)
jmp .Lf70_b7
.Lf70_b5:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $7, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_int@PLT
movq %rax, -624(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
movq -624(%rbp), %rdx
call f62@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call evn_output@PLT
movq %rax, -640(%rbp)
call evn_void@PLT
movq %rax, -648(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $1, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
call evn_int@PLT
movq %rax, -672(%rbp)
movabsq $0, %rax
movq %rax, -680(%rbp)
movq -680(%rbp), %rdi
movq -656(%rbp), %rsi
movq -672(%rbp), %rdx
call evn_binary@PLT
movq %rax, -688(%rbp)
movq -104(%rbp), %rdi
movq -688(%rbp), %rsi
call evn_store@PLT
movq %rax, -696(%rbp)
jmp .Lf70_b4
.Lf70_b4:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movabsq $8, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
movq -560(%rbp), %rsi
movq -568(%rbp), %rdx
call evn_binary@PLT
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_truth@PLT
movq %rax, -592(%rbp)
cmpq $0, -592(%rbp)
je .Lf70_b6
jmp .Lf70_b5
.Lf70_b3:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call f53@PLT
movq %rax, -528(%rbp)
movabsq $1, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
call evn_int@PLT
movq %rax, -544(%rbp)
movq -104(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_store@PLT
movq %rax, -552(%rbp)
jmp .Lf70_b4
.Lf70_b2:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $1, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movabsq $0, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
movq -400(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_index@PLT
movq %rax, -424(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -448(%rbp)
movq -432(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_index@PLT
movq %rax, -456(%rbp)
movq -352(%rbp), %rdi
movq -392(%rbp), %rsi
movq -424(%rbp), %rdx
movq -456(%rbp), %rcx
call f59@PLT
movq %rax, -464(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movabsq $1, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $0, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -96(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_store@PLT
movq %rax, -512(%rbp)
jmp .Lf70_b1
.Lf70_b1:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_count@PLT
movq %rax, -320(%rbp)
movabsq $7, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf70_b3
jmp .Lf70_b2
.Lf70_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1136(%rbp), %rsi
leaq .Lroots_f70(%rip), %rdx
movq $142, %rcx
call evn_bind_roots@PLT
movq -1120(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1128(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1136(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
call evn_void@PLT
movq %rax, -120(%rbp)
call f27@PLT
movq %rax, -128(%rbp)
movq -64(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_store@PLT
movq %rax, -136(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $0, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_bool@PLT
movq %rax, -160(%rbp)
movq -144(%rbp), %rdi
movq -160(%rbp), %rsi
call f24@PLT
movq %rax, -168(%rbp)
movq -72(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_store@PLT
movq %rax, -176(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call f10@PLT
movq %rax, -192(%rbp)
movq -80(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_store@PLT
movq %rax, -200(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call f66@PLT
movq %rax, -224(%rbp)
movq -88(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_count@PLT
movq %rax, -264(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
movq -264(%rbp), %rdx
call f64@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movq -96(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
jmp .Lf70_b1
.size f70, .-f70
.text
.p2align 4
.type erist_entry, @function
erist_entry:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lerist_entry_b0
.Lerist_entry_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_erist_entry(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
call f67@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size erist_entry, .-erist_entry
.section .rodata
.Lroots_f0:
.byte 1,1,1,0,1,2,1,2,0,1,2,1,2,0,1,2,1,2,0,1,2,1,2,1,1,1,1,2,1,2,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,6,0
.section .rodata
.Lroots_f1:
.byte 1,1,1,1,0,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f2:
.byte 1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f3:
.byte 1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f4:
.byte 1,1,1,0,1,2,1,2,2,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f5:
.byte 1,1,1,1,1,1,1,1,1,2,1,2,1,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f6:
.byte 1,1,1,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f7:
.byte 1,1,1,1,0,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,0,1,2,1,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,1,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f8:
.byte 1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f9:
.byte 1,1,1,1,2,1,1,1,6,0
.section .rodata
.Lroots_f10:
.byte 1,1,1,1,2,1,1,1,6,0
.section .rodata
.Lroots_f11:
.byte 1,1,1,1,2,1,1,1,6,0
.section .rodata
.Lroots_f12:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,1,2,2,1,2,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f13:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,0,2,1,2,1,1,2,2,0,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f14:
.byte 1,1,1,1,0,1,2,1,0,1,2,1,2,1,2,1,2,1,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,0,1,2,1,0,1,2,1,1,1,2,1,2,1,1,1,1,1,1,0,1,2,1,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f15:
.byte 1,1,1,0,1,2,1,2,0,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,0,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f16:
.byte 1,1,1,0,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,0,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f17:
.byte 1,1,1,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f18:
.byte 1,1,1,2,0,2,1,2,0,2,1,2,1,0,2,1,1,2,2,0,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f19:
.byte 1,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f20:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,0,2,1,1,2,2,1,1,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f21:
.byte 1,1,1,1,1,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f22:
.byte 1,1,1,1,0,1,2,1,2,1,2,1,2,1,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f23:
.byte 1,1,1,1,2,1,1,2,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,2,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f24:
.byte 1,1,1,1,1,2,1,2,1,2,1,2,1,1,1,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f25:
.byte 1,1,1,1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,0,2,1,0,2,1,2,0,2,1,0,2,1,2,1,1,2,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f26:
.byte 1,1,1,1,2,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f27:
.byte 1,1,1,2,1,2,1,2,6,0
.section .rodata
.Lroots_f28:
.byte 1,1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,0,2,1,0,2,1,2,0,2,1,2,0,2,1,2,1,2,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f29:
.byte 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f30:
.byte 1,1,1,0,2,0,2,1,0,2,1,0,2,1,2,3,0,2,1,2,3,1,2,2,0,1,2,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_0:
.byte 85,49,97,32,114,101,115,111,117,114,99,101,32,108,105,109,105,116,32,101,120,99,101,101,100,101,100,0
.section .rodata
.Ldata_1:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Lroots_f31:
.byte 1,1,1,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,2,3,1,2,2,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,0,1,2,1,0,1,1,1,1,1,6,0
.section .rodata
.Ldata_2:
.byte 85,49,97,32,97,116,116,101,109,112,116,32,99,97,110,99,101,108,108,101,100,0
.section .rodata
.Ldata_3:
.byte 99,97,110,99,101,108,108,101,100,0
.section .rodata
.Lroots_f32:
.byte 1,0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,1,2,2,1,1,6,0
.section .rodata
.Ldata_4:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Lroots_f33:
.byte 0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,2,3,1,2,2,6,0
.section .rodata
.Ldata_5:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,97,99,99,111,117,110,116,105,110,103,32,115,116,97,116,101,0
.section .rodata
.Ldata_6:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Lroots_f34:
.byte 1,1,1,1,1,2,1,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,2,0,1,2,1,2,0,1,2,1,0,1,2,1,2,1,1,2,3,2,1,2,1,1,1,1,6,0
.section .rodata
.Ldata_7:
.byte 100,111,117,98,108,101,32,99,108,111,115,101,32,111,102,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Lroots_f35:
.byte 1,1,1,1,1,1,1,2,1,2,1,2,1,0,1,2,1,2,0,1,2,1,1,1,1,2,1,2,1,2,1,0,1,2,1,1,2,0,1,2,1,1,2,1,2,1,2,1,0,1,2,1,2,0,1,2,1,0,1,2,1,2,1,1,1,2,1,2,1,1,1,2,1,2,1,2,1,0,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f36:
.byte 1,1,1,0,1,2,1,2,1,1,2,3,2,1,2,1,1,1,2,1,1,1,6,0
.section .rodata
.Ldata_8:
.byte 99,108,111,115,101,100,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Lroots_f37:
.byte 1,1,1,1,1,0,1,2,1,2,1,2,1,1,1,1,2,1,2,1,1,0,1,1,2,1,1,1,0,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,1,2,1,1,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f38:
.byte 1,1,1,1,1,1,1,1,1,2,1,2,1,1,0,1,1,2,1,1,1,1,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,1,2,1,2,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_9:
.byte 85,49,97,32,119,111,114,100,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Lroots_f39:
.byte 1,1,1,1,1,1,2,1,2,1,1,0,1,1,2,1,1,1,1,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,1,2,1,2,1,1,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_10:
.byte 85,49,97,32,119,111,114,100,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Lroots_f40:
.byte 1,1,1,1,1,1,1,2,1,0,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,0,1,2,1,2,1,0,1,1,0,1,2,1,1,1,1,1,0,1,1,1,2,1,2,1,2,1,1,2,1,2,1,0,1,1,1,0,1,2,1,2,1,2,1,1,1,1,2,1,2,1,2,1,2,1,0,1,2,1,2,1,0,1,2,0,1,1,2,1,0,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f41:
.byte 1,1,1,1,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f42:
.byte 1,1,1,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f43:
.byte 1,1,1,1,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f44:
.byte 1,1,1,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f45:
.byte 1,0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,2,3,1,2,2,1,1,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Ldata_11:
.byte 109,105,115,115,105,110,103,32,85,49,97,32,119,111,114,100,32,112,97,103,101,0
.section .rodata
.Ldata_12:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Lroots_f46:
.byte 1,0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,2,3,1,2,2,1,1,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Ldata_13:
.byte 109,105,115,115,105,110,103,32,85,49,97,32,114,97,100,105,120,32,110,111,100,101,0
.section .rodata
.Ldata_14:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Lroots_f47:
.byte 1,1,1,1,0,1,2,1,2,1,1,0,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,1,2,2,0,1,1,2,1,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f48:
.byte 1,1,1,1,0,1,2,1,2,1,1,0,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,1,2,2,0,1,1,2,1,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f49:
.byte 1,1,1,1,0,1,2,0,2,1,1,0,2,1,2,0,2,1,2,0,2,1,0,2,1,2,0,2,1,2,0,2,1,1,2,2,0,1,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_15:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,119,111,114,100,32,108,105,109,105,116,0
.section .rodata
.Lroots_f50:
.byte 1,1,1,1,1,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,1,2,3,2,1,2,1,1,1,2,1,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_16:
.byte 102,111,114,101,105,103,110,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Ldata_17:
.byte 105,109,109,117,116,97,98,108,101,32,111,114,32,102,111,114,101,105,103,110,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Ldata_18:
.byte 99,108,111,115,101,100,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Lroots_f51:
.byte 1,1,1,1,1,2,1,1,1,6,0
.section .rodata
.Lroots_f52:
.byte 1,1,1,1,1,2,1,1,2,1,1,1,1,2,1,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,0,1,1,2,1,1,0,1,1,2,1,1,1,1,2,3,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_19:
.byte 105,110,118,97,108,105,100,32,100,111,109,105,110,97,110,99,101,32,113,117,101,114,121,0
.section .rodata
.Lroots_f53:
.byte 1,1,1,0,1,2,1,2,1,1,1,1,0,1,2,1,2,1,1,1,1,2,1,1,1,2,1,1,1,1,1,2,1,1,0,1,2,1,2,1,1,1,1,2,1,1,1,2,1,1,0,1,2,1,2,1,1,1,1,2,1,1,0,1,2,1,2,1,2,1,2,1,2,1,0,1,1,2,1,1,0,1,1,1,2,1,2,1,2,1,1,1,1,2,1,2,1,1,2,1,2,1,1,1,1,2,1,2,1,1,1,2,1,1,0,1,2,0,1,2,0,1,2,1,2,1,1,1,1,2,1,1,1,1,1,2,1,1,1,2,1,1,1,1,1,2,1,1,0,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,1,1,0,1,1,2,1,1,0,1,1,2,1,1,2,1,2,1,2,1,1,0,1,2,0,1,2,1,2,1,0,1,1,2,1,1,1,1,1,2,1,1,0,1,2,1,2,1,1,2,1,1,1,1,2,1,1,0,1,0,1,1,1,2,1,2,1,2,1,1,1,2,1,2,1,1,0,1,1,2,1,1,1,1,1,2,1,1,0,1,1,2,1,1,1,1,1,2,1,1,1,1,1,2,1,1,1,2,1,1,0,1,1,2,1,1,2,1,1,1,0,1,1,2,1,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,1,0,1,1,2,1,1,0,1,1,1,2,1,2,1,2,1,1,2,1,1,0,1,1,2,1,1,2,1,2,1,2,1,0,1,1,2,1,1,0,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,1,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,2,0,1,2,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,1,0,1,2,0,1,2,1,1,0,1,2,1,2,1,1,2,3,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_20:
.byte 100,111,109,105,110,97,110,99,101,32,103,114,97,112,104,32,97,108,114,101,97,100,121,32,97,110,97,108,121,122,101,100,0
.section .rodata
.Lroots_f54:
.byte 1,1,1,1,1,2,1,1,1,1,1,2,1,1,1,2,1,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,1,1,2,1,1,0,1,1,2,1,1,0,1,1,2,1,1,0,1,1,2,1,1,0,1,2,1,2,1,0,1,1,1,2,1,2,1,2,1,0,1,1,2,1,1,0,1,1,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,0,1,1,2,1,1,0,1,2,0,1,1,1,1,2,1,1,2,1,2,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f55:
.byte 1,1,1,1,1,1,1,0,1,2,1,2,1,1,1,1,1,2,1,2,1,2,1,1,2,1,1,0,1,1,2,1,1,1,1,1,2,1,1,1,2,1,1,0,1,2,1,2,1,2,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,0,1,1,2,1,1,0,1,1,1,2,1,2,1,2,1,1,1,2,1,1,0,1,2,1,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f56:
.byte 1,1,1,1,1,1,1,1,2,1,1,1,2,1,1,1,1,1,2,1,1,1,1,1,2,1,1,1,1,1,2,1,1,1,1,1,2,1,1,1,1,1,2,1,1,0,1,2,1,0,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f57:
.byte 1,1,1,1,1,2,1,1,2,1,1,2,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f58:
.byte 1,1,1,1,1,1,1,1,2,1,1,2,1,1,2,1,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f59:
.byte 1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,2,1,1,1,1,1,2,1,1,1,2,1,2,1,1,2,1,1,2,1,1,1,1,2,1,1,1,2,1,2,1,1,2,1,1,2,1,1,1,1,2,1,2,1,1,2,1,1,2,1,1,1,1,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_21:
.byte 105,110,118,97,108,105,100,32,100,111,109,105,110,97,110,99,101,32,97,100,106,97,99,101,110,99,121,0
.section .rodata
.Lroots_f60:
.byte 1,1,1,1,1,1,2,1,1,2,1,2,1,2,1,1,2,1,1,2,1,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f61:
.byte 1,1,1,1,1,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f62:
.byte 1,1,1,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f63:
.byte 1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f64:
.byte 1,1,1,1,1,0,1,2,1,2,0,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,1,2,0,1,2,1,2,1,0,1,2,1,2,1,2,1,2,1,1,0,1,2,0,1,2,0,1,2,1,1,2,1,2,1,1,0,1,2,1,1,2,1,2,1,2,1,2,1,1,0,1,1,2,1,2,1,2,1,2,1,1,0,1,2,1,0,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_22:
.byte 105,110,118,97,108,105,100,32,100,111,109,105,110,97,110,99,101,32,103,114,97,112,104,32,115,104,97,112,101,0
.section .rodata
.Lroots_f65:
.byte 1,1,1,1,0,1,2,1,2,1,0,1,1,2,1,2,1,1,2,1,2,1,2,1,1,0,1,2,0,1,2,1,2,1,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f66:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,1,2,1,1,2,2,1,1,2,3,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_23:
.byte 102,111,114,101,105,103,110,32,100,111,109,105,110,97,110,99,101,32,112,104,97,115,101,0
.section .rodata
.Lroots_f67:
.byte 1,1,0,0,1,1,1,2,3,1,2,1,0,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,4,1,1,6,0
.section .rodata
.Ldata_24:
.byte 58,0
.section .rodata
.Ldata_25:
.byte 115,116,100,46,112,114,111,99,101,115,115,46,115,101,116,69,120,105,116,67,111,100,101,0
.section .rodata
.Lroots_f68:
.byte 1,1,2,1,1,2,6,0
.section .rodata
.Lroots_f69:
.byte 1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,1,2,2,1,2,1,1,2,1,1,2,1,1,1,1,2,1,0,1,2,1,0,1,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,1,1,2,1,2,1,1,1,1,2,1,2,1,1,0,1,2,1,1,2,1,2,1,1,1,0,1,1,1,0,1,1,0,1,1,2,1,0,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f70:
.byte 1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,2,1,2,1,0,1,2,1,2,1,1,0,1,0,1,2,2,1,1,1,1,0,1,2,2,1,2,1,1,0,1,2,2,1,2,1,1,0,1,2,0,1,2,1,2,1,1,0,1,1,2,1,1,2,1,2,1,1,0,1,2,1,1,0,1,2,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,1,0,1,2,1,1,1,1,1,0,1,1,1,0,1,1,0,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_erist_entry:
.byte 1,1,1,6,0
.section .data.rel.ro
.p2align 3
.globl ev_types
ev_types:
.long 0,0
.quad .Ltype_name_0
.quad 0
.quad 0
.long 1,0
.quad .Ltype_name_1
.quad 0
.quad 0
.long 2,0
.quad .Ltype_name_2
.quad 0
.quad 0
.long 3,0
.quad .Ltype_name_3
.quad 0
.quad 0
.long 4,0
.quad .Ltype_name_4
.quad 0
.quad 0
.long 5,0
.quad .Ltype_name_5
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_6
.quad 13
.quad .Ltype_fields_6
.long 9,6
.quad .Ltype_name_7
.quad 0
.quad 0
.long 8,7
.quad .Ltype_name_8
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_9
.quad 4
.quad .Ltype_fields_9
.long 6,-1
.quad .Ltype_name_10
.quad 5
.quad .Ltype_fields_10
.long 9,10
.quad .Ltype_name_11
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_12
.quad 3
.quad .Ltype_fields_12
.long 9,12
.quad .Ltype_name_13
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_14
.quad 3
.quad .Ltype_fields_14
.long 9,14
.quad .Ltype_name_15
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_16
.quad 7
.quad .Ltype_fields_16
.long 6,-1
.quad .Ltype_name_17
.quad 18
.quad .Ltype_fields_17
.long 8,13
.quad .Ltype_name_18
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_19
.quad 17
.quad .Ltype_fields_19
.long 9,19
.quad .Ltype_name_20
.quad 0
.quad 0
.long 8,20
.quad .Ltype_name_21
.quad 0
.quad 0
.long 9,17
.quad .Ltype_name_22
.quad 0
.quad 0
.long 8,22
.quad .Ltype_name_23
.quad 0
.quad 0
.long 9,16
.quad .Ltype_name_24
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_25
.quad 12
.quad .Ltype_fields_25
.long 9,25
.quad .Ltype_name_26
.quad 0
.quad 0
.long 7,1
.quad .Ltype_name_27
.quad 0
.quad 0
.globl ev_types_end
ev_types_end:
.Ltype_name_0:
.byte 0
.Ltype_name_1:
.byte 0
.Ltype_name_2:
.byte 0
.Ltype_name_3:
.byte 0
.Ltype_name_4:
.byte 0
.Ltype_name_5:
.byte 0
.Ltype_name_6:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,79,119,110,101,114,0
.p2align 2
.Ltype_fields_6:
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 8
.Ltype_name_7:
.byte 0
.Ltype_name_8:
.byte 0
.Ltype_name_9:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,76,105,109,105,116,69,114,114,111,114,0
.p2align 2
.Ltype_fields_9:
.long 1
.long 1
.long 4
.long 4
.Ltype_name_10:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,80,104,97,115,101,0
.p2align 2
.Ltype_fields_10:
.long 1
.long 1
.long 1
.long 1
.long 7
.Ltype_name_11:
.byte 0
.Ltype_name_12:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,65,108,108,111,99,97,116,105,111,110,0
.p2align 2
.Ltype_fields_12:
.long 1
.long 1
.long 7
.Ltype_name_13:
.byte 0
.Ltype_name_14:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,82,101,115,101,114,118,97,116,105,111,110,0
.p2align 2
.Ltype_fields_14:
.long 1
.long 1
.long 7
.Ltype_name_15:
.byte 0
.Ltype_name_16:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,119,111,114,100,115,46,87,111,114,100,115,0
.p2align 2
.Ltype_fields_16:
.long 13
.long 3
.long 3
.long 1
.long 1
.long 23
.long 7
.Ltype_name_17:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,119,111,114,100,115,46,78,111,100,101,0
.p2align 2
.Ltype_fields_17:
.long 18
.long 21
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.Ltype_name_18:
.byte 0
.Ltype_name_19:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,119,111,114,100,115,46,80,97,103,101,0
.p2align 2
.Ltype_fields_19:
.long 18
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.Ltype_name_20:
.byte 0
.Ltype_name_21:
.byte 0
.Ltype_name_22:
.byte 0
.Ltype_name_23:
.byte 0
.Ltype_name_24:
.byte 0
.Ltype_name_25:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,100,111,109,105,110,97,110,99,101,46,71,114,97,112,104,0
.p2align 2
.Ltype_fields_25:
.long 1
.long 3
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 11
.long 24
.Ltype_name_26:
.byte 0
.Ltype_name_27:
.byte 0
.section .note.GNU-stack,"",@progbits

