#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <limits.h>
#include <math.h>
#include <fenv.h>
#include <string.h>
#include <stddef.h>
#include <setjmp.h>
#include <errno.h>

typedef struct { size_t len; unsigned char *data; } eri_text;
typedef struct eri_handler_frame { jmp_buf env; struct eri_handler_frame *prev; } eri_handler_frame;
typedef struct eri_secondary_failure { const char *type; void *payload; eri_text message; struct eri_secondary_failure *next; } eri_secondary_failure;
typedef struct { const char *type; void *payload; eri_text message; eri_secondary_failure *secondary; } eri_failure_value;
typedef struct { eri_text f_message; } eri_error_view;
static eri_handler_frame *eri_handler_top = NULL;
static eri_failure_value eri_failure = {NULL,NULL,{0,NULL},NULL};

static _Noreturn void eri_fault(const char *m) { fprintf(stderr, "Eristavi runtime fault: %s\n", m); exit(1); }
static void *eri_alloc(size_t n){ void *p=malloc(n?n:1); if(!p)eri_fault("out of memory"); return p; }
static void *eri_realloc(void *p,size_t n){ void *q=realloc(p,n?n:1); if(!q)eri_fault("out of memory"); return q; }
static eri_text eri_text_from_bytes(const unsigned char *s,size_t n){ eri_text r={n,NULL}; if(n){r.data=(unsigned char*)eri_alloc(n); memcpy(r.data,s,n);} return r; }
static eri_text eri_text_from_cstr(const char *s){ return eri_text_from_bytes((const unsigned char*)s,strlen(s)); }
static bool eri_text_eq(eri_text a,eri_text b){ if(!a.len || !b.len)return a.len==b.len; return a.len==b.len && memcmp(a.data,b.data,a.len)==0; }

typedef struct eri_text_append_buffer { unsigned char *data; size_t used,capacity; struct eri_text_append_buffer *next; } eri_text_append_buffer;
static eri_text_append_buffer *eri_text_append_buckets[4096];
static size_t eri_text_append_hash(const unsigned char *data){return ((uintptr_t)data>>4)%4096;}
static unsigned char *eri_prefix_append(const unsigned char *prefix,size_t prefix_size,const unsigned char *suffix,size_t suffix_size){
    eri_text a={prefix_size,(unsigned char*)prefix},b={suffix_size,(unsigned char*)suffix};
    if(a.len>SIZE_MAX-b.len)eri_fault("Text size overflow");
    if(!b.len)return a.data;
    size_t length=a.len+b.len;
    eri_text_append_buffer *buffer=eri_text_append_buckets[eri_text_append_hash(a.data)];
    while(buffer && buffer->data!=a.data)buffer=buffer->next;
    if(buffer && buffer->used==a.len && length<=buffer->capacity){memmove(buffer->data+a.len,b.data,b.len);buffer->used=length;return buffer->data;}
    size_t capacity=32;while(capacity<length){if(capacity>SIZE_MAX/2){capacity=length;break;}capacity*=2;}
    unsigned char *data=eri_alloc(capacity);if(a.len)memcpy(data,a.data,a.len);memcpy(data+a.len,b.data,b.len);
    buffer=eri_alloc(sizeof(*buffer));size_t hash=eri_text_append_hash(data);
    *buffer=(eri_text_append_buffer){data,length,capacity,eri_text_append_buckets[hash]};eri_text_append_buckets[hash]=buffer;
    return data;
}
static eri_text eri_text_add(eri_text a,eri_text b){if(!b.len)return a;if(!a.len)return b;unsigned char *data=eri_prefix_append(a.data,a.len,b.data,b.len);return (eri_text){a.len+b.len,data};}

static char *eri_text_to_c_path(eri_text t){ if(t.len && memchr(t.data,0,t.len))return NULL; char *r=(char*)eri_alloc(t.len+1); if(t.len)memcpy(r,t.data,t.len); r[t.len]='\0'; return r; }
static _Noreturn void eri_fault_text(eri_text t){ fputs("Eristavi runtime fault: ",stderr); if(t.len)fwrite(t.data,1,t.len,stderr); fputc('\n',stderr); exit(1); }
static void eri_attach_secondary(eri_failure_value *primary, eri_failure_value secondary){ eri_secondary_failure *n=(eri_secondary_failure*)eri_alloc(sizeof(*n)); n->type=secondary.type; n->payload=secondary.payload; n->message=secondary.message; n->next=NULL; eri_secondary_failure **p=&primary->secondary; while(*p)p=&(*p)->next; *p=n; }
static _Noreturn void eri_raise(const char *type, void *payload, eri_text message){ eri_failure=(eri_failure_value){type,payload,message,NULL}; if(!eri_handler_top)eri_fault_text(message); longjmp(eri_handler_top->env,1); }
static _Noreturn void eri_propagate_saved(eri_failure_value f){ eri_failure=f; if(!eri_handler_top)eri_fault_text(f.message); longjmp(eri_handler_top->env,1); }

typedef struct { eri_text f_message; eri_text f_path; } eri_file_error;
typedef struct { eri_text path; char *c_path; FILE *handle; bool closed; bool writable; } eri_file;
static bool eri_utf8_valid(const unsigned char *s,size_t n){ size_t i=0; while(i<n){ unsigned c=s[i++]; if(c<=0x7f)continue; if(c>=0xc2&&c<=0xdf){ if(i>=n||(s[i]&0xc0)!=0x80)return false; i++; continue; } if(c>=0xe0&&c<=0xef){ if(i+1>=n)return false; unsigned c1=s[i],c2=s[i+1]; if((c1&0xc0)!=0x80||(c2&0xc0)!=0x80)return false; if(c==0xe0&&c1<0xa0)return false; if(c==0xed&&c1>=0xa0)return false; i+=2; continue; } if(c>=0xf0&&c<=0xf4){ if(i+2>=n)return false; unsigned c1=s[i],c2=s[i+1],c3=s[i+2]; if((c1&0xc0)!=0x80||(c2&0xc0)!=0x80||(c3&0xc0)!=0x80)return false; if(c==0xf0&&c1<0x90)return false; if(c==0xf4&&c1>=0x90)return false; i+=3; continue; } return false; } return true; }
static eri_failure_value eri_make_file_failure(const char *message,eri_text path){ eri_file_error *e=(eri_file_error*)eri_alloc(sizeof(*e)); e->f_message=eri_text_from_cstr(message?message:"file error"); e->f_path=path; return (eri_failure_value){"std.files.FileError",e,e->f_message,NULL}; }
static _Noreturn void eri_raise_file_failure(const char *message,eri_text path){ eri_failure_value f=eri_make_file_failure(message,path); eri_raise(f.type,f.payload,f.message); }
static _Noreturn void eri_fail_std_u002e_files_u002e_FileError(eri_file_error v){ eri_file_error *p=(eri_file_error*)eri_alloc(sizeof(*p)); *p=v; eri_raise("std.files.FileError",p,v.f_message); }
static eri_file eri_file_open(eri_text path){ char *cp=eri_text_to_c_path(path); if(!cp)eri_raise_file_failure("file path contains NUL",path); FILE *h=fopen(cp,"r+"); if(!h)eri_raise_file_failure(strerror(errno),path); return (eri_file){path,cp,h,false,true}; }
static eri_text eri_file_read_text(eri_file *f){ if(!f||f->closed||!f->handle)eri_fault("file resource is closed"); if(fseek(f->handle,0,SEEK_END)!=0)eri_raise_file_failure(strerror(errno),f->path); long n=ftell(f->handle); if(n<0)eri_raise_file_failure(strerror(errno),f->path); rewind(f->handle); unsigned char *buf=(unsigned char*)eri_alloc((size_t)n?((size_t)n):1); size_t got=fread(buf,1,(size_t)n,f->handle); if(got<(size_t)n&&ferror(f->handle))eri_raise_file_failure(strerror(errno),f->path); if(!eri_utf8_valid(buf,got))eri_raise_file_failure("invalid UTF-8",f->path); return eri_text_from_bytes(buf,got); }
static void eri_file_write_text(eri_file *f,eri_text text){ if(f&&!f->writable)eri_raise_file_failure("file was opened read-only",f->path); if(!f||f->closed||!f->handle)eri_fault("file resource is closed"); FILE *h=freopen(f->c_path,"w+",f->handle); if(!h){f->handle=NULL; f->closed=true; eri_raise_file_failure(strerror(errno),f->path);} f->handle=h; if(text.len&&fwrite(text.data,1,text.len,h)!=text.len)eri_raise_file_failure(strerror(errno),f->path); if(fflush(h)!=0)eri_raise_file_failure(strerror(errno),f->path); rewind(h); }
static bool eri_file_cleanup(eri_file *f,eri_failure_value *failure){ if(!f||f->closed)return false; FILE *h=f->handle; f->handle=NULL; f->closed=true; if(h&&fclose(h)!=0){ if(failure)*failure=eri_make_file_failure(strerror(errno),f->path); return true; } return false; }

static int64_t *eri_identity_Int_new(int64_t v){ int64_t *p=(int64_t*)eri_alloc(sizeof(int64_t)); *p=v; return p; }
static double *eri_identity_Float_new(double v){ double *p=(double*)eri_alloc(sizeof(double)); *p=v; return p; }
static bool *eri_identity_Bool_new(bool v){ bool *p=(bool*)eri_alloc(sizeof(bool)); *p=v; return p; }
static eri_text *eri_identity_Text_new(eri_text v){ eri_text *p=(eri_text*)eri_alloc(sizeof(eri_text)); *p=v; return p; }
static int64_t eri_iadd(int64_t a,int64_t b){ if((b>0&&a>INT64_MAX-b)||(b<0&&a<INT64_MIN-b))eri_fault("Int overflow"); return a+b; }
static int64_t eri_isub(int64_t a,int64_t b){ if((b<0&&a>INT64_MAX+b)||(b>0&&a<INT64_MIN+b))eri_fault("Int overflow"); return a-b; }
static int64_t eri_imul(int64_t a,int64_t b){ if(a==0||b==0)return 0; if((a==INT64_MIN&&b==-1)||(b==INT64_MIN&&a==-1))eri_fault("Int overflow"); if(a>0){ if(b>0){if(a>INT64_MAX/b)eri_fault("Int overflow");} else {if(b<INT64_MIN/a)eri_fault("Int overflow");}} else { if(b>0){if(a<INT64_MIN/b)eri_fault("Int overflow");} else {if(a!=0&&b<INT64_MAX/a)eri_fault("Int overflow");}} return a*b; }
static int64_t eri_idiv(int64_t a,int64_t b){ if(!b)eri_fault("Int division by zero"); if(a==INT64_MIN&&b==-1)eri_fault("Int overflow"); return a/b; }
static int64_t eri_irem(int64_t a,int64_t b){ if(!b)eri_fault("Int remainder by zero"); if(a==INT64_MIN&&b==-1)eri_fault("Int overflow"); return a%b; }
static int64_t eri_ineg(int64_t a){ if(a==INT64_MIN)eri_fault("Int overflow"); return -a; }
static double eri_fadd(double a,double b){ volatile double r=a+b; return r; }
static double eri_fsub(double a,double b){ volatile double r=a-b; return r; }
static double eri_fmul(double a,double b){ volatile double r=a*b; return r; }
static double eri_fdiv(double a,double b){ volatile double r; if(b==0.0){if(a==0.0||isnan(a))r=NAN;else r=copysign(INFINITY,copysign(1.0,a)*copysign(1.0,b));}else r=a/b; return r; }
static double eri_fneg(double a){ volatile double r=-a; return r; }
static void eri_out_int(int64_t v){ printf("%" PRId64 "\n",v); }
static void eri_out_float(double v){ printf("%.17g\n",v); }
static void eri_out_bool(bool v){ puts(v?"true":"false"); }
static void eri_out_text(eri_text v){ if(v.len)fwrite(v.data,1,v.len,stdout); fputc('\n',stdout); }

#define ERI_LIST_SCALAR(NAME, TYPE) \
typedef struct { size_t count; TYPE *data; } eri_list_##NAME; \
static eri_list_##NAME eri_list_##NAME##_make(size_t n,const TYPE *src){ eri_list_##NAME r={n,NULL}; if(n){r.data=(TYPE*)eri_alloc(sizeof(TYPE)*n); memcpy(r.data,src,sizeof(TYPE)*n);} return r; } \
static void eri_list_##NAME##_detach(eri_list_##NAME *v){ if(!v->count){v->data=NULL;return;} TYPE *p=(TYPE*)eri_alloc(sizeof(TYPE)*v->count); memcpy(p,v->data,sizeof(TYPE)*v->count); v->data=p; } \
static TYPE eri_list_##NAME##_get(eri_list_##NAME v,int64_t i){ if(i<0||(uint64_t)i>=v.count)eri_fault("List index out of bounds"); return v.data[i]; } \
static void eri_list_##NAME##_set(eri_list_##NAME *v,int64_t i,TYPE x){ if(i<0||(uint64_t)i>=v->count)eri_fault("List index out of bounds"); eri_list_##NAME##_detach(v); v->data[i]=x; } \
static void eri_list_##NAME##_add(eri_list_##NAME *v,TYPE x){ if(v->count>=SIZE_MAX/sizeof(TYPE))eri_fault("List size overflow"); v->data=(TYPE*)eri_prefix_append((const unsigned char*)v->data,v->count*sizeof(TYPE),(const unsigned char*)&x,sizeof(TYPE)); v->count++; } \
static bool eri_list_##NAME##_eq(eri_list_##NAME a,eri_list_##NAME b){ if(a.count!=b.count)return false; for(size_t i=0;i<a.count;i++){if(!(a.data[i]==b.data[i]))return false;} return true; }
ERI_LIST_SCALAR(int, int64_t)
ERI_LIST_SCALAR(float, double)
ERI_LIST_SCALAR(bool, bool)
typedef struct { size_t count; eri_text *data; } eri_list_text;
static eri_list_text eri_list_text_make(size_t n,const eri_text *src){ eri_list_text r={n,NULL}; if(n){r.data=(eri_text*)eri_alloc(sizeof(eri_text)*n); memcpy(r.data,src,sizeof(eri_text)*n);} return r; }
static void eri_list_text_detach(eri_list_text *v){ if(!v->count){v->data=NULL;return;} eri_text *p=(eri_text*)eri_alloc(sizeof(eri_text)*v->count); memcpy(p,v->data,sizeof(eri_text)*v->count); v->data=p; }
static eri_text eri_list_text_get(eri_list_text v,int64_t i){ if(i<0||(uint64_t)i>=v.count)eri_fault("List index out of bounds"); return v.data[i]; }
static void eri_list_text_set(eri_list_text *v,int64_t i,eri_text x){ if(i<0||(uint64_t)i>=v->count)eri_fault("List index out of bounds"); eri_list_text_detach(v); v->data[i]=x; }
static void eri_list_text_add(eri_list_text *v,eri_text x){ if(v->count>=SIZE_MAX/sizeof(eri_text))eri_fault("List size overflow"); v->data=(eri_text*)eri_prefix_append((const unsigned char*)v->data,v->count*sizeof(eri_text),(const unsigned char*)&x,sizeof(eri_text)); v->count++; }
static bool eri_list_text_eq(eri_list_text a,eri_list_text b){ if(a.count!=b.count)return false; for(size_t i=0;i<a.count;i++){if(!eri_text_eq(a.data[i],b.data[i]))return false;} return true; }


#include <sys/stat.h>

typedef struct { eri_text text; int kind; } eri_text_view;
enum { ERI_TEXT_VIEW_BYTES=1, ERI_TEXT_VIEW_SCALARS=2, ERI_TEXT_VIEW_CHARACTERS=3 };

static eri_text_view eri_text_view_make(eri_text text,int kind){ return (eri_text_view){text,kind}; }

static size_t eri_utf8_width(unsigned char c){
    if(c<=0x7f)return 1;
    if(c>=0xc2&&c<=0xdf)return 2;
    if(c>=0xe0&&c<=0xef)return 3;
    if(c>=0xf0&&c<=0xf4)return 4;
    eri_fault("invalid UTF-8 inside Text");
    return 0;
}

static size_t eri_text_scalar_count(eri_text text){
    size_t count=0;
    for(size_t i=0;i<text.len;){ i+=eri_utf8_width(text.data[i]); count++; }
    return count;
}

static eri_text eri_text_scalar_get(eri_text text,int64_t index){
    if(index<0)eri_fault("Text view index out of bounds");
    int64_t current=0;
    for(size_t i=0;i<text.len;){
        size_t width=eri_utf8_width(text.data[i]);
        if(current==index)return eri_text_from_bytes(text.data+i,width);
        i+=width; current++;
    }
    eri_fault("Text view index out of bounds");
    return eri_text_from_bytes(NULL,0);
}

static int64_t eri_text_byte_get(eri_text text,int64_t index){
    if(index<0||(uint64_t)index>=text.len)eri_fault("Text view index out of bounds");
    return (int64_t)text.data[index];
}

static bool eri_file_exists_path(eri_text path){
    char *cp=eri_text_to_c_path(path);
    if(!cp)eri_raise_file_failure("file path contains NUL",path);
    struct stat st;
    if(stat(cp,&st)==0)return true;
    if(errno==ENOENT)return false;
    eri_raise_file_failure(strerror(errno),path);
    return false;
}

static void eri_file_remove_path(eri_text path){
    char *cp=eri_text_to_c_path(path);
    if(!cp)eri_raise_file_failure("file path contains NUL",path);
    if(remove(cp)!=0)eri_raise_file_failure(strerror(errno),path);
}

/* Unicode 17.0.0 grapheme properties generated by pinned regex 2026.9.29. */

typedef struct { uint32_t first; uint32_t last; uint8_t value; } eri_unicode_range;

enum {
    ERI_GCB_OTHER=0, ERI_GCB_CR=1, ERI_GCB_LF=2, ERI_GCB_CONTROL=3,
    ERI_GCB_EXTEND=4, ERI_GCB_ZWJ=5, ERI_GCB_RI=6, ERI_GCB_PREPEND=7,
    ERI_GCB_SPACINGMARK=8, ERI_GCB_L=9, ERI_GCB_V=10, ERI_GCB_T=11,
    ERI_GCB_LV=12, ERI_GCB_LVT=13
};
enum { ERI_INCB_NONE=0, ERI_INCB_CONSONANT=1, ERI_INCB_EXTEND=2, ERI_INCB_LINKER=3 };

static const eri_unicode_range eri_gcb_table[] = {
    {0x0u,0x9u,3},
    {0xAu,0xAu,2},
    {0xBu,0xCu,3},
    {0xDu,0xDu,1},
    {0xEu,0x1Fu,3},
    {0x7Fu,0x9Fu,3},
    {0xADu,0xADu,3},
    {0x300u,0x36Fu,4},
    {0x483u,0x489u,4},
    {0x591u,0x5BDu,4},
    {0x5BFu,0x5BFu,4},
    {0x5C1u,0x5C2u,4},
    {0x5C4u,0x5C5u,4},
    {0x5C7u,0x5C9u,4},
    {0x600u,0x605u,7},
    {0x610u,0x61Au,4},
    {0x61Cu,0x61Cu,3},
    {0x64Bu,0x65Fu,4},
    {0x670u,0x670u,4},
    {0x6D6u,0x6DCu,4},
    {0x6DDu,0x6DDu,7},
    {0x6DFu,0x6E4u,4},
    {0x6E7u,0x6E8u,4},
    {0x6EAu,0x6EDu,4},
    {0x70Fu,0x70Fu,7},
    {0x711u,0x711u,4},
    {0x730u,0x74Au,4},
    {0x7A6u,0x7B0u,4},
    {0x7EBu,0x7F3u,4},
    {0x7FDu,0x7FDu,4},
    {0x816u,0x819u,4},
    {0x81Bu,0x823u,4},
    {0x825u,0x827u,4},
    {0x829u,0x82Du,4},
    {0x859u,0x85Bu,4},
    {0x890u,0x891u,7},
    {0x897u,0x89Fu,4},
    {0x8CAu,0x8E1u,4},
    {0x8E2u,0x8E2u,7},
    {0x8E3u,0x902u,4},
    {0x903u,0x903u,8},
    {0x93Au,0x93Au,4},
    {0x93Bu,0x93Bu,8},
    {0x93Cu,0x93Cu,4},
    {0x93Eu,0x940u,8},
    {0x941u,0x948u,4},
    {0x949u,0x94Cu,8},
    {0x94Du,0x94Du,4},
    {0x94Eu,0x94Fu,8},
    {0x951u,0x957u,4},
    {0x962u,0x963u,4},
    {0x981u,0x981u,4},
    {0x982u,0x983u,8},
    {0x9BCu,0x9BCu,4},
    {0x9BEu,0x9BEu,4},
    {0x9BFu,0x9C0u,8},
    {0x9C1u,0x9C4u,4},
    {0x9C7u,0x9C8u,8},
    {0x9CBu,0x9CCu,8},
    {0x9CDu,0x9CDu,4},
    {0x9D7u,0x9D7u,4},
    {0x9E2u,0x9E3u,4},
    {0x9FEu,0x9FEu,4},
    {0xA01u,0xA02u,4},
    {0xA03u,0xA03u,8},
    {0xA3Cu,0xA3Cu,4},
    {0xA3Eu,0xA40u,8},
    {0xA41u,0xA42u,4},
    {0xA47u,0xA48u,4},
    {0xA4Bu,0xA4Du,4},
    {0xA51u,0xA51u,4},
    {0xA70u,0xA71u,4},
    {0xA75u,0xA75u,4},
    {0xA81u,0xA82u,4},
    {0xA83u,0xA83u,8},
    {0xABCu,0xABCu,4},
    {0xABEu,0xAC0u,8},
    {0xAC1u,0xAC5u,4},
    {0xAC7u,0xAC8u,4},
    {0xAC9u,0xAC9u,8},
    {0xACBu,0xACCu,8},
    {0xACDu,0xACDu,4},
    {0xAE2u,0xAE3u,4},
    {0xAFAu,0xAFFu,4},
    {0xB01u,0xB01u,4},
    {0xB02u,0xB03u,8},
    {0xB3Cu,0xB3Cu,4},
    {0xB3Eu,0xB3Fu,4},
    {0xB40u,0xB40u,8},
    {0xB41u,0xB44u,4},
    {0xB47u,0xB48u,8},
    {0xB4Bu,0xB4Cu,8},
    {0xB4Du,0xB4Du,4},
    {0xB53u,0xB57u,4},
    {0xB62u,0xB63u,4},
    {0xB82u,0xB82u,4},
    {0xBBEu,0xBBEu,4},
    {0xBBFu,0xBBFu,8},
    {0xBC0u,0xBC0u,4},
    {0xBC1u,0xBC2u,8},
    {0xBC6u,0xBC8u,8},
    {0xBCAu,0xBCCu,8},
    {0xBCDu,0xBCDu,4},
    {0xBD7u,0xBD7u,4},
    {0xC00u,0xC00u,4},
    {0xC01u,0xC03u,8},
    {0xC04u,0xC04u,4},
    {0xC3Cu,0xC3Cu,4},
    {0xC3Eu,0xC40u,4},
    {0xC41u,0xC44u,8},
    {0xC46u,0xC48u,4},
    {0xC4Au,0xC4Du,4},
    {0xC55u,0xC56u,4},
    {0xC62u,0xC63u,4},
    {0xC81u,0xC81u,4},
    {0xC82u,0xC83u,8},
    {0xCBCu,0xCBCu,4},
    {0xCBEu,0xCBEu,8},
    {0xCBFu,0xCC0u,4},
    {0xCC1u,0xCC1u,8},
    {0xCC2u,0xCC2u,4},
    {0xCC3u,0xCC4u,8},
    {0xCC6u,0xCC8u,4},
    {0xCCAu,0xCCDu,4},
    {0xCD5u,0xCD6u,4},
    {0xCE2u,0xCE3u,4},
    {0xCF3u,0xCF3u,8},
    {0xD00u,0xD01u,4},
    {0xD02u,0xD03u,8},
    {0xD3Bu,0xD3Cu,4},
    {0xD3Eu,0xD3Eu,4},
    {0xD3Fu,0xD40u,8},
    {0xD41u,0xD44u,4},
    {0xD46u,0xD48u,8},
    {0xD4Au,0xD4Cu,8},
    {0xD4Du,0xD4Du,4},
    {0xD4Eu,0xD4Eu,7},
    {0xD57u,0xD57u,4},
    {0xD62u,0xD63u,4},
    {0xD81u,0xD81u,4},
    {0xD82u,0xD83u,8},
    {0xDCAu,0xDCAu,4},
    {0xDCFu,0xDCFu,4},
    {0xDD0u,0xDD1u,8},
    {0xDD2u,0xDD4u,4},
    {0xDD6u,0xDD6u,4},
    {0xDD8u,0xDDEu,8},
    {0xDDFu,0xDDFu,4},
    {0xDF2u,0xDF3u,8},
    {0xE31u,0xE31u,4},
    {0xE33u,0xE33u,8},
    {0xE34u,0xE3Au,4},
    {0xE47u,0xE4Eu,4},
    {0xEB1u,0xEB1u,4},
    {0xEB3u,0xEB3u,8},
    {0xEB4u,0xEBCu,4},
    {0xEC8u,0xECEu,4},
    {0xF18u,0xF19u,4},
    {0xF35u,0xF35u,4},
    {0xF37u,0xF37u,4},
    {0xF39u,0xF39u,4},
    {0xF3Eu,0xF3Fu,8},
    {0xF71u,0xF7Eu,4},
    {0xF7Fu,0xF7Fu,8},
    {0xF80u,0xF84u,4},
    {0xF86u,0xF87u,4},
    {0xF8Du,0xF97u,4},
    {0xF99u,0xFBCu,4},
    {0xFC6u,0xFC6u,4},
    {0x102Du,0x1030u,4},
    {0x1031u,0x1031u,8},
    {0x1032u,0x1037u,4},
    {0x1039u,0x103Au,4},
    {0x103Bu,0x103Cu,8},
    {0x103Du,0x103Eu,4},
    {0x1056u,0x1057u,8},
    {0x1058u,0x1059u,4},
    {0x105Eu,0x1060u,4},
    {0x1071u,0x1074u,4},
    {0x1082u,0x1082u,4},
    {0x1084u,0x1084u,8},
    {0x1085u,0x1086u,4},
    {0x108Du,0x108Du,4},
    {0x109Du,0x109Du,4},
    {0x1100u,0x115Fu,9},
    {0x1160u,0x11A7u,10},
    {0x11A8u,0x11FFu,11},
    {0x135Du,0x135Fu,4},
    {0x1712u,0x1715u,4},
    {0x1732u,0x1734u,4},
    {0x1752u,0x1753u,4},
    {0x1772u,0x1773u,4},
    {0x17B4u,0x17B5u,4},
    {0x17B6u,0x17B6u,8},
    {0x17B7u,0x17BDu,4},
    {0x17BEu,0x17C5u,8},
    {0x17C6u,0x17C6u,4},
    {0x17C7u,0x17C8u,8},
    {0x17C9u,0x17D3u,4},
    {0x17DDu,0x17DDu,4},
    {0x180Bu,0x180Du,4},
    {0x180Eu,0x180Eu,3},
    {0x180Fu,0x180Fu,4},
    {0x1885u,0x1886u,4},
    {0x18A9u,0x18A9u,4},
    {0x1920u,0x1922u,4},
    {0x1923u,0x1926u,8},
    {0x1927u,0x1928u,4},
    {0x1929u,0x192Bu,8},
    {0x1930u,0x1931u,8},
    {0x1932u,0x1932u,4},
    {0x1933u,0x1938u,8},
    {0x1939u,0x193Bu,4},
    {0x1A17u,0x1A18u,4},
    {0x1A19u,0x1A1Au,8},
    {0x1A1Bu,0x1A1Bu,4},
    {0x1A55u,0x1A55u,8},
    {0x1A56u,0x1A56u,4},
    {0x1A57u,0x1A57u,8},
    {0x1A58u,0x1A5Eu,4},
    {0x1A60u,0x1A60u,4},
    {0x1A62u,0x1A62u,4},
    {0x1A65u,0x1A6Cu,4},
    {0x1A6Du,0x1A72u,8},
    {0x1A73u,0x1A7Cu,4},
    {0x1A7Fu,0x1A7Fu,4},
    {0x1AB0u,0x1AF0u,4},
    {0x1B00u,0x1B03u,4},
    {0x1B04u,0x1B04u,8},
    {0x1B34u,0x1B3Du,4},
    {0x1B3Eu,0x1B41u,8},
    {0x1B42u,0x1B44u,4},
    {0x1B6Bu,0x1B73u,4},
    {0x1B80u,0x1B81u,4},
    {0x1B82u,0x1B82u,8},
    {0x1BA1u,0x1BA1u,8},
    {0x1BA2u,0x1BA5u,4},
    {0x1BA6u,0x1BA7u,8},
    {0x1BA8u,0x1BADu,4},
    {0x1BE6u,0x1BE6u,4},
    {0x1BE7u,0x1BE7u,8},
    {0x1BE8u,0x1BE9u,4},
    {0x1BEAu,0x1BECu,8},
    {0x1BEDu,0x1BEDu,4},
    {0x1BEEu,0x1BEEu,8},
    {0x1BEFu,0x1BF3u,4},
    {0x1C24u,0x1C2Bu,8},
    {0x1C2Cu,0x1C33u,4},
    {0x1C34u,0x1C35u,8},
    {0x1C36u,0x1C37u,4},
    {0x1CD0u,0x1CD2u,4},
    {0x1CD4u,0x1CE0u,4},
    {0x1CE1u,0x1CE1u,8},
    {0x1CE2u,0x1CE8u,4},
    {0x1CEDu,0x1CEDu,4},
    {0x1CF4u,0x1CF4u,4},
    {0x1CF7u,0x1CF7u,8},
    {0x1CF8u,0x1CF9u,4},
    {0x1DC0u,0x1DFFu,4},
    {0x200Bu,0x200Bu,3},
    {0x200Cu,0x200Cu,4},
    {0x200Du,0x200Du,5},
    {0x200Eu,0x200Fu,3},
    {0x2028u,0x202Eu,3},
    {0x2060u,0x206Fu,3},
    {0x20D0u,0x20F0u,4},
    {0x2CEFu,0x2CF1u,4},
    {0x2D7Fu,0x2D7Fu,4},
    {0x2DE0u,0x2DFFu,4},
    {0x302Au,0x302Fu,4},
    {0x3099u,0x309Au,4},
    {0xA66Fu,0xA672u,4},
    {0xA674u,0xA67Du,4},
    {0xA69Eu,0xA69Fu,4},
    {0xA6F0u,0xA6F1u,4},
    {0xA802u,0xA802u,4},
    {0xA806u,0xA806u,4},
    {0xA80Bu,0xA80Bu,4},
    {0xA823u,0xA824u,8},
    {0xA825u,0xA826u,4},
    {0xA827u,0xA827u,8},
    {0xA82Cu,0xA82Cu,4},
    {0xA880u,0xA881u,8},
    {0xA8B4u,0xA8C3u,8},
    {0xA8C4u,0xA8C5u,4},
    {0xA8E0u,0xA8F1u,4},
    {0xA8FFu,0xA8FFu,4},
    {0xA926u,0xA92Du,4},
    {0xA947u,0xA951u,4},
    {0xA952u,0xA952u,8},
    {0xA953u,0xA953u,4},
    {0xA960u,0xA97Cu,9},
    {0xA980u,0xA982u,4},
    {0xA983u,0xA983u,8},
    {0xA9B3u,0xA9B3u,4},
    {0xA9B4u,0xA9B5u,8},
    {0xA9B6u,0xA9B9u,4},
    {0xA9BAu,0xA9BBu,8},
    {0xA9BCu,0xA9BDu,4},
    {0xA9BEu,0xA9BFu,8},
    {0xA9C0u,0xA9C0u,4},
    {0xA9E5u,0xA9E5u,4},
    {0xAA29u,0xAA2Eu,4},
    {0xAA2Fu,0xAA30u,8},
    {0xAA31u,0xAA32u,4},
    {0xAA33u,0xAA34u,8},
    {0xAA35u,0xAA36u,4},
    {0xAA43u,0xAA43u,4},
    {0xAA4Cu,0xAA4Cu,4},
    {0xAA4Du,0xAA4Du,8},
    {0xAA7Cu,0xAA7Cu,4},
    {0xAAB0u,0xAAB0u,4},
    {0xAAB2u,0xAAB4u,4},
    {0xAAB7u,0xAAB8u,4},
    {0xAABEu,0xAABFu,4},
    {0xAAC1u,0xAAC1u,4},
    {0xAAEBu,0xAAEBu,8},
    {0xAAECu,0xAAEDu,4},
    {0xAAEEu,0xAAEFu,8},
    {0xAAF5u,0xAAF5u,8},
    {0xAAF6u,0xAAF6u,4},
    {0xABE3u,0xABE4u,8},
    {0xABE5u,0xABE5u,4},
    {0xABE6u,0xABE7u,8},
    {0xABE8u,0xABE8u,4},
    {0xABE9u,0xABEAu,8},
    {0xABECu,0xABECu,8},
    {0xABEDu,0xABEDu,4},
    {0xAC00u,0xAC00u,12},
    {0xAC01u,0xAC1Bu,13},
    {0xAC1Cu,0xAC1Cu,12},
    {0xAC1Du,0xAC37u,13},
    {0xAC38u,0xAC38u,12},
    {0xAC39u,0xAC53u,13},
    {0xAC54u,0xAC54u,12},
    {0xAC55u,0xAC6Fu,13},
    {0xAC70u,0xAC70u,12},
    {0xAC71u,0xAC8Bu,13},
    {0xAC8Cu,0xAC8Cu,12},
    {0xAC8Du,0xACA7u,13},
    {0xACA8u,0xACA8u,12},
    {0xACA9u,0xACC3u,13},
    {0xACC4u,0xACC4u,12},
    {0xACC5u,0xACDFu,13},
    {0xACE0u,0xACE0u,12},
    {0xACE1u,0xACFBu,13},
    {0xACFCu,0xACFCu,12},
    {0xACFDu,0xAD17u,13},
    {0xAD18u,0xAD18u,12},
    {0xAD19u,0xAD33u,13},
    {0xAD34u,0xAD34u,12},
    {0xAD35u,0xAD4Fu,13},
    {0xAD50u,0xAD50u,12},
    {0xAD51u,0xAD6Bu,13},
    {0xAD6Cu,0xAD6Cu,12},
    {0xAD6Du,0xAD87u,13},
    {0xAD88u,0xAD88u,12},
    {0xAD89u,0xADA3u,13},
    {0xADA4u,0xADA4u,12},
    {0xADA5u,0xADBFu,13},
    {0xADC0u,0xADC0u,12},
    {0xADC1u,0xADDBu,13},
    {0xADDCu,0xADDCu,12},
    {0xADDDu,0xADF7u,13},
    {0xADF8u,0xADF8u,12},
    {0xADF9u,0xAE13u,13},
    {0xAE14u,0xAE14u,12},
    {0xAE15u,0xAE2Fu,13},
    {0xAE30u,0xAE30u,12},
    {0xAE31u,0xAE4Bu,13},
    {0xAE4Cu,0xAE4Cu,12},
    {0xAE4Du,0xAE67u,13},
    {0xAE68u,0xAE68u,12},
    {0xAE69u,0xAE83u,13},
    {0xAE84u,0xAE84u,12},
    {0xAE85u,0xAE9Fu,13},
    {0xAEA0u,0xAEA0u,12},
    {0xAEA1u,0xAEBBu,13},
    {0xAEBCu,0xAEBCu,12},
    {0xAEBDu,0xAED7u,13},
    {0xAED8u,0xAED8u,12},
    {0xAED9u,0xAEF3u,13},
    {0xAEF4u,0xAEF4u,12},
    {0xAEF5u,0xAF0Fu,13},
    {0xAF10u,0xAF10u,12},
    {0xAF11u,0xAF2Bu,13},
    {0xAF2Cu,0xAF2Cu,12},
    {0xAF2Du,0xAF47u,13},
    {0xAF48u,0xAF48u,12},
    {0xAF49u,0xAF63u,13},
    {0xAF64u,0xAF64u,12},
    {0xAF65u,0xAF7Fu,13},
    {0xAF80u,0xAF80u,12},
    {0xAF81u,0xAF9Bu,13},
    {0xAF9Cu,0xAF9Cu,12},
    {0xAF9Du,0xAFB7u,13},
    {0xAFB8u,0xAFB8u,12},
    {0xAFB9u,0xAFD3u,13},
    {0xAFD4u,0xAFD4u,12},
    {0xAFD5u,0xAFEFu,13},
    {0xAFF0u,0xAFF0u,12},
    {0xAFF1u,0xB00Bu,13},
    {0xB00Cu,0xB00Cu,12},
    {0xB00Du,0xB027u,13},
    {0xB028u,0xB028u,12},
    {0xB029u,0xB043u,13},
    {0xB044u,0xB044u,12},
    {0xB045u,0xB05Fu,13},
    {0xB060u,0xB060u,12},
    {0xB061u,0xB07Bu,13},
    {0xB07Cu,0xB07Cu,12},
    {0xB07Du,0xB097u,13},
    {0xB098u,0xB098u,12},
    {0xB099u,0xB0B3u,13},
    {0xB0B4u,0xB0B4u,12},
    {0xB0B5u,0xB0CFu,13},
    {0xB0D0u,0xB0D0u,12},
    {0xB0D1u,0xB0EBu,13},
    {0xB0ECu,0xB0ECu,12},
    {0xB0EDu,0xB107u,13},
    {0xB108u,0xB108u,12},
    {0xB109u,0xB123u,13},
    {0xB124u,0xB124u,12},
    {0xB125u,0xB13Fu,13},
    {0xB140u,0xB140u,12},
    {0xB141u,0xB15Bu,13},
    {0xB15Cu,0xB15Cu,12},
    {0xB15Du,0xB177u,13},
    {0xB178u,0xB178u,12},
    {0xB179u,0xB193u,13},
    {0xB194u,0xB194u,12},
    {0xB195u,0xB1AFu,13},
    {0xB1B0u,0xB1B0u,12},
    {0xB1B1u,0xB1CBu,13},
    {0xB1CCu,0xB1CCu,12},
    {0xB1CDu,0xB1E7u,13},
    {0xB1E8u,0xB1E8u,12},
    {0xB1E9u,0xB203u,13},
    {0xB204u,0xB204u,12},
    {0xB205u,0xB21Fu,13},
    {0xB220u,0xB220u,12},
    {0xB221u,0xB23Bu,13},
    {0xB23Cu,0xB23Cu,12},
    {0xB23Du,0xB257u,13},
    {0xB258u,0xB258u,12},
    {0xB259u,0xB273u,13},
    {0xB274u,0xB274u,12},
    {0xB275u,0xB28Fu,13},
    {0xB290u,0xB290u,12},
    {0xB291u,0xB2ABu,13},
    {0xB2ACu,0xB2ACu,12},
    {0xB2ADu,0xB2C7u,13},
    {0xB2C8u,0xB2C8u,12},
    {0xB2C9u,0xB2E3u,13},
    {0xB2E4u,0xB2E4u,12},
    {0xB2E5u,0xB2FFu,13},
    {0xB300u,0xB300u,12},
    {0xB301u,0xB31Bu,13},
    {0xB31Cu,0xB31Cu,12},
    {0xB31Du,0xB337u,13},
    {0xB338u,0xB338u,12},
    {0xB339u,0xB353u,13},
    {0xB354u,0xB354u,12},
    {0xB355u,0xB36Fu,13},
    {0xB370u,0xB370u,12},
    {0xB371u,0xB38Bu,13},
    {0xB38Cu,0xB38Cu,12},
    {0xB38Du,0xB3A7u,13},
    {0xB3A8u,0xB3A8u,12},
    {0xB3A9u,0xB3C3u,13},
    {0xB3C4u,0xB3C4u,12},
    {0xB3C5u,0xB3DFu,13},
    {0xB3E0u,0xB3E0u,12},
    {0xB3E1u,0xB3FBu,13},
    {0xB3FCu,0xB3FCu,12},
    {0xB3FDu,0xB417u,13},
    {0xB418u,0xB418u,12},
    {0xB419u,0xB433u,13},
    {0xB434u,0xB434u,12},
    {0xB435u,0xB44Fu,13},
    {0xB450u,0xB450u,12},
    {0xB451u,0xB46Bu,13},
    {0xB46Cu,0xB46Cu,12},
    {0xB46Du,0xB487u,13},
    {0xB488u,0xB488u,12},
    {0xB489u,0xB4A3u,13},
    {0xB4A4u,0xB4A4u,12},
    {0xB4A5u,0xB4BFu,13},
    {0xB4C0u,0xB4C0u,12},
    {0xB4C1u,0xB4DBu,13},
    {0xB4DCu,0xB4DCu,12},
    {0xB4DDu,0xB4F7u,13},
    {0xB4F8u,0xB4F8u,12},
    {0xB4F9u,0xB513u,13},
    {0xB514u,0xB514u,12},
    {0xB515u,0xB52Fu,13},
    {0xB530u,0xB530u,12},
    {0xB531u,0xB54Bu,13},
    {0xB54Cu,0xB54Cu,12},
    {0xB54Du,0xB567u,13},
    {0xB568u,0xB568u,12},
    {0xB569u,0xB583u,13},
    {0xB584u,0xB584u,12},
    {0xB585u,0xB59Fu,13},
    {0xB5A0u,0xB5A0u,12},
    {0xB5A1u,0xB5BBu,13},
    {0xB5BCu,0xB5BCu,12},
    {0xB5BDu,0xB5D7u,13},
    {0xB5D8u,0xB5D8u,12},
    {0xB5D9u,0xB5F3u,13},
    {0xB5F4u,0xB5F4u,12},
    {0xB5F5u,0xB60Fu,13},
    {0xB610u,0xB610u,12},
    {0xB611u,0xB62Bu,13},
    {0xB62Cu,0xB62Cu,12},
    {0xB62Du,0xB647u,13},
    {0xB648u,0xB648u,12},
    {0xB649u,0xB663u,13},
    {0xB664u,0xB664u,12},
    {0xB665u,0xB67Fu,13},
    {0xB680u,0xB680u,12},
    {0xB681u,0xB69Bu,13},
    {0xB69Cu,0xB69Cu,12},
    {0xB69Du,0xB6B7u,13},
    {0xB6B8u,0xB6B8u,12},
    {0xB6B9u,0xB6D3u,13},
    {0xB6D4u,0xB6D4u,12},
    {0xB6D5u,0xB6EFu,13},
    {0xB6F0u,0xB6F0u,12},
    {0xB6F1u,0xB70Bu,13},
    {0xB70Cu,0xB70Cu,12},
    {0xB70Du,0xB727u,13},
    {0xB728u,0xB728u,12},
    {0xB729u,0xB743u,13},
    {0xB744u,0xB744u,12},
    {0xB745u,0xB75Fu,13},
    {0xB760u,0xB760u,12},
    {0xB761u,0xB77Bu,13},
    {0xB77Cu,0xB77Cu,12},
    {0xB77Du,0xB797u,13},
    {0xB798u,0xB798u,12},
    {0xB799u,0xB7B3u,13},
    {0xB7B4u,0xB7B4u,12},
    {0xB7B5u,0xB7CFu,13},
    {0xB7D0u,0xB7D0u,12},
    {0xB7D1u,0xB7EBu,13},
    {0xB7ECu,0xB7ECu,12},
    {0xB7EDu,0xB807u,13},
    {0xB808u,0xB808u,12},
    {0xB809u,0xB823u,13},
    {0xB824u,0xB824u,12},
    {0xB825u,0xB83Fu,13},
    {0xB840u,0xB840u,12},
    {0xB841u,0xB85Bu,13},
    {0xB85Cu,0xB85Cu,12},
    {0xB85Du,0xB877u,13},
    {0xB878u,0xB878u,12},
    {0xB879u,0xB893u,13},
    {0xB894u,0xB894u,12},
    {0xB895u,0xB8AFu,13},
    {0xB8B0u,0xB8B0u,12},
    {0xB8B1u,0xB8CBu,13},
    {0xB8CCu,0xB8CCu,12},
    {0xB8CDu,0xB8E7u,13},
    {0xB8E8u,0xB8E8u,12},
    {0xB8E9u,0xB903u,13},
    {0xB904u,0xB904u,12},
    {0xB905u,0xB91Fu,13},
    {0xB920u,0xB920u,12},
    {0xB921u,0xB93Bu,13},
    {0xB93Cu,0xB93Cu,12},
    {0xB93Du,0xB957u,13},
    {0xB958u,0xB958u,12},
    {0xB959u,0xB973u,13},
    {0xB974u,0xB974u,12},
    {0xB975u,0xB98Fu,13},
    {0xB990u,0xB990u,12},
    {0xB991u,0xB9ABu,13},
    {0xB9ACu,0xB9ACu,12},
    {0xB9ADu,0xB9C7u,13},
    {0xB9C8u,0xB9C8u,12},
    {0xB9C9u,0xB9E3u,13},
    {0xB9E4u,0xB9E4u,12},
    {0xB9E5u,0xB9FFu,13},
    {0xBA00u,0xBA00u,12},
    {0xBA01u,0xBA1Bu,13},
    {0xBA1Cu,0xBA1Cu,12},
    {0xBA1Du,0xBA37u,13},
    {0xBA38u,0xBA38u,12},
    {0xBA39u,0xBA53u,13},
    {0xBA54u,0xBA54u,12},
    {0xBA55u,0xBA6Fu,13},
    {0xBA70u,0xBA70u,12},
    {0xBA71u,0xBA8Bu,13},
    {0xBA8Cu,0xBA8Cu,12},
    {0xBA8Du,0xBAA7u,13},
    {0xBAA8u,0xBAA8u,12},
    {0xBAA9u,0xBAC3u,13},
    {0xBAC4u,0xBAC4u,12},
    {0xBAC5u,0xBADFu,13},
    {0xBAE0u,0xBAE0u,12},
    {0xBAE1u,0xBAFBu,13},
    {0xBAFCu,0xBAFCu,12},
    {0xBAFDu,0xBB17u,13},
    {0xBB18u,0xBB18u,12},
    {0xBB19u,0xBB33u,13},
    {0xBB34u,0xBB34u,12},
    {0xBB35u,0xBB4Fu,13},
    {0xBB50u,0xBB50u,12},
    {0xBB51u,0xBB6Bu,13},
    {0xBB6Cu,0xBB6Cu,12},
    {0xBB6Du,0xBB87u,13},
    {0xBB88u,0xBB88u,12},
    {0xBB89u,0xBBA3u,13},
    {0xBBA4u,0xBBA4u,12},
    {0xBBA5u,0xBBBFu,13},
    {0xBBC0u,0xBBC0u,12},
    {0xBBC1u,0xBBDBu,13},
    {0xBBDCu,0xBBDCu,12},
    {0xBBDDu,0xBBF7u,13},
    {0xBBF8u,0xBBF8u,12},
    {0xBBF9u,0xBC13u,13},
    {0xBC14u,0xBC14u,12},
    {0xBC15u,0xBC2Fu,13},
    {0xBC30u,0xBC30u,12},
    {0xBC31u,0xBC4Bu,13},
    {0xBC4Cu,0xBC4Cu,12},
    {0xBC4Du,0xBC67u,13},
    {0xBC68u,0xBC68u,12},
    {0xBC69u,0xBC83u,13},
    {0xBC84u,0xBC84u,12},
    {0xBC85u,0xBC9Fu,13},
    {0xBCA0u,0xBCA0u,12},
    {0xBCA1u,0xBCBBu,13},
    {0xBCBCu,0xBCBCu,12},
    {0xBCBDu,0xBCD7u,13},
    {0xBCD8u,0xBCD8u,12},
    {0xBCD9u,0xBCF3u,13},
    {0xBCF4u,0xBCF4u,12},
    {0xBCF5u,0xBD0Fu,13},
    {0xBD10u,0xBD10u,12},
    {0xBD11u,0xBD2Bu,13},
    {0xBD2Cu,0xBD2Cu,12},
    {0xBD2Du,0xBD47u,13},
    {0xBD48u,0xBD48u,12},
    {0xBD49u,0xBD63u,13},
    {0xBD64u,0xBD64u,12},
    {0xBD65u,0xBD7Fu,13},
    {0xBD80u,0xBD80u,12},
    {0xBD81u,0xBD9Bu,13},
    {0xBD9Cu,0xBD9Cu,12},
    {0xBD9Du,0xBDB7u,13},
    {0xBDB8u,0xBDB8u,12},
    {0xBDB9u,0xBDD3u,13},
    {0xBDD4u,0xBDD4u,12},
    {0xBDD5u,0xBDEFu,13},
    {0xBDF0u,0xBDF0u,12},
    {0xBDF1u,0xBE0Bu,13},
    {0xBE0Cu,0xBE0Cu,12},
    {0xBE0Du,0xBE27u,13},
    {0xBE28u,0xBE28u,12},
    {0xBE29u,0xBE43u,13},
    {0xBE44u,0xBE44u,12},
    {0xBE45u,0xBE5Fu,13},
    {0xBE60u,0xBE60u,12},
    {0xBE61u,0xBE7Bu,13},
    {0xBE7Cu,0xBE7Cu,12},
    {0xBE7Du,0xBE97u,13},
    {0xBE98u,0xBE98u,12},
    {0xBE99u,0xBEB3u,13},
    {0xBEB4u,0xBEB4u,12},
    {0xBEB5u,0xBECFu,13},
    {0xBED0u,0xBED0u,12},
    {0xBED1u,0xBEEBu,13},
    {0xBEECu,0xBEECu,12},
    {0xBEEDu,0xBF07u,13},
    {0xBF08u,0xBF08u,12},
    {0xBF09u,0xBF23u,13},
    {0xBF24u,0xBF24u,12},
    {0xBF25u,0xBF3Fu,13},
    {0xBF40u,0xBF40u,12},
    {0xBF41u,0xBF5Bu,13},
    {0xBF5Cu,0xBF5Cu,12},
    {0xBF5Du,0xBF77u,13},
    {0xBF78u,0xBF78u,12},
    {0xBF79u,0xBF93u,13},
    {0xBF94u,0xBF94u,12},
    {0xBF95u,0xBFAFu,13},
    {0xBFB0u,0xBFB0u,12},
    {0xBFB1u,0xBFCBu,13},
    {0xBFCCu,0xBFCCu,12},
    {0xBFCDu,0xBFE7u,13},
    {0xBFE8u,0xBFE8u,12},
    {0xBFE9u,0xC003u,13},
    {0xC004u,0xC004u,12},
    {0xC005u,0xC01Fu,13},
    {0xC020u,0xC020u,12},
    {0xC021u,0xC03Bu,13},
    {0xC03Cu,0xC03Cu,12},
    {0xC03Du,0xC057u,13},
    {0xC058u,0xC058u,12},
    {0xC059u,0xC073u,13},
    {0xC074u,0xC074u,12},
    {0xC075u,0xC08Fu,13},
    {0xC090u,0xC090u,12},
    {0xC091u,0xC0ABu,13},
    {0xC0ACu,0xC0ACu,12},
    {0xC0ADu,0xC0C7u,13},
    {0xC0C8u,0xC0C8u,12},
    {0xC0C9u,0xC0E3u,13},
    {0xC0E4u,0xC0E4u,12},
    {0xC0E5u,0xC0FFu,13},
    {0xC100u,0xC100u,12},
    {0xC101u,0xC11Bu,13},
    {0xC11Cu,0xC11Cu,12},
    {0xC11Du,0xC137u,13},
    {0xC138u,0xC138u,12},
    {0xC139u,0xC153u,13},
    {0xC154u,0xC154u,12},
    {0xC155u,0xC16Fu,13},
    {0xC170u,0xC170u,12},
    {0xC171u,0xC18Bu,13},
    {0xC18Cu,0xC18Cu,12},
    {0xC18Du,0xC1A7u,13},
    {0xC1A8u,0xC1A8u,12},
    {0xC1A9u,0xC1C3u,13},
    {0xC1C4u,0xC1C4u,12},
    {0xC1C5u,0xC1DFu,13},
    {0xC1E0u,0xC1E0u,12},
    {0xC1E1u,0xC1FBu,13},
    {0xC1FCu,0xC1FCu,12},
    {0xC1FDu,0xC217u,13},
    {0xC218u,0xC218u,12},
    {0xC219u,0xC233u,13},
    {0xC234u,0xC234u,12},
    {0xC235u,0xC24Fu,13},
    {0xC250u,0xC250u,12},
    {0xC251u,0xC26Bu,13},
    {0xC26Cu,0xC26Cu,12},
    {0xC26Du,0xC287u,13},
    {0xC288u,0xC288u,12},
    {0xC289u,0xC2A3u,13},
    {0xC2A4u,0xC2A4u,12},
    {0xC2A5u,0xC2BFu,13},
    {0xC2C0u,0xC2C0u,12},
    {0xC2C1u,0xC2DBu,13},
    {0xC2DCu,0xC2DCu,12},
    {0xC2DDu,0xC2F7u,13},
    {0xC2F8u,0xC2F8u,12},
    {0xC2F9u,0xC313u,13},
    {0xC314u,0xC314u,12},
    {0xC315u,0xC32Fu,13},
    {0xC330u,0xC330u,12},
    {0xC331u,0xC34Bu,13},
    {0xC34Cu,0xC34Cu,12},
    {0xC34Du,0xC367u,13},
    {0xC368u,0xC368u,12},
    {0xC369u,0xC383u,13},
    {0xC384u,0xC384u,12},
    {0xC385u,0xC39Fu,13},
    {0xC3A0u,0xC3A0u,12},
    {0xC3A1u,0xC3BBu,13},
    {0xC3BCu,0xC3BCu,12},
    {0xC3BDu,0xC3D7u,13},
    {0xC3D8u,0xC3D8u,12},
    {0xC3D9u,0xC3F3u,13},
    {0xC3F4u,0xC3F4u,12},
    {0xC3F5u,0xC40Fu,13},
    {0xC410u,0xC410u,12},
    {0xC411u,0xC42Bu,13},
    {0xC42Cu,0xC42Cu,12},
    {0xC42Du,0xC447u,13},
    {0xC448u,0xC448u,12},
    {0xC449u,0xC463u,13},
    {0xC464u,0xC464u,12},
    {0xC465u,0xC47Fu,13},
    {0xC480u,0xC480u,12},
    {0xC481u,0xC49Bu,13},
    {0xC49Cu,0xC49Cu,12},
    {0xC49Du,0xC4B7u,13},
    {0xC4B8u,0xC4B8u,12},
    {0xC4B9u,0xC4D3u,13},
    {0xC4D4u,0xC4D4u,12},
    {0xC4D5u,0xC4EFu,13},
    {0xC4F0u,0xC4F0u,12},
    {0xC4F1u,0xC50Bu,13},
    {0xC50Cu,0xC50Cu,12},
    {0xC50Du,0xC527u,13},
    {0xC528u,0xC528u,12},
    {0xC529u,0xC543u,13},
    {0xC544u,0xC544u,12},
    {0xC545u,0xC55Fu,13},
    {0xC560u,0xC560u,12},
    {0xC561u,0xC57Bu,13},
    {0xC57Cu,0xC57Cu,12},
    {0xC57Du,0xC597u,13},
    {0xC598u,0xC598u,12},
    {0xC599u,0xC5B3u,13},
    {0xC5B4u,0xC5B4u,12},
    {0xC5B5u,0xC5CFu,13},
    {0xC5D0u,0xC5D0u,12},
    {0xC5D1u,0xC5EBu,13},
    {0xC5ECu,0xC5ECu,12},
    {0xC5EDu,0xC607u,13},
    {0xC608u,0xC608u,12},
    {0xC609u,0xC623u,13},
    {0xC624u,0xC624u,12},
    {0xC625u,0xC63Fu,13},
    {0xC640u,0xC640u,12},
    {0xC641u,0xC65Bu,13},
    {0xC65Cu,0xC65Cu,12},
    {0xC65Du,0xC677u,13},
    {0xC678u,0xC678u,12},
    {0xC679u,0xC693u,13},
    {0xC694u,0xC694u,12},
    {0xC695u,0xC6AFu,13},
    {0xC6B0u,0xC6B0u,12},
    {0xC6B1u,0xC6CBu,13},
    {0xC6CCu,0xC6CCu,12},
    {0xC6CDu,0xC6E7u,13},
    {0xC6E8u,0xC6E8u,12},
    {0xC6E9u,0xC703u,13},
    {0xC704u,0xC704u,12},
    {0xC705u,0xC71Fu,13},
    {0xC720u,0xC720u,12},
    {0xC721u,0xC73Bu,13},
    {0xC73Cu,0xC73Cu,12},
    {0xC73Du,0xC757u,13},
    {0xC758u,0xC758u,12},
    {0xC759u,0xC773u,13},
    {0xC774u,0xC774u,12},
    {0xC775u,0xC78Fu,13},
    {0xC790u,0xC790u,12},
    {0xC791u,0xC7ABu,13},
    {0xC7ACu,0xC7ACu,12},
    {0xC7ADu,0xC7C7u,13},
    {0xC7C8u,0xC7C8u,12},
    {0xC7C9u,0xC7E3u,13},
    {0xC7E4u,0xC7E4u,12},
    {0xC7E5u,0xC7FFu,13},
    {0xC800u,0xC800u,12},
    {0xC801u,0xC81Bu,13},
    {0xC81Cu,0xC81Cu,12},
    {0xC81Du,0xC837u,13},
    {0xC838u,0xC838u,12},
    {0xC839u,0xC853u,13},
    {0xC854u,0xC854u,12},
    {0xC855u,0xC86Fu,13},
    {0xC870u,0xC870u,12},
    {0xC871u,0xC88Bu,13},
    {0xC88Cu,0xC88Cu,12},
    {0xC88Du,0xC8A7u,13},
    {0xC8A8u,0xC8A8u,12},
    {0xC8A9u,0xC8C3u,13},
    {0xC8C4u,0xC8C4u,12},
    {0xC8C5u,0xC8DFu,13},
    {0xC8E0u,0xC8E0u,12},
    {0xC8E1u,0xC8FBu,13},
    {0xC8FCu,0xC8FCu,12},
    {0xC8FDu,0xC917u,13},
    {0xC918u,0xC918u,12},
    {0xC919u,0xC933u,13},
    {0xC934u,0xC934u,12},
    {0xC935u,0xC94Fu,13},
    {0xC950u,0xC950u,12},
    {0xC951u,0xC96Bu,13},
    {0xC96Cu,0xC96Cu,12},
    {0xC96Du,0xC987u,13},
    {0xC988u,0xC988u,12},
    {0xC989u,0xC9A3u,13},
    {0xC9A4u,0xC9A4u,12},
    {0xC9A5u,0xC9BFu,13},
    {0xC9C0u,0xC9C0u,12},
    {0xC9C1u,0xC9DBu,13},
    {0xC9DCu,0xC9DCu,12},
    {0xC9DDu,0xC9F7u,13},
    {0xC9F8u,0xC9F8u,12},
    {0xC9F9u,0xCA13u,13},
    {0xCA14u,0xCA14u,12},
    {0xCA15u,0xCA2Fu,13},
    {0xCA30u,0xCA30u,12},
    {0xCA31u,0xCA4Bu,13},
    {0xCA4Cu,0xCA4Cu,12},
    {0xCA4Du,0xCA67u,13},
    {0xCA68u,0xCA68u,12},
    {0xCA69u,0xCA83u,13},
    {0xCA84u,0xCA84u,12},
    {0xCA85u,0xCA9Fu,13},
    {0xCAA0u,0xCAA0u,12},
    {0xCAA1u,0xCABBu,13},
    {0xCABCu,0xCABCu,12},
    {0xCABDu,0xCAD7u,13},
    {0xCAD8u,0xCAD8u,12},
    {0xCAD9u,0xCAF3u,13},
    {0xCAF4u,0xCAF4u,12},
    {0xCAF5u,0xCB0Fu,13},
    {0xCB10u,0xCB10u,12},
    {0xCB11u,0xCB2Bu,13},
    {0xCB2Cu,0xCB2Cu,12},
    {0xCB2Du,0xCB47u,13},
    {0xCB48u,0xCB48u,12},
    {0xCB49u,0xCB63u,13},
    {0xCB64u,0xCB64u,12},
    {0xCB65u,0xCB7Fu,13},
    {0xCB80u,0xCB80u,12},
    {0xCB81u,0xCB9Bu,13},
    {0xCB9Cu,0xCB9Cu,12},
    {0xCB9Du,0xCBB7u,13},
    {0xCBB8u,0xCBB8u,12},
    {0xCBB9u,0xCBD3u,13},
    {0xCBD4u,0xCBD4u,12},
    {0xCBD5u,0xCBEFu,13},
    {0xCBF0u,0xCBF0u,12},
    {0xCBF1u,0xCC0Bu,13},
    {0xCC0Cu,0xCC0Cu,12},
    {0xCC0Du,0xCC27u,13},
    {0xCC28u,0xCC28u,12},
    {0xCC29u,0xCC43u,13},
    {0xCC44u,0xCC44u,12},
    {0xCC45u,0xCC5Fu,13},
    {0xCC60u,0xCC60u,12},
    {0xCC61u,0xCC7Bu,13},
    {0xCC7Cu,0xCC7Cu,12},
    {0xCC7Du,0xCC97u,13},
    {0xCC98u,0xCC98u,12},
    {0xCC99u,0xCCB3u,13},
    {0xCCB4u,0xCCB4u,12},
    {0xCCB5u,0xCCCFu,13},
    {0xCCD0u,0xCCD0u,12},
    {0xCCD1u,0xCCEBu,13},
    {0xCCECu,0xCCECu,12},
    {0xCCEDu,0xCD07u,13},
    {0xCD08u,0xCD08u,12},
    {0xCD09u,0xCD23u,13},
    {0xCD24u,0xCD24u,12},
    {0xCD25u,0xCD3Fu,13},
    {0xCD40u,0xCD40u,12},
    {0xCD41u,0xCD5Bu,13},
    {0xCD5Cu,0xCD5Cu,12},
    {0xCD5Du,0xCD77u,13},
    {0xCD78u,0xCD78u,12},
    {0xCD79u,0xCD93u,13},
    {0xCD94u,0xCD94u,12},
    {0xCD95u,0xCDAFu,13},
    {0xCDB0u,0xCDB0u,12},
    {0xCDB1u,0xCDCBu,13},
    {0xCDCCu,0xCDCCu,12},
    {0xCDCDu,0xCDE7u,13},
    {0xCDE8u,0xCDE8u,12},
    {0xCDE9u,0xCE03u,13},
    {0xCE04u,0xCE04u,12},
    {0xCE05u,0xCE1Fu,13},
    {0xCE20u,0xCE20u,12},
    {0xCE21u,0xCE3Bu,13},
    {0xCE3Cu,0xCE3Cu,12},
    {0xCE3Du,0xCE57u,13},
    {0xCE58u,0xCE58u,12},
    {0xCE59u,0xCE73u,13},
    {0xCE74u,0xCE74u,12},
    {0xCE75u,0xCE8Fu,13},
    {0xCE90u,0xCE90u,12},
    {0xCE91u,0xCEABu,13},
    {0xCEACu,0xCEACu,12},
    {0xCEADu,0xCEC7u,13},
    {0xCEC8u,0xCEC8u,12},
    {0xCEC9u,0xCEE3u,13},
    {0xCEE4u,0xCEE4u,12},
    {0xCEE5u,0xCEFFu,13},
    {0xCF00u,0xCF00u,12},
    {0xCF01u,0xCF1Bu,13},
    {0xCF1Cu,0xCF1Cu,12},
    {0xCF1Du,0xCF37u,13},
    {0xCF38u,0xCF38u,12},
    {0xCF39u,0xCF53u,13},
    {0xCF54u,0xCF54u,12},
    {0xCF55u,0xCF6Fu,13},
    {0xCF70u,0xCF70u,12},
    {0xCF71u,0xCF8Bu,13},
    {0xCF8Cu,0xCF8Cu,12},
    {0xCF8Du,0xCFA7u,13},
    {0xCFA8u,0xCFA8u,12},
    {0xCFA9u,0xCFC3u,13},
    {0xCFC4u,0xCFC4u,12},
    {0xCFC5u,0xCFDFu,13},
    {0xCFE0u,0xCFE0u,12},
    {0xCFE1u,0xCFFBu,13},
    {0xCFFCu,0xCFFCu,12},
    {0xCFFDu,0xD017u,13},
    {0xD018u,0xD018u,12},
    {0xD019u,0xD033u,13},
    {0xD034u,0xD034u,12},
    {0xD035u,0xD04Fu,13},
    {0xD050u,0xD050u,12},
    {0xD051u,0xD06Bu,13},
    {0xD06Cu,0xD06Cu,12},
    {0xD06Du,0xD087u,13},
    {0xD088u,0xD088u,12},
    {0xD089u,0xD0A3u,13},
    {0xD0A4u,0xD0A4u,12},
    {0xD0A5u,0xD0BFu,13},
    {0xD0C0u,0xD0C0u,12},
    {0xD0C1u,0xD0DBu,13},
    {0xD0DCu,0xD0DCu,12},
    {0xD0DDu,0xD0F7u,13},
    {0xD0F8u,0xD0F8u,12},
    {0xD0F9u,0xD113u,13},
    {0xD114u,0xD114u,12},
    {0xD115u,0xD12Fu,13},
    {0xD130u,0xD130u,12},
    {0xD131u,0xD14Bu,13},
    {0xD14Cu,0xD14Cu,12},
    {0xD14Du,0xD167u,13},
    {0xD168u,0xD168u,12},
    {0xD169u,0xD183u,13},
    {0xD184u,0xD184u,12},
    {0xD185u,0xD19Fu,13},
    {0xD1A0u,0xD1A0u,12},
    {0xD1A1u,0xD1BBu,13},
    {0xD1BCu,0xD1BCu,12},
    {0xD1BDu,0xD1D7u,13},
    {0xD1D8u,0xD1D8u,12},
    {0xD1D9u,0xD1F3u,13},
    {0xD1F4u,0xD1F4u,12},
    {0xD1F5u,0xD20Fu,13},
    {0xD210u,0xD210u,12},
    {0xD211u,0xD22Bu,13},
    {0xD22Cu,0xD22Cu,12},
    {0xD22Du,0xD247u,13},
    {0xD248u,0xD248u,12},
    {0xD249u,0xD263u,13},
    {0xD264u,0xD264u,12},
    {0xD265u,0xD27Fu,13},
    {0xD280u,0xD280u,12},
    {0xD281u,0xD29Bu,13},
    {0xD29Cu,0xD29Cu,12},
    {0xD29Du,0xD2B7u,13},
    {0xD2B8u,0xD2B8u,12},
    {0xD2B9u,0xD2D3u,13},
    {0xD2D4u,0xD2D4u,12},
    {0xD2D5u,0xD2EFu,13},
    {0xD2F0u,0xD2F0u,12},
    {0xD2F1u,0xD30Bu,13},
    {0xD30Cu,0xD30Cu,12},
    {0xD30Du,0xD327u,13},
    {0xD328u,0xD328u,12},
    {0xD329u,0xD343u,13},
    {0xD344u,0xD344u,12},
    {0xD345u,0xD35Fu,13},
    {0xD360u,0xD360u,12},
    {0xD361u,0xD37Bu,13},
    {0xD37Cu,0xD37Cu,12},
    {0xD37Du,0xD397u,13},
    {0xD398u,0xD398u,12},
    {0xD399u,0xD3B3u,13},
    {0xD3B4u,0xD3B4u,12},
    {0xD3B5u,0xD3CFu,13},
    {0xD3D0u,0xD3D0u,12},
    {0xD3D1u,0xD3EBu,13},
    {0xD3ECu,0xD3ECu,12},
    {0xD3EDu,0xD407u,13},
    {0xD408u,0xD408u,12},
    {0xD409u,0xD423u,13},
    {0xD424u,0xD424u,12},
    {0xD425u,0xD43Fu,13},
    {0xD440u,0xD440u,12},
    {0xD441u,0xD45Bu,13},
    {0xD45Cu,0xD45Cu,12},
    {0xD45Du,0xD477u,13},
    {0xD478u,0xD478u,12},
    {0xD479u,0xD493u,13},
    {0xD494u,0xD494u,12},
    {0xD495u,0xD4AFu,13},
    {0xD4B0u,0xD4B0u,12},
    {0xD4B1u,0xD4CBu,13},
    {0xD4CCu,0xD4CCu,12},
    {0xD4CDu,0xD4E7u,13},
    {0xD4E8u,0xD4E8u,12},
    {0xD4E9u,0xD503u,13},
    {0xD504u,0xD504u,12},
    {0xD505u,0xD51Fu,13},
    {0xD520u,0xD520u,12},
    {0xD521u,0xD53Bu,13},
    {0xD53Cu,0xD53Cu,12},
    {0xD53Du,0xD557u,13},
    {0xD558u,0xD558u,12},
    {0xD559u,0xD573u,13},
    {0xD574u,0xD574u,12},
    {0xD575u,0xD58Fu,13},
    {0xD590u,0xD590u,12},
    {0xD591u,0xD5ABu,13},
    {0xD5ACu,0xD5ACu,12},
    {0xD5ADu,0xD5C7u,13},
    {0xD5C8u,0xD5C8u,12},
    {0xD5C9u,0xD5E3u,13},
    {0xD5E4u,0xD5E4u,12},
    {0xD5E5u,0xD5FFu,13},
    {0xD600u,0xD600u,12},
    {0xD601u,0xD61Bu,13},
    {0xD61Cu,0xD61Cu,12},
    {0xD61Du,0xD637u,13},
    {0xD638u,0xD638u,12},
    {0xD639u,0xD653u,13},
    {0xD654u,0xD654u,12},
    {0xD655u,0xD66Fu,13},
    {0xD670u,0xD670u,12},
    {0xD671u,0xD68Bu,13},
    {0xD68Cu,0xD68Cu,12},
    {0xD68Du,0xD6A7u,13},
    {0xD6A8u,0xD6A8u,12},
    {0xD6A9u,0xD6C3u,13},
    {0xD6C4u,0xD6C4u,12},
    {0xD6C5u,0xD6DFu,13},
    {0xD6E0u,0xD6E0u,12},
    {0xD6E1u,0xD6FBu,13},
    {0xD6FCu,0xD6FCu,12},
    {0xD6FDu,0xD717u,13},
    {0xD718u,0xD718u,12},
    {0xD719u,0xD733u,13},
    {0xD734u,0xD734u,12},
    {0xD735u,0xD74Fu,13},
    {0xD750u,0xD750u,12},
    {0xD751u,0xD76Bu,13},
    {0xD76Cu,0xD76Cu,12},
    {0xD76Du,0xD787u,13},
    {0xD788u,0xD788u,12},
    {0xD789u,0xD7A3u,13},
    {0xD7B0u,0xD7C6u,10},
    {0xD7CBu,0xD7FBu,11},
    {0xFB1Eu,0xFB1Eu,4},
    {0xFE00u,0xFE0Fu,4},
    {0xFE20u,0xFE2Fu,4},
    {0xFEFFu,0xFEFFu,3},
    {0xFF9Eu,0xFF9Fu,4},
    {0xFFF0u,0xFFFBu,3},
    {0x101FDu,0x101FDu,4},
    {0x102E0u,0x102E0u,4},
    {0x10376u,0x1037Au,4},
    {0x10A01u,0x10A03u,4},
    {0x10A05u,0x10A06u,4},
    {0x10A0Cu,0x10A0Fu,4},
    {0x10A38u,0x10A3Au,4},
    {0x10A3Fu,0x10A3Fu,4},
    {0x10AE5u,0x10AE6u,4},
    {0x10D24u,0x10D27u,4},
    {0x10D69u,0x10D6Du,4},
    {0x10EABu,0x10EACu,4},
    {0x10ECBu,0x10ECFu,4},
    {0x10EF0u,0x10EFFu,4},
    {0x10F46u,0x10F50u,4},
    {0x10F82u,0x10F85u,4},
    {0x11000u,0x11000u,8},
    {0x11001u,0x11001u,4},
    {0x11002u,0x11002u,8},
    {0x11038u,0x11046u,4},
    {0x11070u,0x11070u,4},
    {0x11073u,0x11074u,4},
    {0x1107Fu,0x11081u,4},
    {0x11082u,0x11082u,8},
    {0x110B0u,0x110B2u,8},
    {0x110B3u,0x110B6u,4},
    {0x110B7u,0x110B8u,8},
    {0x110B9u,0x110BAu,4},
    {0x110BDu,0x110BDu,7},
    {0x110C2u,0x110C2u,4},
    {0x110CDu,0x110CDu,7},
    {0x11100u,0x11102u,4},
    {0x11127u,0x1112Bu,4},
    {0x1112Cu,0x1112Cu,8},
    {0x1112Du,0x11134u,4},
    {0x11145u,0x11146u,8},
    {0x11173u,0x11173u,4},
    {0x11180u,0x11181u,4},
    {0x11182u,0x11182u,8},
    {0x111B3u,0x111B5u,8},
    {0x111B6u,0x111BEu,4},
    {0x111BFu,0x111BFu,8},
    {0x111C0u,0x111C0u,4},
    {0x111C2u,0x111C3u,7},
    {0x111C9u,0x111CCu,4},
    {0x111CEu,0x111CEu,8},
    {0x111CFu,0x111CFu,4},
    {0x1122Cu,0x1122Eu,8},
    {0x1122Fu,0x11231u,4},
    {0x11232u,0x11233u,8},
    {0x11234u,0x11237u,4},
    {0x1123Eu,0x1123Eu,4},
    {0x11241u,0x11241u,4},
    {0x112DFu,0x112DFu,4},
    {0x112E0u,0x112E2u,8},
    {0x112E3u,0x112EAu,4},
    {0x11300u,0x11301u,4},
    {0x11302u,0x11303u,8},
    {0x1133Bu,0x1133Cu,4},
    {0x1133Eu,0x1133Eu,4},
    {0x1133Fu,0x1133Fu,8},
    {0x11340u,0x11340u,4},
    {0x11341u,0x11344u,8},
    {0x11347u,0x11348u,8},
    {0x1134Bu,0x1134Cu,8},
    {0x1134Du,0x1134Du,4},
    {0x11357u,0x11357u,4},
    {0x11362u,0x11363u,8},
    {0x11366u,0x1136Cu,4},
    {0x11370u,0x11374u,4},
    {0x113B8u,0x113B8u,4},
    {0x113B9u,0x113BAu,8},
    {0x113BBu,0x113C0u,4},
    {0x113C2u,0x113C2u,4},
    {0x113C5u,0x113C5u,4},
    {0x113C7u,0x113C9u,4},
    {0x113CAu,0x113CAu,8},
    {0x113CCu,0x113CDu,8},
    {0x113CEu,0x113D0u,4},
    {0x113D1u,0x113D1u,7},
    {0x113D2u,0x113D2u,4},
    {0x113E1u,0x113E2u,4},
    {0x11435u,0x11437u,8},
    {0x11438u,0x1143Fu,4},
    {0x11440u,0x11441u,8},
    {0x11442u,0x11444u,4},
    {0x11445u,0x11445u,8},
    {0x11446u,0x11446u,4},
    {0x1145Eu,0x1145Eu,4},
    {0x114B0u,0x114B0u,4},
    {0x114B1u,0x114B2u,8},
    {0x114B3u,0x114B8u,4},
    {0x114B9u,0x114B9u,8},
    {0x114BAu,0x114BAu,4},
    {0x114BBu,0x114BCu,8},
    {0x114BDu,0x114BDu,4},
    {0x114BEu,0x114BEu,8},
    {0x114BFu,0x114C0u,4},
    {0x114C1u,0x114C1u,8},
    {0x114C2u,0x114C3u,4},
    {0x115AFu,0x115AFu,4},
    {0x115B0u,0x115B1u,8},
    {0x115B2u,0x115B5u,4},
    {0x115B8u,0x115BBu,8},
    {0x115BCu,0x115BDu,4},
    {0x115BEu,0x115BEu,8},
    {0x115BFu,0x115C0u,4},
    {0x115DCu,0x115DDu,4},
    {0x11630u,0x11632u,8},
    {0x11633u,0x1163Au,4},
    {0x1163Bu,0x1163Cu,8},
    {0x1163Du,0x1163Du,4},
    {0x1163Eu,0x1163Eu,8},
    {0x1163Fu,0x11640u,4},
    {0x116ABu,0x116ABu,4},
    {0x116ACu,0x116ACu,8},
    {0x116ADu,0x116ADu,4},
    {0x116AEu,0x116AFu,8},
    {0x116B0u,0x116B7u,4},
    {0x1171Du,0x1171Du,4},
    {0x1171Eu,0x1171Eu,8},
    {0x1171Fu,0x1171Fu,4},
    {0x11722u,0x11725u,4},
    {0x11726u,0x11726u,8},
    {0x11727u,0x1172Bu,4},
    {0x1182Cu,0x1182Eu,8},
    {0x1182Fu,0x11837u,4},
    {0x11838u,0x11838u,8},
    {0x11839u,0x1183Au,4},
    {0x11930u,0x11930u,4},
    {0x11931u,0x11935u,8},
    {0x11937u,0x11938u,8},
    {0x1193Bu,0x1193Eu,4},
    {0x1193Fu,0x1193Fu,7},
    {0x11940u,0x11940u,8},
    {0x11941u,0x11941u,7},
    {0x11942u,0x11942u,8},
    {0x11943u,0x11943u,4},
    {0x119D1u,0x119D3u,8},
    {0x119D4u,0x119D7u,4},
    {0x119DAu,0x119DBu,4},
    {0x119DCu,0x119DFu,8},
    {0x119E0u,0x119E0u,4},
    {0x119E4u,0x119E4u,8},
    {0x11A01u,0x11A0Au,4},
    {0x11A33u,0x11A38u,4},
    {0x11A39u,0x11A39u,8},
    {0x11A3Bu,0x11A3Eu,4},
    {0x11A47u,0x11A47u,4},
    {0x11A51u,0x11A56u,4},
    {0x11A57u,0x11A58u,8},
    {0x11A59u,0x11A5Bu,4},
    {0x11A84u,0x11A89u,7},
    {0x11A8Au,0x11A96u,4},
    {0x11A97u,0x11A97u,8},
    {0x11A98u,0x11A99u,4},
    {0x11B60u,0x11B60u,4},
    {0x11B61u,0x11B61u,8},
    {0x11B62u,0x11B64u,4},
    {0x11B65u,0x11B65u,8},
    {0x11B66u,0x11B66u,4},
    {0x11B67u,0x11B67u,8},
    {0x11C2Fu,0x11C2Fu,8},
    {0x11C30u,0x11C36u,4},
    {0x11C38u,0x11C3Du,4},
    {0x11C3Eu,0x11C3Eu,8},
    {0x11C3Fu,0x11C3Fu,4},
    {0x11C92u,0x11CA7u,4},
    {0x11CA9u,0x11CA9u,8},
    {0x11CAAu,0x11CB0u,4},
    {0x11CB1u,0x11CB1u,8},
    {0x11CB2u,0x11CB3u,4},
    {0x11CB4u,0x11CB4u,8},
    {0x11CB5u,0x11CB6u,4},
    {0x11D31u,0x11D36u,4},
    {0x11D3Au,0x11D3Au,4},
    {0x11D3Cu,0x11D3Du,4},
    {0x11D3Fu,0x11D45u,4},
    {0x11D46u,0x11D46u,7},
    {0x11D47u,0x11D47u,4},
    {0x11D8Au,0x11D8Eu,8},
    {0x11D90u,0x11D91u,4},
    {0x11D93u,0x11D94u,8},
    {0x11D95u,0x11D95u,4},
    {0x11D96u,0x11D96u,8},
    {0x11D97u,0x11D97u,4},
    {0x11DF0u,0x11DF0u,4},
    {0x11EF3u,0x11EF4u,4},
    {0x11EF5u,0x11EF6u,8},
    {0x11F00u,0x11F01u,4},
    {0x11F02u,0x11F02u,7},
    {0x11F03u,0x11F03u,8},
    {0x11F34u,0x11F35u,8},
    {0x11F36u,0x11F3Au,4},
    {0x11F3Eu,0x11F3Fu,8},
    {0x11F40u,0x11F42u,4},
    {0x11F5Au,0x11F5Au,4},
    {0x13430u,0x1343Fu,3},
    {0x13440u,0x13440u,4},
    {0x13447u,0x13455u,4},
    {0x1611Eu,0x16129u,4},
    {0x1612Au,0x1612Cu,8},
    {0x1612Du,0x1612Fu,4},
    {0x16AF0u,0x16AF4u,4},
    {0x16B30u,0x16B36u,4},
    {0x16D63u,0x16D63u,10},
    {0x16D67u,0x16D6Au,10},
    {0x16F4Fu,0x16F4Fu,4},
    {0x16F51u,0x16F87u,8},
    {0x16F8Fu,0x16F92u,4},
    {0x16FE4u,0x16FE4u,4},
    {0x16FF0u,0x16FF1u,4},
    {0x1BC9Du,0x1BC9Eu,4},
    {0x1BCA0u,0x1BCA3u,3},
    {0x1CF00u,0x1CF2Du,4},
    {0x1CF30u,0x1CF46u,4},
    {0x1D127u,0x1D128u,4},
    {0x1D165u,0x1D169u,4},
    {0x1D16Du,0x1D172u,4},
    {0x1D173u,0x1D17Au,3},
    {0x1D17Bu,0x1D182u,4},
    {0x1D185u,0x1D18Bu,4},
    {0x1D1AAu,0x1D1ADu,4},
    {0x1D242u,0x1D244u,4},
    {0x1D250u,0x1D252u,4},
    {0x1D25Bu,0x1D25Cu,4},
    {0x1D25Fu,0x1D25Fu,4},
    {0x1D280u,0x1D281u,4},
    {0x1DA00u,0x1DA36u,4},
    {0x1DA3Bu,0x1DA6Cu,4},
    {0x1DA75u,0x1DA75u,4},
    {0x1DA84u,0x1DA84u,4},
    {0x1DA9Bu,0x1DA9Fu,4},
    {0x1DAA1u,0x1DAAFu,4},
    {0x1E000u,0x1E006u,4},
    {0x1E008u,0x1E018u,4},
    {0x1E01Bu,0x1E021u,4},
    {0x1E023u,0x1E024u,4},
    {0x1E026u,0x1E02Au,4},
    {0x1E08Fu,0x1E08Fu,4},
    {0x1E130u,0x1E136u,4},
    {0x1E2AEu,0x1E2AEu,4},
    {0x1E2ECu,0x1E2EFu,4},
    {0x1E4ECu,0x1E4EFu,4},
    {0x1E5EEu,0x1E5EFu,4},
    {0x1E6E3u,0x1E6E3u,4},
    {0x1E6E6u,0x1E6E6u,4},
    {0x1E6EEu,0x1E6EFu,4},
    {0x1E6F5u,0x1E6F5u,4},
    {0x1E8D0u,0x1E8D6u,4},
    {0x1E944u,0x1E94Au,4},
    {0x1F1E6u,0x1F1FFu,6},
    {0x1F3FBu,0x1F3FFu,4},
    {0xE0000u,0xE001Fu,3},
    {0xE0020u,0xE007Fu,4},
    {0xE0080u,0xE00FFu,3},
    {0xE0100u,0xE01EFu,4},
    {0xE01F0u,0xE0FFFu,3}
};
static const size_t eri_gcb_table_count = sizeof(eri_gcb_table)/sizeof(eri_gcb_table[0]);
static const eri_unicode_range eri_incb_table[] = {
    {0x300u,0x36Fu,2},
    {0x483u,0x489u,2},
    {0x591u,0x5BDu,2},
    {0x5BFu,0x5BFu,2},
    {0x5C1u,0x5C2u,2},
    {0x5C4u,0x5C5u,2},
    {0x5C7u,0x5C9u,2},
    {0x610u,0x61Au,2},
    {0x64Bu,0x65Fu,2},
    {0x670u,0x670u,2},
    {0x6D6u,0x6DCu,2},
    {0x6DFu,0x6E4u,2},
    {0x6E7u,0x6E8u,2},
    {0x6EAu,0x6EDu,2},
    {0x711u,0x711u,2},
    {0x730u,0x74Au,2},
    {0x7A6u,0x7B0u,2},
    {0x7EBu,0x7F3u,2},
    {0x7FDu,0x7FDu,2},
    {0x816u,0x819u,2},
    {0x81Bu,0x823u,2},
    {0x825u,0x827u,2},
    {0x829u,0x82Du,2},
    {0x859u,0x85Bu,2},
    {0x897u,0x89Fu,2},
    {0x8CAu,0x8E1u,2},
    {0x8E3u,0x902u,2},
    {0x915u,0x939u,1},
    {0x93Au,0x93Au,2},
    {0x93Cu,0x93Cu,2},
    {0x941u,0x948u,2},
    {0x94Du,0x94Du,3},
    {0x951u,0x957u,2},
    {0x958u,0x95Fu,1},
    {0x962u,0x963u,2},
    {0x978u,0x97Fu,1},
    {0x981u,0x981u,2},
    {0x995u,0x9A8u,1},
    {0x9AAu,0x9B0u,1},
    {0x9B2u,0x9B2u,1},
    {0x9B6u,0x9B9u,1},
    {0x9BCu,0x9BCu,2},
    {0x9BEu,0x9BEu,2},
    {0x9C1u,0x9C4u,2},
    {0x9CDu,0x9CDu,3},
    {0x9D7u,0x9D7u,2},
    {0x9DCu,0x9DDu,1},
    {0x9DFu,0x9DFu,1},
    {0x9E2u,0x9E3u,2},
    {0x9F0u,0x9F1u,1},
    {0x9FEu,0x9FEu,2},
    {0xA01u,0xA02u,2},
    {0xA3Cu,0xA3Cu,2},
    {0xA41u,0xA42u,2},
    {0xA47u,0xA48u,2},
    {0xA4Bu,0xA4Du,2},
    {0xA51u,0xA51u,2},
    {0xA70u,0xA71u,2},
    {0xA75u,0xA75u,2},
    {0xA81u,0xA82u,2},
    {0xA95u,0xAA8u,1},
    {0xAAAu,0xAB0u,1},
    {0xAB2u,0xAB3u,1},
    {0xAB5u,0xAB9u,1},
    {0xABCu,0xABCu,2},
    {0xAC1u,0xAC5u,2},
    {0xAC7u,0xAC8u,2},
    {0xACDu,0xACDu,3},
    {0xAE2u,0xAE3u,2},
    {0xAF9u,0xAF9u,1},
    {0xAFAu,0xAFFu,2},
    {0xB01u,0xB01u,2},
    {0xB15u,0xB28u,1},
    {0xB2Au,0xB30u,1},
    {0xB32u,0xB33u,1},
    {0xB35u,0xB39u,1},
    {0xB3Cu,0xB3Cu,2},
    {0xB3Eu,0xB3Fu,2},
    {0xB41u,0xB44u,2},
    {0xB4Du,0xB4Du,3},
    {0xB53u,0xB57u,2},
    {0xB5Cu,0xB5Du,1},
    {0xB5Fu,0xB5Fu,1},
    {0xB62u,0xB63u,2},
    {0xB71u,0xB71u,1},
    {0xB82u,0xB82u,2},
    {0xBBEu,0xBBEu,2},
    {0xBC0u,0xBC0u,2},
    {0xBCDu,0xBCDu,2},
    {0xBD7u,0xBD7u,2},
    {0xC00u,0xC00u,2},
    {0xC04u,0xC04u,2},
    {0xC15u,0xC28u,1},
    {0xC2Au,0xC39u,1},
    {0xC3Cu,0xC3Cu,2},
    {0xC3Eu,0xC40u,2},
    {0xC46u,0xC48u,2},
    {0xC4Au,0xC4Cu,2},
    {0xC4Du,0xC4Du,3},
    {0xC55u,0xC56u,2},
    {0xC58u,0xC5Au,1},
    {0xC62u,0xC63u,2},
    {0xC81u,0xC81u,2},
    {0xCBCu,0xCBCu,2},
    {0xCBFu,0xCC0u,2},
    {0xCC2u,0xCC2u,2},
    {0xCC6u,0xCC8u,2},
    {0xCCAu,0xCCDu,2},
    {0xCD5u,0xCD6u,2},
    {0xCE2u,0xCE3u,2},
    {0xD00u,0xD01u,2},
    {0xD15u,0xD3Au,1},
    {0xD3Bu,0xD3Cu,2},
    {0xD3Eu,0xD3Eu,2},
    {0xD41u,0xD44u,2},
    {0xD4Du,0xD4Du,3},
    {0xD57u,0xD57u,2},
    {0xD62u,0xD63u,2},
    {0xD81u,0xD81u,2},
    {0xDCAu,0xDCAu,2},
    {0xDCFu,0xDCFu,2},
    {0xDD2u,0xDD4u,2},
    {0xDD6u,0xDD6u,2},
    {0xDDFu,0xDDFu,2},
    {0xE31u,0xE31u,2},
    {0xE34u,0xE3Au,2},
    {0xE47u,0xE4Eu,2},
    {0xEB1u,0xEB1u,2},
    {0xEB4u,0xEBCu,2},
    {0xEC8u,0xECEu,2},
    {0xF18u,0xF19u,2},
    {0xF35u,0xF35u,2},
    {0xF37u,0xF37u,2},
    {0xF39u,0xF39u,2},
    {0xF71u,0xF7Eu,2},
    {0xF80u,0xF84u,2},
    {0xF86u,0xF87u,2},
    {0xF8Du,0xF97u,2},
    {0xF99u,0xFBCu,2},
    {0xFC6u,0xFC6u,2},
    {0x1000u,0x102Au,1},
    {0x102Du,0x1030u,2},
    {0x1032u,0x1037u,2},
    {0x1039u,0x1039u,3},
    {0x103Au,0x103Au,2},
    {0x103Du,0x103Eu,2},
    {0x103Fu,0x103Fu,1},
    {0x1050u,0x1055u,1},
    {0x1058u,0x1059u,2},
    {0x105Au,0x105Du,1},
    {0x105Eu,0x1060u,2},
    {0x1061u,0x1061u,1},
    {0x1065u,0x1066u,1},
    {0x106Eu,0x1070u,1},
    {0x1071u,0x1074u,2},
    {0x1075u,0x1081u,1},
    {0x1082u,0x1082u,2},
    {0x1085u,0x1086u,2},
    {0x108Du,0x108Du,2},
    {0x108Eu,0x108Eu,1},
    {0x109Du,0x109Du,2},
    {0x135Du,0x135Fu,2},
    {0x1712u,0x1715u,2},
    {0x1732u,0x1734u,2},
    {0x1752u,0x1753u,2},
    {0x1772u,0x1773u,2},
    {0x1780u,0x17B3u,1},
    {0x17B4u,0x17B5u,2},
    {0x17B7u,0x17BDu,2},
    {0x17C6u,0x17C6u,2},
    {0x17C9u,0x17D1u,2},
    {0x17D2u,0x17D2u,3},
    {0x17D3u,0x17D3u,2},
    {0x17DDu,0x17DDu,2},
    {0x180Bu,0x180Du,2},
    {0x180Fu,0x180Fu,2},
    {0x1885u,0x1886u,2},
    {0x18A9u,0x18A9u,2},
    {0x1920u,0x1922u,2},
    {0x1927u,0x1928u,2},
    {0x1932u,0x1932u,2},
    {0x1939u,0x193Bu,2},
    {0x1A17u,0x1A18u,2},
    {0x1A1Bu,0x1A1Bu,2},
    {0x1A20u,0x1A54u,1},
    {0x1A56u,0x1A56u,2},
    {0x1A58u,0x1A5Eu,2},
    {0x1A60u,0x1A60u,3},
    {0x1A62u,0x1A62u,2},
    {0x1A65u,0x1A6Cu,2},
    {0x1A73u,0x1A7Cu,2},
    {0x1A7Fu,0x1A7Fu,2},
    {0x1AB0u,0x1AF0u,2},
    {0x1B00u,0x1B03u,2},
    {0x1B0Bu,0x1B0Cu,1},
    {0x1B13u,0x1B33u,1},
    {0x1B34u,0x1B3Du,2},
    {0x1B42u,0x1B43u,2},
    {0x1B44u,0x1B44u,3},
    {0x1B45u,0x1B4Cu,1},
    {0x1B6Bu,0x1B73u,2},
    {0x1B80u,0x1B81u,2},
    {0x1B83u,0x1BA0u,1},
    {0x1BA2u,0x1BA5u,2},
    {0x1BA8u,0x1BAAu,2},
    {0x1BABu,0x1BABu,3},
    {0x1BACu,0x1BADu,2},
    {0x1BAEu,0x1BAFu,1},
    {0x1BBBu,0x1BBDu,1},
    {0x1BE6u,0x1BE6u,2},
    {0x1BE8u,0x1BE9u,2},
    {0x1BEDu,0x1BEDu,2},
    {0x1BEFu,0x1BF3u,2},
    {0x1C2Cu,0x1C33u,2},
    {0x1C36u,0x1C37u,2},
    {0x1CD0u,0x1CD2u,2},
    {0x1CD4u,0x1CE0u,2},
    {0x1CE2u,0x1CE8u,2},
    {0x1CEDu,0x1CEDu,2},
    {0x1CF4u,0x1CF4u,2},
    {0x1CF5u,0x1CF6u,3},
    {0x1CF8u,0x1CF9u,2},
    {0x1DC0u,0x1DFFu,2},
    {0x200Du,0x200Du,2},
    {0x20D0u,0x20F0u,2},
    {0x2CEFu,0x2CF1u,2},
    {0x2D7Fu,0x2D7Fu,2},
    {0x2DE0u,0x2DFFu,2},
    {0x302Au,0x302Fu,2},
    {0x3099u,0x309Au,2},
    {0xA66Fu,0xA672u,2},
    {0xA674u,0xA67Du,2},
    {0xA69Eu,0xA69Fu,2},
    {0xA6F0u,0xA6F1u,2},
    {0xA802u,0xA802u,2},
    {0xA806u,0xA806u,2},
    {0xA80Bu,0xA80Bu,2},
    {0xA825u,0xA826u,2},
    {0xA82Cu,0xA82Cu,2},
    {0xA8C4u,0xA8C5u,2},
    {0xA8E0u,0xA8F1u,2},
    {0xA8FFu,0xA8FFu,2},
    {0xA926u,0xA92Du,2},
    {0xA947u,0xA951u,2},
    {0xA953u,0xA953u,2},
    {0xA980u,0xA982u,2},
    {0xA989u,0xA98Bu,1},
    {0xA98Fu,0xA9B2u,1},
    {0xA9B3u,0xA9B3u,2},
    {0xA9B6u,0xA9B9u,2},
    {0xA9BCu,0xA9BDu,2},
    {0xA9C0u,0xA9C0u,3},
    {0xA9E0u,0xA9E4u,1},
    {0xA9E5u,0xA9E5u,2},
    {0xA9E7u,0xA9EFu,1},
    {0xA9FAu,0xA9FEu,1},
    {0xAA29u,0xAA2Eu,2},
    {0xAA31u,0xAA32u,2},
    {0xAA35u,0xAA36u,2},
    {0xAA43u,0xAA43u,2},
    {0xAA4Cu,0xAA4Cu,2},
    {0xAA60u,0xAA6Fu,1},
    {0xAA71u,0xAA73u,1},
    {0xAA7Au,0xAA7Au,1},
    {0xAA7Cu,0xAA7Cu,2},
    {0xAA7Eu,0xAA7Fu,1},
    {0xAAB0u,0xAAB0u,2},
    {0xAAB2u,0xAAB4u,2},
    {0xAAB7u,0xAAB8u,2},
    {0xAABEu,0xAABFu,2},
    {0xAAC1u,0xAAC1u,2},
    {0xAAE0u,0xAAEAu,1},
    {0xAAECu,0xAAEDu,2},
    {0xAAF6u,0xAAF6u,3},
    {0xABC0u,0xABDAu,1},
    {0xABE5u,0xABE5u,2},
    {0xABE8u,0xABE8u,2},
    {0xABEDu,0xABEDu,2},
    {0xFB1Eu,0xFB1Eu,2},
    {0xFE00u,0xFE0Fu,2},
    {0xFE20u,0xFE2Fu,2},
    {0xFF9Eu,0xFF9Fu,2},
    {0x101FDu,0x101FDu,2},
    {0x102E0u,0x102E0u,2},
    {0x10376u,0x1037Au,2},
    {0x10A00u,0x10A00u,1},
    {0x10A01u,0x10A03u,2},
    {0x10A05u,0x10A06u,2},
    {0x10A0Cu,0x10A0Fu,2},
    {0x10A10u,0x10A13u,1},
    {0x10A15u,0x10A17u,1},
    {0x10A19u,0x10A35u,1},
    {0x10A38u,0x10A3Au,2},
    {0x10A3Fu,0x10A3Fu,3},
    {0x10AE5u,0x10AE6u,2},
    {0x10D24u,0x10D27u,2},
    {0x10D69u,0x10D6Du,2},
    {0x10EABu,0x10EACu,2},
    {0x10ECBu,0x10ECFu,2},
    {0x10EF0u,0x10EFFu,2},
    {0x10F46u,0x10F50u,2},
    {0x10F82u,0x10F85u,2},
    {0x11001u,0x11001u,2},
    {0x11038u,0x11046u,2},
    {0x11070u,0x11070u,2},
    {0x11073u,0x11074u,2},
    {0x1107Fu,0x11081u,2},
    {0x110B3u,0x110B6u,2},
    {0x110B9u,0x110BAu,2},
    {0x110C2u,0x110C2u,2},
    {0x11100u,0x11102u,2},
    {0x11103u,0x11126u,1},
    {0x11127u,0x1112Bu,2},
    {0x1112Du,0x11132u,2},
    {0x11133u,0x11133u,3},
    {0x11134u,0x11134u,2},
    {0x11144u,0x11144u,1},
    {0x11147u,0x11147u,1},
    {0x11173u,0x11173u,2},
    {0x11180u,0x11181u,2},
    {0x111B6u,0x111BEu,2},
    {0x111C0u,0x111C0u,2},
    {0x111C9u,0x111CCu,2},
    {0x111CFu,0x111CFu,2},
    {0x1122Fu,0x11231u,2},
    {0x11234u,0x11237u,2},
    {0x1123Eu,0x1123Eu,2},
    {0x11241u,0x11241u,2},
    {0x112DFu,0x112DFu,2},
    {0x112E3u,0x112EAu,2},
    {0x11300u,0x11301u,2},
    {0x1133Bu,0x1133Cu,2},
    {0x1133Eu,0x1133Eu,2},
    {0x11340u,0x11340u,2},
    {0x1134Du,0x1134Du,2},
    {0x11357u,0x11357u,2},
    {0x11366u,0x1136Cu,2},
    {0x11370u,0x11374u,2},
    {0x11380u,0x11389u,1},
    {0x1138Bu,0x1138Bu,1},
    {0x1138Eu,0x1138Eu,1},
    {0x11390u,0x113B5u,1},
    {0x113B8u,0x113B8u,2},
    {0x113BBu,0x113C0u,2},
    {0x113C2u,0x113C2u,2},
    {0x113C5u,0x113C5u,2},
    {0x113C7u,0x113C9u,2},
    {0x113CEu,0x113CFu,2},
    {0x113D0u,0x113D0u,3},
    {0x113D2u,0x113D2u,2},
    {0x113E1u,0x113E2u,2},
    {0x11438u,0x1143Fu,2},
    {0x11442u,0x11444u,2},
    {0x11446u,0x11446u,2},
    {0x1145Eu,0x1145Eu,2},
    {0x114B0u,0x114B0u,2},
    {0x114B3u,0x114B8u,2},
    {0x114BAu,0x114BAu,2},
    {0x114BDu,0x114BDu,2},
    {0x114BFu,0x114C0u,2},
    {0x114C2u,0x114C3u,2},
    {0x115AFu,0x115AFu,2},
    {0x115B2u,0x115B5u,2},
    {0x115BCu,0x115BDu,2},
    {0x115BFu,0x115C0u,2},
    {0x115DCu,0x115DDu,2},
    {0x11633u,0x1163Au,2},
    {0x1163Du,0x1163Du,2},
    {0x1163Fu,0x11640u,2},
    {0x116ABu,0x116ABu,2},
    {0x116ADu,0x116ADu,2},
    {0x116B0u,0x116B7u,2},
    {0x1171Du,0x1171Du,2},
    {0x1171Fu,0x1171Fu,2},
    {0x11722u,0x11725u,2},
    {0x11727u,0x1172Bu,2},
    {0x1182Fu,0x11837u,2},
    {0x11839u,0x1183Au,2},
    {0x11900u,0x11906u,1},
    {0x11909u,0x11909u,1},
    {0x1190Cu,0x11913u,1},
    {0x11915u,0x11916u,1},
    {0x11918u,0x1192Fu,1},
    {0x11930u,0x11930u,2},
    {0x1193Bu,0x1193Du,2},
    {0x1193Eu,0x1193Eu,3},
    {0x11943u,0x11943u,2},
    {0x119D4u,0x119D7u,2},
    {0x119DAu,0x119DBu,2},
    {0x119E0u,0x119E0u,2},
    {0x11A00u,0x11A00u,1},
    {0x11A01u,0x11A0Au,2},
    {0x11A0Bu,0x11A32u,1},
    {0x11A33u,0x11A38u,2},
    {0x11A3Au,0x11A3Au,3},
    {0x11A3Bu,0x11A3Eu,2},
    {0x11A47u,0x11A47u,3},
    {0x11A50u,0x11A50u,1},
    {0x11A51u,0x11A56u,2},
    {0x11A59u,0x11A5Bu,2},
    {0x11A5Cu,0x11A83u,1},
    {0x11A8Au,0x11A96u,2},
    {0x11A98u,0x11A98u,2},
    {0x11A99u,0x11A99u,3},
    {0x11B0Au,0x11B0Au,1},
    {0x11B60u,0x11B60u,2},
    {0x11B62u,0x11B64u,2},
    {0x11B66u,0x11B66u,2},
    {0x11C30u,0x11C36u,2},
    {0x11C38u,0x11C3Du,2},
    {0x11C3Fu,0x11C3Fu,2},
    {0x11C92u,0x11CA7u,2},
    {0x11CAAu,0x11CB0u,2},
    {0x11CB2u,0x11CB3u,2},
    {0x11CB5u,0x11CB6u,2},
    {0x11D31u,0x11D36u,2},
    {0x11D3Au,0x11D3Au,2},
    {0x11D3Cu,0x11D3Du,2},
    {0x11D3Fu,0x11D45u,2},
    {0x11D47u,0x11D47u,2},
    {0x11D90u,0x11D91u,2},
    {0x11D95u,0x11D95u,2},
    {0x11D97u,0x11D97u,2},
    {0x11DF0u,0x11DF0u,2},
    {0x11DF1u,0x11DF1u,1},
    {0x11EF3u,0x11EF4u,2},
    {0x11F00u,0x11F01u,2},
    {0x11F04u,0x11F10u,1},
    {0x11F12u,0x11F33u,1},
    {0x11F36u,0x11F3Au,2},
    {0x11F40u,0x11F41u,2},
    {0x11F42u,0x11F42u,3},
    {0x11F5Au,0x11F5Au,2},
    {0x13440u,0x13440u,2},
    {0x13447u,0x13455u,2},
    {0x1611Eu,0x16129u,2},
    {0x1612Du,0x1612Fu,2},
    {0x16AF0u,0x16AF4u,2},
    {0x16B30u,0x16B36u,2},
    {0x16F4Fu,0x16F4Fu,2},
    {0x16F8Fu,0x16F92u,2},
    {0x16FE4u,0x16FE4u,2},
    {0x16FF0u,0x16FF1u,2},
    {0x1BC9Du,0x1BC9Eu,2},
    {0x1CF00u,0x1CF2Du,2},
    {0x1CF30u,0x1CF46u,2},
    {0x1D127u,0x1D128u,2},
    {0x1D165u,0x1D169u,2},
    {0x1D16Du,0x1D172u,2},
    {0x1D17Bu,0x1D182u,2},
    {0x1D185u,0x1D18Bu,2},
    {0x1D1AAu,0x1D1ADu,2},
    {0x1D242u,0x1D244u,2},
    {0x1D250u,0x1D252u,2},
    {0x1D25Bu,0x1D25Cu,2},
    {0x1D25Fu,0x1D25Fu,2},
    {0x1D280u,0x1D281u,2},
    {0x1DA00u,0x1DA36u,2},
    {0x1DA3Bu,0x1DA6Cu,2},
    {0x1DA75u,0x1DA75u,2},
    {0x1DA84u,0x1DA84u,2},
    {0x1DA9Bu,0x1DA9Fu,2},
    {0x1DAA1u,0x1DAAFu,2},
    {0x1E000u,0x1E006u,2},
    {0x1E008u,0x1E018u,2},
    {0x1E01Bu,0x1E021u,2},
    {0x1E023u,0x1E024u,2},
    {0x1E026u,0x1E02Au,2},
    {0x1E08Fu,0x1E08Fu,2},
    {0x1E130u,0x1E136u,2},
    {0x1E2AEu,0x1E2AEu,2},
    {0x1E2ECu,0x1E2EFu,2},
    {0x1E4ECu,0x1E4EFu,2},
    {0x1E5EEu,0x1E5EFu,2},
    {0x1E6E3u,0x1E6E3u,2},
    {0x1E6E6u,0x1E6E6u,2},
    {0x1E6EEu,0x1E6EFu,2},
    {0x1E6F5u,0x1E6F5u,2},
    {0x1E8D0u,0x1E8D6u,2},
    {0x1E944u,0x1E94Au,2},
    {0x1F3FBu,0x1F3FFu,2},
    {0xE0020u,0xE007Fu,2},
    {0xE0100u,0xE01EFu,2}
};
static const size_t eri_incb_table_count = sizeof(eri_incb_table)/sizeof(eri_incb_table[0]);
static const eri_unicode_range eri_ep_table[] = {
    {0xA9u,0xA9u,1},
    {0xAEu,0xAEu,1},
    {0x203Cu,0x203Cu,1},
    {0x2049u,0x2049u,1},
    {0x2122u,0x2122u,1},
    {0x2139u,0x2139u,1},
    {0x2194u,0x2199u,1},
    {0x21A9u,0x21AAu,1},
    {0x231Au,0x231Bu,1},
    {0x2328u,0x2328u,1},
    {0x23CFu,0x23CFu,1},
    {0x23E9u,0x23F3u,1},
    {0x23F8u,0x23FAu,1},
    {0x24C2u,0x24C2u,1},
    {0x25AAu,0x25ABu,1},
    {0x25B6u,0x25B6u,1},
    {0x25C0u,0x25C0u,1},
    {0x25FBu,0x25FEu,1},
    {0x2600u,0x2604u,1},
    {0x260Eu,0x260Eu,1},
    {0x2611u,0x2611u,1},
    {0x2614u,0x2615u,1},
    {0x2618u,0x2618u,1},
    {0x261Du,0x261Du,1},
    {0x2620u,0x2620u,1},
    {0x2622u,0x2623u,1},
    {0x2626u,0x2626u,1},
    {0x262Au,0x262Au,1},
    {0x262Eu,0x262Fu,1},
    {0x2638u,0x263Au,1},
    {0x2640u,0x2640u,1},
    {0x2642u,0x2642u,1},
    {0x2648u,0x2653u,1},
    {0x265Fu,0x2660u,1},
    {0x2663u,0x2663u,1},
    {0x2665u,0x2666u,1},
    {0x2668u,0x2668u,1},
    {0x267Bu,0x267Bu,1},
    {0x267Eu,0x267Fu,1},
    {0x2692u,0x2697u,1},
    {0x2699u,0x2699u,1},
    {0x269Bu,0x269Cu,1},
    {0x26A0u,0x26A1u,1},
    {0x26A7u,0x26A7u,1},
    {0x26AAu,0x26ABu,1},
    {0x26B0u,0x26B1u,1},
    {0x26BDu,0x26BEu,1},
    {0x26C4u,0x26C5u,1},
    {0x26C8u,0x26C8u,1},
    {0x26CEu,0x26CFu,1},
    {0x26D1u,0x26D1u,1},
    {0x26D3u,0x26D4u,1},
    {0x26E9u,0x26EAu,1},
    {0x26F0u,0x26F5u,1},
    {0x26F7u,0x26FAu,1},
    {0x26FDu,0x26FDu,1},
    {0x2702u,0x2702u,1},
    {0x2705u,0x2705u,1},
    {0x2708u,0x270Du,1},
    {0x270Fu,0x270Fu,1},
    {0x2712u,0x2712u,1},
    {0x2714u,0x2714u,1},
    {0x2716u,0x2716u,1},
    {0x271Du,0x271Du,1},
    {0x2721u,0x2721u,1},
    {0x2728u,0x2728u,1},
    {0x2733u,0x2734u,1},
    {0x2744u,0x2744u,1},
    {0x2747u,0x2747u,1},
    {0x274Cu,0x274Cu,1},
    {0x274Eu,0x274Eu,1},
    {0x2753u,0x2755u,1},
    {0x2757u,0x2757u,1},
    {0x2763u,0x2764u,1},
    {0x2795u,0x2797u,1},
    {0x27A1u,0x27A1u,1},
    {0x27B0u,0x27B0u,1},
    {0x27BFu,0x27BFu,1},
    {0x2934u,0x2935u,1},
    {0x2B05u,0x2B07u,1},
    {0x2B1Bu,0x2B1Cu,1},
    {0x2B50u,0x2B50u,1},
    {0x2B55u,0x2B55u,1},
    {0x3030u,0x3030u,1},
    {0x303Du,0x303Du,1},
    {0x3297u,0x3297u,1},
    {0x3299u,0x3299u,1},
    {0x1F004u,0x1F004u,1},
    {0x1F02Cu,0x1F02Fu,1},
    {0x1F094u,0x1F09Fu,1},
    {0x1F0AFu,0x1F0B0u,1},
    {0x1F0C0u,0x1F0C0u,1},
    {0x1F0CFu,0x1F0D0u,1},
    {0x1F0F6u,0x1F0FFu,1},
    {0x1F170u,0x1F171u,1},
    {0x1F17Eu,0x1F17Fu,1},
    {0x1F18Eu,0x1F18Eu,1},
    {0x1F191u,0x1F19Au,1},
    {0x1F1AFu,0x1F1E5u,1},
    {0x1F201u,0x1F20Fu,1},
    {0x1F21Au,0x1F21Au,1},
    {0x1F22Fu,0x1F22Fu,1},
    {0x1F232u,0x1F23Au,1},
    {0x1F23Cu,0x1F23Fu,1},
    {0x1F249u,0x1F25Fu,1},
    {0x1F266u,0x1F321u,1},
    {0x1F324u,0x1F393u,1},
    {0x1F396u,0x1F397u,1},
    {0x1F399u,0x1F39Bu,1},
    {0x1F39Eu,0x1F3F0u,1},
    {0x1F3F3u,0x1F3F5u,1},
    {0x1F3F7u,0x1F3FAu,1},
    {0x1F400u,0x1F4FDu,1},
    {0x1F4FFu,0x1F53Du,1},
    {0x1F549u,0x1F54Eu,1},
    {0x1F550u,0x1F567u,1},
    {0x1F56Fu,0x1F570u,1},
    {0x1F573u,0x1F57Au,1},
    {0x1F587u,0x1F587u,1},
    {0x1F58Au,0x1F58Du,1},
    {0x1F590u,0x1F590u,1},
    {0x1F595u,0x1F596u,1},
    {0x1F5A4u,0x1F5A5u,1},
    {0x1F5A8u,0x1F5A8u,1},
    {0x1F5B1u,0x1F5B2u,1},
    {0x1F5BCu,0x1F5BCu,1},
    {0x1F5C2u,0x1F5C4u,1},
    {0x1F5D1u,0x1F5D3u,1},
    {0x1F5DCu,0x1F5DEu,1},
    {0x1F5E1u,0x1F5E1u,1},
    {0x1F5E3u,0x1F5E3u,1},
    {0x1F5E8u,0x1F5E8u,1},
    {0x1F5EFu,0x1F5EFu,1},
    {0x1F5F3u,0x1F5F3u,1},
    {0x1F5FAu,0x1F64Fu,1},
    {0x1F680u,0x1F6C5u,1},
    {0x1F6CBu,0x1F6D2u,1},
    {0x1F6D5u,0x1F6E5u,1},
    {0x1F6E9u,0x1F6E9u,1},
    {0x1F6EBu,0x1F6F0u,1},
    {0x1F6F3u,0x1F6FFu,1},
    {0x1F7DCu,0x1F7F0u,1},
    {0x1F80Cu,0x1F80Fu,1},
    {0x1F848u,0x1F84Fu,1},
    {0x1F85Au,0x1F85Fu,1},
    {0x1F888u,0x1F88Fu,1},
    {0x1F8AEu,0x1F8AFu,1},
    {0x1F8BCu,0x1F8BFu,1},
    {0x1F8C2u,0x1F8CFu,1},
    {0x1F8D9u,0x1F8FFu,1},
    {0x1F90Cu,0x1F93Au,1},
    {0x1F93Cu,0x1F945u,1},
    {0x1F947u,0x1F9FFu,1},
    {0x1FA58u,0x1FA5Fu,1},
    {0x1FA6Eu,0x1FAFFu,1},
    {0x1FC00u,0x1FFFDu,1}
};
static const size_t eri_ep_table_count = sizeof(eri_ep_table)/sizeof(eri_ep_table[0]);
static uint8_t eri_unicode_lookup(const eri_unicode_range *table,size_t count,uint32_t cp){
    size_t lo=0,hi=count;
    while(lo<hi){
        size_t mid=lo+(hi-lo)/2;
        eri_unicode_range r=table[mid];
        if(cp<r.first)hi=mid;
        else if(cp>r.last)lo=mid+1;
        else return r.value;
    }
    return 0;
}

static uint8_t eri_gcb(uint32_t cp){ return eri_unicode_lookup(eri_gcb_table,eri_gcb_table_count,cp); }
static uint8_t eri_incb(uint32_t cp){ return eri_unicode_lookup(eri_incb_table,eri_incb_table_count,cp); }
static bool eri_extended_pictographic(uint32_t cp){ return eri_unicode_lookup(eri_ep_table,eri_ep_table_count,cp)!=0; }

static uint32_t eri_utf8_decode_scalar(eri_text text,size_t pos,size_t *next){
    if(pos>=text.len)eri_fault("invalid UTF-8 inside Text");
    unsigned char c0=text.data[pos];
    size_t width=eri_utf8_width(c0);
    if(pos+width>text.len)eri_fault("invalid UTF-8 inside Text");
    if(width==1){*next=pos+1;return c0;}
    uint32_t cp=(uint32_t)(c0 & (width==2?0x1f:(width==3?0x0f:0x07)));
    for(size_t i=1;i<width;i++){
        unsigned char c=text.data[pos+i];
        if((c&0xc0)!=0x80)eri_fault("invalid UTF-8 inside Text");
        cp=(cp<<6)|(uint32_t)(c&0x3f);
    }
    *next=pos+width;
    return cp;
}

static size_t eri_text_decode_scalars(eri_text text,uint32_t **out_cp,size_t **out_offset){
    size_t capacity=text.len?text.len:1;
    uint32_t *cp=(uint32_t*)eri_alloc(sizeof(uint32_t)*capacity);
    size_t *offset=(size_t*)eri_alloc(sizeof(size_t)*(capacity+1));
    size_t count=0,pos=0;
    while(pos<text.len){
        size_t next;
        offset[count]=pos;
        cp[count]=eri_utf8_decode_scalar(text,pos,&next);
        count++;pos=next;
    }
    offset[count]=text.len;
    *out_cp=cp;*out_offset=offset;
    return count;
}

static bool eri_grapheme_break(const uint32_t *cp,size_t count,size_t i){
    (void)count;
    uint8_t a=eri_gcb(cp[i-1]),b=eri_gcb(cp[i]);
    /* GB3 */ if(a==ERI_GCB_CR&&b==ERI_GCB_LF)return false;
    /* GB4 */ if(a==ERI_GCB_CONTROL||a==ERI_GCB_CR||a==ERI_GCB_LF)return true;
    /* GB5 */ if(b==ERI_GCB_CONTROL||b==ERI_GCB_CR||b==ERI_GCB_LF)return true;
    /* GB6 */ if(a==ERI_GCB_L&&(b==ERI_GCB_L||b==ERI_GCB_V||b==ERI_GCB_LV||b==ERI_GCB_LVT))return false;
    /* GB7 */ if((a==ERI_GCB_LV||a==ERI_GCB_V)&&(b==ERI_GCB_V||b==ERI_GCB_T))return false;
    /* GB8 */ if((a==ERI_GCB_LVT||a==ERI_GCB_T)&&b==ERI_GCB_T)return false;
    /* GB9 */ if(b==ERI_GCB_EXTEND||b==ERI_GCB_ZWJ)return false;
    /* GB9a */ if(b==ERI_GCB_SPACINGMARK)return false;
    /* GB9b */ if(a==ERI_GCB_PREPEND)return false;
    /* GB9c: InCB Consonant ... Linker ... x Consonant */
    if(eri_incb(cp[i])==ERI_INCB_CONSONANT){
        size_t j=i;bool saw_linker=false;
        while(j>0){
            uint8_t p=eri_incb(cp[j-1]);
            if(p==ERI_INCB_LINKER){saw_linker=true;j--;continue;}
            if(p==ERI_INCB_EXTEND){j--;continue;}
            break;
        }
        if(saw_linker&&j>0&&eri_incb(cp[j-1])==ERI_INCB_CONSONANT)return false;
    }
    /* GB11: Extended_Pictographic Extend* ZWJ x Extended_Pictographic */
    if(eri_extended_pictographic(cp[i])&&a==ERI_GCB_ZWJ){
        size_t j=i-1;
        if(j>0)j--;
        else j=(size_t)-1;
        while(j!=(size_t)-1&&eri_gcb(cp[j])==ERI_GCB_EXTEND){ if(j==0){j=(size_t)-1;break;} j--; }
        if(j!=(size_t)-1&&eri_extended_pictographic(cp[j]))return false;
    }
    /* GB12/GB13: pair consecutive Regional Indicators. */
    if(a==ERI_GCB_RI&&b==ERI_GCB_RI){
        size_t preceding=0,j=i;
        while(j>0&&eri_gcb(cp[j-1])==ERI_GCB_RI){preceding++;j--;}
        if((preceding&1u)!=0)return false;
    }
    /* GB999 */ return true;
}

static int64_t eri_text_character_count(eri_text text){
    uint32_t *cp;size_t *offset;
    size_t n=eri_text_decode_scalars(text,&cp,&offset);
    (void)offset;
    if(n==0)return 0;
    int64_t clusters=1;
    for(size_t i=1;i<n;i++)if(eri_grapheme_break(cp,n,i))clusters++;
    return clusters;
}

static eri_text eri_text_character_get(eri_text text,int64_t index){
    if(index<0)eri_fault("Text view index out of bounds");
    uint32_t *cp;size_t *offset;
    size_t n=eri_text_decode_scalars(text,&cp,&offset);
    if(n==0)eri_fault("Text view index out of bounds");
    int64_t cluster=0;size_t start=0;
    for(size_t i=1;i<=n;i++){
        bool boundary=(i==n)||eri_grapheme_break(cp,n,i);
        if(boundary){
            if(cluster==index)return eri_text_from_bytes(text.data+offset[start],offset[i]-offset[start]);
            cluster++;start=i;
        }
    }
    eri_fault("Text view index out of bounds");
    return eri_text_from_bytes(NULL,0);
}

static int64_t eri_text_view_count(eri_text_view view){
    if(view.kind==ERI_TEXT_VIEW_BYTES)return (int64_t)view.text.len;
    if(view.kind==ERI_TEXT_VIEW_SCALARS)return (int64_t)eri_text_scalar_count(view.text);
    if(view.kind==ERI_TEXT_VIEW_CHARACTERS)return eri_text_character_count(view.text);
    eri_fault("internal Text view kind mismatch");
    return 0;
}

static int64_t eri_text_view_byte_get(eri_text_view view,int64_t index){
    if(view.kind!=ERI_TEXT_VIEW_BYTES)eri_fault("internal Text view kind mismatch");
    return eri_text_byte_get(view.text,index);
}

static eri_text eri_text_view_text_get(eri_text_view view,int64_t index){
    if(view.kind==ERI_TEXT_VIEW_SCALARS)return eri_text_scalar_get(view.text,index);
    if(view.kind==ERI_TEXT_VIEW_CHARACTERS)return eri_text_character_get(view.text,index);
    eri_fault("internal Text view kind mismatch");
    return eri_text_from_bytes(NULL,0);
}

#ifndef _WIN32
extern char *realpath(const char *restrict path,char *restrict resolved_path);
#endif
static eri_text eri_file_canonical_path(eri_text path){
    char *cp=eri_text_to_c_path(path);
    if(!cp)eri_raise_file_failure("file path contains NUL",path);
#ifdef _WIN32
    struct stat information;
    if(stat(cp,&information)!=0)eri_raise_file_failure(strerror(errno),path);
    char *resolved=_fullpath(NULL,cp,0);
#else
    char *resolved=realpath(cp,NULL);
#endif
    if(!resolved)eri_raise_file_failure(strerror(errno),path);
    eri_text result=eri_text_from_cstr(resolved);free(resolved);return result;
}
static eri_file eri_file_acquire(eri_text path,bool create){
    char *cp=eri_text_to_c_path(path);
    if(!cp)eri_raise_file_failure("file path contains NUL",path);
    FILE *handle=fopen(cp,create ? "wx+" : "r");
    if(!handle)eri_raise_file_failure(strerror(errno),path);
    return (eri_file){path,cp,handle,false,create};
}

static int eri_process_argc=0;
static char **eri_process_argv=NULL;
static int eri_process_exit_code=0;
static eri_list_text eri_process_arguments(void){
    size_t count=eri_process_argc>0 ? (size_t)eri_process_argc-1 : 0;
    eri_list_text result={count,NULL};
    if(count>SIZE_MAX/sizeof(eri_text))eri_fault("too many process arguments");
    if(count)result.data=(eri_text*)eri_alloc(count*sizeof(eri_text));
    for(size_t i=0;i<count;i++){
        const unsigned char *data=(const unsigned char*)eri_process_argv[i+1];
        size_t length=strlen((const char*)data);
        if(!eri_utf8_valid(data,length))eri_fault("process arguments must be valid UTF-8");
        result.data[i]=eri_text_from_bytes(data,length);
    }
    return result;
}
static void eri_process_writeError(eri_text text){
    if(text.len)fwrite(text.data,1,text.len,stderr);
    fputc('\n',stderr);
}
static void eri_process_setExitCode(int64_t code){
    if(code<0||code>255)eri_fault("process exit code must be between 0 and 255");
    eri_process_exit_code=(int)code;
}

typedef struct eri_struct_tag_compiler_u002e_u1_budget_u002e_LimitError eri_struct_compiler_u002e_u1_budget_u002e_LimitError;
typedef struct eri_struct_tag_compiler_u002e_u1_budget_u002e_Owner eri_struct_compiler_u002e_u1_budget_u002e_Owner;
typedef struct eri_struct_tag_compiler_u002e_u1_budget_u002e_Reservation eri_struct_compiler_u002e_u1_budget_u002e_Reservation;
typedef struct eri_struct_tag_compiler_u002e_u1_budget_u002e_Allocation eri_struct_compiler_u002e_u1_budget_u002e_Allocation;
typedef struct eri_struct_tag_compiler_u002e_u1_budget_u002e_Phase eri_struct_compiler_u002e_u1_budget_u002e_Phase;
typedef struct eri_struct_tag_compiler_u002e_u1_words_u002e_Page eri_struct_compiler_u002e_u1_words_u002e_Page;
typedef struct eri_struct_tag_compiler_u002e_u1_words_u002e_Node eri_struct_compiler_u002e_u1_words_u002e_Node;
typedef struct eri_struct_tag_compiler_u002e_u1_words_u002e_Words eri_struct_compiler_u002e_u1_words_u002e_Words;
typedef struct eri_struct_tag_compiler_u002e_u1_meta_u002e_Key eri_struct_compiler_u002e_u1_meta_u002e_Key;
typedef struct eri_struct_tag_compiler_u002e_u1_meta_u002e_TypeId eri_struct_compiler_u002e_u1_meta_u002e_TypeId;
typedef struct eri_struct_tag_compiler_u002e_u1_meta_u002e_SignatureId eri_struct_compiler_u002e_u1_meta_u002e_SignatureId;
typedef struct eri_struct_tag_compiler_u002e_u1_meta_u002e_SourceId eri_struct_compiler_u002e_u1_meta_u002e_SourceId;
typedef struct eri_struct_tag_compiler_u002e_u1_meta_u002e_LocId eri_struct_compiler_u002e_u1_meta_u002e_LocId;
typedef struct eri_struct_tag_compiler_u002e_u1_meta_u002e_Metadata eri_struct_compiler_u002e_u1_meta_u002e_Metadata;
typedef struct eri_struct_tag_compiler_u002e_u1_builder_u002e_BlockId eri_struct_compiler_u002e_u1_builder_u002e_BlockId;
typedef struct eri_struct_tag_compiler_u002e_u1_builder_u002e_ValueId eri_struct_compiler_u002e_u1_builder_u002e_ValueId;
typedef struct eri_struct_tag_compiler_u002e_u1_builder_u002e_InstId eri_struct_compiler_u002e_u1_builder_u002e_InstId;
typedef struct eri_struct_tag_compiler_u002e_u1_builder_u002e_CellId eri_struct_compiler_u002e_u1_builder_u002e_CellId;
typedef struct eri_struct_tag_compiler_u002e_u1_builder_u002e_Pair eri_struct_compiler_u002e_u1_builder_u002e_Pair;
typedef struct eri_struct_tag_compiler_u002e_u1_builder_u002e_Function eri_struct_compiler_u002e_u1_builder_u002e_Function;
typedef struct eri_struct_tag_compiler_u002e_u1_dominance_u002e_Graph eri_struct_compiler_u002e_u1_dominance_u002e_Graph;
typedef struct eri_struct_tag_compiler_u002e_u1_verify_u002e_InvalidIR eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR;
typedef struct eri_struct_tag_compiler_u002e_u1_verify_u002e_Report eri_struct_compiler_u002e_u1_verify_u002e_Report;
typedef struct eri_struct_tag_compiler_u002e_u1_verify_u002e_Context eri_struct_compiler_u002e_u1_verify_u002e_Context;
typedef struct eri_struct_tag_verifier_u002d_debug_u002e_ProbeError eri_struct_verifier_u002d_debug_u002e_ProbeError;
typedef struct eri_struct_tag_verifier_u002d_debug_u002e_Harness eri_struct_verifier_u002d_debug_u002e_Harness;
typedef struct { size_t count; eri_struct_compiler_u002e_u1_builder_u002e_ValueId *data; } eri_list_compiler_u002e_u1_builder_u002e_ValueId;
typedef struct { size_t count; eri_struct_compiler_u002e_u1_meta_u002e_TypeId *data; } eri_list_compiler_u002e_u1_meta_u002e_TypeId;
typedef struct { bool has; eri_struct_compiler_u002e_u1_budget_u002e_Allocation * value; } eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation;
static eri_struct_compiler_u002e_u1_budget_u002e_Allocation * eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_get(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation v) { if(!v.has) eri_fault("optional value is absent"); return v.value; }

typedef struct { bool has; eri_struct_compiler_u002e_u1_budget_u002e_Owner * value; } eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner;
static eri_struct_compiler_u002e_u1_budget_u002e_Owner * eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v) { if(!v.has) eri_fault("optional value is absent"); return v.value; }

typedef struct { bool has; eri_struct_compiler_u002e_u1_words_u002e_Node * value; } eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node;
static eri_struct_compiler_u002e_u1_words_u002e_Node * eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_get(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node v) { if(!v.has) eri_fault("optional value is absent"); return v.value; }

typedef struct { bool has; eri_struct_compiler_u002e_u1_words_u002e_Page * value; } eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page;
static eri_struct_compiler_u002e_u1_words_u002e_Page * eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_get(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page v) { if(!v.has) eri_fault("optional value is absent"); return v.value; }

struct eri_struct_tag_compiler_u002e_u1_budget_u002e_LimitError {
    eri_text f_message;
    eri_text f_category;
    int64_t f_requested;
    int64_t f_remaining;
};

struct eri_struct_tag_compiler_u002e_u1_budget_u002e_Owner {
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner f_parent;
    int64_t f_kind;
    int64_t f_state;
    int64_t f_limit;
    int64_t f_trafficLimit;
    int64_t f_workLimit;
    int64_t f_live;
    int64_t f_pending;
    int64_t f_peak;
    int64_t f_reservedPeak;
    int64_t f_traffic;
    int64_t f_pendingTraffic;
    int64_t f_work;
};

struct eri_struct_tag_compiler_u002e_u1_budget_u002e_Reservation {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_owner;
    int64_t f_bytes;
    int64_t f_state;
};

struct eri_struct_tag_compiler_u002e_u1_budget_u002e_Allocation {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_owner;
    int64_t f_bytes;
    int64_t f_state;
};

struct eri_struct_tag_compiler_u002e_u1_budget_u002e_Phase {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_owner;
    int64_t f_limit;
    int64_t f_used;
    int64_t f_prepaid;
    int64_t f_state;
};

struct eri_struct_tag_compiler_u002e_u1_words_u002e_Page {
    int64_t f_w0;
    int64_t f_w1;
    int64_t f_w2;
    int64_t f_w3;
    int64_t f_w4;
    int64_t f_w5;
    int64_t f_w6;
    int64_t f_w7;
    int64_t f_w8;
    int64_t f_w9;
    int64_t f_w10;
    int64_t f_w11;
    int64_t f_w12;
    int64_t f_w13;
    int64_t f_w14;
    int64_t f_w15;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation f_charge;
};

struct eri_struct_tag_compiler_u002e_u1_words_u002e_Node {
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c0;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c1;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c2;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c3;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c4;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c5;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c6;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c7;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c8;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c9;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c10;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c11;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c12;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c13;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c14;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_c15;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page f_page;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation f_charge;
};

struct eri_struct_tag_compiler_u002e_u1_words_u002e_Words {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_owner;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node f_root;
    int64_t f_length;
    int64_t f_limit;
    bool f_closed;
    bool f_frozen;
    eri_struct_compiler_u002e_u1_budget_u002e_Allocation * f_control;
};

struct eri_struct_tag_compiler_u002e_u1_meta_u002e_Key {
    int64_t f_marker;
};

struct eri_struct_tag_compiler_u002e_u1_meta_u002e_TypeId {
    int64_t f_index;
};

struct eri_struct_tag_compiler_u002e_u1_meta_u002e_SignatureId {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_owner;
    int64_t f_index;
};

struct eri_struct_tag_compiler_u002e_u1_meta_u002e_SourceId {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_owner;
    int64_t f_index;
};

struct eri_struct_tag_compiler_u002e_u1_meta_u002e_LocId {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_owner;
    int64_t f_index;
};

struct eri_struct_tag_compiler_u002e_u1_meta_u002e_Metadata {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_key;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_owner;
    bool f_frozen;
    bool f_closed;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation f_control;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_signatures;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_types;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_buckets;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_sources;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_bytes;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_locations;
};

struct eri_struct_tag_compiler_u002e_u1_builder_u002e_BlockId {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_owner;
    int64_t f_index;
};

struct eri_struct_tag_compiler_u002e_u1_builder_u002e_ValueId {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_owner;
    int64_t f_index;
};

struct eri_struct_tag_compiler_u002e_u1_builder_u002e_InstId {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_owner;
    int64_t f_index;
};

struct eri_struct_tag_compiler_u002e_u1_builder_u002e_CellId {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_owner;
    int64_t f_index;
};

struct eri_struct_tag_compiler_u002e_u1_builder_u002e_Pair {
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId f_value;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId f_overflow;
};

struct eri_struct_tag_compiler_u002e_u1_builder_u002e_Function {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * f_key;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * f_metadata;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId f_signature;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_owner;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * f_phase;
    int64_t f_state;
    int64_t f_revision;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation f_control;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_blocks;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_values;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_instructions;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_operands;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_edges;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_arguments;
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_cells;
};

struct eri_struct_tag_compiler_u002e_u1_dominance_u002e_Graph {
    eri_struct_compiler_u002e_u1_words_u002e_Words * f_data;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * f_phase;
    int64_t f_blocks;
    int64_t f_edges;
    int64_t f_edgeBase;
    int64_t f_stackBase;
    int64_t f_reachable;
    int64_t f_reachableEdges;
    int64_t f_visits;
    int64_t f_visitLimit;
    bool f_prepared;
    int64_t f_state;
};

struct eri_struct_tag_compiler_u002e_u1_verify_u002e_InvalidIR {
    eri_text f_message;
    eri_text f_category;
    int64_t f_stage;
    int64_t f_block;
    int64_t f_instruction;
    int64_t f_location;
};

struct eri_struct_tag_compiler_u002e_u1_verify_u002e_Report {
    int64_t f_reachableBlocks;
    int64_t f_structuralVisits;
    int64_t f_dominanceVisits;
    int64_t f_work;
    int64_t f_revision;
};

struct eri_struct_tag_compiler_u002e_u1_verify_u002e_Context {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * f_routine;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * f_phase;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * f_graph;
    int64_t f_stage;
    int64_t f_block;
    int64_t f_instruction;
    int64_t f_location;
    int64_t f_visits;
    int64_t f_scanLimit;
    int64_t f_positions;
    int64_t f_buckets;
    bool f_construction;
};

struct eri_struct_tag_verifier_u002d_debug_u002e_ProbeError {
    eri_text f_message;
};

struct eri_struct_tag_verifier_u002d_debug_u002e_Harness {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_root;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_shared;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * f_data;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * f_owner;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * f_construct;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * f_routine;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId f_location;
};

static bool eri_eq_compiler_u002e_u1_budget_u002e_LimitError(eri_struct_compiler_u002e_u1_budget_u002e_LimitError a, eri_struct_compiler_u002e_u1_budget_u002e_LimitError b);
static bool eri_eq_compiler_u002e_u1_budget_u002e_Owner(eri_struct_compiler_u002e_u1_budget_u002e_Owner a, eri_struct_compiler_u002e_u1_budget_u002e_Owner b);
static bool eri_eq_compiler_u002e_u1_budget_u002e_Reservation(eri_struct_compiler_u002e_u1_budget_u002e_Reservation a, eri_struct_compiler_u002e_u1_budget_u002e_Reservation b);
static bool eri_eq_compiler_u002e_u1_budget_u002e_Allocation(eri_struct_compiler_u002e_u1_budget_u002e_Allocation a, eri_struct_compiler_u002e_u1_budget_u002e_Allocation b);
static bool eri_eq_compiler_u002e_u1_budget_u002e_Phase(eri_struct_compiler_u002e_u1_budget_u002e_Phase a, eri_struct_compiler_u002e_u1_budget_u002e_Phase b);
static bool eri_eq_compiler_u002e_u1_words_u002e_Page(eri_struct_compiler_u002e_u1_words_u002e_Page a, eri_struct_compiler_u002e_u1_words_u002e_Page b);
static bool eri_eq_compiler_u002e_u1_words_u002e_Node(eri_struct_compiler_u002e_u1_words_u002e_Node a, eri_struct_compiler_u002e_u1_words_u002e_Node b);
static bool eri_eq_compiler_u002e_u1_words_u002e_Words(eri_struct_compiler_u002e_u1_words_u002e_Words a, eri_struct_compiler_u002e_u1_words_u002e_Words b);
static bool eri_eq_compiler_u002e_u1_meta_u002e_Key(eri_struct_compiler_u002e_u1_meta_u002e_Key a, eri_struct_compiler_u002e_u1_meta_u002e_Key b);
static bool eri_eq_compiler_u002e_u1_meta_u002e_TypeId(eri_struct_compiler_u002e_u1_meta_u002e_TypeId a, eri_struct_compiler_u002e_u1_meta_u002e_TypeId b);
static bool eri_eq_compiler_u002e_u1_meta_u002e_SignatureId(eri_struct_compiler_u002e_u1_meta_u002e_SignatureId a, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId b);
static bool eri_eq_compiler_u002e_u1_meta_u002e_SourceId(eri_struct_compiler_u002e_u1_meta_u002e_SourceId a, eri_struct_compiler_u002e_u1_meta_u002e_SourceId b);
static bool eri_eq_compiler_u002e_u1_meta_u002e_LocId(eri_struct_compiler_u002e_u1_meta_u002e_LocId a, eri_struct_compiler_u002e_u1_meta_u002e_LocId b);
static bool eri_eq_compiler_u002e_u1_meta_u002e_Metadata(eri_struct_compiler_u002e_u1_meta_u002e_Metadata a, eri_struct_compiler_u002e_u1_meta_u002e_Metadata b);
static bool eri_eq_compiler_u002e_u1_builder_u002e_BlockId(eri_struct_compiler_u002e_u1_builder_u002e_BlockId a, eri_struct_compiler_u002e_u1_builder_u002e_BlockId b);
static bool eri_eq_compiler_u002e_u1_builder_u002e_ValueId(eri_struct_compiler_u002e_u1_builder_u002e_ValueId a, eri_struct_compiler_u002e_u1_builder_u002e_ValueId b);
static bool eri_eq_compiler_u002e_u1_builder_u002e_InstId(eri_struct_compiler_u002e_u1_builder_u002e_InstId a, eri_struct_compiler_u002e_u1_builder_u002e_InstId b);
static bool eri_eq_compiler_u002e_u1_builder_u002e_CellId(eri_struct_compiler_u002e_u1_builder_u002e_CellId a, eri_struct_compiler_u002e_u1_builder_u002e_CellId b);
static bool eri_eq_compiler_u002e_u1_builder_u002e_Pair(eri_struct_compiler_u002e_u1_builder_u002e_Pair a, eri_struct_compiler_u002e_u1_builder_u002e_Pair b);
static bool eri_eq_compiler_u002e_u1_builder_u002e_Function(eri_struct_compiler_u002e_u1_builder_u002e_Function a, eri_struct_compiler_u002e_u1_builder_u002e_Function b);
static bool eri_eq_compiler_u002e_u1_dominance_u002e_Graph(eri_struct_compiler_u002e_u1_dominance_u002e_Graph a, eri_struct_compiler_u002e_u1_dominance_u002e_Graph b);
static bool eri_eq_compiler_u002e_u1_verify_u002e_InvalidIR(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR a, eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR b);
static bool eri_eq_compiler_u002e_u1_verify_u002e_Report(eri_struct_compiler_u002e_u1_verify_u002e_Report a, eri_struct_compiler_u002e_u1_verify_u002e_Report b);
static bool eri_eq_compiler_u002e_u1_verify_u002e_Context(eri_struct_compiler_u002e_u1_verify_u002e_Context a, eri_struct_compiler_u002e_u1_verify_u002e_Context b);
static bool eri_eq_verifier_u002d_debug_u002e_ProbeError(eri_struct_verifier_u002d_debug_u002e_ProbeError a, eri_struct_verifier_u002d_debug_u002e_ProbeError b);
static bool eri_eq_verifier_u002d_debug_u002e_Harness(eri_struct_verifier_u002d_debug_u002e_Harness a, eri_struct_verifier_u002d_debug_u002e_Harness b);
static bool eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation a, eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation b);
static bool eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner a, eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner b);
static bool eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node a, eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node b);
static bool eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_eq(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page a, eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page b);
static bool eri_list_compiler_u002e_u1_builder_u002e_ValueId_eq(eri_list_compiler_u002e_u1_builder_u002e_ValueId a, eri_list_compiler_u002e_u1_builder_u002e_ValueId b);
static bool eri_list_compiler_u002e_u1_meta_u002e_TypeId_eq(eri_list_compiler_u002e_u1_meta_u002e_TypeId a, eri_list_compiler_u002e_u1_meta_u002e_TypeId b);
static eri_struct_compiler_u002e_u1_budget_u002e_LimitError *eri_identity_compiler_u002e_u1_budget_u002e_LimitError_new(eri_struct_compiler_u002e_u1_budget_u002e_LimitError v) { eri_struct_compiler_u002e_u1_budget_u002e_LimitError *p=(eri_struct_compiler_u002e_u1_budget_u002e_LimitError*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_budget_u002e_LimitError)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_budget_u002e_Owner *eri_identity_compiler_u002e_u1_budget_u002e_Owner_new(eri_struct_compiler_u002e_u1_budget_u002e_Owner v) { eri_struct_compiler_u002e_u1_budget_u002e_Owner *p=(eri_struct_compiler_u002e_u1_budget_u002e_Owner*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_budget_u002e_Owner)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_budget_u002e_Reservation *eri_identity_compiler_u002e_u1_budget_u002e_Reservation_new(eri_struct_compiler_u002e_u1_budget_u002e_Reservation v) { eri_struct_compiler_u002e_u1_budget_u002e_Reservation *p=(eri_struct_compiler_u002e_u1_budget_u002e_Reservation*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_budget_u002e_Reservation)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_budget_u002e_Allocation *eri_identity_compiler_u002e_u1_budget_u002e_Allocation_new(eri_struct_compiler_u002e_u1_budget_u002e_Allocation v) { eri_struct_compiler_u002e_u1_budget_u002e_Allocation *p=(eri_struct_compiler_u002e_u1_budget_u002e_Allocation*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_budget_u002e_Allocation)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_budget_u002e_Phase *eri_identity_compiler_u002e_u1_budget_u002e_Phase_new(eri_struct_compiler_u002e_u1_budget_u002e_Phase v) { eri_struct_compiler_u002e_u1_budget_u002e_Phase *p=(eri_struct_compiler_u002e_u1_budget_u002e_Phase*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_budget_u002e_Phase)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_words_u002e_Page *eri_identity_compiler_u002e_u1_words_u002e_Page_new(eri_struct_compiler_u002e_u1_words_u002e_Page v) { eri_struct_compiler_u002e_u1_words_u002e_Page *p=(eri_struct_compiler_u002e_u1_words_u002e_Page*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_words_u002e_Page)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_words_u002e_Node *eri_identity_compiler_u002e_u1_words_u002e_Node_new(eri_struct_compiler_u002e_u1_words_u002e_Node v) { eri_struct_compiler_u002e_u1_words_u002e_Node *p=(eri_struct_compiler_u002e_u1_words_u002e_Node*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_words_u002e_Node)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_words_u002e_Words *eri_identity_compiler_u002e_u1_words_u002e_Words_new(eri_struct_compiler_u002e_u1_words_u002e_Words v) { eri_struct_compiler_u002e_u1_words_u002e_Words *p=(eri_struct_compiler_u002e_u1_words_u002e_Words*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_words_u002e_Words)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_meta_u002e_Key *eri_identity_compiler_u002e_u1_meta_u002e_Key_new(eri_struct_compiler_u002e_u1_meta_u002e_Key v) { eri_struct_compiler_u002e_u1_meta_u002e_Key *p=(eri_struct_compiler_u002e_u1_meta_u002e_Key*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_meta_u002e_Key)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_meta_u002e_TypeId *eri_identity_compiler_u002e_u1_meta_u002e_TypeId_new(eri_struct_compiler_u002e_u1_meta_u002e_TypeId v) { eri_struct_compiler_u002e_u1_meta_u002e_TypeId *p=(eri_struct_compiler_u002e_u1_meta_u002e_TypeId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_meta_u002e_TypeId)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_meta_u002e_SignatureId *eri_identity_compiler_u002e_u1_meta_u002e_SignatureId_new(eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v) { eri_struct_compiler_u002e_u1_meta_u002e_SignatureId *p=(eri_struct_compiler_u002e_u1_meta_u002e_SignatureId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_meta_u002e_SignatureId)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_meta_u002e_SourceId *eri_identity_compiler_u002e_u1_meta_u002e_SourceId_new(eri_struct_compiler_u002e_u1_meta_u002e_SourceId v) { eri_struct_compiler_u002e_u1_meta_u002e_SourceId *p=(eri_struct_compiler_u002e_u1_meta_u002e_SourceId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_meta_u002e_SourceId)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_meta_u002e_LocId *eri_identity_compiler_u002e_u1_meta_u002e_LocId_new(eri_struct_compiler_u002e_u1_meta_u002e_LocId v) { eri_struct_compiler_u002e_u1_meta_u002e_LocId *p=(eri_struct_compiler_u002e_u1_meta_u002e_LocId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_meta_u002e_LocId)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_meta_u002e_Metadata *eri_identity_compiler_u002e_u1_meta_u002e_Metadata_new(eri_struct_compiler_u002e_u1_meta_u002e_Metadata v) { eri_struct_compiler_u002e_u1_meta_u002e_Metadata *p=(eri_struct_compiler_u002e_u1_meta_u002e_Metadata*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_meta_u002e_Metadata)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_builder_u002e_BlockId *eri_identity_compiler_u002e_u1_builder_u002e_BlockId_new(eri_struct_compiler_u002e_u1_builder_u002e_BlockId v) { eri_struct_compiler_u002e_u1_builder_u002e_BlockId *p=(eri_struct_compiler_u002e_u1_builder_u002e_BlockId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_builder_u002e_BlockId)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId *eri_identity_compiler_u002e_u1_builder_u002e_ValueId_new(eri_struct_compiler_u002e_u1_builder_u002e_ValueId v) { eri_struct_compiler_u002e_u1_builder_u002e_ValueId *p=(eri_struct_compiler_u002e_u1_builder_u002e_ValueId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_builder_u002e_ValueId)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_builder_u002e_InstId *eri_identity_compiler_u002e_u1_builder_u002e_InstId_new(eri_struct_compiler_u002e_u1_builder_u002e_InstId v) { eri_struct_compiler_u002e_u1_builder_u002e_InstId *p=(eri_struct_compiler_u002e_u1_builder_u002e_InstId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_builder_u002e_InstId)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_builder_u002e_CellId *eri_identity_compiler_u002e_u1_builder_u002e_CellId_new(eri_struct_compiler_u002e_u1_builder_u002e_CellId v) { eri_struct_compiler_u002e_u1_builder_u002e_CellId *p=(eri_struct_compiler_u002e_u1_builder_u002e_CellId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_builder_u002e_CellId)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_builder_u002e_Pair *eri_identity_compiler_u002e_u1_builder_u002e_Pair_new(eri_struct_compiler_u002e_u1_builder_u002e_Pair v) { eri_struct_compiler_u002e_u1_builder_u002e_Pair *p=(eri_struct_compiler_u002e_u1_builder_u002e_Pair*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_builder_u002e_Pair)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_builder_u002e_Function *eri_identity_compiler_u002e_u1_builder_u002e_Function_new(eri_struct_compiler_u002e_u1_builder_u002e_Function v) { eri_struct_compiler_u002e_u1_builder_u002e_Function *p=(eri_struct_compiler_u002e_u1_builder_u002e_Function*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_builder_u002e_Function)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_dominance_u002e_Graph *eri_identity_compiler_u002e_u1_dominance_u002e_Graph_new(eri_struct_compiler_u002e_u1_dominance_u002e_Graph v) { eri_struct_compiler_u002e_u1_dominance_u002e_Graph *p=(eri_struct_compiler_u002e_u1_dominance_u002e_Graph*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_dominance_u002e_Graph)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR *eri_identity_compiler_u002e_u1_verify_u002e_InvalidIR_new(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR v) { eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR *p=(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_verify_u002e_Report *eri_identity_compiler_u002e_u1_verify_u002e_Report_new(eri_struct_compiler_u002e_u1_verify_u002e_Report v) { eri_struct_compiler_u002e_u1_verify_u002e_Report *p=(eri_struct_compiler_u002e_u1_verify_u002e_Report*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_verify_u002e_Report)); *p=v; return p; }

static eri_struct_compiler_u002e_u1_verify_u002e_Context *eri_identity_compiler_u002e_u1_verify_u002e_Context_new(eri_struct_compiler_u002e_u1_verify_u002e_Context v) { eri_struct_compiler_u002e_u1_verify_u002e_Context *p=(eri_struct_compiler_u002e_u1_verify_u002e_Context*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_verify_u002e_Context)); *p=v; return p; }

static eri_struct_verifier_u002d_debug_u002e_ProbeError *eri_identity_verifier_u002d_debug_u002e_ProbeError_new(eri_struct_verifier_u002d_debug_u002e_ProbeError v) { eri_struct_verifier_u002d_debug_u002e_ProbeError *p=(eri_struct_verifier_u002d_debug_u002e_ProbeError*)eri_alloc(sizeof(eri_struct_verifier_u002d_debug_u002e_ProbeError)); *p=v; return p; }

static eri_struct_verifier_u002d_debug_u002e_Harness *eri_identity_verifier_u002d_debug_u002e_Harness_new(eri_struct_verifier_u002d_debug_u002e_Harness v) { eri_struct_verifier_u002d_debug_u002e_Harness *p=(eri_struct_verifier_u002d_debug_u002e_Harness*)eri_alloc(sizeof(eri_struct_verifier_u002d_debug_u002e_Harness)); *p=v; return p; }

static bool eri_eq_compiler_u002e_u1_budget_u002e_LimitError(eri_struct_compiler_u002e_u1_budget_u002e_LimitError a, eri_struct_compiler_u002e_u1_budget_u002e_LimitError b) { return eri_text_eq(a.f_message, b.f_message) && eri_text_eq(a.f_category, b.f_category) && (a.f_requested == b.f_requested) && (a.f_remaining == b.f_remaining); }

static bool eri_eq_compiler_u002e_u1_budget_u002e_Owner(eri_struct_compiler_u002e_u1_budget_u002e_Owner a, eri_struct_compiler_u002e_u1_budget_u002e_Owner b) { return eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(a.f_parent, b.f_parent) && (a.f_kind == b.f_kind) && (a.f_state == b.f_state) && (a.f_limit == b.f_limit) && (a.f_trafficLimit == b.f_trafficLimit) && (a.f_workLimit == b.f_workLimit) && (a.f_live == b.f_live) && (a.f_pending == b.f_pending) && (a.f_peak == b.f_peak) && (a.f_reservedPeak == b.f_reservedPeak) && (a.f_traffic == b.f_traffic) && (a.f_pendingTraffic == b.f_pendingTraffic) && (a.f_work == b.f_work); }

static bool eri_eq_compiler_u002e_u1_budget_u002e_Reservation(eri_struct_compiler_u002e_u1_budget_u002e_Reservation a, eri_struct_compiler_u002e_u1_budget_u002e_Reservation b) { return (a.f_owner == b.f_owner) && (a.f_bytes == b.f_bytes) && (a.f_state == b.f_state); }

static bool eri_eq_compiler_u002e_u1_budget_u002e_Allocation(eri_struct_compiler_u002e_u1_budget_u002e_Allocation a, eri_struct_compiler_u002e_u1_budget_u002e_Allocation b) { return (a.f_owner == b.f_owner) && (a.f_bytes == b.f_bytes) && (a.f_state == b.f_state); }

static bool eri_eq_compiler_u002e_u1_budget_u002e_Phase(eri_struct_compiler_u002e_u1_budget_u002e_Phase a, eri_struct_compiler_u002e_u1_budget_u002e_Phase b) { return (a.f_owner == b.f_owner) && (a.f_limit == b.f_limit) && (a.f_used == b.f_used) && (a.f_prepaid == b.f_prepaid) && (a.f_state == b.f_state); }

static bool eri_eq_compiler_u002e_u1_words_u002e_Page(eri_struct_compiler_u002e_u1_words_u002e_Page a, eri_struct_compiler_u002e_u1_words_u002e_Page b) { return (a.f_w0 == b.f_w0) && (a.f_w1 == b.f_w1) && (a.f_w2 == b.f_w2) && (a.f_w3 == b.f_w3) && (a.f_w4 == b.f_w4) && (a.f_w5 == b.f_w5) && (a.f_w6 == b.f_w6) && (a.f_w7 == b.f_w7) && (a.f_w8 == b.f_w8) && (a.f_w9 == b.f_w9) && (a.f_w10 == b.f_w10) && (a.f_w11 == b.f_w11) && (a.f_w12 == b.f_w12) && (a.f_w13 == b.f_w13) && (a.f_w14 == b.f_w14) && (a.f_w15 == b.f_w15) && eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(a.f_charge, b.f_charge); }

static bool eri_eq_compiler_u002e_u1_words_u002e_Node(eri_struct_compiler_u002e_u1_words_u002e_Node a, eri_struct_compiler_u002e_u1_words_u002e_Node b) { return eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c0, b.f_c0) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c1, b.f_c1) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c2, b.f_c2) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c3, b.f_c3) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c4, b.f_c4) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c5, b.f_c5) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c6, b.f_c6) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c7, b.f_c7) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c8, b.f_c8) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c9, b.f_c9) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c10, b.f_c10) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c11, b.f_c11) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c12, b.f_c12) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c13, b.f_c13) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c14, b.f_c14) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_c15, b.f_c15) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_eq(a.f_page, b.f_page) && eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(a.f_charge, b.f_charge); }

static bool eri_eq_compiler_u002e_u1_words_u002e_Words(eri_struct_compiler_u002e_u1_words_u002e_Words a, eri_struct_compiler_u002e_u1_words_u002e_Words b) { return (a.f_owner == b.f_owner) && eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(a.f_root, b.f_root) && (a.f_length == b.f_length) && (a.f_limit == b.f_limit) && (a.f_closed == b.f_closed) && (a.f_frozen == b.f_frozen) && (a.f_control == b.f_control); }

static bool eri_eq_compiler_u002e_u1_meta_u002e_Key(eri_struct_compiler_u002e_u1_meta_u002e_Key a, eri_struct_compiler_u002e_u1_meta_u002e_Key b) { return (a.f_marker == b.f_marker); }

static bool eri_eq_compiler_u002e_u1_meta_u002e_TypeId(eri_struct_compiler_u002e_u1_meta_u002e_TypeId a, eri_struct_compiler_u002e_u1_meta_u002e_TypeId b) { return (a.f_index == b.f_index); }

static bool eri_eq_compiler_u002e_u1_meta_u002e_SignatureId(eri_struct_compiler_u002e_u1_meta_u002e_SignatureId a, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId b) { return (a.f_owner == b.f_owner) && (a.f_index == b.f_index); }

static bool eri_eq_compiler_u002e_u1_meta_u002e_SourceId(eri_struct_compiler_u002e_u1_meta_u002e_SourceId a, eri_struct_compiler_u002e_u1_meta_u002e_SourceId b) { return (a.f_owner == b.f_owner) && (a.f_index == b.f_index); }

static bool eri_eq_compiler_u002e_u1_meta_u002e_LocId(eri_struct_compiler_u002e_u1_meta_u002e_LocId a, eri_struct_compiler_u002e_u1_meta_u002e_LocId b) { return (a.f_owner == b.f_owner) && (a.f_index == b.f_index); }

static bool eri_eq_compiler_u002e_u1_meta_u002e_Metadata(eri_struct_compiler_u002e_u1_meta_u002e_Metadata a, eri_struct_compiler_u002e_u1_meta_u002e_Metadata b) { return (a.f_key == b.f_key) && (a.f_owner == b.f_owner) && (a.f_frozen == b.f_frozen) && (a.f_closed == b.f_closed) && eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(a.f_control, b.f_control) && (a.f_signatures == b.f_signatures) && (a.f_types == b.f_types) && (a.f_buckets == b.f_buckets) && (a.f_sources == b.f_sources) && (a.f_bytes == b.f_bytes) && (a.f_locations == b.f_locations); }

static bool eri_eq_compiler_u002e_u1_builder_u002e_BlockId(eri_struct_compiler_u002e_u1_builder_u002e_BlockId a, eri_struct_compiler_u002e_u1_builder_u002e_BlockId b) { return (a.f_owner == b.f_owner) && (a.f_index == b.f_index); }

static bool eri_eq_compiler_u002e_u1_builder_u002e_ValueId(eri_struct_compiler_u002e_u1_builder_u002e_ValueId a, eri_struct_compiler_u002e_u1_builder_u002e_ValueId b) { return (a.f_owner == b.f_owner) && (a.f_index == b.f_index); }

static bool eri_eq_compiler_u002e_u1_builder_u002e_InstId(eri_struct_compiler_u002e_u1_builder_u002e_InstId a, eri_struct_compiler_u002e_u1_builder_u002e_InstId b) { return (a.f_owner == b.f_owner) && (a.f_index == b.f_index); }

static bool eri_eq_compiler_u002e_u1_builder_u002e_CellId(eri_struct_compiler_u002e_u1_builder_u002e_CellId a, eri_struct_compiler_u002e_u1_builder_u002e_CellId b) { return (a.f_owner == b.f_owner) && (a.f_index == b.f_index); }

static bool eri_eq_compiler_u002e_u1_builder_u002e_Pair(eri_struct_compiler_u002e_u1_builder_u002e_Pair a, eri_struct_compiler_u002e_u1_builder_u002e_Pair b) { return eri_eq_compiler_u002e_u1_builder_u002e_ValueId(a.f_value, b.f_value) && eri_eq_compiler_u002e_u1_builder_u002e_ValueId(a.f_overflow, b.f_overflow); }

static bool eri_eq_compiler_u002e_u1_builder_u002e_Function(eri_struct_compiler_u002e_u1_builder_u002e_Function a, eri_struct_compiler_u002e_u1_builder_u002e_Function b) { return (a.f_key == b.f_key) && (a.f_metadata == b.f_metadata) && eri_eq_compiler_u002e_u1_meta_u002e_SignatureId(a.f_signature, b.f_signature) && (a.f_owner == b.f_owner) && (a.f_phase == b.f_phase) && (a.f_state == b.f_state) && (a.f_revision == b.f_revision) && eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(a.f_control, b.f_control) && (a.f_blocks == b.f_blocks) && (a.f_values == b.f_values) && (a.f_instructions == b.f_instructions) && (a.f_operands == b.f_operands) && (a.f_edges == b.f_edges) && (a.f_arguments == b.f_arguments) && (a.f_cells == b.f_cells); }

static bool eri_eq_compiler_u002e_u1_dominance_u002e_Graph(eri_struct_compiler_u002e_u1_dominance_u002e_Graph a, eri_struct_compiler_u002e_u1_dominance_u002e_Graph b) { return (a.f_data == b.f_data) && (a.f_phase == b.f_phase) && (a.f_blocks == b.f_blocks) && (a.f_edges == b.f_edges) && (a.f_edgeBase == b.f_edgeBase) && (a.f_stackBase == b.f_stackBase) && (a.f_reachable == b.f_reachable) && (a.f_reachableEdges == b.f_reachableEdges) && (a.f_visits == b.f_visits) && (a.f_visitLimit == b.f_visitLimit) && (a.f_prepared == b.f_prepared) && (a.f_state == b.f_state); }

static bool eri_eq_compiler_u002e_u1_verify_u002e_InvalidIR(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR a, eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR b) { return eri_text_eq(a.f_message, b.f_message) && eri_text_eq(a.f_category, b.f_category) && (a.f_stage == b.f_stage) && (a.f_block == b.f_block) && (a.f_instruction == b.f_instruction) && (a.f_location == b.f_location); }

static bool eri_eq_compiler_u002e_u1_verify_u002e_Report(eri_struct_compiler_u002e_u1_verify_u002e_Report a, eri_struct_compiler_u002e_u1_verify_u002e_Report b) { return (a.f_reachableBlocks == b.f_reachableBlocks) && (a.f_structuralVisits == b.f_structuralVisits) && (a.f_dominanceVisits == b.f_dominanceVisits) && (a.f_work == b.f_work) && (a.f_revision == b.f_revision); }

static bool eri_eq_compiler_u002e_u1_verify_u002e_Context(eri_struct_compiler_u002e_u1_verify_u002e_Context a, eri_struct_compiler_u002e_u1_verify_u002e_Context b) { return (a.f_routine == b.f_routine) && (a.f_phase == b.f_phase) && (a.f_graph == b.f_graph) && (a.f_stage == b.f_stage) && (a.f_block == b.f_block) && (a.f_instruction == b.f_instruction) && (a.f_location == b.f_location) && (a.f_visits == b.f_visits) && (a.f_scanLimit == b.f_scanLimit) && (a.f_positions == b.f_positions) && (a.f_buckets == b.f_buckets) && (a.f_construction == b.f_construction); }

static bool eri_eq_verifier_u002d_debug_u002e_ProbeError(eri_struct_verifier_u002d_debug_u002e_ProbeError a, eri_struct_verifier_u002d_debug_u002e_ProbeError b) { return eri_text_eq(a.f_message, b.f_message); }

static bool eri_eq_verifier_u002d_debug_u002e_Harness(eri_struct_verifier_u002d_debug_u002e_Harness a, eri_struct_verifier_u002d_debug_u002e_Harness b) { return (a.f_root == b.f_root) && (a.f_shared == b.f_shared) && (a.f_data == b.f_data) && (a.f_owner == b.f_owner) && (a.f_construct == b.f_construct) && (a.f_routine == b.f_routine) && eri_eq_compiler_u002e_u1_meta_u002e_LocId(a.f_location, b.f_location); }

static _Noreturn void eri_fail_compiler_u002e_u1_budget_u002e_LimitError(eri_struct_compiler_u002e_u1_budget_u002e_LimitError v) { eri_struct_compiler_u002e_u1_budget_u002e_LimitError *p=(eri_struct_compiler_u002e_u1_budget_u002e_LimitError*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_budget_u002e_LimitError)); *p=v; eri_raise("compiler.u1_budget.LimitError", p, v.f_message); }

static _Noreturn void eri_fail_compiler_u002e_u1_verify_u002e_InvalidIR(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR v) { eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR *p=(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR)); *p=v; eri_raise("compiler.u1_verify.InvalidIR", p, v.f_message); }

static _Noreturn void eri_fail_verifier_u002d_debug_u002e_ProbeError(eri_struct_verifier_u002d_debug_u002e_ProbeError v) { eri_struct_verifier_u002d_debug_u002e_ProbeError *p=(eri_struct_verifier_u002d_debug_u002e_ProbeError*)eri_alloc(sizeof(eri_struct_verifier_u002d_debug_u002e_ProbeError)); *p=v; eri_raise("verifier-debug.ProbeError", p, v.f_message); }

static bool eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation a, eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation b) { if(a.has!=b.has)return false; if(!a.has)return true; return (a.value == b.value); }

static bool eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner a, eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner b) { if(a.has!=b.has)return false; if(!a.has)return true; return (a.value == b.value); }

static bool eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node a, eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node b) { if(a.has!=b.has)return false; if(!a.has)return true; return (a.value == b.value); }

static bool eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_eq(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page a, eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page b) { if(a.has!=b.has)return false; if(!a.has)return true; return (a.value == b.value); }

static eri_list_compiler_u002e_u1_builder_u002e_ValueId eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(size_t n,const eri_struct_compiler_u002e_u1_builder_u002e_ValueId *src){ eri_list_compiler_u002e_u1_builder_u002e_ValueId r={n,NULL}; if(n){r.data=(eri_struct_compiler_u002e_u1_builder_u002e_ValueId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_builder_u002e_ValueId)*n); memcpy(r.data,src,sizeof(eri_struct_compiler_u002e_u1_builder_u002e_ValueId)*n);} return r; }
static void eri_list_compiler_u002e_u1_builder_u002e_ValueId_detach(eri_list_compiler_u002e_u1_builder_u002e_ValueId *v){ if(!v->count){v->data=NULL;return;} eri_struct_compiler_u002e_u1_builder_u002e_ValueId *p=(eri_struct_compiler_u002e_u1_builder_u002e_ValueId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_builder_u002e_ValueId)*v->count); memcpy(p,v->data,sizeof(eri_struct_compiler_u002e_u1_builder_u002e_ValueId)*v->count); v->data=p; }
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId eri_list_compiler_u002e_u1_builder_u002e_ValueId_get(eri_list_compiler_u002e_u1_builder_u002e_ValueId v,int64_t i){ if(i<0||(uint64_t)i>=v.count)eri_fault("List index out of bounds"); return v.data[i]; }
static void eri_list_compiler_u002e_u1_builder_u002e_ValueId_set(eri_list_compiler_u002e_u1_builder_u002e_ValueId *v,int64_t i,eri_struct_compiler_u002e_u1_builder_u002e_ValueId x){ if(i<0||(uint64_t)i>=v->count)eri_fault("List index out of bounds"); eri_list_compiler_u002e_u1_builder_u002e_ValueId_detach(v); v->data[i]=x; }
static void eri_list_compiler_u002e_u1_builder_u002e_ValueId_add(eri_list_compiler_u002e_u1_builder_u002e_ValueId *v,eri_struct_compiler_u002e_u1_builder_u002e_ValueId x){ if(v->count>=SIZE_MAX/sizeof(eri_struct_compiler_u002e_u1_builder_u002e_ValueId))eri_fault("List size overflow"); v->data=(eri_struct_compiler_u002e_u1_builder_u002e_ValueId*)eri_prefix_append((const unsigned char*)v->data,v->count*sizeof(eri_struct_compiler_u002e_u1_builder_u002e_ValueId),(const unsigned char*)&x,sizeof(eri_struct_compiler_u002e_u1_builder_u002e_ValueId)); v->count++; }
static bool eri_list_compiler_u002e_u1_builder_u002e_ValueId_eq(eri_list_compiler_u002e_u1_builder_u002e_ValueId a,eri_list_compiler_u002e_u1_builder_u002e_ValueId b){ if(a.count!=b.count)return false; for(size_t i=0;i<a.count;i++){if(!(eri_eq_compiler_u002e_u1_builder_u002e_ValueId(a.data[i], b.data[i])))return false;} return true; }

static eri_list_compiler_u002e_u1_meta_u002e_TypeId eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(size_t n,const eri_struct_compiler_u002e_u1_meta_u002e_TypeId *src){ eri_list_compiler_u002e_u1_meta_u002e_TypeId r={n,NULL}; if(n){r.data=(eri_struct_compiler_u002e_u1_meta_u002e_TypeId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_meta_u002e_TypeId)*n); memcpy(r.data,src,sizeof(eri_struct_compiler_u002e_u1_meta_u002e_TypeId)*n);} return r; }
static void eri_list_compiler_u002e_u1_meta_u002e_TypeId_detach(eri_list_compiler_u002e_u1_meta_u002e_TypeId *v){ if(!v->count){v->data=NULL;return;} eri_struct_compiler_u002e_u1_meta_u002e_TypeId *p=(eri_struct_compiler_u002e_u1_meta_u002e_TypeId*)eri_alloc(sizeof(eri_struct_compiler_u002e_u1_meta_u002e_TypeId)*v->count); memcpy(p,v->data,sizeof(eri_struct_compiler_u002e_u1_meta_u002e_TypeId)*v->count); v->data=p; }
static eri_struct_compiler_u002e_u1_meta_u002e_TypeId eri_list_compiler_u002e_u1_meta_u002e_TypeId_get(eri_list_compiler_u002e_u1_meta_u002e_TypeId v,int64_t i){ if(i<0||(uint64_t)i>=v.count)eri_fault("List index out of bounds"); return v.data[i]; }
static void eri_list_compiler_u002e_u1_meta_u002e_TypeId_set(eri_list_compiler_u002e_u1_meta_u002e_TypeId *v,int64_t i,eri_struct_compiler_u002e_u1_meta_u002e_TypeId x){ if(i<0||(uint64_t)i>=v->count)eri_fault("List index out of bounds"); eri_list_compiler_u002e_u1_meta_u002e_TypeId_detach(v); v->data[i]=x; }
static void eri_list_compiler_u002e_u1_meta_u002e_TypeId_add(eri_list_compiler_u002e_u1_meta_u002e_TypeId *v,eri_struct_compiler_u002e_u1_meta_u002e_TypeId x){ if(v->count>=SIZE_MAX/sizeof(eri_struct_compiler_u002e_u1_meta_u002e_TypeId))eri_fault("List size overflow"); v->data=(eri_struct_compiler_u002e_u1_meta_u002e_TypeId*)eri_prefix_append((const unsigned char*)v->data,v->count*sizeof(eri_struct_compiler_u002e_u1_meta_u002e_TypeId),(const unsigned char*)&x,sizeof(eri_struct_compiler_u002e_u1_meta_u002e_TypeId)); v->count++; }
static bool eri_list_compiler_u002e_u1_meta_u002e_TypeId_eq(eri_list_compiler_u002e_u1_meta_u002e_TypeId a,eri_list_compiler_u002e_u1_meta_u002e_TypeId b){ if(a.count!=b.count)return false; for(size_t i=0;i<a.count;i++){if(!(eri_eq_compiler_u002e_u1_meta_u002e_TypeId(a.data[i], b.data[i])))return false;} return true; }

static void fn_compiler_u002e_u1_budget_u002e_invalid(void);
static void fn_compiler_u002e_u1_budget_u002e_reject(eri_text v_message);
static void fn_compiler_u002e_u1_budget_u002e_active(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static void fn_compiler_u002e_u1_budget_u002e_exhausted(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount, int64_t v_remaining);
static void fn_compiler_u002e_u1_budget_u002e_exceed(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount, int64_t v_remaining);
static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_request(int64_t v_limit, int64_t v_trafficLimit, int64_t v_workLimit);
static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_developmentRequest(void);
static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_metadataOwner(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_root);
static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_child(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_root, int64_t v_kind, int64_t v_limit, int64_t v_trafficLimit, int64_t v_workLimit);
static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_functionOwner(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_root, bool v_qualification);
static int64_t fn_compiler_u002e_u1_budget_u002e_fits(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount);
static void fn_compiler_u002e_u1_budget_u002e_pendingAdd(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount);
static void fn_compiler_u002e_u1_budget_u002e_checkFits(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_charged, int64_t v_amount);
static eri_struct_compiler_u002e_u1_budget_u002e_Reservation * fn_compiler_u002e_u1_budget_u002e_reserve(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount);
static void fn_compiler_u002e_u1_budget_u002e_commitAt(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount);
static eri_struct_compiler_u002e_u1_budget_u002e_Allocation * fn_compiler_u002e_u1_budget_u002e_commit(eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_reservation);
static void fn_compiler_u002e_u1_budget_u002e_cancelAt(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount);
static void fn_compiler_u002e_u1_budget_u002e_cancelReservation(eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_reservation);
static void fn_compiler_u002e_u1_budget_u002e_release(eri_struct_compiler_u002e_u1_budget_u002e_Allocation * v_allocation);
static void fn_compiler_u002e_u1_budget_u002e_transfer(eri_struct_compiler_u002e_u1_budget_u002e_Allocation * v_allocation, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_destination);
static eri_struct_compiler_u002e_u1_budget_u002e_Allocation * fn_compiler_u002e_u1_budget_u002e_split(eri_struct_compiler_u002e_u1_budget_u002e_Allocation * v_allocation, int64_t v_amount);
static eri_struct_compiler_u002e_u1_budget_u002e_Phase * fn_compiler_u002e_u1_budget_u002e_phase(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_limit);
static eri_struct_compiler_u002e_u1_budget_u002e_Phase * fn_compiler_u002e_u1_budget_u002e_constructionPhase(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static eri_struct_compiler_u002e_u1_budget_u002e_Phase * fn_compiler_u002e_u1_budget_u002e_verificationPhase(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static eri_struct_compiler_u002e_u1_budget_u002e_Phase * fn_compiler_u002e_u1_budget_u002e_promotionPhase(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static void fn_compiler_u002e_u1_budget_u002e_finishPhase(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static void fn_compiler_u002e_u1_budget_u002e_prepay(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_amount);
static void fn_compiler_u002e_u1_budget_u002e_consume(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_amount);
static void fn_compiler_u002e_u1_budget_u002e_work(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_amount);
static void fn_compiler_u002e_u1_budget_u002e_cancel(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static void fn_compiler_u002e_u1_budget_u002e_poll(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static void fn_compiler_u002e_u1_budget_u002e_close(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static void fn_compiler_u002e_u1_budget_u002e_abandonAt(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_parent, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static void fn_compiler_u002e_u1_budget_u002e_abandon(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner);
static void fn_compiler_u002e_u1_words_u002e_context(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, bool v_write);
static eri_struct_compiler_u002e_u1_words_u002e_Words * fn_compiler_u002e_u1_words_u002e_create(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_limit);
static eri_struct_compiler_u002e_u1_words_u002e_Node * fn_compiler_u002e_u1_words_u002e_newNode(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static eri_struct_compiler_u002e_u1_words_u002e_Page * fn_compiler_u002e_u1_words_u002e_newPage(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static eri_struct_compiler_u002e_u1_words_u002e_Node * fn_compiler_u002e_u1_words_u002e_needNode(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node v_node);
static eri_struct_compiler_u002e_u1_words_u002e_Page * fn_compiler_u002e_u1_words_u002e_needPage(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page v_page);
static int64_t fn_compiler_u002e_u1_words_u002e_readPage(eri_struct_compiler_u002e_u1_words_u002e_Page * v_page, int64_t v_offset);
static void fn_compiler_u002e_u1_words_u002e_writePage(eri_struct_compiler_u002e_u1_words_u002e_Page * v_page, int64_t v_offset, int64_t v_value);
static eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node fn_compiler_u002e_u1_words_u002e_readChild(eri_struct_compiler_u002e_u1_words_u002e_Node * v_node, int64_t v_offset);
static void fn_compiler_u002e_u1_words_u002e_writeChild(eri_struct_compiler_u002e_u1_words_u002e_Node * v_node, int64_t v_offset, eri_struct_compiler_u002e_u1_words_u002e_Node * v_value);
static eri_struct_compiler_u002e_u1_words_u002e_Page * fn_compiler_u002e_u1_words_u002e_pageAt(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_index, bool v_create);
static int64_t fn_compiler_u002e_u1_words_u002e_get(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_index);
static void fn_compiler_u002e_u1_words_u002e_set(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_index, int64_t v_value);
static int64_t fn_compiler_u002e_u1_words_u002e_push(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_value);
static void fn_compiler_u002e_u1_words_u002e_freeze(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words);
static void fn_compiler_u002e_u1_words_u002e_closeNode(eri_struct_compiler_u002e_u1_words_u002e_Node * v_node, int64_t v_depth);
static void fn_compiler_u002e_u1_words_u002e_close(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words);
static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_typeAt(int64_t v_index);
static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_pred(void);
static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_i64(void);
static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_f64(void);
static void fn_compiler_u002e_u1_meta_u002e_validType(eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_value);
static void fn_compiler_u002e_u1_meta_u002e_mutable(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static eri_struct_compiler_u002e_u1_meta_u002e_Metadata * fn_compiler_u002e_u1_meta_u002e_create(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static int64_t fn_compiler_u002e_u1_meta_u002e_signatureIndex(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value);
static int64_t fn_compiler_u002e_u1_meta_u002e_parameterCount(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value);
static int64_t fn_compiler_u002e_u1_meta_u002e_resultCount(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value);
static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_parameterType(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value, int64_t v_index);
static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_resultType(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value, int64_t v_index);
static int64_t fn_compiler_u002e_u1_meta_u002e_sequenceHash_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_Int(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_values, int64_t v_seed);
static bool fn_compiler_u002e_u1_meta_u002e_sameTypes_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_first, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_values);
static eri_struct_compiler_u002e_u1_meta_u002e_SignatureId fn_compiler_u002e_u1_meta_u002e_signature_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_parameters, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_results);
static int64_t fn_compiler_u002e_u1_meta_u002e_appendBytes(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_text v_value);
static bool fn_compiler_u002e_u1_meta_u002e_sameBytes(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_first, int64_t v_count, eri_text v_value);
static eri_struct_compiler_u002e_u1_meta_u002e_SourceId fn_compiler_u002e_u1_meta_u002e_source(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_text v_name, eri_text v_digest, int64_t v_length);
static eri_struct_compiler_u002e_u1_meta_u002e_LocId fn_compiler_u002e_u1_meta_u002e_location(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SourceId v_source, int64_t v_start, int64_t v_end, int64_t v_anchor, int64_t v_line, int64_t v_column);
static void fn_compiler_u002e_u1_meta_u002e_validLocation(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_value);
static void fn_compiler_u002e_u1_meta_u002e_freeze(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta);
static void fn_compiler_u002e_u1_meta_u002e_close(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta);
static bool fn_compiler_u002e_u1_ops_u002e_known(int64_t v_op);
static bool fn_compiler_u002e_u1_ops_u002e_terminal(int64_t v_op);
static int64_t fn_compiler_u002e_u1_ops_u002e_operands(int64_t v_op);
static int64_t fn_compiler_u002e_u1_ops_u002e_results(int64_t v_op);
static int64_t fn_compiler_u002e_u1_ops_u002e_operandType(int64_t v_op, int64_t v_index);
static int64_t fn_compiler_u002e_u1_ops_u002e_resultType(int64_t v_op, int64_t v_index);
static void fn_compiler_u002e_u1_builder_u002e_mutable(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine);
static int64_t fn_compiler_u002e_u1_builder_u002e_blockOffset(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block);
static int64_t fn_compiler_u002e_u1_builder_u002e_valueOffset(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value);
static int64_t fn_compiler_u002e_u1_builder_u002e_instOffset(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_InstId v_value);
static eri_struct_compiler_u002e_u1_builder_u002e_Function * fn_compiler_u002e_u1_builder_u002e_create(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_metadata, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_signature, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_builder_u002e_valueType(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value);
static eri_struct_compiler_u002e_u1_builder_u002e_BlockId fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_parameters);
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_parameter(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, int64_t v_index);
static int64_t fn_compiler_u002e_u1_builder_u002e_openBlock(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block);
static void fn_compiler_u002e_u1_builder_u002e_checkEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_target, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_arguments);
static int64_t fn_compiler_u002e_u1_builder_u002e_appendEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_target, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_arguments);
static eri_struct_compiler_u002e_u1_builder_u002e_InstId fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, int64_t v_op, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_arguments, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location, int64_t v_payload, int64_t v_extra);
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_result(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_InstId v_instruction, int64_t v_index);
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_integer(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, int64_t v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_predicate(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, bool v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_floatBits(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, int64_t v_bits, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static eri_struct_compiler_u002e_u1_builder_u002e_Pair fn_compiler_u002e_u1_builder_u002e_addOverflow(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_first, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_second, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_negatePredicate(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static void fn_compiler_u002e_u1_builder_u002e_guard(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value, int64_t v_trap, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static void fn_compiler_u002e_u1_builder_u002e_jump_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_target, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_arguments, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static void fn_compiler_u002e_u1_builder_u002e_branch_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_test, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_first, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_firstArguments, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_second, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_secondArguments, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static void fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_values, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_edgeArgument(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, int64_t v_edge, int64_t v_index);
static int64_t fn_compiler_u002e_u1_builder_u002e_cellOffset(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_CellId v_cell);
static eri_struct_compiler_u002e_u1_builder_u002e_CellId fn_compiler_u002e_u1_builder_u002e_cell(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_valueType);
static void fn_compiler_u002e_u1_builder_u002e_initialize(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_CellId v_cell, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_readCell(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_CellId v_cell, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static void fn_compiler_u002e_u1_builder_u002e_writeCell(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_CellId v_cell, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location);
static void fn_compiler_u002e_u1_builder_u002e_complete(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine);
static void fn_compiler_u002e_u1_builder_u002e_close(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine);
static eri_struct_compiler_u002e_u1_dominance_u002e_Graph * fn_compiler_u002e_u1_dominance_u002e_create(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static int64_t fn_compiler_u002e_u1_dominance_u002e_zeros(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_count);
static void fn_compiler_u002e_u1_dominance_u002e_prepare(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_blocks, int64_t v_edges);
static void fn_compiler_u002e_u1_dominance_u002e_visit(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph);
static int64_t fn_compiler_u002e_u1_dominance_u002e_slot(int64_t v_field);
static int64_t fn_compiler_u002e_u1_dominance_u002e_get(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_block, int64_t v_field);
static void fn_compiler_u002e_u1_dominance_u002e_set(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_block, int64_t v_field, int64_t v_value);
static int64_t fn_compiler_u002e_u1_dominance_u002e_edgeGet(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_edge, int64_t v_field);
static void fn_compiler_u002e_u1_dominance_u002e_addEdge(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_edge, int64_t v_source, int64_t v_target);
static void fn_compiler_u002e_u1_dominance_u002e_stackSet(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_index, int64_t v_value);
static int64_t fn_compiler_u002e_u1_dominance_u002e_stackGet(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_index);
static void fn_compiler_u002e_u1_dominance_u002e_discover(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_block, int64_t v_parent);
static void fn_compiler_u002e_u1_dominance_u002e_dfs(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph);
static int64_t fn_compiler_u002e_u1_dominance_u002e_evaluate(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_value);
static void fn_compiler_u002e_u1_dominance_u002e_compute(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph);
static bool fn_compiler_u002e_u1_dominance_u002e_dominates(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_first, int64_t v_second);
static void fn_compiler_u002e_u1_dominance_u002e_close(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph);
static void fn_compiler_u002e_u1_verify_u002e_invalid(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, eri_text v_message);
static void fn_compiler_u002e_u1_verify_u002e_require(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, bool v_condition, eri_text v_message);
static int64_t fn_compiler_u002e_u1_verify_u002e_read(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, eri_struct_compiler_u002e_u1_words_u002e_Words * v_table, int64_t v_index);
static int64_t fn_compiler_u002e_u1_verify_u002e_scratch(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_first, int64_t v_index);
static void fn_compiler_u002e_u1_verify_u002e_mark(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_first, int64_t v_index, int64_t v_value);
static void fn_compiler_u002e_u1_verify_u002e_range(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_first, int64_t v_count, int64_t v_length);
static void fn_compiler_u002e_u1_verify_u002e_store(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, eri_struct_compiler_u002e_u1_words_u002e_Words * v_table, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_width, int64_t v_ceiling);
static void fn_compiler_u002e_u1_verify_u002e_bounds(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context);
static void fn_compiler_u002e_u1_verify_u002e_typeIndex(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_index);
static bool fn_compiler_u002e_u1_verify_u002e_sameSequence(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, eri_struct_compiler_u002e_u1_words_u002e_Words * v_table, int64_t v_first, int64_t v_second, int64_t v_count);
static void fn_compiler_u002e_u1_verify_u002e_signatures(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context);
static void fn_compiler_u002e_u1_verify_u002e_utf8(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_first, int64_t v_count);
static void fn_compiler_u002e_u1_verify_u002e_sources(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context);
static void fn_compiler_u002e_u1_verify_u002e_locations(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context);
static void fn_compiler_u002e_u1_verify_u002e_claimValue(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_value, int64_t v_valueTypeIndex, int64_t v_kind, int64_t v_definition, int64_t v_ordinal);
static int64_t fn_compiler_u002e_u1_verify_u002e_valueType(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_value);
static void fn_compiler_u002e_u1_verify_u002e_edge(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_index);
static void fn_compiler_u002e_u1_verify_u002e_instruction(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_index, bool v_terminal, int64_t v_position);
static void fn_compiler_u002e_u1_verify_u002e_structure(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context);
static void fn_compiler_u002e_u1_verify_u002e_use(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_value, int64_t v_position);
static void fn_compiler_u002e_u1_verify_u002e_ssaInstruction(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_index);
static void fn_compiler_u002e_u1_verify_u002e_reachableSSA(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context);
static eri_struct_compiler_u002e_u1_verify_u002e_Report fn_compiler_u002e_u1_verify_u002e_inspect(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context);
static eri_struct_compiler_u002e_u1_verify_u002e_Report fn_compiler_u002e_u1_verify_u002e_verifyMode(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, bool v_construction);
static eri_struct_compiler_u002e_u1_verify_u002e_Report fn_compiler_u002e_u1_verify_u002e_verify(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static eri_struct_compiler_u002e_u1_verify_u002e_Report fn_compiler_u002e_u1_verify_u002e_construction(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase);
static void fn_verifier_u002d_debug_u002e_check(bool v_condition, eri_text v_message);
static eri_struct_verifier_u002d_debug_u002e_Harness * fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(eri_list_compiler_u002e_u1_meta_u002e_TypeId v_parameters, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_results);
static void fn_verifier_u002d_debug_u002e_close(eri_struct_verifier_u002d_debug_u002e_Harness * v_harness);
static void fn_verifier_u002d_debug_u002e_change(eri_struct_compiler_u002e_u1_words_u002e_Words * v_table, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_index, int64_t v_value);
static void fn_verifier_u002d_debug_u002e_accepted(eri_struct_verifier_u002d_debug_u002e_Harness * v_harness, int64_t v_reachable, eri_text v_label);
static void fn_verifier_u002d_debug_u002e_rejected(eri_struct_verifier_u002d_debug_u002e_Harness * v_harness, int64_t v_stage, int64_t v_block, eri_text v_label);
static eri_struct_verifier_u002d_debug_u002e_Harness * fn_verifier_u002d_debug_u002e_straight(void);
static void fn_verifier_u002d_debug_u002e_mutations(void);
static void fn_verifier_u002d_debug_u002e_orphanRecords(void);
static void fn_verifier_u002d_debug_u002e_diamond(void);
static void fn_verifier_u002d_debug_u002e_loop(void);
static void fn_verifier_u002d_debug_u002e_dead(void);
static void fn_verifier_u002d_debug_u002e_repeatedTarget(void);
static void fn_verifier_u002d_debug_u002e_limits(void);
static void fn_verifier_u002d_debug_u002e_cancellation(void);
static void fn_verifier_u002d_debug_u002e_scalarShapes(void);
static void fn_verifier_u002d_debug_u002e_manyUses(void);
static bool fn_verifier_u002d_debug_u002e_run(void);
static void fn_verifier_u002d_debug_u002e_main(void);
static void fn_compiler_u002e_u1_budget_u002e_invalid(void) {
    eri_fail_compiler_u002e_u1_budget_u002e_LimitError((eri_struct_compiler_u002e_u1_budget_u002e_LimitError){.f_message = eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x61, 0x63, 0x63, 0x6f, 0x75, 0x6e, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x73, 0x74, 0x61, 0x74, 0x65}, 28), .f_category = eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x2d, 0x73, 0x74, 0x61, 0x74, 0x65}, 13), .f_requested = 0, .f_remaining = 0});
}

static void fn_compiler_u002e_u1_budget_u002e_reject(eri_text v_message) {
    eri_fail_compiler_u002e_u1_budget_u002e_LimitError((eri_struct_compiler_u002e_u1_budget_u002e_LimitError){.f_message = v_message, .f_category = eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x2d, 0x73, 0x74, 0x61, 0x74, 0x65}, 13), .f_requested = 0, .f_remaining = 0});
}

static void fn_compiler_u002e_u1_budget_u002e_active(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_1;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_2;
    int64_t _eri_order_3;
    int64_t _eri_order_4;
    int64_t _eri_order_5;
    int64_t _eri_order_6;
    int64_t _eri_order_7;
    int64_t _eri_order_8;
    int64_t _eri_order_9;
    int64_t _eri_order_10;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_root = v_owner;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_parent = (v_owner)->f_parent;
    if ((_eri_order_1 = (v_parent), _eri_order_2 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_1, _eri_order_2)))) {
        v_root = eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent);
    }
    if (((_eri_order_3 = ((v_owner)->f_state), _eri_order_4 = (2), (_eri_order_3 == _eri_order_4)) || (_eri_order_5 = ((v_root)->f_state), _eri_order_6 = (2), (_eri_order_5 == _eri_order_6)))) {
        eri_fail_compiler_u002e_u1_budget_u002e_LimitError((eri_struct_compiler_u002e_u1_budget_u002e_LimitError){.f_message = eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x61, 0x74, 0x74, 0x65, 0x6d, 0x70, 0x74, 0x20, 0x63, 0x61, 0x6e, 0x63, 0x65, 0x6c, 0x6c, 0x65, 0x64}, 21), .f_category = eri_text_from_bytes((const unsigned char[]){0x63, 0x61, 0x6e, 0x63, 0x65, 0x6c, 0x6c, 0x65, 0x64}, 9), .f_requested = 0, .f_remaining = 0});
    }
    if (((_eri_order_7 = ((v_owner)->f_state), _eri_order_8 = (0), (_eri_order_7 != _eri_order_8)) || (_eri_order_9 = ((v_root)->f_state), _eri_order_10 = (0), (_eri_order_9 != _eri_order_10)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
}

static void fn_compiler_u002e_u1_budget_u002e_exhausted(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount, int64_t v_remaining) {
    (v_owner)->f_state = 1;
    eri_fail_compiler_u002e_u1_budget_u002e_LimitError((eri_struct_compiler_u002e_u1_budget_u002e_LimitError){.f_message = eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x72, 0x65, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x6c, 0x69, 0x6d, 0x69, 0x74, 0x20, 0x65, 0x78, 0x63, 0x65, 0x65, 0x64, 0x65, 0x64}, 27), .f_category = eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x2d, 0x6c, 0x69, 0x6d, 0x69, 0x74}, 14), .f_requested = v_amount, .f_remaining = v_remaining});
}

static void fn_compiler_u002e_u1_budget_u002e_exceed(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount, int64_t v_remaining) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_11;
    int64_t _eri_order_12;
    int64_t _eri_order_13;
    (_eri_order_11 = (v_owner), _eri_order_12 = (v_amount), _eri_order_13 = (v_remaining), fn_compiler_u002e_u1_budget_u002e_exhausted(_eri_order_11, _eri_order_12, _eri_order_13));
}

static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_request(int64_t v_limit, int64_t v_trafficLimit, int64_t v_workLimit) {
    int64_t _eri_order_14;
    int64_t _eri_order_15;
    int64_t _eri_order_16;
    int64_t _eri_order_17;
    int64_t _eri_order_18;
    int64_t _eri_order_19;
    if ((((_eri_order_14 = (v_limit), _eri_order_15 = (0), (_eri_order_14 < _eri_order_15)) || (_eri_order_16 = (v_trafficLimit), _eri_order_17 = (0), (_eri_order_16 < _eri_order_17))) || (_eri_order_18 = (v_workLimit), _eri_order_19 = (0), (_eri_order_18 < _eri_order_19)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    return eri_identity_compiler_u002e_u1_budget_u002e_Owner_new((eri_struct_compiler_u002e_u1_budget_u002e_Owner){.f_parent = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}, .f_kind = 0, .f_state = 0, .f_limit = v_limit, .f_trafficLimit = v_trafficLimit, .f_workLimit = v_workLimit, .f_live = 0, .f_pending = 0, .f_peak = 0, .f_reservedPeak = 0, .f_traffic = 0, .f_pendingTraffic = 0, .f_work = 0});
}

static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_developmentRequest(void) {
    int64_t _eri_order_20;
    int64_t _eri_order_21;
    int64_t _eri_order_22;
    return (_eri_order_20 = (536870912), _eri_order_21 = (2147483648), _eri_order_22 = (268435456), fn_compiler_u002e_u1_budget_u002e_request(_eri_order_20, _eri_order_21, _eri_order_22));
}

static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_metadataOwner(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_root) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_23;
    int64_t _eri_order_24;
    int64_t _eri_order_25;
    int64_t _eri_order_26;
    int64_t _eri_order_27;
    return (_eri_order_23 = (v_root), _eri_order_24 = (1), _eri_order_25 = (134217728), _eri_order_26 = (2147483648), _eri_order_27 = (268435456), fn_compiler_u002e_u1_budget_u002e_child(_eri_order_23, _eri_order_24, _eri_order_25, _eri_order_26, _eri_order_27));
}

static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_child(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_root, int64_t v_kind, int64_t v_limit, int64_t v_trafficLimit, int64_t v_workLimit) {
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_28;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_29;
    int64_t _eri_order_30;
    int64_t _eri_order_31;
    int64_t _eri_order_32;
    int64_t _eri_order_33;
    int64_t _eri_order_34;
    int64_t _eri_order_35;
    int64_t _eri_order_36;
    int64_t _eri_order_37;
    int64_t _eri_order_38;
    int64_t _eri_order_39;
    int64_t _eri_order_40;
    int64_t _eri_order_41;
    fn_compiler_u002e_u1_budget_u002e_active(v_root);
    if ((((((((_eri_order_28 = ((v_root)->f_parent), _eri_order_29 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_28, _eri_order_29))) || (_eri_order_30 = ((v_root)->f_kind), _eri_order_31 = (0), (_eri_order_30 != _eri_order_31))) || (_eri_order_32 = (v_kind), _eri_order_33 = (1), (_eri_order_32 < _eri_order_33))) || (_eri_order_34 = (v_kind), _eri_order_35 = (2), (_eri_order_34 > _eri_order_35))) || (_eri_order_36 = (v_limit), _eri_order_37 = (0), (_eri_order_36 < _eri_order_37))) || (_eri_order_38 = (v_trafficLimit), _eri_order_39 = (0), (_eri_order_38 < _eri_order_39))) || (_eri_order_40 = (v_workLimit), _eri_order_41 = (0), (_eri_order_40 < _eri_order_41)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    return eri_identity_compiler_u002e_u1_budget_u002e_Owner_new((eri_struct_compiler_u002e_u1_budget_u002e_Owner){.f_parent = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=true,.value=v_root}, .f_kind = v_kind, .f_state = 0, .f_limit = v_limit, .f_trafficLimit = v_trafficLimit, .f_workLimit = v_workLimit, .f_live = 0, .f_pending = 0, .f_peak = 0, .f_reservedPeak = 0, .f_traffic = 0, .f_pendingTraffic = 0, .f_work = 0});
}

static eri_struct_compiler_u002e_u1_budget_u002e_Owner * fn_compiler_u002e_u1_budget_u002e_functionOwner(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_root, bool v_qualification) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_42;
    int64_t _eri_order_43;
    int64_t _eri_order_44;
    int64_t _eri_order_45;
    int64_t _eri_order_46;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_47;
    int64_t _eri_order_48;
    int64_t _eri_order_49;
    int64_t _eri_order_50;
    int64_t _eri_order_51;
    if (v_qualification) {
        return (_eri_order_42 = (v_root), _eri_order_43 = (2), _eri_order_44 = (8388608), _eri_order_45 = (67108864), _eri_order_46 = (268435456), fn_compiler_u002e_u1_budget_u002e_child(_eri_order_42, _eri_order_43, _eri_order_44, _eri_order_45, _eri_order_46));
    }
    return (_eri_order_47 = (v_root), _eri_order_48 = (2), _eri_order_49 = (67108864), _eri_order_50 = (268435456), _eri_order_51 = (268435456), fn_compiler_u002e_u1_budget_u002e_child(_eri_order_47, _eri_order_48, _eri_order_49, _eri_order_50, _eri_order_51));
}

static int64_t fn_compiler_u002e_u1_budget_u002e_fits(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount) {
    int64_t _eri_order_52;
    int64_t _eri_order_53;
    int64_t _eri_order_54;
    int64_t _eri_order_55;
    int64_t _eri_order_56;
    int64_t _eri_order_57;
    int64_t _eri_order_58;
    int64_t _eri_order_59;
    int64_t _eri_order_60;
    int64_t _eri_order_61;
    int64_t _eri_order_62;
    int64_t _eri_order_63;
    if ((_eri_order_52 = (v_amount), _eri_order_57 = ((_eri_order_55 = ((_eri_order_53 = ((v_owner)->f_limit), _eri_order_54 = ((v_owner)->f_live), eri_isub(_eri_order_53, _eri_order_54))), _eri_order_56 = ((v_owner)->f_pending), eri_isub(_eri_order_55, _eri_order_56))), (_eri_order_52 > _eri_order_57))) {
        return 1;
    }
    if ((_eri_order_58 = (v_amount), _eri_order_63 = ((_eri_order_61 = ((_eri_order_59 = ((v_owner)->f_trafficLimit), _eri_order_60 = ((v_owner)->f_traffic), eri_isub(_eri_order_59, _eri_order_60))), _eri_order_62 = ((v_owner)->f_pendingTraffic), eri_isub(_eri_order_61, _eri_order_62))), (_eri_order_58 > _eri_order_63))) {
        return 2;
    }
    return 0;
}

static void fn_compiler_u002e_u1_budget_u002e_pendingAdd(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount) {
    int64_t _eri_order_64;
    int64_t _eri_order_65;
    int64_t _eri_order_66;
    int64_t _eri_order_67;
    int64_t _eri_order_68;
    int64_t _eri_order_69;
    int64_t _eri_order_70;
    int64_t _eri_order_71;
    (v_owner)->f_pending = (_eri_order_64 = ((v_owner)->f_pending), _eri_order_65 = (v_amount), eri_iadd(_eri_order_64, _eri_order_65));
    (v_owner)->f_pendingTraffic = (_eri_order_66 = ((v_owner)->f_pendingTraffic), _eri_order_67 = (v_amount), eri_iadd(_eri_order_66, _eri_order_67));
    int64_t v_total = (_eri_order_68 = ((v_owner)->f_live), _eri_order_69 = ((v_owner)->f_pending), eri_iadd(_eri_order_68, _eri_order_69));
    if ((_eri_order_70 = (v_total), _eri_order_71 = ((v_owner)->f_reservedPeak), (_eri_order_70 > _eri_order_71))) {
        (v_owner)->f_reservedPeak = v_total;
    }
}

static void fn_compiler_u002e_u1_budget_u002e_checkFits(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_charged, int64_t v_amount) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_72;
    int64_t _eri_order_73;
    int64_t _eri_order_74;
    int64_t _eri_order_75;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_76;
    int64_t _eri_order_77;
    int64_t _eri_order_78;
    int64_t _eri_order_79;
    int64_t _eri_order_80;
    int64_t _eri_order_81;
    int64_t _eri_order_82;
    int64_t _eri_order_83;
    int64_t _eri_order_84;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_85;
    int64_t _eri_order_86;
    int64_t _eri_order_87;
    int64_t _eri_order_88;
    int64_t _eri_order_89;
    int64_t _eri_order_90;
    int64_t _eri_order_91;
    int64_t v_reason = (_eri_order_72 = (v_charged), _eri_order_73 = (v_amount), fn_compiler_u002e_u1_budget_u002e_fits(_eri_order_72, _eri_order_73));
    if ((_eri_order_74 = (v_reason), _eri_order_75 = (1), (_eri_order_74 == _eri_order_75))) {
        (_eri_order_76 = (v_owner), _eri_order_77 = (v_amount), _eri_order_82 = ((_eri_order_80 = ((_eri_order_78 = ((v_charged)->f_limit), _eri_order_79 = ((v_charged)->f_live), eri_isub(_eri_order_78, _eri_order_79))), _eri_order_81 = ((v_charged)->f_pending), eri_isub(_eri_order_80, _eri_order_81))), fn_compiler_u002e_u1_budget_u002e_exhausted(_eri_order_76, _eri_order_77, _eri_order_82));
    }
    if ((_eri_order_83 = (v_reason), _eri_order_84 = (2), (_eri_order_83 == _eri_order_84))) {
        (_eri_order_85 = (v_owner), _eri_order_86 = (v_amount), _eri_order_91 = ((_eri_order_89 = ((_eri_order_87 = ((v_charged)->f_trafficLimit), _eri_order_88 = ((v_charged)->f_traffic), eri_isub(_eri_order_87, _eri_order_88))), _eri_order_90 = ((v_charged)->f_pendingTraffic), eri_isub(_eri_order_89, _eri_order_90))), fn_compiler_u002e_u1_budget_u002e_exhausted(_eri_order_85, _eri_order_86, _eri_order_91));
    }
}

static eri_struct_compiler_u002e_u1_budget_u002e_Reservation * fn_compiler_u002e_u1_budget_u002e_reserve(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount) {
    int64_t _eri_order_92;
    int64_t _eri_order_93;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_94;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_95;
    int64_t _eri_order_96;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_97;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_98;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_99;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_100;
    int64_t _eri_order_101;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_102;
    int64_t _eri_order_103;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_104;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_105;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_106;
    int64_t _eri_order_107;
    fn_compiler_u002e_u1_budget_u002e_active(v_owner);
    if ((_eri_order_92 = (v_amount), _eri_order_93 = (0), (_eri_order_92 < _eri_order_93))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    (_eri_order_94 = (v_owner), _eri_order_95 = (v_owner), _eri_order_96 = (v_amount), fn_compiler_u002e_u1_budget_u002e_checkFits(_eri_order_94, _eri_order_95, _eri_order_96));
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_parent = (v_owner)->f_parent;
    if ((_eri_order_97 = (v_parent), _eri_order_98 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_97, _eri_order_98)))) {
        (_eri_order_99 = (v_owner), _eri_order_100 = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent)), _eri_order_101 = (v_amount), fn_compiler_u002e_u1_budget_u002e_checkFits(_eri_order_99, _eri_order_100, _eri_order_101));
    }
    (_eri_order_102 = (v_owner), _eri_order_103 = (v_amount), fn_compiler_u002e_u1_budget_u002e_pendingAdd(_eri_order_102, _eri_order_103));
    if ((_eri_order_104 = (v_parent), _eri_order_105 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_104, _eri_order_105)))) {
        (_eri_order_106 = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent)), _eri_order_107 = (v_amount), fn_compiler_u002e_u1_budget_u002e_pendingAdd(_eri_order_106, _eri_order_107));
    }
    return eri_identity_compiler_u002e_u1_budget_u002e_Reservation_new((eri_struct_compiler_u002e_u1_budget_u002e_Reservation){.f_owner = v_owner, .f_bytes = v_amount, .f_state = 0});
}

static void fn_compiler_u002e_u1_budget_u002e_commitAt(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount) {
    int64_t _eri_order_108;
    int64_t _eri_order_109;
    int64_t _eri_order_110;
    int64_t _eri_order_111;
    int64_t _eri_order_112;
    int64_t _eri_order_113;
    int64_t _eri_order_114;
    int64_t _eri_order_115;
    int64_t _eri_order_116;
    int64_t _eri_order_117;
    (v_owner)->f_pending = (_eri_order_108 = ((v_owner)->f_pending), _eri_order_109 = (v_amount), eri_isub(_eri_order_108, _eri_order_109));
    (v_owner)->f_pendingTraffic = (_eri_order_110 = ((v_owner)->f_pendingTraffic), _eri_order_111 = (v_amount), eri_isub(_eri_order_110, _eri_order_111));
    (v_owner)->f_live = (_eri_order_112 = ((v_owner)->f_live), _eri_order_113 = (v_amount), eri_iadd(_eri_order_112, _eri_order_113));
    (v_owner)->f_traffic = (_eri_order_114 = ((v_owner)->f_traffic), _eri_order_115 = (v_amount), eri_iadd(_eri_order_114, _eri_order_115));
    if ((_eri_order_116 = ((v_owner)->f_live), _eri_order_117 = ((v_owner)->f_peak), (_eri_order_116 > _eri_order_117))) {
        (v_owner)->f_peak = (v_owner)->f_live;
    }
}

static eri_struct_compiler_u002e_u1_budget_u002e_Allocation * fn_compiler_u002e_u1_budget_u002e_commit(eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_reservation) {
    int64_t _eri_order_118;
    int64_t _eri_order_119;
    int64_t _eri_order_120;
    int64_t _eri_order_121;
    int64_t _eri_order_122;
    int64_t _eri_order_123;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_124;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_125;
    int64_t _eri_order_126;
    int64_t _eri_order_127;
    int64_t _eri_order_128;
    int64_t _eri_order_129;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_130;
    int64_t _eri_order_131;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_132;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_133;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_134;
    int64_t _eri_order_135;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner = (v_reservation)->f_owner;
    fn_compiler_u002e_u1_budget_u002e_active(v_owner);
    if ((_eri_order_118 = ((v_reservation)->f_state), _eri_order_119 = (0), (_eri_order_118 != _eri_order_119))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_parent = (v_owner)->f_parent;
    if (((_eri_order_120 = ((v_reservation)->f_bytes), _eri_order_121 = ((v_owner)->f_pending), (_eri_order_120 > _eri_order_121)) || (_eri_order_122 = ((v_reservation)->f_bytes), _eri_order_123 = ((v_owner)->f_pendingTraffic), (_eri_order_122 > _eri_order_123)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    if ((_eri_order_124 = (v_parent), _eri_order_125 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_124, _eri_order_125)))) {
        if (((_eri_order_126 = ((v_reservation)->f_bytes), _eri_order_127 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_pending), (_eri_order_126 > _eri_order_127)) || (_eri_order_128 = ((v_reservation)->f_bytes), _eri_order_129 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_pendingTraffic), (_eri_order_128 > _eri_order_129)))) {
            fn_compiler_u002e_u1_budget_u002e_invalid();
        }
    }
    (_eri_order_130 = (v_owner), _eri_order_131 = ((v_reservation)->f_bytes), fn_compiler_u002e_u1_budget_u002e_commitAt(_eri_order_130, _eri_order_131));
    if ((_eri_order_132 = (v_parent), _eri_order_133 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_132, _eri_order_133)))) {
        (_eri_order_134 = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent)), _eri_order_135 = ((v_reservation)->f_bytes), fn_compiler_u002e_u1_budget_u002e_commitAt(_eri_order_134, _eri_order_135));
    }
    (v_reservation)->f_state = 1;
    return eri_identity_compiler_u002e_u1_budget_u002e_Allocation_new((eri_struct_compiler_u002e_u1_budget_u002e_Allocation){.f_owner = v_owner, .f_bytes = (v_reservation)->f_bytes, .f_state = 0});
}

static void fn_compiler_u002e_u1_budget_u002e_cancelAt(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_amount) {
    int64_t _eri_order_136;
    int64_t _eri_order_137;
    int64_t _eri_order_138;
    int64_t _eri_order_139;
    (v_owner)->f_pending = (_eri_order_136 = ((v_owner)->f_pending), _eri_order_137 = (v_amount), eri_isub(_eri_order_136, _eri_order_137));
    (v_owner)->f_pendingTraffic = (_eri_order_138 = ((v_owner)->f_pendingTraffic), _eri_order_139 = (v_amount), eri_isub(_eri_order_138, _eri_order_139));
}

static void fn_compiler_u002e_u1_budget_u002e_cancelReservation(eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_reservation) {
    int64_t _eri_order_140;
    int64_t _eri_order_141;
    int64_t _eri_order_142;
    int64_t _eri_order_143;
    int64_t _eri_order_144;
    int64_t _eri_order_145;
    int64_t _eri_order_146;
    int64_t _eri_order_147;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_148;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_149;
    int64_t _eri_order_150;
    int64_t _eri_order_151;
    int64_t _eri_order_152;
    int64_t _eri_order_153;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_154;
    int64_t _eri_order_155;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_156;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_157;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_158;
    int64_t _eri_order_159;
    if (((_eri_order_140 = ((v_reservation)->f_state), _eri_order_141 = (0), (_eri_order_140 != _eri_order_141)) || (_eri_order_142 = (((v_reservation)->f_owner)->f_state), _eri_order_143 = (3), (_eri_order_142 == _eri_order_143)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner = (v_reservation)->f_owner;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_parent = (v_owner)->f_parent;
    if (((_eri_order_144 = ((v_reservation)->f_bytes), _eri_order_145 = ((v_owner)->f_pending), (_eri_order_144 > _eri_order_145)) || (_eri_order_146 = ((v_reservation)->f_bytes), _eri_order_147 = ((v_owner)->f_pendingTraffic), (_eri_order_146 > _eri_order_147)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    if ((_eri_order_148 = (v_parent), _eri_order_149 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_148, _eri_order_149)))) {
        if (((_eri_order_150 = ((v_reservation)->f_bytes), _eri_order_151 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_pending), (_eri_order_150 > _eri_order_151)) || (_eri_order_152 = ((v_reservation)->f_bytes), _eri_order_153 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_pendingTraffic), (_eri_order_152 > _eri_order_153)))) {
            fn_compiler_u002e_u1_budget_u002e_invalid();
        }
    }
    (_eri_order_154 = (v_owner), _eri_order_155 = ((v_reservation)->f_bytes), fn_compiler_u002e_u1_budget_u002e_cancelAt(_eri_order_154, _eri_order_155));
    if ((_eri_order_156 = (v_parent), _eri_order_157 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_156, _eri_order_157)))) {
        (_eri_order_158 = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent)), _eri_order_159 = ((v_reservation)->f_bytes), fn_compiler_u002e_u1_budget_u002e_cancelAt(_eri_order_158, _eri_order_159));
    }
    (v_reservation)->f_state = 2;
}

static void fn_compiler_u002e_u1_budget_u002e_release(eri_struct_compiler_u002e_u1_budget_u002e_Allocation * v_allocation) {
    int64_t _eri_order_160;
    int64_t _eri_order_161;
    int64_t _eri_order_162;
    int64_t _eri_order_163;
    int64_t _eri_order_164;
    int64_t _eri_order_165;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_166;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_167;
    int64_t _eri_order_168;
    int64_t _eri_order_169;
    int64_t _eri_order_170;
    int64_t _eri_order_171;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_172;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_173;
    int64_t _eri_order_174;
    int64_t _eri_order_175;
    if (((_eri_order_160 = ((v_allocation)->f_state), _eri_order_161 = (0), (_eri_order_160 != _eri_order_161)) || (_eri_order_162 = (((v_allocation)->f_owner)->f_state), _eri_order_163 = (3), (_eri_order_162 == _eri_order_163)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner = (v_allocation)->f_owner;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_parent = (v_owner)->f_parent;
    if ((_eri_order_164 = ((v_allocation)->f_bytes), _eri_order_165 = ((v_owner)->f_live), (_eri_order_164 > _eri_order_165))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    if ((_eri_order_166 = (v_parent), _eri_order_167 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_166, _eri_order_167)))) {
        if ((_eri_order_168 = ((v_allocation)->f_bytes), _eri_order_169 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_live), (_eri_order_168 > _eri_order_169))) {
            fn_compiler_u002e_u1_budget_u002e_invalid();
        }
    }
    (v_owner)->f_live = (_eri_order_170 = ((v_owner)->f_live), _eri_order_171 = ((v_allocation)->f_bytes), eri_isub(_eri_order_170, _eri_order_171));
    if ((_eri_order_172 = (v_parent), _eri_order_173 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_172, _eri_order_173)))) {
        ((v_parent).value)->f_live = (_eri_order_174 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_live), _eri_order_175 = ((v_allocation)->f_bytes), eri_isub(_eri_order_174, _eri_order_175));
    }
    (v_allocation)->f_state = 1;
}

static void fn_compiler_u002e_u1_budget_u002e_transfer(eri_struct_compiler_u002e_u1_budget_u002e_Allocation * v_allocation, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_destination) {
    int64_t _eri_order_176;
    int64_t _eri_order_177;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_178;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_179;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_180;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_181;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_182;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_183;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_184;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_185;
    int64_t _eri_order_186;
    int64_t _eri_order_187;
    int64_t _eri_order_188;
    int64_t _eri_order_189;
    int64_t _eri_order_190;
    int64_t _eri_order_191;
    int64_t _eri_order_192;
    int64_t _eri_order_193;
    int64_t _eri_order_194;
    int64_t _eri_order_195;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_196;
    int64_t _eri_order_197;
    int64_t _eri_order_198;
    int64_t _eri_order_199;
    int64_t _eri_order_200;
    int64_t _eri_order_201;
    int64_t _eri_order_202;
    int64_t _eri_order_203;
    int64_t _eri_order_204;
    int64_t _eri_order_205;
    int64_t _eri_order_206;
    int64_t _eri_order_207;
    int64_t _eri_order_208;
    int64_t _eri_order_209;
    int64_t _eri_order_210;
    int64_t _eri_order_211;
    int64_t _eri_order_212;
    if ((_eri_order_176 = ((v_allocation)->f_state), _eri_order_177 = (0), (_eri_order_176 != _eri_order_177))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_source = (v_allocation)->f_owner;
    fn_compiler_u002e_u1_budget_u002e_active(v_source);
    fn_compiler_u002e_u1_budget_u002e_active(v_destination);
    if ((_eri_order_178 = (v_source), _eri_order_179 = (v_destination), (_eri_order_178 == _eri_order_179))) {
        return;
    }
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_first = (v_source)->f_parent;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_second = (v_destination)->f_parent;
    if (((((_eri_order_180 = (v_first), _eri_order_181 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_180, _eri_order_181)) || (_eri_order_182 = (v_second), _eri_order_183 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_182, _eri_order_183))) || (_eri_order_184 = (v_first), _eri_order_185 = (v_second), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_184, _eri_order_185)))) || (_eri_order_186 = ((v_source)->f_kind), _eri_order_187 = ((v_destination)->f_kind), (_eri_order_186 != _eri_order_187)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    if ((_eri_order_188 = ((v_allocation)->f_bytes), _eri_order_189 = ((v_source)->f_live), (_eri_order_188 > _eri_order_189))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    if ((_eri_order_190 = ((v_allocation)->f_bytes), _eri_order_195 = ((_eri_order_193 = ((_eri_order_191 = ((v_destination)->f_limit), _eri_order_192 = ((v_destination)->f_live), eri_isub(_eri_order_191, _eri_order_192))), _eri_order_194 = ((v_destination)->f_pending), eri_isub(_eri_order_193, _eri_order_194))), (_eri_order_190 > _eri_order_195))) {
        (_eri_order_196 = (v_destination), _eri_order_197 = ((v_allocation)->f_bytes), _eri_order_202 = ((_eri_order_200 = ((_eri_order_198 = ((v_destination)->f_limit), _eri_order_199 = ((v_destination)->f_live), eri_isub(_eri_order_198, _eri_order_199))), _eri_order_201 = ((v_destination)->f_pending), eri_isub(_eri_order_200, _eri_order_201))), fn_compiler_u002e_u1_budget_u002e_exhausted(_eri_order_196, _eri_order_197, _eri_order_202));
    }
    (v_source)->f_live = (_eri_order_203 = ((v_source)->f_live), _eri_order_204 = ((v_allocation)->f_bytes), eri_isub(_eri_order_203, _eri_order_204));
    (v_destination)->f_live = (_eri_order_205 = ((v_destination)->f_live), _eri_order_206 = ((v_allocation)->f_bytes), eri_iadd(_eri_order_205, _eri_order_206));
    if ((_eri_order_207 = ((v_destination)->f_live), _eri_order_208 = ((v_destination)->f_peak), (_eri_order_207 > _eri_order_208))) {
        (v_destination)->f_peak = (v_destination)->f_live;
    }
    int64_t v_total = (_eri_order_209 = ((v_destination)->f_live), _eri_order_210 = ((v_destination)->f_pending), eri_iadd(_eri_order_209, _eri_order_210));
    if ((_eri_order_211 = (v_total), _eri_order_212 = ((v_destination)->f_reservedPeak), (_eri_order_211 > _eri_order_212))) {
        (v_destination)->f_reservedPeak = v_total;
    }
    (v_allocation)->f_owner = v_destination;
}

static eri_struct_compiler_u002e_u1_budget_u002e_Allocation * fn_compiler_u002e_u1_budget_u002e_split(eri_struct_compiler_u002e_u1_budget_u002e_Allocation * v_allocation, int64_t v_amount) {
    int64_t _eri_order_213;
    int64_t _eri_order_214;
    int64_t _eri_order_215;
    int64_t _eri_order_216;
    int64_t _eri_order_217;
    int64_t _eri_order_218;
    int64_t _eri_order_219;
    int64_t _eri_order_220;
    fn_compiler_u002e_u1_budget_u002e_active((v_allocation)->f_owner);
    if ((((_eri_order_213 = ((v_allocation)->f_state), _eri_order_214 = (0), (_eri_order_213 != _eri_order_214)) || (_eri_order_215 = (v_amount), _eri_order_216 = (0), (_eri_order_215 < _eri_order_216))) || (_eri_order_217 = (v_amount), _eri_order_218 = ((v_allocation)->f_bytes), (_eri_order_217 > _eri_order_218)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    (v_allocation)->f_bytes = (_eri_order_219 = ((v_allocation)->f_bytes), _eri_order_220 = (v_amount), eri_isub(_eri_order_219, _eri_order_220));
    return eri_identity_compiler_u002e_u1_budget_u002e_Allocation_new((eri_struct_compiler_u002e_u1_budget_u002e_Allocation){.f_owner = (v_allocation)->f_owner, .f_bytes = v_amount, .f_state = 0});
}

static eri_struct_compiler_u002e_u1_budget_u002e_Phase * fn_compiler_u002e_u1_budget_u002e_phase(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_limit) {
    int64_t _eri_order_221;
    int64_t _eri_order_222;
    fn_compiler_u002e_u1_budget_u002e_active(v_owner);
    if ((_eri_order_221 = (v_limit), _eri_order_222 = (0), (_eri_order_221 < _eri_order_222))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    return eri_identity_compiler_u002e_u1_budget_u002e_Phase_new((eri_struct_compiler_u002e_u1_budget_u002e_Phase){.f_owner = v_owner, .f_limit = v_limit, .f_used = 0, .f_prepaid = 0, .f_state = 0});
}

static eri_struct_compiler_u002e_u1_budget_u002e_Phase * fn_compiler_u002e_u1_budget_u002e_constructionPhase(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_223;
    int64_t _eri_order_224;
    return (_eri_order_223 = (v_owner), _eri_order_224 = (16777216), fn_compiler_u002e_u1_budget_u002e_phase(_eri_order_223, _eri_order_224));
}

static eri_struct_compiler_u002e_u1_budget_u002e_Phase * fn_compiler_u002e_u1_budget_u002e_verificationPhase(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_225;
    int64_t _eri_order_226;
    return (_eri_order_225 = (v_owner), _eri_order_226 = (16777216), fn_compiler_u002e_u1_budget_u002e_phase(_eri_order_225, _eri_order_226));
}

static eri_struct_compiler_u002e_u1_budget_u002e_Phase * fn_compiler_u002e_u1_budget_u002e_promotionPhase(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_227;
    int64_t _eri_order_228;
    return (_eri_order_227 = (v_owner), _eri_order_228 = (33554432), fn_compiler_u002e_u1_budget_u002e_phase(_eri_order_227, _eri_order_228));
}

static void fn_compiler_u002e_u1_budget_u002e_finishPhase(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    int64_t _eri_order_229;
    int64_t _eri_order_230;
    if ((_eri_order_229 = ((v_phase)->f_state), _eri_order_230 = (0), (_eri_order_229 != _eri_order_230))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    (v_phase)->f_state = 1;
}

static void fn_compiler_u002e_u1_budget_u002e_prepay(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_amount) {
    int64_t _eri_order_231;
    int64_t _eri_order_232;
    int64_t _eri_order_233;
    int64_t _eri_order_234;
    int64_t _eri_order_235;
    int64_t _eri_order_236;
    int64_t _eri_order_237;
    int64_t _eri_order_238;
    int64_t _eri_order_239;
    int64_t _eri_order_240;
    int64_t _eri_order_241;
    int64_t _eri_order_242;
    int64_t _eri_order_243;
    int64_t _eri_order_244;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_245;
    int64_t _eri_order_246;
    int64_t _eri_order_247;
    int64_t _eri_order_248;
    int64_t _eri_order_249;
    int64_t _eri_order_250;
    int64_t _eri_order_251;
    int64_t _eri_order_252;
    int64_t _eri_order_253;
    int64_t _eri_order_254;
    int64_t _eri_order_255;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_256;
    int64_t _eri_order_257;
    int64_t _eri_order_258;
    int64_t _eri_order_259;
    int64_t _eri_order_260;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_261;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_262;
    int64_t _eri_order_263;
    int64_t _eri_order_264;
    int64_t _eri_order_265;
    int64_t _eri_order_266;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_267;
    int64_t _eri_order_268;
    int64_t _eri_order_269;
    int64_t _eri_order_270;
    int64_t _eri_order_271;
    int64_t _eri_order_272;
    int64_t _eri_order_273;
    int64_t _eri_order_274;
    int64_t _eri_order_275;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_276;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_277;
    int64_t _eri_order_278;
    int64_t _eri_order_279;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner = (v_phase)->f_owner;
    fn_compiler_u002e_u1_budget_u002e_active(v_owner);
    if ((((_eri_order_231 = ((v_phase)->f_state), _eri_order_232 = (0), (_eri_order_231 != _eri_order_232)) || (_eri_order_233 = (v_amount), _eri_order_234 = (0), (_eri_order_233 < _eri_order_234))) || (_eri_order_235 = (v_amount), _eri_order_238 = ((_eri_order_236 = (1024), _eri_order_237 = ((v_phase)->f_prepaid), eri_isub(_eri_order_236, _eri_order_237))), (_eri_order_235 > _eri_order_238)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    if ((_eri_order_239 = (v_amount), _eri_order_244 = ((_eri_order_242 = ((_eri_order_240 = ((v_phase)->f_limit), _eri_order_241 = ((v_phase)->f_used), eri_isub(_eri_order_240, _eri_order_241))), _eri_order_243 = ((v_phase)->f_prepaid), eri_isub(_eri_order_242, _eri_order_243))), (_eri_order_239 > _eri_order_244))) {
        (_eri_order_245 = (v_owner), _eri_order_246 = (v_amount), _eri_order_251 = ((_eri_order_249 = ((_eri_order_247 = ((v_phase)->f_limit), _eri_order_248 = ((v_phase)->f_used), eri_isub(_eri_order_247, _eri_order_248))), _eri_order_250 = ((v_phase)->f_prepaid), eri_isub(_eri_order_249, _eri_order_250))), fn_compiler_u002e_u1_budget_u002e_exhausted(_eri_order_245, _eri_order_246, _eri_order_251));
    }
    if ((_eri_order_252 = (v_amount), _eri_order_255 = ((_eri_order_253 = ((v_owner)->f_workLimit), _eri_order_254 = ((v_owner)->f_work), eri_isub(_eri_order_253, _eri_order_254))), (_eri_order_252 > _eri_order_255))) {
        (_eri_order_256 = (v_owner), _eri_order_257 = (v_amount), _eri_order_260 = ((_eri_order_258 = ((v_owner)->f_workLimit), _eri_order_259 = ((v_owner)->f_work), eri_isub(_eri_order_258, _eri_order_259))), fn_compiler_u002e_u1_budget_u002e_exhausted(_eri_order_256, _eri_order_257, _eri_order_260));
    }
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_parent = (v_owner)->f_parent;
    if ((_eri_order_261 = (v_parent), _eri_order_262 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_261, _eri_order_262)))) {
        if ((_eri_order_263 = (v_amount), _eri_order_266 = ((_eri_order_264 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_workLimit), _eri_order_265 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_work), eri_isub(_eri_order_264, _eri_order_265))), (_eri_order_263 > _eri_order_266))) {
            (_eri_order_267 = (v_owner), _eri_order_268 = (v_amount), _eri_order_271 = ((_eri_order_269 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_workLimit), _eri_order_270 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_work), eri_isub(_eri_order_269, _eri_order_270))), fn_compiler_u002e_u1_budget_u002e_exhausted(_eri_order_267, _eri_order_268, _eri_order_271));
        }
    }
    (v_phase)->f_prepaid = (_eri_order_272 = ((v_phase)->f_prepaid), _eri_order_273 = (v_amount), eri_iadd(_eri_order_272, _eri_order_273));
    (v_owner)->f_work = (_eri_order_274 = ((v_owner)->f_work), _eri_order_275 = (v_amount), eri_iadd(_eri_order_274, _eri_order_275));
    if ((_eri_order_276 = (v_parent), _eri_order_277 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_276, _eri_order_277)))) {
        ((v_parent).value)->f_work = (_eri_order_278 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent))->f_work), _eri_order_279 = (v_amount), eri_iadd(_eri_order_278, _eri_order_279));
    }
}

static void fn_compiler_u002e_u1_budget_u002e_consume(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_amount) {
    int64_t _eri_order_280;
    int64_t _eri_order_281;
    int64_t _eri_order_282;
    int64_t _eri_order_283;
    int64_t _eri_order_284;
    int64_t _eri_order_285;
    int64_t _eri_order_286;
    int64_t _eri_order_287;
    int64_t _eri_order_288;
    int64_t _eri_order_289;
    int64_t _eri_order_290;
    int64_t _eri_order_291;
    fn_compiler_u002e_u1_budget_u002e_active((v_phase)->f_owner);
    if (((((_eri_order_280 = ((v_phase)->f_state), _eri_order_281 = (0), (_eri_order_280 != _eri_order_281)) || (_eri_order_282 = (v_amount), _eri_order_283 = (0), (_eri_order_282 < _eri_order_283))) || (_eri_order_284 = (v_amount), _eri_order_285 = (1024), (_eri_order_284 > _eri_order_285))) || (_eri_order_286 = (v_amount), _eri_order_287 = ((v_phase)->f_prepaid), (_eri_order_286 > _eri_order_287)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    (v_phase)->f_prepaid = (_eri_order_288 = ((v_phase)->f_prepaid), _eri_order_289 = (v_amount), eri_isub(_eri_order_288, _eri_order_289));
    (v_phase)->f_used = (_eri_order_290 = ((v_phase)->f_used), _eri_order_291 = (v_amount), eri_iadd(_eri_order_290, _eri_order_291));
}

static void fn_compiler_u002e_u1_budget_u002e_work(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_amount) {
    int64_t _eri_order_292;
    int64_t _eri_order_293;
    int64_t _eri_order_294;
    int64_t _eri_order_295;
    int64_t _eri_order_296;
    int64_t _eri_order_297;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_298;
    int64_t _eri_order_299;
    int64_t _eri_order_300;
    int64_t _eri_order_301;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_302;
    int64_t _eri_order_303;
    if (((_eri_order_292 = (v_amount), _eri_order_293 = (0), (_eri_order_292 < _eri_order_293)) || (_eri_order_294 = (v_amount), _eri_order_295 = (1024), (_eri_order_294 > _eri_order_295)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    if ((_eri_order_296 = ((v_phase)->f_prepaid), _eri_order_297 = (v_amount), (_eri_order_296 < _eri_order_297))) {
        (_eri_order_298 = (v_phase), _eri_order_301 = ((_eri_order_299 = (v_amount), _eri_order_300 = ((v_phase)->f_prepaid), eri_isub(_eri_order_299, _eri_order_300))), fn_compiler_u002e_u1_budget_u002e_prepay(_eri_order_298, _eri_order_301));
    }
    (_eri_order_302 = (v_phase), _eri_order_303 = (v_amount), fn_compiler_u002e_u1_budget_u002e_consume(_eri_order_302, _eri_order_303));
}

static void fn_compiler_u002e_u1_budget_u002e_cancel(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    int64_t _eri_order_304;
    int64_t _eri_order_305;
    if ((_eri_order_304 = ((v_owner)->f_state), _eri_order_305 = (3), (_eri_order_304 != _eri_order_305))) {
        (v_owner)->f_state = 2;
    }
}

static void fn_compiler_u002e_u1_budget_u002e_poll(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    fn_compiler_u002e_u1_budget_u002e_active(v_owner);
}

static void fn_compiler_u002e_u1_budget_u002e_close(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    int64_t _eri_order_306;
    int64_t _eri_order_307;
    int64_t _eri_order_308;
    int64_t _eri_order_309;
    int64_t _eri_order_310;
    int64_t _eri_order_311;
    int64_t _eri_order_312;
    int64_t _eri_order_313;
    if (((((_eri_order_306 = ((v_owner)->f_state), _eri_order_307 = (3), (_eri_order_306 == _eri_order_307)) || (_eri_order_308 = ((v_owner)->f_live), _eri_order_309 = (0), (_eri_order_308 != _eri_order_309))) || (_eri_order_310 = ((v_owner)->f_pending), _eri_order_311 = (0), (_eri_order_310 != _eri_order_311))) || (_eri_order_312 = ((v_owner)->f_pendingTraffic), _eri_order_313 = (0), (_eri_order_312 != _eri_order_313)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    (v_owner)->f_state = 3;
}

static void fn_compiler_u002e_u1_budget_u002e_abandonAt(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_parent, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    int64_t _eri_order_314;
    int64_t _eri_order_315;
    int64_t _eri_order_316;
    int64_t _eri_order_317;
    int64_t _eri_order_318;
    int64_t _eri_order_319;
    int64_t _eri_order_320;
    int64_t _eri_order_321;
    int64_t _eri_order_322;
    int64_t _eri_order_323;
    int64_t _eri_order_324;
    int64_t _eri_order_325;
    if ((((_eri_order_314 = ((v_owner)->f_live), _eri_order_315 = ((v_parent)->f_live), (_eri_order_314 > _eri_order_315)) || (_eri_order_316 = ((v_owner)->f_pending), _eri_order_317 = ((v_parent)->f_pending), (_eri_order_316 > _eri_order_317))) || (_eri_order_318 = ((v_owner)->f_pendingTraffic), _eri_order_319 = ((v_parent)->f_pendingTraffic), (_eri_order_318 > _eri_order_319)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    (v_parent)->f_live = (_eri_order_320 = ((v_parent)->f_live), _eri_order_321 = ((v_owner)->f_live), eri_isub(_eri_order_320, _eri_order_321));
    (v_parent)->f_pending = (_eri_order_322 = ((v_parent)->f_pending), _eri_order_323 = ((v_owner)->f_pending), eri_isub(_eri_order_322, _eri_order_323));
    (v_parent)->f_pendingTraffic = (_eri_order_324 = ((v_parent)->f_pendingTraffic), _eri_order_325 = ((v_owner)->f_pendingTraffic), eri_isub(_eri_order_324, _eri_order_325));
}

static void fn_compiler_u002e_u1_budget_u002e_abandon(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner) {
    int64_t _eri_order_326;
    int64_t _eri_order_327;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_328;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_329;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_330;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_331;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_332;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_333;
    if (((_eri_order_326 = ((v_owner)->f_state), _eri_order_327 = (3), (_eri_order_326 == _eri_order_327)) || (_eri_order_328 = ((v_owner)->f_parent), _eri_order_329 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_328, _eri_order_329)))) {
        fn_compiler_u002e_u1_budget_u002e_invalid();
    }
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner v_parent = (v_owner)->f_parent;
    if ((_eri_order_330 = (v_parent), _eri_order_331 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_330, _eri_order_331)))) {
        (_eri_order_332 = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_get(v_parent)), _eri_order_333 = (v_owner), fn_compiler_u002e_u1_budget_u002e_abandonAt(_eri_order_332, _eri_order_333));
    }
    (v_owner)->f_live = 0;
    (v_owner)->f_pending = 0;
    (v_owner)->f_pendingTraffic = 0;
    (v_owner)->f_state = 3;
}

static void fn_compiler_u002e_u1_words_u002e_context(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, bool v_write) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_334;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_335;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_336;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_337;
    int64_t _eri_order_338;
    int64_t _eri_order_339;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_340;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_341;
    fn_compiler_u002e_u1_budget_u002e_poll((v_words)->f_owner);
    fn_compiler_u002e_u1_budget_u002e_poll((v_phase)->f_owner);
    if ((v_words)->f_closed) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x63, 0x6c, 0x6f, 0x73, 0x65, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x73, 0x74, 0x6f, 0x72, 0x65}, 21));
    }
    if (v_write) {
        if (((v_words)->f_frozen || (_eri_order_334 = ((v_words)->f_owner), _eri_order_335 = ((v_phase)->f_owner), (!(_eri_order_334 == _eri_order_335))))) {
            fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6d, 0x6d, 0x75, 0x74, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x6f, 0x72, 0x20, 0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x73, 0x74, 0x6f, 0x72, 0x65}, 35));
        }
    } else {
        if ((_eri_order_336 = ((v_words)->f_owner), _eri_order_337 = ((v_phase)->f_owner), (!(_eri_order_336 == _eri_order_337)))) {
            if (((_eri_order_338 = (((v_words)->f_owner)->f_kind), _eri_order_339 = (1), (_eri_order_338 != _eri_order_339)) || (_eri_order_340 = (((v_words)->f_owner)->f_parent), _eri_order_341 = (((v_phase)->f_owner)->f_parent), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_340, _eri_order_341))))) {
                fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x73, 0x74, 0x6f, 0x72, 0x65}, 22));
            }
        }
    }
}

static eri_struct_compiler_u002e_u1_words_u002e_Words * fn_compiler_u002e_u1_words_u002e_create(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_limit) {
    int64_t _eri_order_342;
    int64_t _eri_order_343;
    int64_t _eri_order_344;
    int64_t _eri_order_345;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_346;
    int64_t _eri_order_347;
    if (((_eri_order_342 = (v_limit), _eri_order_343 = (0), (_eri_order_342 < _eri_order_343)) || (_eri_order_344 = (v_limit), _eri_order_345 = (33554432), (_eri_order_344 > _eri_order_345)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x6c, 0x69, 0x6d, 0x69, 0x74}, 22));
    }
    eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_pending = (_eri_order_346 = (v_owner), _eri_order_347 = (512), fn_compiler_u002e_u1_budget_u002e_reserve(_eri_order_346, _eri_order_347));
    eri_struct_compiler_u002e_u1_words_u002e_Words * v_words = eri_identity_compiler_u002e_u1_words_u002e_Words_new((eri_struct_compiler_u002e_u1_words_u002e_Words){.f_owner = v_owner, .f_root = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_length = 0, .f_limit = v_limit, .f_closed = false, .f_frozen = false, .f_control = fn_compiler_u002e_u1_budget_u002e_commit(v_pending)});
    return v_words;
}

static eri_struct_compiler_u002e_u1_words_u002e_Node * fn_compiler_u002e_u1_words_u002e_newNode(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_348;
    int64_t _eri_order_349;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_350;
    int64_t _eri_order_351;
    (_eri_order_348 = (v_phase), _eri_order_349 = (18), fn_compiler_u002e_u1_budget_u002e_work(_eri_order_348, _eri_order_349));
    eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_pending = (_eri_order_350 = (v_owner), _eri_order_351 = (800), fn_compiler_u002e_u1_budget_u002e_reserve(_eri_order_350, _eri_order_351));
    eri_struct_compiler_u002e_u1_words_u002e_Node * v_node = eri_identity_compiler_u002e_u1_words_u002e_Node_new((eri_struct_compiler_u002e_u1_words_u002e_Node){.f_c0 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c1 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c2 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c3 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c4 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c5 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c6 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c7 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c8 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c9 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c10 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c11 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c12 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c13 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c14 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_c15 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}, .f_page = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page){.has=false}, .f_charge = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false}});
    (v_node)->f_charge = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=true,.value=fn_compiler_u002e_u1_budget_u002e_commit(v_pending)};
    return v_node;
}

static eri_struct_compiler_u002e_u1_words_u002e_Page * fn_compiler_u002e_u1_words_u002e_newPage(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_352;
    int64_t _eri_order_353;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_354;
    int64_t _eri_order_355;
    (_eri_order_352 = (v_phase), _eri_order_353 = (17), fn_compiler_u002e_u1_budget_u002e_work(_eri_order_352, _eri_order_353));
    eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_pending = (_eri_order_354 = (v_owner), _eri_order_355 = (768), fn_compiler_u002e_u1_budget_u002e_reserve(_eri_order_354, _eri_order_355));
    eri_struct_compiler_u002e_u1_words_u002e_Page * v_page = eri_identity_compiler_u002e_u1_words_u002e_Page_new((eri_struct_compiler_u002e_u1_words_u002e_Page){.f_w0 = 0, .f_w1 = 0, .f_w2 = 0, .f_w3 = 0, .f_w4 = 0, .f_w5 = 0, .f_w6 = 0, .f_w7 = 0, .f_w8 = 0, .f_w9 = 0, .f_w10 = 0, .f_w11 = 0, .f_w12 = 0, .f_w13 = 0, .f_w14 = 0, .f_w15 = 0, .f_charge = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false}});
    (v_page)->f_charge = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=true,.value=fn_compiler_u002e_u1_budget_u002e_commit(v_pending)};
    return v_page;
}

static eri_struct_compiler_u002e_u1_words_u002e_Node * fn_compiler_u002e_u1_words_u002e_needNode(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node v_node) {
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_356;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_357;
    if ((_eri_order_356 = (v_node), _eri_order_357 = ((eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(_eri_order_356, _eri_order_357)))) {
        return eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_get(v_node);
    }
    eri_fail_compiler_u002e_u1_budget_u002e_LimitError((eri_struct_compiler_u002e_u1_budget_u002e_LimitError){.f_message = eri_text_from_bytes((const unsigned char[]){0x6d, 0x69, 0x73, 0x73, 0x69, 0x6e, 0x67, 0x20, 0x55, 0x31, 0x61, 0x20, 0x72, 0x61, 0x64, 0x69, 0x78, 0x20, 0x6e, 0x6f, 0x64, 0x65}, 22), .f_category = eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x2d, 0x73, 0x74, 0x61, 0x74, 0x65}, 13), .f_requested = 0, .f_remaining = 0});
}

static eri_struct_compiler_u002e_u1_words_u002e_Page * fn_compiler_u002e_u1_words_u002e_needPage(eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page v_page) {
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page _eri_order_358;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page _eri_order_359;
    if ((_eri_order_358 = (v_page), _eri_order_359 = ((eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_eq(_eri_order_358, _eri_order_359)))) {
        return eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_get(v_page);
    }
    eri_fail_compiler_u002e_u1_budget_u002e_LimitError((eri_struct_compiler_u002e_u1_budget_u002e_LimitError){.f_message = eri_text_from_bytes((const unsigned char[]){0x6d, 0x69, 0x73, 0x73, 0x69, 0x6e, 0x67, 0x20, 0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x70, 0x61, 0x67, 0x65}, 21), .f_category = eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x2d, 0x73, 0x74, 0x61, 0x74, 0x65}, 13), .f_requested = 0, .f_remaining = 0});
}

static int64_t fn_compiler_u002e_u1_words_u002e_readPage(eri_struct_compiler_u002e_u1_words_u002e_Page * v_page, int64_t v_offset) {
    int64_t _eri_order_360;
    int64_t _eri_order_361;
    int64_t _eri_order_362;
    int64_t _eri_order_363;
    int64_t _eri_order_364;
    int64_t _eri_order_365;
    int64_t _eri_order_366;
    int64_t _eri_order_367;
    int64_t _eri_order_368;
    int64_t _eri_order_369;
    int64_t _eri_order_370;
    int64_t _eri_order_371;
    int64_t _eri_order_372;
    int64_t _eri_order_373;
    int64_t _eri_order_374;
    int64_t _eri_order_375;
    int64_t _eri_order_376;
    int64_t _eri_order_377;
    int64_t _eri_order_378;
    int64_t _eri_order_379;
    int64_t _eri_order_380;
    int64_t _eri_order_381;
    int64_t _eri_order_382;
    int64_t _eri_order_383;
    int64_t _eri_order_384;
    int64_t _eri_order_385;
    int64_t _eri_order_386;
    int64_t _eri_order_387;
    int64_t _eri_order_388;
    int64_t _eri_order_389;
    if ((_eri_order_360 = (v_offset), _eri_order_361 = (8), (_eri_order_360 < _eri_order_361))) {
        if ((_eri_order_362 = (v_offset), _eri_order_363 = (4), (_eri_order_362 < _eri_order_363))) {
            if ((_eri_order_364 = (v_offset), _eri_order_365 = (2), (_eri_order_364 < _eri_order_365))) {
                if ((_eri_order_366 = (v_offset), _eri_order_367 = (1), (_eri_order_366 < _eri_order_367))) {
                    return (v_page)->f_w0;
                } else {
                    return (v_page)->f_w1;
                }
            } else {
                if ((_eri_order_368 = (v_offset), _eri_order_369 = (3), (_eri_order_368 < _eri_order_369))) {
                    return (v_page)->f_w2;
                } else {
                    return (v_page)->f_w3;
                }
            }
        } else {
            if ((_eri_order_370 = (v_offset), _eri_order_371 = (6), (_eri_order_370 < _eri_order_371))) {
                if ((_eri_order_372 = (v_offset), _eri_order_373 = (5), (_eri_order_372 < _eri_order_373))) {
                    return (v_page)->f_w4;
                } else {
                    return (v_page)->f_w5;
                }
            } else {
                if ((_eri_order_374 = (v_offset), _eri_order_375 = (7), (_eri_order_374 < _eri_order_375))) {
                    return (v_page)->f_w6;
                } else {
                    return (v_page)->f_w7;
                }
            }
        }
    } else {
        if ((_eri_order_376 = (v_offset), _eri_order_377 = (12), (_eri_order_376 < _eri_order_377))) {
            if ((_eri_order_378 = (v_offset), _eri_order_379 = (10), (_eri_order_378 < _eri_order_379))) {
                if ((_eri_order_380 = (v_offset), _eri_order_381 = (9), (_eri_order_380 < _eri_order_381))) {
                    return (v_page)->f_w8;
                } else {
                    return (v_page)->f_w9;
                }
            } else {
                if ((_eri_order_382 = (v_offset), _eri_order_383 = (11), (_eri_order_382 < _eri_order_383))) {
                    return (v_page)->f_w10;
                } else {
                    return (v_page)->f_w11;
                }
            }
        } else {
            if ((_eri_order_384 = (v_offset), _eri_order_385 = (14), (_eri_order_384 < _eri_order_385))) {
                if ((_eri_order_386 = (v_offset), _eri_order_387 = (13), (_eri_order_386 < _eri_order_387))) {
                    return (v_page)->f_w12;
                } else {
                    return (v_page)->f_w13;
                }
            } else {
                if ((_eri_order_388 = (v_offset), _eri_order_389 = (15), (_eri_order_388 < _eri_order_389))) {
                    return (v_page)->f_w14;
                } else {
                    return (v_page)->f_w15;
                }
            }
        }
    }
}

static void fn_compiler_u002e_u1_words_u002e_writePage(eri_struct_compiler_u002e_u1_words_u002e_Page * v_page, int64_t v_offset, int64_t v_value) {
    int64_t _eri_order_390;
    int64_t _eri_order_391;
    int64_t _eri_order_392;
    int64_t _eri_order_393;
    int64_t _eri_order_394;
    int64_t _eri_order_395;
    int64_t _eri_order_396;
    int64_t _eri_order_397;
    int64_t _eri_order_398;
    int64_t _eri_order_399;
    int64_t _eri_order_400;
    int64_t _eri_order_401;
    int64_t _eri_order_402;
    int64_t _eri_order_403;
    int64_t _eri_order_404;
    int64_t _eri_order_405;
    int64_t _eri_order_406;
    int64_t _eri_order_407;
    int64_t _eri_order_408;
    int64_t _eri_order_409;
    int64_t _eri_order_410;
    int64_t _eri_order_411;
    int64_t _eri_order_412;
    int64_t _eri_order_413;
    int64_t _eri_order_414;
    int64_t _eri_order_415;
    int64_t _eri_order_416;
    int64_t _eri_order_417;
    int64_t _eri_order_418;
    int64_t _eri_order_419;
    if ((_eri_order_390 = (v_offset), _eri_order_391 = (8), (_eri_order_390 < _eri_order_391))) {
        if ((_eri_order_392 = (v_offset), _eri_order_393 = (4), (_eri_order_392 < _eri_order_393))) {
            if ((_eri_order_394 = (v_offset), _eri_order_395 = (2), (_eri_order_394 < _eri_order_395))) {
                if ((_eri_order_396 = (v_offset), _eri_order_397 = (1), (_eri_order_396 < _eri_order_397))) {
                    (v_page)->f_w0 = v_value;
                    return;
                } else {
                    (v_page)->f_w1 = v_value;
                    return;
                }
            } else {
                if ((_eri_order_398 = (v_offset), _eri_order_399 = (3), (_eri_order_398 < _eri_order_399))) {
                    (v_page)->f_w2 = v_value;
                    return;
                } else {
                    (v_page)->f_w3 = v_value;
                    return;
                }
            }
        } else {
            if ((_eri_order_400 = (v_offset), _eri_order_401 = (6), (_eri_order_400 < _eri_order_401))) {
                if ((_eri_order_402 = (v_offset), _eri_order_403 = (5), (_eri_order_402 < _eri_order_403))) {
                    (v_page)->f_w4 = v_value;
                    return;
                } else {
                    (v_page)->f_w5 = v_value;
                    return;
                }
            } else {
                if ((_eri_order_404 = (v_offset), _eri_order_405 = (7), (_eri_order_404 < _eri_order_405))) {
                    (v_page)->f_w6 = v_value;
                    return;
                } else {
                    (v_page)->f_w7 = v_value;
                    return;
                }
            }
        }
    } else {
        if ((_eri_order_406 = (v_offset), _eri_order_407 = (12), (_eri_order_406 < _eri_order_407))) {
            if ((_eri_order_408 = (v_offset), _eri_order_409 = (10), (_eri_order_408 < _eri_order_409))) {
                if ((_eri_order_410 = (v_offset), _eri_order_411 = (9), (_eri_order_410 < _eri_order_411))) {
                    (v_page)->f_w8 = v_value;
                    return;
                } else {
                    (v_page)->f_w9 = v_value;
                    return;
                }
            } else {
                if ((_eri_order_412 = (v_offset), _eri_order_413 = (11), (_eri_order_412 < _eri_order_413))) {
                    (v_page)->f_w10 = v_value;
                    return;
                } else {
                    (v_page)->f_w11 = v_value;
                    return;
                }
            }
        } else {
            if ((_eri_order_414 = (v_offset), _eri_order_415 = (14), (_eri_order_414 < _eri_order_415))) {
                if ((_eri_order_416 = (v_offset), _eri_order_417 = (13), (_eri_order_416 < _eri_order_417))) {
                    (v_page)->f_w12 = v_value;
                    return;
                } else {
                    (v_page)->f_w13 = v_value;
                    return;
                }
            } else {
                if ((_eri_order_418 = (v_offset), _eri_order_419 = (15), (_eri_order_418 < _eri_order_419))) {
                    (v_page)->f_w14 = v_value;
                    return;
                } else {
                    (v_page)->f_w15 = v_value;
                    return;
                }
            }
        }
    }
}

static eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node fn_compiler_u002e_u1_words_u002e_readChild(eri_struct_compiler_u002e_u1_words_u002e_Node * v_node, int64_t v_offset) {
    int64_t _eri_order_420;
    int64_t _eri_order_421;
    int64_t _eri_order_422;
    int64_t _eri_order_423;
    int64_t _eri_order_424;
    int64_t _eri_order_425;
    int64_t _eri_order_426;
    int64_t _eri_order_427;
    int64_t _eri_order_428;
    int64_t _eri_order_429;
    int64_t _eri_order_430;
    int64_t _eri_order_431;
    int64_t _eri_order_432;
    int64_t _eri_order_433;
    int64_t _eri_order_434;
    int64_t _eri_order_435;
    int64_t _eri_order_436;
    int64_t _eri_order_437;
    int64_t _eri_order_438;
    int64_t _eri_order_439;
    int64_t _eri_order_440;
    int64_t _eri_order_441;
    int64_t _eri_order_442;
    int64_t _eri_order_443;
    int64_t _eri_order_444;
    int64_t _eri_order_445;
    int64_t _eri_order_446;
    int64_t _eri_order_447;
    int64_t _eri_order_448;
    int64_t _eri_order_449;
    if ((_eri_order_420 = (v_offset), _eri_order_421 = (8), (_eri_order_420 < _eri_order_421))) {
        if ((_eri_order_422 = (v_offset), _eri_order_423 = (4), (_eri_order_422 < _eri_order_423))) {
            if ((_eri_order_424 = (v_offset), _eri_order_425 = (2), (_eri_order_424 < _eri_order_425))) {
                if ((_eri_order_426 = (v_offset), _eri_order_427 = (1), (_eri_order_426 < _eri_order_427))) {
                    return (v_node)->f_c0;
                } else {
                    return (v_node)->f_c1;
                }
            } else {
                if ((_eri_order_428 = (v_offset), _eri_order_429 = (3), (_eri_order_428 < _eri_order_429))) {
                    return (v_node)->f_c2;
                } else {
                    return (v_node)->f_c3;
                }
            }
        } else {
            if ((_eri_order_430 = (v_offset), _eri_order_431 = (6), (_eri_order_430 < _eri_order_431))) {
                if ((_eri_order_432 = (v_offset), _eri_order_433 = (5), (_eri_order_432 < _eri_order_433))) {
                    return (v_node)->f_c4;
                } else {
                    return (v_node)->f_c5;
                }
            } else {
                if ((_eri_order_434 = (v_offset), _eri_order_435 = (7), (_eri_order_434 < _eri_order_435))) {
                    return (v_node)->f_c6;
                } else {
                    return (v_node)->f_c7;
                }
            }
        }
    } else {
        if ((_eri_order_436 = (v_offset), _eri_order_437 = (12), (_eri_order_436 < _eri_order_437))) {
            if ((_eri_order_438 = (v_offset), _eri_order_439 = (10), (_eri_order_438 < _eri_order_439))) {
                if ((_eri_order_440 = (v_offset), _eri_order_441 = (9), (_eri_order_440 < _eri_order_441))) {
                    return (v_node)->f_c8;
                } else {
                    return (v_node)->f_c9;
                }
            } else {
                if ((_eri_order_442 = (v_offset), _eri_order_443 = (11), (_eri_order_442 < _eri_order_443))) {
                    return (v_node)->f_c10;
                } else {
                    return (v_node)->f_c11;
                }
            }
        } else {
            if ((_eri_order_444 = (v_offset), _eri_order_445 = (14), (_eri_order_444 < _eri_order_445))) {
                if ((_eri_order_446 = (v_offset), _eri_order_447 = (13), (_eri_order_446 < _eri_order_447))) {
                    return (v_node)->f_c12;
                } else {
                    return (v_node)->f_c13;
                }
            } else {
                if ((_eri_order_448 = (v_offset), _eri_order_449 = (15), (_eri_order_448 < _eri_order_449))) {
                    return (v_node)->f_c14;
                } else {
                    return (v_node)->f_c15;
                }
            }
        }
    }
}

static void fn_compiler_u002e_u1_words_u002e_writeChild(eri_struct_compiler_u002e_u1_words_u002e_Node * v_node, int64_t v_offset, eri_struct_compiler_u002e_u1_words_u002e_Node * v_value) {
    int64_t _eri_order_450;
    int64_t _eri_order_451;
    int64_t _eri_order_452;
    int64_t _eri_order_453;
    int64_t _eri_order_454;
    int64_t _eri_order_455;
    int64_t _eri_order_456;
    int64_t _eri_order_457;
    int64_t _eri_order_458;
    int64_t _eri_order_459;
    int64_t _eri_order_460;
    int64_t _eri_order_461;
    int64_t _eri_order_462;
    int64_t _eri_order_463;
    int64_t _eri_order_464;
    int64_t _eri_order_465;
    int64_t _eri_order_466;
    int64_t _eri_order_467;
    int64_t _eri_order_468;
    int64_t _eri_order_469;
    int64_t _eri_order_470;
    int64_t _eri_order_471;
    int64_t _eri_order_472;
    int64_t _eri_order_473;
    int64_t _eri_order_474;
    int64_t _eri_order_475;
    int64_t _eri_order_476;
    int64_t _eri_order_477;
    int64_t _eri_order_478;
    int64_t _eri_order_479;
    if ((_eri_order_450 = (v_offset), _eri_order_451 = (8), (_eri_order_450 < _eri_order_451))) {
        if ((_eri_order_452 = (v_offset), _eri_order_453 = (4), (_eri_order_452 < _eri_order_453))) {
            if ((_eri_order_454 = (v_offset), _eri_order_455 = (2), (_eri_order_454 < _eri_order_455))) {
                if ((_eri_order_456 = (v_offset), _eri_order_457 = (1), (_eri_order_456 < _eri_order_457))) {
                    (v_node)->f_c0 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                } else {
                    (v_node)->f_c1 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                }
            } else {
                if ((_eri_order_458 = (v_offset), _eri_order_459 = (3), (_eri_order_458 < _eri_order_459))) {
                    (v_node)->f_c2 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                } else {
                    (v_node)->f_c3 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                }
            }
        } else {
            if ((_eri_order_460 = (v_offset), _eri_order_461 = (6), (_eri_order_460 < _eri_order_461))) {
                if ((_eri_order_462 = (v_offset), _eri_order_463 = (5), (_eri_order_462 < _eri_order_463))) {
                    (v_node)->f_c4 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                } else {
                    (v_node)->f_c5 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                }
            } else {
                if ((_eri_order_464 = (v_offset), _eri_order_465 = (7), (_eri_order_464 < _eri_order_465))) {
                    (v_node)->f_c6 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                } else {
                    (v_node)->f_c7 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                }
            }
        }
    } else {
        if ((_eri_order_466 = (v_offset), _eri_order_467 = (12), (_eri_order_466 < _eri_order_467))) {
            if ((_eri_order_468 = (v_offset), _eri_order_469 = (10), (_eri_order_468 < _eri_order_469))) {
                if ((_eri_order_470 = (v_offset), _eri_order_471 = (9), (_eri_order_470 < _eri_order_471))) {
                    (v_node)->f_c8 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                } else {
                    (v_node)->f_c9 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                }
            } else {
                if ((_eri_order_472 = (v_offset), _eri_order_473 = (11), (_eri_order_472 < _eri_order_473))) {
                    (v_node)->f_c10 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                } else {
                    (v_node)->f_c11 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                }
            }
        } else {
            if ((_eri_order_474 = (v_offset), _eri_order_475 = (14), (_eri_order_474 < _eri_order_475))) {
                if ((_eri_order_476 = (v_offset), _eri_order_477 = (13), (_eri_order_476 < _eri_order_477))) {
                    (v_node)->f_c12 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                } else {
                    (v_node)->f_c13 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                }
            } else {
                if ((_eri_order_478 = (v_offset), _eri_order_479 = (15), (_eri_order_478 < _eri_order_479))) {
                    (v_node)->f_c14 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                } else {
                    (v_node)->f_c15 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_value};
                    return;
                }
            }
        }
    }
}

static eri_struct_compiler_u002e_u1_words_u002e_Page * fn_compiler_u002e_u1_words_u002e_pageAt(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_index, bool v_create) {
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_480;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_481;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_482;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_483;
    int64_t _eri_order_484;
    int64_t _eri_order_485;
    int64_t _eri_order_486;
    int64_t _eri_order_487;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_488;
    int64_t _eri_order_489;
    int64_t _eri_order_490;
    int64_t _eri_order_491;
    int64_t _eri_order_492;
    int64_t _eri_order_493;
    eri_struct_compiler_u002e_u1_words_u002e_Node * _eri_order_494;
    int64_t _eri_order_495;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_496;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_497;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_498;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_499;
    eri_struct_compiler_u002e_u1_words_u002e_Node * _eri_order_500;
    int64_t _eri_order_501;
    eri_struct_compiler_u002e_u1_words_u002e_Node * _eri_order_502;
    int64_t _eri_order_503;
    int64_t _eri_order_504;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page _eri_order_505;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page _eri_order_506;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_507;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_508;
    if ((v_create && (_eri_order_480 = ((v_words)->f_root), _eri_order_481 = ((eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}), eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(_eri_order_480, _eri_order_481)))) {
        (v_words)->f_root = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=(_eri_order_482 = ((v_words)->f_owner), _eri_order_483 = (v_phase), fn_compiler_u002e_u1_words_u002e_newNode(_eri_order_482, _eri_order_483))};
    }
    eri_struct_compiler_u002e_u1_words_u002e_Node * v_node = fn_compiler_u002e_u1_words_u002e_needNode((v_words)->f_root);
    int64_t v_divisor = 1048576;
    int64_t v_pageIndex = (_eri_order_484 = (v_index), _eri_order_485 = (16), eri_idiv(_eri_order_484, _eri_order_485));
    while ((_eri_order_486 = (v_divisor), _eri_order_487 = (1), (_eri_order_486 >= _eri_order_487))) {
        (_eri_order_488 = (v_phase), _eri_order_489 = (1), fn_compiler_u002e_u1_budget_u002e_work(_eri_order_488, _eri_order_489));
        int64_t v_offset = (_eri_order_492 = ((_eri_order_490 = (v_pageIndex), _eri_order_491 = (v_divisor), eri_idiv(_eri_order_490, _eri_order_491))), _eri_order_493 = (16), eri_irem(_eri_order_492, _eri_order_493));
        eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node v_next = (_eri_order_494 = (v_node), _eri_order_495 = (v_offset), fn_compiler_u002e_u1_words_u002e_readChild(_eri_order_494, _eri_order_495));
        if (((_eri_order_496 = (v_next), _eri_order_497 = ((eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}), eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(_eri_order_496, _eri_order_497)) && v_create)) {
            eri_struct_compiler_u002e_u1_words_u002e_Node * v_fresh = (_eri_order_498 = ((v_words)->f_owner), _eri_order_499 = (v_phase), fn_compiler_u002e_u1_words_u002e_newNode(_eri_order_498, _eri_order_499));
            (_eri_order_500 = (v_node), _eri_order_501 = (v_offset), _eri_order_502 = (v_fresh), fn_compiler_u002e_u1_words_u002e_writeChild(_eri_order_500, _eri_order_501, _eri_order_502));
            v_next = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=true,.value=v_fresh};
        }
        v_node = fn_compiler_u002e_u1_words_u002e_needNode(v_next);
        v_divisor = (_eri_order_503 = (v_divisor), _eri_order_504 = (16), eri_idiv(_eri_order_503, _eri_order_504));
    }
    if ((v_create && (_eri_order_505 = ((v_node)->f_page), _eri_order_506 = ((eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page){.has=false}), eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_eq(_eri_order_505, _eri_order_506)))) {
        (v_node)->f_page = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page){.has=true,.value=(_eri_order_507 = ((v_words)->f_owner), _eri_order_508 = (v_phase), fn_compiler_u002e_u1_words_u002e_newPage(_eri_order_507, _eri_order_508))};
    }
    return fn_compiler_u002e_u1_words_u002e_needPage((v_node)->f_page);
}

static int64_t fn_compiler_u002e_u1_words_u002e_get(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_index) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_509;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_510;
    bool _eri_order_511;
    int64_t _eri_order_512;
    int64_t _eri_order_513;
    int64_t _eri_order_514;
    int64_t _eri_order_515;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_516;
    int64_t _eri_order_517;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_518;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_519;
    int64_t _eri_order_520;
    bool _eri_order_521;
    eri_struct_compiler_u002e_u1_words_u002e_Page * _eri_order_522;
    int64_t _eri_order_523;
    int64_t _eri_order_524;
    int64_t _eri_order_525;
    (_eri_order_509 = (v_words), _eri_order_510 = (v_phase), _eri_order_511 = (false), fn_compiler_u002e_u1_words_u002e_context(_eri_order_509, _eri_order_510, _eri_order_511));
    if (((_eri_order_512 = (v_index), _eri_order_513 = (0), (_eri_order_512 < _eri_order_513)) || (_eri_order_514 = (v_index), _eri_order_515 = ((v_words)->f_length), (_eri_order_514 >= _eri_order_515)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x20, 0x6f, 0x75, 0x74, 0x20, 0x6f, 0x66, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 27));
    }
    (_eri_order_516 = (v_phase), _eri_order_517 = (1), fn_compiler_u002e_u1_budget_u002e_work(_eri_order_516, _eri_order_517));
    eri_struct_compiler_u002e_u1_words_u002e_Page * v_page = (_eri_order_518 = (v_words), _eri_order_519 = (v_phase), _eri_order_520 = (v_index), _eri_order_521 = (false), fn_compiler_u002e_u1_words_u002e_pageAt(_eri_order_518, _eri_order_519, _eri_order_520, _eri_order_521));
    return (_eri_order_522 = (v_page), _eri_order_525 = ((_eri_order_523 = (v_index), _eri_order_524 = (16), eri_irem(_eri_order_523, _eri_order_524))), fn_compiler_u002e_u1_words_u002e_readPage(_eri_order_522, _eri_order_525));
}

static void fn_compiler_u002e_u1_words_u002e_set(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_index, int64_t v_value) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_526;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_527;
    bool _eri_order_528;
    int64_t _eri_order_529;
    int64_t _eri_order_530;
    int64_t _eri_order_531;
    int64_t _eri_order_532;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_533;
    int64_t _eri_order_534;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_535;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_536;
    int64_t _eri_order_537;
    bool _eri_order_538;
    eri_struct_compiler_u002e_u1_words_u002e_Page * _eri_order_539;
    int64_t _eri_order_540;
    int64_t _eri_order_541;
    int64_t _eri_order_542;
    int64_t _eri_order_543;
    (_eri_order_526 = (v_words), _eri_order_527 = (v_phase), _eri_order_528 = (true), fn_compiler_u002e_u1_words_u002e_context(_eri_order_526, _eri_order_527, _eri_order_528));
    if (((_eri_order_529 = (v_index), _eri_order_530 = (0), (_eri_order_529 < _eri_order_530)) || (_eri_order_531 = (v_index), _eri_order_532 = ((v_words)->f_length), (_eri_order_531 >= _eri_order_532)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x20, 0x6f, 0x75, 0x74, 0x20, 0x6f, 0x66, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 27));
    }
    (_eri_order_533 = (v_phase), _eri_order_534 = (1), fn_compiler_u002e_u1_budget_u002e_work(_eri_order_533, _eri_order_534));
    eri_struct_compiler_u002e_u1_words_u002e_Page * v_page = (_eri_order_535 = (v_words), _eri_order_536 = (v_phase), _eri_order_537 = (v_index), _eri_order_538 = (false), fn_compiler_u002e_u1_words_u002e_pageAt(_eri_order_535, _eri_order_536, _eri_order_537, _eri_order_538));
    (_eri_order_539 = (v_page), _eri_order_542 = ((_eri_order_540 = (v_index), _eri_order_541 = (16), eri_irem(_eri_order_540, _eri_order_541))), _eri_order_543 = (v_value), fn_compiler_u002e_u1_words_u002e_writePage(_eri_order_539, _eri_order_542, _eri_order_543));
}

static int64_t fn_compiler_u002e_u1_words_u002e_push(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_value) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_544;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_545;
    bool _eri_order_546;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_547;
    int64_t _eri_order_548;
    int64_t _eri_order_549;
    int64_t _eri_order_550;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_551;
    int64_t _eri_order_552;
    int64_t _eri_order_553;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_554;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_555;
    int64_t _eri_order_556;
    bool _eri_order_557;
    eri_struct_compiler_u002e_u1_words_u002e_Page * _eri_order_558;
    int64_t _eri_order_559;
    int64_t _eri_order_560;
    int64_t _eri_order_561;
    int64_t _eri_order_562;
    int64_t _eri_order_563;
    int64_t _eri_order_564;
    (_eri_order_544 = (v_words), _eri_order_545 = (v_phase), _eri_order_546 = (true), fn_compiler_u002e_u1_words_u002e_context(_eri_order_544, _eri_order_545, _eri_order_546));
    (_eri_order_547 = (v_phase), _eri_order_548 = (1), fn_compiler_u002e_u1_budget_u002e_work(_eri_order_547, _eri_order_548));
    if ((_eri_order_549 = ((v_words)->f_length), _eri_order_550 = ((v_words)->f_limit), (_eri_order_549 >= _eri_order_550))) {
        (_eri_order_551 = ((v_words)->f_owner), _eri_order_552 = (1), _eri_order_553 = (0), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_551, _eri_order_552, _eri_order_553));
    }
    int64_t v_index = (v_words)->f_length;
    eri_struct_compiler_u002e_u1_words_u002e_Page * v_page = (_eri_order_554 = (v_words), _eri_order_555 = (v_phase), _eri_order_556 = (v_index), _eri_order_557 = (true), fn_compiler_u002e_u1_words_u002e_pageAt(_eri_order_554, _eri_order_555, _eri_order_556, _eri_order_557));
    (_eri_order_558 = (v_page), _eri_order_561 = ((_eri_order_559 = (v_index), _eri_order_560 = (16), eri_irem(_eri_order_559, _eri_order_560))), _eri_order_562 = (v_value), fn_compiler_u002e_u1_words_u002e_writePage(_eri_order_558, _eri_order_561, _eri_order_562));
    (v_words)->f_length = (_eri_order_563 = (v_index), _eri_order_564 = (1), eri_iadd(_eri_order_563, _eri_order_564));
    return v_index;
}

static void fn_compiler_u002e_u1_words_u002e_freeze(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words) {
    fn_compiler_u002e_u1_budget_u002e_poll((v_words)->f_owner);
    if ((v_words)->f_closed) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x63, 0x6c, 0x6f, 0x73, 0x65, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x73, 0x74, 0x6f, 0x72, 0x65}, 21));
    }
    (v_words)->f_frozen = true;
}

static void fn_compiler_u002e_u1_words_u002e_closeNode(eri_struct_compiler_u002e_u1_words_u002e_Node * v_node, int64_t v_depth) {
    int64_t _eri_order_565;
    int64_t _eri_order_566;
    int64_t _eri_order_567;
    int64_t _eri_order_568;
    eri_struct_compiler_u002e_u1_words_u002e_Node * _eri_order_569;
    int64_t _eri_order_570;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_571;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_572;
    eri_struct_compiler_u002e_u1_words_u002e_Node * _eri_order_573;
    int64_t _eri_order_574;
    int64_t _eri_order_575;
    int64_t _eri_order_576;
    int64_t _eri_order_577;
    int64_t _eri_order_578;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page _eri_order_579;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page _eri_order_580;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation _eri_order_581;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation _eri_order_582;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation _eri_order_583;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation _eri_order_584;
    int64_t v_offset = 0;
    if ((_eri_order_565 = (v_depth), _eri_order_566 = (0), (_eri_order_565 > _eri_order_566))) {
        while ((_eri_order_567 = (v_offset), _eri_order_568 = (16), (_eri_order_567 < _eri_order_568))) {
            eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node v_child = (_eri_order_569 = (v_node), _eri_order_570 = (v_offset), fn_compiler_u002e_u1_words_u002e_readChild(_eri_order_569, _eri_order_570));
            if ((_eri_order_571 = (v_child), _eri_order_572 = ((eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(_eri_order_571, _eri_order_572)))) {
                (_eri_order_573 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_get(v_child)), _eri_order_576 = ((_eri_order_574 = (v_depth), _eri_order_575 = (1), eri_isub(_eri_order_574, _eri_order_575))), fn_compiler_u002e_u1_words_u002e_closeNode(_eri_order_573, _eri_order_576));
            }
            v_offset = (_eri_order_577 = (v_offset), _eri_order_578 = (1), eri_iadd(_eri_order_577, _eri_order_578));
        }
    }
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page v_page = (v_node)->f_page;
    (v_node)->f_page = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page){.has=false};
    if ((_eri_order_579 = (v_page), _eri_order_580 = ((eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_eq(_eri_order_579, _eri_order_580)))) {
        eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation v_allocation = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Page_get(v_page))->f_charge;
        ((v_page).value)->f_charge = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false};
        if ((_eri_order_581 = (v_allocation), _eri_order_582 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(_eri_order_581, _eri_order_582)))) {
            fn_compiler_u002e_u1_budget_u002e_release(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_get(v_allocation));
        }
    }
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation v_allocation = (v_node)->f_charge;
    (v_node)->f_charge = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false};
    if ((_eri_order_583 = (v_allocation), _eri_order_584 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(_eri_order_583, _eri_order_584)))) {
        fn_compiler_u002e_u1_budget_u002e_release(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_get(v_allocation));
    }
}

static void fn_compiler_u002e_u1_words_u002e_close(eri_struct_compiler_u002e_u1_words_u002e_Words * v_words) {
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_585;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node _eri_order_586;
    eri_struct_compiler_u002e_u1_words_u002e_Node * _eri_order_587;
    int64_t _eri_order_588;
    if ((v_words)->f_closed) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x64, 0x6f, 0x75, 0x62, 0x6c, 0x65, 0x20, 0x63, 0x6c, 0x6f, 0x73, 0x65, 0x20, 0x6f, 0x66, 0x20, 0x55, 0x31, 0x61, 0x20, 0x77, 0x6f, 0x72, 0x64, 0x20, 0x73, 0x74, 0x6f, 0x72, 0x65}, 30));
    }
    (v_words)->f_closed = true;
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node v_root = (v_words)->f_root;
    (v_words)->f_root = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false};
    (v_words)->f_length = 0;
    if ((_eri_order_585 = (v_root), _eri_order_586 = ((eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_eq(_eri_order_585, _eri_order_586)))) {
        (_eri_order_587 = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node_get(v_root)), _eri_order_588 = (6), fn_compiler_u002e_u1_words_u002e_closeNode(_eri_order_587, _eri_order_588));
    }
    fn_compiler_u002e_u1_budget_u002e_release((v_words)->f_control);
}

static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_typeAt(int64_t v_index) {
    int64_t _eri_order_589;
    int64_t _eri_order_590;
    int64_t _eri_order_591;
    int64_t _eri_order_592;
    if (((_eri_order_589 = (v_index), _eri_order_590 = (1), (_eri_order_589 < _eri_order_590)) || (_eri_order_591 = (v_index), _eri_order_592 = (3), (_eri_order_591 > _eri_order_592)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x74, 0x79, 0x70, 0x65}, 20));
    }
    return (eri_struct_compiler_u002e_u1_meta_u002e_TypeId){.f_index = v_index};
}

static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_pred(void) {
    return (eri_struct_compiler_u002e_u1_meta_u002e_TypeId){.f_index = 1};
}

static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_i64(void) {
    return (eri_struct_compiler_u002e_u1_meta_u002e_TypeId){.f_index = 2};
}

static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_f64(void) {
    return (eri_struct_compiler_u002e_u1_meta_u002e_TypeId){.f_index = 3};
}

static void fn_compiler_u002e_u1_meta_u002e_validType(eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_value) {
    eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_checked = fn_compiler_u002e_u1_meta_u002e_typeAt((v_value).f_index);
}

static void fn_compiler_u002e_u1_meta_u002e_mutable(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_593;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_594;
    fn_compiler_u002e_u1_budget_u002e_poll((v_meta)->f_owner);
    if ((((v_meta)->f_closed || (v_meta)->f_frozen) || (_eri_order_593 = ((v_phase)->f_owner), _eri_order_594 = ((v_meta)->f_owner), (!(_eri_order_593 == _eri_order_594))))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6d, 0x6d, 0x75, 0x74, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x6f, 0x72, 0x20, 0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x55, 0x31, 0x61, 0x20, 0x6d, 0x65, 0x74, 0x61, 0x64, 0x61, 0x74, 0x61}, 33));
    }
}

static eri_struct_compiler_u002e_u1_meta_u002e_Metadata * fn_compiler_u002e_u1_meta_u002e_create(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    int64_t _eri_order_595;
    int64_t _eri_order_596;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_597;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_598;
    int64_t _eri_order_599;
    int64_t _eri_order_600;
    int64_t _eri_order_601;
    int64_t _eri_order_602;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_603;
    int64_t _eri_order_604;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_605;
    int64_t _eri_order_606;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_607;
    int64_t _eri_order_608;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_609;
    int64_t _eri_order_610;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_611;
    int64_t _eri_order_612;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_613;
    int64_t _eri_order_614;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_615;
    int64_t _eri_order_616;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_617;
    int64_t _eri_order_618;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_619;
    int64_t _eri_order_620;
    int64_t _eri_order_621;
    int64_t _eri_order_622;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_623;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_624;
    int64_t _eri_order_625;
    int64_t _eri_order_626;
    int64_t _eri_order_627;
    if (((((_eri_order_595 = ((v_owner)->f_kind), _eri_order_596 = (1), (_eri_order_595 != _eri_order_596)) || (_eri_order_597 = ((v_phase)->f_owner), _eri_order_598 = (v_owner), (!(_eri_order_597 == _eri_order_598)))) || (_eri_order_599 = ((v_phase)->f_used), _eri_order_600 = (0), (_eri_order_599 != _eri_order_600))) || (_eri_order_601 = ((v_phase)->f_prepaid), _eri_order_602 = (0), (_eri_order_601 != _eri_order_602)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x6d, 0x65, 0x74, 0x61, 0x64, 0x61, 0x74, 0x61, 0x20, 0x72, 0x65, 0x71, 0x75, 0x69, 0x72, 0x65, 0x73, 0x20, 0x61, 0x20, 0x66, 0x72, 0x65, 0x73, 0x68, 0x20, 0x73, 0x68, 0x61, 0x72, 0x65, 0x64, 0x20, 0x70, 0x68, 0x61, 0x73, 0x65}, 38));
    }
    eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_preflight = (_eri_order_603 = (v_owner), _eri_order_604 = (16384), fn_compiler_u002e_u1_budget_u002e_reserve(_eri_order_603, _eri_order_604));
    fn_compiler_u002e_u1_budget_u002e_cancelReservation(v_preflight);
    (_eri_order_605 = (v_phase), _eri_order_606 = (1024), fn_compiler_u002e_u1_budget_u002e_prepay(_eri_order_605, _eri_order_606));
    eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_pending = (_eri_order_607 = (v_owner), _eri_order_608 = (768), fn_compiler_u002e_u1_budget_u002e_reserve(_eri_order_607, _eri_order_608));
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta = eri_identity_compiler_u002e_u1_meta_u002e_Metadata_new((eri_struct_compiler_u002e_u1_meta_u002e_Metadata){.f_key = eri_identity_compiler_u002e_u1_meta_u002e_Key_new((eri_struct_compiler_u002e_u1_meta_u002e_Key){.f_marker = 0}), .f_owner = v_owner, .f_frozen = false, .f_closed = false, .f_control = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false}, .f_signatures = (_eri_order_609 = (v_owner), _eri_order_610 = (6291456), fn_compiler_u002e_u1_words_u002e_create(_eri_order_609, _eri_order_610)), .f_types = (_eri_order_611 = (v_owner), _eri_order_612 = (8388608), fn_compiler_u002e_u1_words_u002e_create(_eri_order_611, _eri_order_612)), .f_buckets = (_eri_order_613 = (v_owner), _eri_order_614 = (64), fn_compiler_u002e_u1_words_u002e_create(_eri_order_613, _eri_order_614)), .f_sources = (_eri_order_615 = (v_owner), _eri_order_616 = (524288), fn_compiler_u002e_u1_words_u002e_create(_eri_order_615, _eri_order_616)), .f_bytes = (_eri_order_617 = (v_owner), _eri_order_618 = (8388608), fn_compiler_u002e_u1_words_u002e_create(_eri_order_617, _eri_order_618)), .f_locations = (_eri_order_619 = (v_owner), _eri_order_620 = (7340032), fn_compiler_u002e_u1_words_u002e_create(_eri_order_619, _eri_order_620))});
    int64_t v_index = 0;
    while ((_eri_order_621 = (v_index), _eri_order_622 = (64), (_eri_order_621 < _eri_order_622))) {
        int64_t v_ignored = (_eri_order_623 = ((v_meta)->f_buckets), _eri_order_624 = (v_phase), _eri_order_625 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_623, _eri_order_624, _eri_order_625));
        v_index = (_eri_order_626 = (v_index), _eri_order_627 = (1), eri_iadd(_eri_order_626, _eri_order_627));
    }
    (v_meta)->f_control = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=true,.value=fn_compiler_u002e_u1_budget_u002e_commit(v_pending)};
    return v_meta;
}

static int64_t fn_compiler_u002e_u1_meta_u002e_signatureIndex(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value) {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_628;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_629;
    int64_t _eri_order_630;
    int64_t _eri_order_631;
    int64_t _eri_order_632;
    int64_t _eri_order_633;
    int64_t _eri_order_634;
    int64_t _eri_order_635;
    int64_t _eri_order_636;
    int64_t _eri_order_637;
    int64_t _eri_order_638;
    int64_t _eri_order_639;
    if (((((v_meta)->f_closed || (_eri_order_628 = ((v_value).f_owner), _eri_order_629 = ((v_meta)->f_key), (!(_eri_order_628 == _eri_order_629)))) || (_eri_order_630 = ((v_value).f_index), _eri_order_631 = (1), (_eri_order_630 < _eri_order_631))) || (_eri_order_632 = ((v_value).f_index), _eri_order_635 = ((_eri_order_633 = (((v_meta)->f_signatures)->f_length), _eri_order_634 = (6), eri_idiv(_eri_order_633, _eri_order_634))), (_eri_order_632 > _eri_order_635)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x53, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x49, 0x64}, 34));
    }
    return (_eri_order_638 = ((_eri_order_636 = ((v_value).f_index), _eri_order_637 = (1), eri_isub(_eri_order_636, _eri_order_637))), _eri_order_639 = (6), eri_imul(_eri_order_638, _eri_order_639));
}

static int64_t fn_compiler_u002e_u1_meta_u002e_parameterCount(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value) {
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_640;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_641;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_642;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_643;
    int64_t _eri_order_644;
    int64_t _eri_order_645;
    int64_t _eri_order_646;
    int64_t v_offset = (_eri_order_640 = (v_meta), _eri_order_641 = (v_value), fn_compiler_u002e_u1_meta_u002e_signatureIndex(_eri_order_640, _eri_order_641));
    return (_eri_order_642 = ((v_meta)->f_signatures), _eri_order_643 = (v_phase), _eri_order_646 = ((_eri_order_644 = (v_offset), _eri_order_645 = (3), eri_iadd(_eri_order_644, _eri_order_645))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_642, _eri_order_643, _eri_order_646));
}

static int64_t fn_compiler_u002e_u1_meta_u002e_resultCount(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value) {
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_647;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_648;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_649;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_650;
    int64_t _eri_order_651;
    int64_t _eri_order_652;
    int64_t _eri_order_653;
    int64_t v_offset = (_eri_order_647 = (v_meta), _eri_order_648 = (v_value), fn_compiler_u002e_u1_meta_u002e_signatureIndex(_eri_order_647, _eri_order_648));
    return (_eri_order_649 = ((v_meta)->f_signatures), _eri_order_650 = (v_phase), _eri_order_653 = ((_eri_order_651 = (v_offset), _eri_order_652 = (5), eri_iadd(_eri_order_651, _eri_order_652))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_649, _eri_order_650, _eri_order_653));
}

static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_parameterType(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value, int64_t v_index) {
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_654;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_655;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_656;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_657;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_658;
    int64_t _eri_order_659;
    int64_t _eri_order_660;
    int64_t _eri_order_661;
    int64_t _eri_order_662;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_663;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_664;
    int64_t _eri_order_665;
    int64_t _eri_order_666;
    int64_t _eri_order_667;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_668;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_669;
    int64_t _eri_order_670;
    int64_t _eri_order_671;
    int64_t _eri_order_672;
    int64_t v_offset = (_eri_order_654 = (v_meta), _eri_order_655 = (v_value), fn_compiler_u002e_u1_meta_u002e_signatureIndex(_eri_order_654, _eri_order_655));
    int64_t v_count = (_eri_order_656 = (v_meta), _eri_order_657 = (v_phase), _eri_order_658 = (v_value), fn_compiler_u002e_u1_meta_u002e_parameterCount(_eri_order_656, _eri_order_657, _eri_order_658));
    if (((_eri_order_659 = (v_index), _eri_order_660 = (0), (_eri_order_659 < _eri_order_660)) || (_eri_order_661 = (v_index), _eri_order_662 = (v_count), (_eri_order_661 >= _eri_order_662)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x65, 0x74, 0x65, 0x72, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x20, 0x6f, 0x75, 0x74, 0x20, 0x6f, 0x66, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 32));
    }
    int64_t v_first = (_eri_order_663 = ((v_meta)->f_signatures), _eri_order_664 = (v_phase), _eri_order_667 = ((_eri_order_665 = (v_offset), _eri_order_666 = (2), eri_iadd(_eri_order_665, _eri_order_666))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_663, _eri_order_664, _eri_order_667));
    return fn_compiler_u002e_u1_meta_u002e_typeAt((_eri_order_668 = ((v_meta)->f_types), _eri_order_669 = (v_phase), _eri_order_672 = ((_eri_order_670 = (v_first), _eri_order_671 = (v_index), eri_iadd(_eri_order_670, _eri_order_671))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_668, _eri_order_669, _eri_order_672)));
}

static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_meta_u002e_resultType(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value, int64_t v_index) {
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_673;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_674;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_675;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_676;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_677;
    int64_t _eri_order_678;
    int64_t _eri_order_679;
    int64_t _eri_order_680;
    int64_t _eri_order_681;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_682;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_683;
    int64_t _eri_order_684;
    int64_t _eri_order_685;
    int64_t _eri_order_686;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_687;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_688;
    int64_t _eri_order_689;
    int64_t _eri_order_690;
    int64_t _eri_order_691;
    int64_t v_offset = (_eri_order_673 = (v_meta), _eri_order_674 = (v_value), fn_compiler_u002e_u1_meta_u002e_signatureIndex(_eri_order_673, _eri_order_674));
    int64_t v_count = (_eri_order_675 = (v_meta), _eri_order_676 = (v_phase), _eri_order_677 = (v_value), fn_compiler_u002e_u1_meta_u002e_resultCount(_eri_order_675, _eri_order_676, _eri_order_677));
    if (((_eri_order_678 = (v_index), _eri_order_679 = (0), (_eri_order_678 < _eri_order_679)) || (_eri_order_680 = (v_index), _eri_order_681 = (v_count), (_eri_order_680 >= _eri_order_681)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x20, 0x6f, 0x75, 0x74, 0x20, 0x6f, 0x66, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 29));
    }
    int64_t v_first = (_eri_order_682 = ((v_meta)->f_signatures), _eri_order_683 = (v_phase), _eri_order_686 = ((_eri_order_684 = (v_offset), _eri_order_685 = (4), eri_iadd(_eri_order_684, _eri_order_685))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_682, _eri_order_683, _eri_order_686));
    return fn_compiler_u002e_u1_meta_u002e_typeAt((_eri_order_687 = ((v_meta)->f_types), _eri_order_688 = (v_phase), _eri_order_691 = ((_eri_order_689 = (v_first), _eri_order_690 = (v_index), eri_iadd(_eri_order_689, _eri_order_690))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_687, _eri_order_688, _eri_order_691)));
}

static int64_t fn_compiler_u002e_u1_meta_u002e_sequenceHash_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_Int(eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_values, int64_t v_seed) {
    int64_t _eri_order_692;
    int64_t _eri_order_693;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_694;
    int64_t _eri_order_695;
    int64_t _eri_order_696;
    int64_t _eri_order_697;
    int64_t _eri_order_698;
    int64_t _eri_order_699;
    int64_t _eri_order_700;
    int64_t _eri_order_701;
    int64_t _eri_order_702;
    int64_t _eri_order_703;
    int64_t _eri_order_704;
    int64_t _eri_order_705;
    int64_t _eri_order_706;
    int64_t _eri_order_707;
    int64_t _eri_order_708;
    int64_t _eri_order_709;
    int64_t v_hash = v_seed;
    int64_t v_index = 0;
    while ((_eri_order_692 = (v_index), _eri_order_693 = (((int64_t)(v_values).count)), (_eri_order_692 < _eri_order_693))) {
        (_eri_order_694 = (v_phase), _eri_order_695 = (1), fn_compiler_u002e_u1_budget_u002e_work(_eri_order_694, _eri_order_695));
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_value = eri_list_compiler_u002e_u1_meta_u002e_TypeId_get(v_values, v_index);
        fn_compiler_u002e_u1_meta_u002e_validType(v_value);
        v_hash = (_eri_order_700 = ((_eri_order_698 = ((_eri_order_696 = (v_hash), _eri_order_697 = (131), eri_imul(_eri_order_696, _eri_order_697))), _eri_order_699 = ((v_value).f_index), eri_iadd(_eri_order_698, _eri_order_699))), _eri_order_701 = (2147483629), eri_irem(_eri_order_700, _eri_order_701));
        v_index = (_eri_order_702 = (v_index), _eri_order_703 = (1), eri_iadd(_eri_order_702, _eri_order_703));
    }
    return (_eri_order_708 = ((_eri_order_706 = ((_eri_order_704 = (v_hash), _eri_order_705 = (131), eri_imul(_eri_order_704, _eri_order_705))), _eri_order_707 = (((int64_t)(v_values).count)), eri_iadd(_eri_order_706, _eri_order_707))), _eri_order_709 = (2147483629), eri_irem(_eri_order_708, _eri_order_709));
}

static bool fn_compiler_u002e_u1_meta_u002e_sameTypes_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_first, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_values) {
    int64_t _eri_order_710;
    int64_t _eri_order_711;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_712;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_713;
    int64_t _eri_order_714;
    int64_t _eri_order_715;
    int64_t _eri_order_716;
    int64_t _eri_order_717;
    int64_t _eri_order_718;
    int64_t _eri_order_719;
    int64_t _eri_order_720;
    int64_t v_index = 0;
    while ((_eri_order_710 = (v_index), _eri_order_711 = (((int64_t)(v_values).count)), (_eri_order_710 < _eri_order_711))) {
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_value = eri_list_compiler_u002e_u1_meta_u002e_TypeId_get(v_values, v_index);
        fn_compiler_u002e_u1_meta_u002e_validType(v_value);
        if ((_eri_order_717 = ((_eri_order_712 = ((v_meta)->f_types), _eri_order_713 = (v_phase), _eri_order_716 = ((_eri_order_714 = (v_first), _eri_order_715 = (v_index), eri_iadd(_eri_order_714, _eri_order_715))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_712, _eri_order_713, _eri_order_716))), _eri_order_718 = ((v_value).f_index), (_eri_order_717 != _eri_order_718))) {
            return false;
        }
        v_index = (_eri_order_719 = (v_index), _eri_order_720 = (1), eri_iadd(_eri_order_719, _eri_order_720));
    }
    return true;
}

static eri_struct_compiler_u002e_u1_meta_u002e_SignatureId fn_compiler_u002e_u1_meta_u002e_signature_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_parameters, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_results) {
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_721;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_722;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_723;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_724;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_725;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_726;
    int64_t _eri_order_727;
    int64_t _eri_order_728;
    int64_t _eri_order_729;
    int64_t _eri_order_730;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_731;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_732;
    int64_t _eri_order_733;
    int64_t _eri_order_734;
    int64_t _eri_order_735;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_736;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_737;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_738;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_739;
    int64_t _eri_order_740;
    int64_t _eri_order_741;
    int64_t _eri_order_742;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_743;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_744;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_745;
    int64_t _eri_order_746;
    int64_t _eri_order_747;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_748;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_749;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_750;
    int64_t _eri_order_751;
    int64_t _eri_order_752;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_753;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_754;
    int64_t _eri_order_755;
    int64_t _eri_order_756;
    int64_t _eri_order_757;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_758;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_759;
    int64_t _eri_order_760;
    int64_t _eri_order_761;
    int64_t _eri_order_762;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_763;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_764;
    int64_t _eri_order_765;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_766;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_767;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_768;
    int64_t _eri_order_769;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_770;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_771;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_772;
    int64_t _eri_order_773;
    int64_t _eri_order_774;
    int64_t _eri_order_775;
    int64_t _eri_order_776;
    int64_t _eri_order_777;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_778;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_779;
    int64_t _eri_order_780;
    int64_t _eri_order_781;
    int64_t _eri_order_782;
    int64_t _eri_order_783;
    int64_t _eri_order_784;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_785;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_786;
    int64_t _eri_order_787;
    int64_t _eri_order_788;
    int64_t _eri_order_789;
    int64_t _eri_order_790;
    int64_t _eri_order_791;
    int64_t _eri_order_792;
    int64_t _eri_order_793;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_794;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_795;
    int64_t _eri_order_796;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_797;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_798;
    int64_t _eri_order_799;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_800;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_801;
    int64_t _eri_order_802;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_803;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_804;
    int64_t _eri_order_805;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_806;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_807;
    int64_t _eri_order_808;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_809;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_810;
    int64_t _eri_order_811;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_812;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_813;
    int64_t _eri_order_814;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_815;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_816;
    int64_t _eri_order_817;
    int64_t _eri_order_818;
    (_eri_order_721 = (v_meta), _eri_order_722 = (v_phase), fn_compiler_u002e_u1_meta_u002e_mutable(_eri_order_721, _eri_order_722));
    int64_t v_hash = (_eri_order_723 = (v_phase), _eri_order_724 = (v_results), _eri_order_728 = ((_eri_order_725 = (v_phase), _eri_order_726 = (v_parameters), _eri_order_727 = (17), fn_compiler_u002e_u1_meta_u002e_sequenceHash_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_Int(_eri_order_725, _eri_order_726, _eri_order_727))), fn_compiler_u002e_u1_meta_u002e_sequenceHash_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_Int(_eri_order_723, _eri_order_724, _eri_order_728));
    int64_t v_bucket = (_eri_order_729 = (v_hash), _eri_order_730 = (64), eri_irem(_eri_order_729, _eri_order_730));
    int64_t v_cursor = (_eri_order_731 = ((v_meta)->f_buckets), _eri_order_732 = (v_phase), _eri_order_733 = (v_bucket), fn_compiler_u002e_u1_words_u002e_get(_eri_order_731, _eri_order_732, _eri_order_733));
    while ((_eri_order_734 = (v_cursor), _eri_order_735 = (0), (_eri_order_734 != _eri_order_735))) {
        eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value = (eri_struct_compiler_u002e_u1_meta_u002e_SignatureId){.f_owner = (v_meta)->f_key, .f_index = v_cursor};
        int64_t v_offset = (_eri_order_736 = (v_meta), _eri_order_737 = (v_value), fn_compiler_u002e_u1_meta_u002e_signatureIndex(_eri_order_736, _eri_order_737));
        if ((_eri_order_741 = ((_eri_order_738 = ((v_meta)->f_signatures), _eri_order_739 = (v_phase), _eri_order_740 = (v_offset), fn_compiler_u002e_u1_words_u002e_get(_eri_order_738, _eri_order_739, _eri_order_740))), _eri_order_742 = (v_hash), (_eri_order_741 == _eri_order_742))) {
            if (((_eri_order_746 = ((_eri_order_743 = (v_meta), _eri_order_744 = (v_phase), _eri_order_745 = (v_value), fn_compiler_u002e_u1_meta_u002e_parameterCount(_eri_order_743, _eri_order_744, _eri_order_745))), _eri_order_747 = (((int64_t)(v_parameters).count)), (_eri_order_746 == _eri_order_747)) && (_eri_order_751 = ((_eri_order_748 = (v_meta), _eri_order_749 = (v_phase), _eri_order_750 = (v_value), fn_compiler_u002e_u1_meta_u002e_resultCount(_eri_order_748, _eri_order_749, _eri_order_750))), _eri_order_752 = (((int64_t)(v_results).count)), (_eri_order_751 == _eri_order_752)))) {
                int64_t v_first = (_eri_order_753 = ((v_meta)->f_signatures), _eri_order_754 = (v_phase), _eri_order_757 = ((_eri_order_755 = (v_offset), _eri_order_756 = (2), eri_iadd(_eri_order_755, _eri_order_756))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_753, _eri_order_754, _eri_order_757));
                int64_t v_second = (_eri_order_758 = ((v_meta)->f_signatures), _eri_order_759 = (v_phase), _eri_order_762 = ((_eri_order_760 = (v_offset), _eri_order_761 = (4), eri_iadd(_eri_order_760, _eri_order_761))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_758, _eri_order_759, _eri_order_762));
                if (((_eri_order_763 = (v_meta), _eri_order_764 = (v_phase), _eri_order_765 = (v_first), _eri_order_766 = (v_parameters), fn_compiler_u002e_u1_meta_u002e_sameTypes_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_763, _eri_order_764, _eri_order_765, _eri_order_766)) && (_eri_order_767 = (v_meta), _eri_order_768 = (v_phase), _eri_order_769 = (v_second), _eri_order_770 = (v_results), fn_compiler_u002e_u1_meta_u002e_sameTypes_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_767, _eri_order_768, _eri_order_769, _eri_order_770)))) {
                    return v_value;
                }
            }
        }
        v_cursor = (_eri_order_771 = ((v_meta)->f_signatures), _eri_order_772 = (v_phase), _eri_order_775 = ((_eri_order_773 = (v_offset), _eri_order_774 = (1), eri_iadd(_eri_order_773, _eri_order_774))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_771, _eri_order_772, _eri_order_775));
    }
    int64_t v_parameterStart = ((v_meta)->f_types)->f_length;
    int64_t v_index = 0;
    while ((_eri_order_776 = (v_index), _eri_order_777 = (((int64_t)(v_parameters).count)), (_eri_order_776 < _eri_order_777))) {
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_value = eri_list_compiler_u002e_u1_meta_u002e_TypeId_get(v_parameters, v_index);
        fn_compiler_u002e_u1_meta_u002e_validType(v_value);
        int64_t v_ignored = (_eri_order_778 = ((v_meta)->f_types), _eri_order_779 = (v_phase), _eri_order_780 = ((v_value).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_778, _eri_order_779, _eri_order_780));
        v_index = (_eri_order_781 = (v_index), _eri_order_782 = (1), eri_iadd(_eri_order_781, _eri_order_782));
    }
    int64_t v_resultStart = ((v_meta)->f_types)->f_length;
    v_index = 0;
    while ((_eri_order_783 = (v_index), _eri_order_784 = (((int64_t)(v_results).count)), (_eri_order_783 < _eri_order_784))) {
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_value = eri_list_compiler_u002e_u1_meta_u002e_TypeId_get(v_results, v_index);
        fn_compiler_u002e_u1_meta_u002e_validType(v_value);
        int64_t v_ignored = (_eri_order_785 = ((v_meta)->f_types), _eri_order_786 = (v_phase), _eri_order_787 = ((v_value).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_785, _eri_order_786, _eri_order_787));
        v_index = (_eri_order_788 = (v_index), _eri_order_789 = (1), eri_iadd(_eri_order_788, _eri_order_789));
    }
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_value = (eri_struct_compiler_u002e_u1_meta_u002e_SignatureId){.f_owner = (v_meta)->f_key, .f_index = (_eri_order_792 = ((_eri_order_790 = (((v_meta)->f_signatures)->f_length), _eri_order_791 = (6), eri_idiv(_eri_order_790, _eri_order_791))), _eri_order_793 = (1), eri_iadd(_eri_order_792, _eri_order_793))};
    int64_t v_previous = (_eri_order_794 = ((v_meta)->f_buckets), _eri_order_795 = (v_phase), _eri_order_796 = (v_bucket), fn_compiler_u002e_u1_words_u002e_get(_eri_order_794, _eri_order_795, _eri_order_796));
    int64_t v_ignored = (_eri_order_797 = ((v_meta)->f_signatures), _eri_order_798 = (v_phase), _eri_order_799 = (v_hash), fn_compiler_u002e_u1_words_u002e_push(_eri_order_797, _eri_order_798, _eri_order_799));
    v_ignored = (_eri_order_800 = ((v_meta)->f_signatures), _eri_order_801 = (v_phase), _eri_order_802 = (v_previous), fn_compiler_u002e_u1_words_u002e_push(_eri_order_800, _eri_order_801, _eri_order_802));
    v_ignored = (_eri_order_803 = ((v_meta)->f_signatures), _eri_order_804 = (v_phase), _eri_order_805 = (v_parameterStart), fn_compiler_u002e_u1_words_u002e_push(_eri_order_803, _eri_order_804, _eri_order_805));
    v_ignored = (_eri_order_806 = ((v_meta)->f_signatures), _eri_order_807 = (v_phase), _eri_order_808 = (((int64_t)(v_parameters).count)), fn_compiler_u002e_u1_words_u002e_push(_eri_order_806, _eri_order_807, _eri_order_808));
    v_ignored = (_eri_order_809 = ((v_meta)->f_signatures), _eri_order_810 = (v_phase), _eri_order_811 = (v_resultStart), fn_compiler_u002e_u1_words_u002e_push(_eri_order_809, _eri_order_810, _eri_order_811));
    v_ignored = (_eri_order_812 = ((v_meta)->f_signatures), _eri_order_813 = (v_phase), _eri_order_814 = (((int64_t)(v_results).count)), fn_compiler_u002e_u1_words_u002e_push(_eri_order_812, _eri_order_813, _eri_order_814));
    (_eri_order_815 = ((v_meta)->f_buckets), _eri_order_816 = (v_phase), _eri_order_817 = (v_bucket), _eri_order_818 = ((v_value).f_index), fn_compiler_u002e_u1_words_u002e_set(_eri_order_815, _eri_order_816, _eri_order_817, _eri_order_818));
    return v_value;
}

static int64_t fn_compiler_u002e_u1_meta_u002e_appendBytes(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_text v_value) {
    int64_t _eri_order_819;
    int64_t _eri_order_820;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_821;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_822;
    int64_t _eri_order_823;
    int64_t _eri_order_824;
    int64_t _eri_order_825;
    int64_t v_first = ((v_meta)->f_bytes)->f_length;
    int64_t v_index = 0;
    while ((_eri_order_819 = (v_index), _eri_order_820 = (eri_text_view_count(eri_text_view_make(v_value, ERI_TEXT_VIEW_BYTES))), (_eri_order_819 < _eri_order_820))) {
        int64_t v_ignored = (_eri_order_821 = ((v_meta)->f_bytes), _eri_order_822 = (v_phase), _eri_order_823 = (eri_text_view_byte_get(eri_text_view_make(v_value, ERI_TEXT_VIEW_BYTES), v_index)), fn_compiler_u002e_u1_words_u002e_push(_eri_order_821, _eri_order_822, _eri_order_823));
        v_index = (_eri_order_824 = (v_index), _eri_order_825 = (1), eri_iadd(_eri_order_824, _eri_order_825));
    }
    return v_first;
}

static bool fn_compiler_u002e_u1_meta_u002e_sameBytes(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_first, int64_t v_count, eri_text v_value) {
    int64_t _eri_order_826;
    int64_t _eri_order_827;
    int64_t _eri_order_828;
    int64_t _eri_order_829;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_830;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_831;
    int64_t _eri_order_832;
    int64_t _eri_order_833;
    int64_t _eri_order_834;
    int64_t _eri_order_835;
    int64_t _eri_order_836;
    int64_t _eri_order_837;
    int64_t _eri_order_838;
    if ((_eri_order_826 = (v_count), _eri_order_827 = (eri_text_view_count(eri_text_view_make(v_value, ERI_TEXT_VIEW_BYTES))), (_eri_order_826 != _eri_order_827))) {
        return false;
    }
    int64_t v_index = 0;
    while ((_eri_order_828 = (v_index), _eri_order_829 = (v_count), (_eri_order_828 < _eri_order_829))) {
        if ((_eri_order_835 = ((_eri_order_830 = ((v_meta)->f_bytes), _eri_order_831 = (v_phase), _eri_order_834 = ((_eri_order_832 = (v_first), _eri_order_833 = (v_index), eri_iadd(_eri_order_832, _eri_order_833))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_830, _eri_order_831, _eri_order_834))), _eri_order_836 = (eri_text_view_byte_get(eri_text_view_make(v_value, ERI_TEXT_VIEW_BYTES), v_index)), (_eri_order_835 != _eri_order_836))) {
            return false;
        }
        v_index = (_eri_order_837 = (v_index), _eri_order_838 = (1), eri_iadd(_eri_order_837, _eri_order_838));
    }
    return true;
}

static eri_struct_compiler_u002e_u1_meta_u002e_SourceId fn_compiler_u002e_u1_meta_u002e_source(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_text v_name, eri_text v_digest, int64_t v_length) {
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_839;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_840;
    int64_t _eri_order_841;
    int64_t _eri_order_842;
    int64_t _eri_order_843;
    int64_t _eri_order_844;
    int64_t _eri_order_845;
    int64_t _eri_order_846;
    int64_t _eri_order_847;
    int64_t _eri_order_848;
    int64_t _eri_order_849;
    int64_t _eri_order_850;
    int64_t _eri_order_851;
    int64_t _eri_order_852;
    int64_t _eri_order_853;
    int64_t _eri_order_854;
    int64_t _eri_order_855;
    int64_t _eri_order_856;
    int64_t _eri_order_857;
    int64_t _eri_order_858;
    int64_t _eri_order_859;
    int64_t _eri_order_860;
    int64_t _eri_order_861;
    int64_t _eri_order_862;
    int64_t _eri_order_863;
    int64_t _eri_order_864;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_865;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_866;
    int64_t _eri_order_867;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_868;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_869;
    int64_t _eri_order_870;
    int64_t _eri_order_871;
    int64_t _eri_order_872;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_873;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_874;
    int64_t _eri_order_875;
    int64_t _eri_order_876;
    eri_text _eri_order_877;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_878;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_879;
    int64_t _eri_order_880;
    int64_t _eri_order_881;
    int64_t _eri_order_882;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_883;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_884;
    int64_t _eri_order_885;
    int64_t _eri_order_886;
    eri_text _eri_order_887;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_888;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_889;
    int64_t _eri_order_890;
    int64_t _eri_order_891;
    int64_t _eri_order_892;
    int64_t _eri_order_893;
    int64_t _eri_order_894;
    int64_t _eri_order_895;
    int64_t _eri_order_896;
    int64_t _eri_order_897;
    int64_t _eri_order_898;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_899;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_900;
    eri_text _eri_order_901;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_902;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_903;
    eri_text _eri_order_904;
    int64_t _eri_order_905;
    int64_t _eri_order_906;
    int64_t _eri_order_907;
    int64_t _eri_order_908;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_909;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_910;
    int64_t _eri_order_911;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_912;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_913;
    int64_t _eri_order_914;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_915;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_916;
    int64_t _eri_order_917;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_918;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_919;
    int64_t _eri_order_920;
    (_eri_order_839 = (v_meta), _eri_order_840 = (v_phase), fn_compiler_u002e_u1_meta_u002e_mutable(_eri_order_839, _eri_order_840));
    if ((((_eri_order_841 = (eri_text_view_count(eri_text_view_make(v_name, ERI_TEXT_VIEW_BYTES))), _eri_order_842 = (0), (_eri_order_841 == _eri_order_842)) || (_eri_order_843 = (eri_text_view_count(eri_text_view_make(v_digest, ERI_TEXT_VIEW_BYTES))), _eri_order_844 = (64), (_eri_order_843 != _eri_order_844))) || (_eri_order_845 = (v_length), _eri_order_846 = (0), (_eri_order_845 < _eri_order_846)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x69, 0x64, 0x65, 0x6e, 0x74, 0x69, 0x74, 0x79}, 27));
    }
    int64_t v_index = 0;
    while ((_eri_order_847 = (v_index), _eri_order_848 = (64), (_eri_order_847 < _eri_order_848))) {
        int64_t v_value = eri_text_view_byte_get(eri_text_view_make(v_digest, ERI_TEXT_VIEW_BYTES), v_index);
        if (((!((_eri_order_849 = (v_value), _eri_order_850 = (48), (_eri_order_849 >= _eri_order_850)) && (_eri_order_851 = (v_value), _eri_order_852 = (57), (_eri_order_851 <= _eri_order_852)))) && (!((_eri_order_853 = (v_value), _eri_order_854 = (97), (_eri_order_853 >= _eri_order_854)) && (_eri_order_855 = (v_value), _eri_order_856 = (102), (_eri_order_855 <= _eri_order_856)))))) {
            fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x64, 0x69, 0x67, 0x65, 0x73, 0x74, 0x20, 0x6d, 0x75, 0x73, 0x74, 0x20, 0x62, 0x65, 0x20, 0x6c, 0x6f, 0x77, 0x65, 0x72, 0x63, 0x61, 0x73, 0x65, 0x20, 0x53, 0x48, 0x41, 0x2d, 0x32, 0x35, 0x36, 0x20, 0x68, 0x65, 0x78}, 43));
        }
        v_index = (_eri_order_857 = (v_index), _eri_order_858 = (1), eri_iadd(_eri_order_857, _eri_order_858));
    }
    v_index = 0;
    while ((_eri_order_859 = (v_index), _eri_order_862 = ((_eri_order_860 = (((v_meta)->f_sources)->f_length), _eri_order_861 = (4), eri_idiv(_eri_order_860, _eri_order_861))), (_eri_order_859 < _eri_order_862))) {
        int64_t v_offset = (_eri_order_863 = (v_index), _eri_order_864 = (4), eri_imul(_eri_order_863, _eri_order_864));
        int64_t v_nameStart = (_eri_order_865 = ((v_meta)->f_sources), _eri_order_866 = (v_phase), _eri_order_867 = (v_offset), fn_compiler_u002e_u1_words_u002e_get(_eri_order_865, _eri_order_866, _eri_order_867));
        int64_t v_nameSize = (_eri_order_868 = ((v_meta)->f_sources), _eri_order_869 = (v_phase), _eri_order_872 = ((_eri_order_870 = (v_offset), _eri_order_871 = (1), eri_iadd(_eri_order_870, _eri_order_871))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_868, _eri_order_869, _eri_order_872));
        if ((_eri_order_873 = (v_meta), _eri_order_874 = (v_phase), _eri_order_875 = (v_nameStart), _eri_order_876 = (v_nameSize), _eri_order_877 = (v_name), fn_compiler_u002e_u1_meta_u002e_sameBytes(_eri_order_873, _eri_order_874, _eri_order_875, _eri_order_876, _eri_order_877))) {
            int64_t v_digestStart = (_eri_order_878 = ((v_meta)->f_sources), _eri_order_879 = (v_phase), _eri_order_882 = ((_eri_order_880 = (v_offset), _eri_order_881 = (2), eri_iadd(_eri_order_880, _eri_order_881))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_878, _eri_order_879, _eri_order_882));
            if (((!(_eri_order_883 = (v_meta), _eri_order_884 = (v_phase), _eri_order_885 = (v_digestStart), _eri_order_886 = (64), _eri_order_887 = (v_digest), fn_compiler_u002e_u1_meta_u002e_sameBytes(_eri_order_883, _eri_order_884, _eri_order_885, _eri_order_886, _eri_order_887))) || (_eri_order_893 = ((_eri_order_888 = ((v_meta)->f_sources), _eri_order_889 = (v_phase), _eri_order_892 = ((_eri_order_890 = (v_offset), _eri_order_891 = (3), eri_iadd(_eri_order_890, _eri_order_891))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_888, _eri_order_889, _eri_order_892))), _eri_order_894 = (v_length), (_eri_order_893 != _eri_order_894)))) {
                fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x63, 0x6f, 0x6e, 0x66, 0x6c, 0x69, 0x63, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x72, 0x65, 0x76, 0x69, 0x73, 0x69, 0x6f, 0x6e}, 27));
            }
            return (eri_struct_compiler_u002e_u1_meta_u002e_SourceId){.f_owner = (v_meta)->f_key, .f_index = (_eri_order_895 = (v_index), _eri_order_896 = (1), eri_iadd(_eri_order_895, _eri_order_896))};
        }
        v_index = (_eri_order_897 = (v_index), _eri_order_898 = (1), eri_iadd(_eri_order_897, _eri_order_898));
    }
    int64_t v_nameStart = (_eri_order_899 = (v_meta), _eri_order_900 = (v_phase), _eri_order_901 = (v_name), fn_compiler_u002e_u1_meta_u002e_appendBytes(_eri_order_899, _eri_order_900, _eri_order_901));
    int64_t v_digestStart = (_eri_order_902 = (v_meta), _eri_order_903 = (v_phase), _eri_order_904 = (v_digest), fn_compiler_u002e_u1_meta_u002e_appendBytes(_eri_order_902, _eri_order_903, _eri_order_904));
    eri_struct_compiler_u002e_u1_meta_u002e_SourceId v_value = (eri_struct_compiler_u002e_u1_meta_u002e_SourceId){.f_owner = (v_meta)->f_key, .f_index = (_eri_order_907 = ((_eri_order_905 = (((v_meta)->f_sources)->f_length), _eri_order_906 = (4), eri_idiv(_eri_order_905, _eri_order_906))), _eri_order_908 = (1), eri_iadd(_eri_order_907, _eri_order_908))};
    int64_t v_ignored = (_eri_order_909 = ((v_meta)->f_sources), _eri_order_910 = (v_phase), _eri_order_911 = (v_nameStart), fn_compiler_u002e_u1_words_u002e_push(_eri_order_909, _eri_order_910, _eri_order_911));
    v_ignored = (_eri_order_912 = ((v_meta)->f_sources), _eri_order_913 = (v_phase), _eri_order_914 = (eri_text_view_count(eri_text_view_make(v_name, ERI_TEXT_VIEW_BYTES))), fn_compiler_u002e_u1_words_u002e_push(_eri_order_912, _eri_order_913, _eri_order_914));
    v_ignored = (_eri_order_915 = ((v_meta)->f_sources), _eri_order_916 = (v_phase), _eri_order_917 = (v_digestStart), fn_compiler_u002e_u1_words_u002e_push(_eri_order_915, _eri_order_916, _eri_order_917));
    v_ignored = (_eri_order_918 = ((v_meta)->f_sources), _eri_order_919 = (v_phase), _eri_order_920 = (v_length), fn_compiler_u002e_u1_words_u002e_push(_eri_order_918, _eri_order_919, _eri_order_920));
    return v_value;
}

static eri_struct_compiler_u002e_u1_meta_u002e_LocId fn_compiler_u002e_u1_meta_u002e_location(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, eri_struct_compiler_u002e_u1_meta_u002e_SourceId v_source, int64_t v_start, int64_t v_end, int64_t v_anchor, int64_t v_line, int64_t v_column) {
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_921;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_922;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_923;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_924;
    int64_t _eri_order_925;
    int64_t _eri_order_926;
    int64_t _eri_order_927;
    int64_t _eri_order_928;
    int64_t _eri_order_929;
    int64_t _eri_order_930;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_931;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_932;
    int64_t _eri_order_933;
    int64_t _eri_order_934;
    int64_t _eri_order_935;
    int64_t _eri_order_936;
    int64_t _eri_order_937;
    int64_t _eri_order_938;
    int64_t _eri_order_939;
    int64_t _eri_order_940;
    int64_t _eri_order_941;
    int64_t _eri_order_942;
    int64_t _eri_order_943;
    int64_t _eri_order_944;
    int64_t _eri_order_945;
    int64_t _eri_order_946;
    int64_t _eri_order_947;
    int64_t _eri_order_948;
    int64_t _eri_order_949;
    int64_t _eri_order_950;
    int64_t _eri_order_951;
    int64_t _eri_order_952;
    int64_t _eri_order_953;
    int64_t _eri_order_954;
    int64_t _eri_order_955;
    int64_t _eri_order_956;
    int64_t _eri_order_957;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_958;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_959;
    int64_t _eri_order_960;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_961;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_962;
    int64_t _eri_order_963;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_964;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_965;
    int64_t _eri_order_966;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_967;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_968;
    int64_t _eri_order_969;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_970;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_971;
    int64_t _eri_order_972;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_973;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_974;
    int64_t _eri_order_975;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_976;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_977;
    int64_t _eri_order_978;
    (_eri_order_921 = (v_meta), _eri_order_922 = (v_phase), fn_compiler_u002e_u1_meta_u002e_mutable(_eri_order_921, _eri_order_922));
    if ((((_eri_order_923 = ((v_source).f_owner), _eri_order_924 = ((v_meta)->f_key), (!(_eri_order_923 == _eri_order_924))) || (_eri_order_925 = ((v_source).f_index), _eri_order_926 = (1), (_eri_order_925 < _eri_order_926))) || (_eri_order_927 = ((v_source).f_index), _eri_order_930 = ((_eri_order_928 = (((v_meta)->f_sources)->f_length), _eri_order_929 = (4), eri_idiv(_eri_order_928, _eri_order_929))), (_eri_order_927 > _eri_order_930)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x53, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x49, 0x64}, 31));
    }
    int64_t v_length = (_eri_order_931 = ((v_meta)->f_sources), _eri_order_932 = (v_phase), _eri_order_939 = ((_eri_order_937 = ((_eri_order_935 = ((_eri_order_933 = ((v_source).f_index), _eri_order_934 = (1), eri_isub(_eri_order_933, _eri_order_934))), _eri_order_936 = (4), eri_imul(_eri_order_935, _eri_order_936))), _eri_order_938 = (3), eri_iadd(_eri_order_937, _eri_order_938))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_931, _eri_order_932, _eri_order_939));
    if ((((((((_eri_order_940 = (v_start), _eri_order_941 = (0), (_eri_order_940 < _eri_order_941)) || (_eri_order_942 = (v_end), _eri_order_943 = (v_start), (_eri_order_942 < _eri_order_943))) || (_eri_order_944 = (v_end), _eri_order_945 = (v_length), (_eri_order_944 > _eri_order_945))) || (_eri_order_946 = (v_anchor), _eri_order_947 = (v_start), (_eri_order_946 < _eri_order_947))) || (_eri_order_948 = (v_anchor), _eri_order_949 = (v_end), (_eri_order_948 > _eri_order_949))) || (_eri_order_950 = (v_line), _eri_order_951 = (1), (_eri_order_950 < _eri_order_951))) || (_eri_order_952 = (v_column), _eri_order_953 = (1), (_eri_order_952 < _eri_order_953)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x73, 0x70, 0x61, 0x6e}, 23));
    }
    eri_struct_compiler_u002e_u1_meta_u002e_LocId v_value = (eri_struct_compiler_u002e_u1_meta_u002e_LocId){.f_owner = (v_meta)->f_key, .f_index = (_eri_order_956 = ((_eri_order_954 = (((v_meta)->f_locations)->f_length), _eri_order_955 = (7), eri_idiv(_eri_order_954, _eri_order_955))), _eri_order_957 = (1), eri_iadd(_eri_order_956, _eri_order_957))};
    int64_t v_ignored = (_eri_order_958 = ((v_meta)->f_locations), _eri_order_959 = (v_phase), _eri_order_960 = ((v_source).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_958, _eri_order_959, _eri_order_960));
    v_ignored = (_eri_order_961 = ((v_meta)->f_locations), _eri_order_962 = (v_phase), _eri_order_963 = (v_start), fn_compiler_u002e_u1_words_u002e_push(_eri_order_961, _eri_order_962, _eri_order_963));
    v_ignored = (_eri_order_964 = ((v_meta)->f_locations), _eri_order_965 = (v_phase), _eri_order_966 = (v_end), fn_compiler_u002e_u1_words_u002e_push(_eri_order_964, _eri_order_965, _eri_order_966));
    v_ignored = (_eri_order_967 = ((v_meta)->f_locations), _eri_order_968 = (v_phase), _eri_order_969 = (v_anchor), fn_compiler_u002e_u1_words_u002e_push(_eri_order_967, _eri_order_968, _eri_order_969));
    v_ignored = (_eri_order_970 = ((v_meta)->f_locations), _eri_order_971 = (v_phase), _eri_order_972 = (v_line), fn_compiler_u002e_u1_words_u002e_push(_eri_order_970, _eri_order_971, _eri_order_972));
    v_ignored = (_eri_order_973 = ((v_meta)->f_locations), _eri_order_974 = (v_phase), _eri_order_975 = (v_column), fn_compiler_u002e_u1_words_u002e_push(_eri_order_973, _eri_order_974, _eri_order_975));
    v_ignored = (_eri_order_976 = ((v_meta)->f_locations), _eri_order_977 = (v_phase), _eri_order_978 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_976, _eri_order_977, _eri_order_978));
    return v_value;
}

static void fn_compiler_u002e_u1_meta_u002e_validLocation(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_value) {
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_979;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_980;
    int64_t _eri_order_981;
    int64_t _eri_order_982;
    int64_t _eri_order_983;
    int64_t _eri_order_984;
    int64_t _eri_order_985;
    int64_t _eri_order_986;
    if (((((v_meta)->f_closed || (_eri_order_979 = ((v_value).f_owner), _eri_order_980 = ((v_meta)->f_key), (!(_eri_order_979 == _eri_order_980)))) || (_eri_order_981 = ((v_value).f_index), _eri_order_982 = (1), (_eri_order_981 < _eri_order_982))) || (_eri_order_983 = ((v_value).f_index), _eri_order_986 = ((_eri_order_984 = (((v_meta)->f_locations)->f_length), _eri_order_985 = (7), eri_idiv(_eri_order_984, _eri_order_985))), (_eri_order_983 > _eri_order_986)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x4c, 0x6f, 0x63, 0x49, 0x64}, 28));
    }
}

static void fn_compiler_u002e_u1_meta_u002e_freeze(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta) {
    fn_compiler_u002e_u1_budget_u002e_poll((v_meta)->f_owner);
    if ((v_meta)->f_closed) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x63, 0x6c, 0x6f, 0x73, 0x65, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x6d, 0x65, 0x74, 0x61, 0x64, 0x61, 0x74, 0x61}, 19));
    }
    fn_compiler_u002e_u1_words_u002e_freeze((v_meta)->f_signatures);
    fn_compiler_u002e_u1_words_u002e_freeze((v_meta)->f_types);
    fn_compiler_u002e_u1_words_u002e_freeze((v_meta)->f_buckets);
    fn_compiler_u002e_u1_words_u002e_freeze((v_meta)->f_sources);
    fn_compiler_u002e_u1_words_u002e_freeze((v_meta)->f_bytes);
    fn_compiler_u002e_u1_words_u002e_freeze((v_meta)->f_locations);
    (v_meta)->f_frozen = true;
}

static void fn_compiler_u002e_u1_meta_u002e_close(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_meta) {
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation _eri_order_987;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation _eri_order_988;
    if ((v_meta)->f_closed) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x64, 0x6f, 0x75, 0x62, 0x6c, 0x65, 0x20, 0x63, 0x6c, 0x6f, 0x73, 0x65, 0x20, 0x6f, 0x66, 0x20, 0x55, 0x31, 0x61, 0x20, 0x6d, 0x65, 0x74, 0x61, 0x64, 0x61, 0x74, 0x61}, 28));
    }
    (v_meta)->f_closed = true;
    fn_compiler_u002e_u1_words_u002e_close((v_meta)->f_signatures);
    fn_compiler_u002e_u1_words_u002e_close((v_meta)->f_types);
    fn_compiler_u002e_u1_words_u002e_close((v_meta)->f_buckets);
    fn_compiler_u002e_u1_words_u002e_close((v_meta)->f_sources);
    fn_compiler_u002e_u1_words_u002e_close((v_meta)->f_bytes);
    fn_compiler_u002e_u1_words_u002e_close((v_meta)->f_locations);
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation v_control = (v_meta)->f_control;
    (v_meta)->f_control = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false};
    if ((_eri_order_987 = (v_control), _eri_order_988 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(_eri_order_987, _eri_order_988)))) {
        fn_compiler_u002e_u1_budget_u002e_release(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_get(v_control));
    }
}

static bool fn_compiler_u002e_u1_ops_u002e_known(int64_t v_op) {
    int64_t _eri_order_989;
    int64_t _eri_order_990;
    int64_t _eri_order_991;
    int64_t _eri_order_992;
    return ((_eri_order_989 = (v_op), _eri_order_990 = (1), (_eri_order_989 >= _eri_order_990)) && (_eri_order_991 = (v_op), _eri_order_992 = (12), (_eri_order_991 <= _eri_order_992)));
}

static bool fn_compiler_u002e_u1_ops_u002e_terminal(int64_t v_op) {
    int64_t _eri_order_993;
    int64_t _eri_order_994;
    int64_t _eri_order_995;
    int64_t _eri_order_996;
    return ((_eri_order_993 = (v_op), _eri_order_994 = (6), (_eri_order_993 >= _eri_order_994)) && (_eri_order_995 = (v_op), _eri_order_996 = (8), (_eri_order_995 <= _eri_order_996)));
}

static int64_t fn_compiler_u002e_u1_ops_u002e_operands(int64_t v_op) {
    int64_t _eri_order_997;
    int64_t _eri_order_998;
    int64_t _eri_order_999;
    int64_t _eri_order_1000;
    int64_t _eri_order_1001;
    int64_t _eri_order_1002;
    int64_t _eri_order_1003;
    int64_t _eri_order_1004;
    int64_t _eri_order_1005;
    int64_t _eri_order_1006;
    int64_t _eri_order_1007;
    int64_t _eri_order_1008;
    int64_t _eri_order_1009;
    int64_t _eri_order_1010;
    if ((_eri_order_997 = (v_op), _eri_order_998 = (3), (_eri_order_997 == _eri_order_998))) {
        return 2;
    }
    if ((((_eri_order_999 = (v_op), _eri_order_1000 = (4), (_eri_order_999 == _eri_order_1000)) || (_eri_order_1001 = (v_op), _eri_order_1002 = (5), (_eri_order_1001 == _eri_order_1002))) || (_eri_order_1003 = (v_op), _eri_order_1004 = (7), (_eri_order_1003 == _eri_order_1004)))) {
        return 1;
    }
    if (((_eri_order_1005 = (v_op), _eri_order_1006 = (10), (_eri_order_1005 == _eri_order_1006)) || (_eri_order_1007 = (v_op), _eri_order_1008 = (12), (_eri_order_1007 == _eri_order_1008)))) {
        return 1;
    }
    if ((_eri_order_1009 = (v_op), _eri_order_1010 = (8), (_eri_order_1009 == _eri_order_1010))) {
        return eri_ineg(1);
    }
    return 0;
}

static int64_t fn_compiler_u002e_u1_ops_u002e_results(int64_t v_op) {
    int64_t _eri_order_1011;
    int64_t _eri_order_1012;
    int64_t _eri_order_1013;
    int64_t _eri_order_1014;
    int64_t _eri_order_1015;
    int64_t _eri_order_1016;
    int64_t _eri_order_1017;
    int64_t _eri_order_1018;
    int64_t _eri_order_1019;
    int64_t _eri_order_1020;
    int64_t _eri_order_1021;
    int64_t _eri_order_1022;
    if ((_eri_order_1011 = (v_op), _eri_order_1012 = (3), (_eri_order_1011 == _eri_order_1012))) {
        return 2;
    }
    if ((((((_eri_order_1013 = (v_op), _eri_order_1014 = (1), (_eri_order_1013 == _eri_order_1014)) || (_eri_order_1015 = (v_op), _eri_order_1016 = (2), (_eri_order_1015 == _eri_order_1016))) || (_eri_order_1017 = (v_op), _eri_order_1018 = (4), (_eri_order_1017 == _eri_order_1018))) || (_eri_order_1019 = (v_op), _eri_order_1020 = (9), (_eri_order_1019 == _eri_order_1020))) || (_eri_order_1021 = (v_op), _eri_order_1022 = (11), (_eri_order_1021 == _eri_order_1022)))) {
        return 1;
    }
    return 0;
}

static int64_t fn_compiler_u002e_u1_ops_u002e_operandType(int64_t v_op, int64_t v_index) {
    int64_t _eri_order_1023;
    int64_t _eri_order_1024;
    if ((_eri_order_1023 = (v_op), _eri_order_1024 = (3), (_eri_order_1023 == _eri_order_1024))) {
        return 2;
    }
    return 1;
}

static int64_t fn_compiler_u002e_u1_ops_u002e_resultType(int64_t v_op, int64_t v_index) {
    int64_t _eri_order_1025;
    int64_t _eri_order_1026;
    int64_t _eri_order_1027;
    int64_t _eri_order_1028;
    int64_t _eri_order_1029;
    int64_t _eri_order_1030;
    int64_t _eri_order_1031;
    int64_t _eri_order_1032;
    if (((_eri_order_1025 = (v_op), _eri_order_1026 = (1), (_eri_order_1025 == _eri_order_1026)) || ((_eri_order_1027 = (v_op), _eri_order_1028 = (3), (_eri_order_1027 == _eri_order_1028)) && (_eri_order_1029 = (v_index), _eri_order_1030 = (0), (_eri_order_1029 == _eri_order_1030))))) {
        return 2;
    }
    if ((_eri_order_1031 = (v_op), _eri_order_1032 = (9), (_eri_order_1031 == _eri_order_1032))) {
        return 3;
    }
    return 1;
}

static void fn_compiler_u002e_u1_builder_u002e_mutable(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine) {
    int64_t _eri_order_1033;
    int64_t _eri_order_1034;
    fn_compiler_u002e_u1_budget_u002e_poll((v_routine)->f_owner);
    if ((_eri_order_1033 = ((v_routine)->f_state), _eri_order_1034 = (0), (_eri_order_1033 != _eri_order_1034))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x66, 0x75, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x63, 0x6f, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x69, 0x73, 0x20, 0x63, 0x6c, 0x6f, 0x73, 0x65, 0x64}, 35));
    }
}

static int64_t fn_compiler_u002e_u1_builder_u002e_blockOffset(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block) {
    int64_t _eri_order_1035;
    int64_t _eri_order_1036;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_1037;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_1038;
    int64_t _eri_order_1039;
    int64_t _eri_order_1040;
    int64_t _eri_order_1041;
    int64_t _eri_order_1042;
    int64_t _eri_order_1043;
    int64_t _eri_order_1044;
    int64_t _eri_order_1045;
    int64_t _eri_order_1046;
    int64_t _eri_order_1047;
    int64_t _eri_order_1048;
    if (((((_eri_order_1035 = ((v_routine)->f_state), _eri_order_1036 = (2), (_eri_order_1035 == _eri_order_1036)) || (_eri_order_1037 = ((v_block).f_owner), _eri_order_1038 = ((v_routine)->f_key), (!(_eri_order_1037 == _eri_order_1038)))) || (_eri_order_1039 = ((v_block).f_index), _eri_order_1040 = (1), (_eri_order_1039 < _eri_order_1040))) || (_eri_order_1041 = ((v_block).f_index), _eri_order_1044 = ((_eri_order_1042 = (((v_routine)->f_blocks)->f_length), _eri_order_1043 = (5), eri_idiv(_eri_order_1042, _eri_order_1043))), (_eri_order_1041 > _eri_order_1044)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x42, 0x6c, 0x6f, 0x63, 0x6b, 0x49, 0x64}, 30));
    }
    return (_eri_order_1047 = ((_eri_order_1045 = ((v_block).f_index), _eri_order_1046 = (1), eri_isub(_eri_order_1045, _eri_order_1046))), _eri_order_1048 = (5), eri_imul(_eri_order_1047, _eri_order_1048));
}

static int64_t fn_compiler_u002e_u1_builder_u002e_valueOffset(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value) {
    int64_t _eri_order_1049;
    int64_t _eri_order_1050;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_1051;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_1052;
    int64_t _eri_order_1053;
    int64_t _eri_order_1054;
    int64_t _eri_order_1055;
    int64_t _eri_order_1056;
    int64_t _eri_order_1057;
    int64_t _eri_order_1058;
    int64_t _eri_order_1059;
    int64_t _eri_order_1060;
    int64_t _eri_order_1061;
    int64_t _eri_order_1062;
    if (((((_eri_order_1049 = ((v_routine)->f_state), _eri_order_1050 = (2), (_eri_order_1049 == _eri_order_1050)) || (_eri_order_1051 = ((v_value).f_owner), _eri_order_1052 = ((v_routine)->f_key), (!(_eri_order_1051 == _eri_order_1052)))) || (_eri_order_1053 = ((v_value).f_index), _eri_order_1054 = (1), (_eri_order_1053 < _eri_order_1054))) || (_eri_order_1055 = ((v_value).f_index), _eri_order_1058 = ((_eri_order_1056 = (((v_routine)->f_values)->f_length), _eri_order_1057 = (4), eri_idiv(_eri_order_1056, _eri_order_1057))), (_eri_order_1055 > _eri_order_1058)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x56, 0x61, 0x6c, 0x75, 0x65, 0x49, 0x64}, 30));
    }
    return (_eri_order_1061 = ((_eri_order_1059 = ((v_value).f_index), _eri_order_1060 = (1), eri_isub(_eri_order_1059, _eri_order_1060))), _eri_order_1062 = (4), eri_imul(_eri_order_1061, _eri_order_1062));
}

static int64_t fn_compiler_u002e_u1_builder_u002e_instOffset(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_InstId v_value) {
    int64_t _eri_order_1063;
    int64_t _eri_order_1064;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_1065;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_1066;
    int64_t _eri_order_1067;
    int64_t _eri_order_1068;
    int64_t _eri_order_1069;
    int64_t _eri_order_1070;
    int64_t _eri_order_1071;
    int64_t _eri_order_1072;
    int64_t _eri_order_1073;
    int64_t _eri_order_1074;
    int64_t _eri_order_1075;
    int64_t _eri_order_1076;
    if (((((_eri_order_1063 = ((v_routine)->f_state), _eri_order_1064 = (2), (_eri_order_1063 == _eri_order_1064)) || (_eri_order_1065 = ((v_value).f_owner), _eri_order_1066 = ((v_routine)->f_key), (!(_eri_order_1065 == _eri_order_1066)))) || (_eri_order_1067 = ((v_value).f_index), _eri_order_1068 = (1), (_eri_order_1067 < _eri_order_1068))) || (_eri_order_1069 = ((v_value).f_index), _eri_order_1072 = ((_eri_order_1070 = (((v_routine)->f_instructions)->f_length), _eri_order_1071 = (10), eri_idiv(_eri_order_1070, _eri_order_1071))), (_eri_order_1069 > _eri_order_1072)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x49, 0x6e, 0x73, 0x74, 0x49, 0x64}, 29));
    }
    return (_eri_order_1075 = ((_eri_order_1073 = ((v_value).f_index), _eri_order_1074 = (1), eri_isub(_eri_order_1073, _eri_order_1074))), _eri_order_1076 = (10), eri_imul(_eri_order_1075, _eri_order_1076));
}

static eri_struct_compiler_u002e_u1_builder_u002e_Function * fn_compiler_u002e_u1_builder_u002e_create(eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_metadata, eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_signature, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    int64_t _eri_order_1077;
    int64_t _eri_order_1078;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1079;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1080;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_1081;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_1082;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_1083;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1084;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_1085;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1086;
    int64_t _eri_order_1087;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1088;
    int64_t _eri_order_1089;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1090;
    int64_t _eri_order_1091;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1092;
    int64_t _eri_order_1093;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1094;
    int64_t _eri_order_1095;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1096;
    int64_t _eri_order_1097;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1098;
    int64_t _eri_order_1099;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1100;
    int64_t _eri_order_1101;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1102;
    int64_t _eri_order_1103;
    if ((((((!(v_metadata)->f_frozen) || (v_metadata)->f_closed) || (_eri_order_1077 = ((v_owner)->f_kind), _eri_order_1078 = (2), (_eri_order_1077 != _eri_order_1078))) || (_eri_order_1079 = ((v_phase)->f_owner), _eri_order_1080 = (v_owner), (!(_eri_order_1079 == _eri_order_1080)))) || (_eri_order_1081 = ((v_owner)->f_parent), _eri_order_1082 = (((v_metadata)->f_owner)->f_parent), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_1081, _eri_order_1082))))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x66, 0x75, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x72, 0x65, 0x71, 0x75, 0x69, 0x72, 0x65, 0x73, 0x20, 0x69, 0x6d, 0x6d, 0x75, 0x74, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x6d, 0x65, 0x74, 0x61, 0x64, 0x61, 0x74, 0x61, 0x20, 0x61, 0x6e, 0x64, 0x20, 0x69, 0x74, 0x73, 0x20, 0x6f, 0x77, 0x6e, 0x20, 0x70, 0x68, 0x61, 0x73, 0x65}, 58));
    }
    int64_t v_checked = (_eri_order_1083 = (v_metadata), _eri_order_1084 = (v_phase), _eri_order_1085 = (v_signature), fn_compiler_u002e_u1_meta_u002e_resultCount(_eri_order_1083, _eri_order_1084, _eri_order_1085));
    eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_preflight = (_eri_order_1086 = (v_owner), _eri_order_1087 = (8192), fn_compiler_u002e_u1_budget_u002e_reserve(_eri_order_1086, _eri_order_1087));
    fn_compiler_u002e_u1_budget_u002e_cancelReservation(v_preflight);
    eri_struct_compiler_u002e_u1_budget_u002e_Reservation * v_pending = (_eri_order_1088 = (v_owner), _eri_order_1089 = (1024), fn_compiler_u002e_u1_budget_u002e_reserve(_eri_order_1088, _eri_order_1089));
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = eri_identity_compiler_u002e_u1_builder_u002e_Function_new((eri_struct_compiler_u002e_u1_builder_u002e_Function){.f_key = eri_identity_compiler_u002e_u1_meta_u002e_Key_new((eri_struct_compiler_u002e_u1_meta_u002e_Key){.f_marker = 0}), .f_metadata = v_metadata, .f_signature = v_signature, .f_owner = v_owner, .f_phase = v_phase, .f_state = 0, .f_revision = 0, .f_control = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false}, .f_blocks = (_eri_order_1090 = (v_owner), _eri_order_1091 = (327680), fn_compiler_u002e_u1_words_u002e_create(_eri_order_1090, _eri_order_1091)), .f_values = (_eri_order_1092 = (v_owner), _eri_order_1093 = (4194304), fn_compiler_u002e_u1_words_u002e_create(_eri_order_1092, _eri_order_1093)), .f_instructions = (_eri_order_1094 = (v_owner), _eri_order_1095 = (10485760), fn_compiler_u002e_u1_words_u002e_create(_eri_order_1094, _eri_order_1095)), .f_operands = (_eri_order_1096 = (v_owner), _eri_order_1097 = (16777216), fn_compiler_u002e_u1_words_u002e_create(_eri_order_1096, _eri_order_1097)), .f_edges = (_eri_order_1098 = (v_owner), _eri_order_1099 = (786432), fn_compiler_u002e_u1_words_u002e_create(_eri_order_1098, _eri_order_1099)), .f_arguments = (_eri_order_1100 = (v_owner), _eri_order_1101 = (4194304), fn_compiler_u002e_u1_words_u002e_create(_eri_order_1100, _eri_order_1101)), .f_cells = (_eri_order_1102 = (v_owner), _eri_order_1103 = (131072), fn_compiler_u002e_u1_words_u002e_create(_eri_order_1102, _eri_order_1103))});
    (v_routine)->f_control = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=true,.value=fn_compiler_u002e_u1_budget_u002e_commit(v_pending)};
    return v_routine;
}

static eri_struct_compiler_u002e_u1_meta_u002e_TypeId fn_compiler_u002e_u1_builder_u002e_valueType(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1104;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1105;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1106;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1107;
    int64_t _eri_order_1108;
    int64_t v_offset = (_eri_order_1104 = (v_routine), _eri_order_1105 = (v_value), fn_compiler_u002e_u1_builder_u002e_valueOffset(_eri_order_1104, _eri_order_1105));
    return fn_compiler_u002e_u1_meta_u002e_typeAt((_eri_order_1106 = ((v_routine)->f_values), _eri_order_1107 = ((v_routine)->f_phase), _eri_order_1108 = (v_offset), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1106, _eri_order_1107, _eri_order_1108)));
}

static eri_struct_compiler_u002e_u1_builder_u002e_BlockId fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_parameters) {
    int64_t _eri_order_1109;
    int64_t _eri_order_1110;
    int64_t _eri_order_1111;
    int64_t _eri_order_1112;
    int64_t _eri_order_1113;
    int64_t _eri_order_1114;
    int64_t _eri_order_1115;
    int64_t _eri_order_1116;
    int64_t _eri_order_1117;
    int64_t _eri_order_1118;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1119;
    int64_t _eri_order_1120;
    int64_t _eri_order_1121;
    int64_t _eri_order_1122;
    int64_t _eri_order_1123;
    int64_t _eri_order_1124;
    int64_t _eri_order_1125;
    int64_t _eri_order_1126;
    int64_t _eri_order_1127;
    int64_t _eri_order_1128;
    int64_t _eri_order_1129;
    int64_t _eri_order_1130;
    int64_t _eri_order_1131;
    int64_t _eri_order_1132;
    int64_t _eri_order_1133;
    int64_t _eri_order_1134;
    int64_t _eri_order_1135;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1136;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1137;
    int64_t _eri_order_1138;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1139;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1140;
    int64_t _eri_order_1141;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1142;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1143;
    int64_t _eri_order_1144;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1145;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1146;
    int64_t _eri_order_1147;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1148;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1149;
    int64_t _eri_order_1150;
    int64_t _eri_order_1151;
    int64_t _eri_order_1152;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1153;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1154;
    int64_t _eri_order_1155;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1156;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1157;
    int64_t _eri_order_1158;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1159;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1160;
    int64_t _eri_order_1161;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1162;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1163;
    int64_t _eri_order_1164;
    int64_t _eri_order_1165;
    int64_t _eri_order_1166;
    int64_t _eri_order_1167;
    int64_t _eri_order_1168;
    fn_compiler_u002e_u1_builder_u002e_mutable(v_routine);
    if (((_eri_order_1111 = ((_eri_order_1109 = (((v_routine)->f_blocks)->f_length), _eri_order_1110 = (5), eri_idiv(_eri_order_1109, _eri_order_1110))), _eri_order_1112 = (65536), (_eri_order_1111 >= _eri_order_1112)) || (_eri_order_1113 = (((int64_t)(v_parameters).count)), _eri_order_1118 = ((_eri_order_1114 = (1048576), _eri_order_1117 = ((_eri_order_1115 = (((v_routine)->f_values)->f_length), _eri_order_1116 = (4), eri_idiv(_eri_order_1115, _eri_order_1116))), eri_isub(_eri_order_1114, _eri_order_1117))), (_eri_order_1113 > _eri_order_1118)))) {
        (_eri_order_1119 = ((v_routine)->f_owner), _eri_order_1120 = (1), _eri_order_1121 = (0), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_1119, _eri_order_1120, _eri_order_1121));
    }
    int64_t v_index = 0;
    while ((_eri_order_1122 = (v_index), _eri_order_1123 = (((int64_t)(v_parameters).count)), (_eri_order_1122 < _eri_order_1123))) {
        fn_compiler_u002e_u1_meta_u002e_validType(eri_list_compiler_u002e_u1_meta_u002e_TypeId_get(v_parameters, v_index));
        v_index = (_eri_order_1124 = (v_index), _eri_order_1125 = (1), eri_iadd(_eri_order_1124, _eri_order_1125));
    }
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_value = (eri_struct_compiler_u002e_u1_builder_u002e_BlockId){.f_owner = (v_routine)->f_key, .f_index = (_eri_order_1128 = ((_eri_order_1126 = (((v_routine)->f_blocks)->f_length), _eri_order_1127 = (5), eri_idiv(_eri_order_1126, _eri_order_1127))), _eri_order_1129 = (1), eri_iadd(_eri_order_1128, _eri_order_1129))};
    int64_t v_first = 0;
    if ((_eri_order_1130 = (((int64_t)(v_parameters).count)), _eri_order_1131 = (0), (_eri_order_1130 > _eri_order_1131))) {
        v_first = (_eri_order_1134 = ((_eri_order_1132 = (((v_routine)->f_values)->f_length), _eri_order_1133 = (4), eri_idiv(_eri_order_1132, _eri_order_1133))), _eri_order_1135 = (1), eri_iadd(_eri_order_1134, _eri_order_1135));
    }
    int64_t v_ignored = (_eri_order_1136 = ((v_routine)->f_blocks), _eri_order_1137 = ((v_routine)->f_phase), _eri_order_1138 = (v_first), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1136, _eri_order_1137, _eri_order_1138));
    v_ignored = (_eri_order_1139 = ((v_routine)->f_blocks), _eri_order_1140 = ((v_routine)->f_phase), _eri_order_1141 = (((int64_t)(v_parameters).count)), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1139, _eri_order_1140, _eri_order_1141));
    v_ignored = (_eri_order_1142 = ((v_routine)->f_blocks), _eri_order_1143 = ((v_routine)->f_phase), _eri_order_1144 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1142, _eri_order_1143, _eri_order_1144));
    v_ignored = (_eri_order_1145 = ((v_routine)->f_blocks), _eri_order_1146 = ((v_routine)->f_phase), _eri_order_1147 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1145, _eri_order_1146, _eri_order_1147));
    v_ignored = (_eri_order_1148 = ((v_routine)->f_blocks), _eri_order_1149 = ((v_routine)->f_phase), _eri_order_1150 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1148, _eri_order_1149, _eri_order_1150));
    v_index = 0;
    while ((_eri_order_1151 = (v_index), _eri_order_1152 = (((int64_t)(v_parameters).count)), (_eri_order_1151 < _eri_order_1152))) {
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_valueType = eri_list_compiler_u002e_u1_meta_u002e_TypeId_get(v_parameters, v_index);
        v_ignored = (_eri_order_1153 = ((v_routine)->f_values), _eri_order_1154 = ((v_routine)->f_phase), _eri_order_1155 = ((v_valueType).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1153, _eri_order_1154, _eri_order_1155));
        v_ignored = (_eri_order_1156 = ((v_routine)->f_values), _eri_order_1157 = ((v_routine)->f_phase), _eri_order_1158 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1156, _eri_order_1157, _eri_order_1158));
        v_ignored = (_eri_order_1159 = ((v_routine)->f_values), _eri_order_1160 = ((v_routine)->f_phase), _eri_order_1161 = ((v_value).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1159, _eri_order_1160, _eri_order_1161));
        v_ignored = (_eri_order_1162 = ((v_routine)->f_values), _eri_order_1163 = ((v_routine)->f_phase), _eri_order_1164 = (v_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1162, _eri_order_1163, _eri_order_1164));
        v_index = (_eri_order_1165 = (v_index), _eri_order_1166 = (1), eri_iadd(_eri_order_1165, _eri_order_1166));
    }
    (v_routine)->f_revision = (_eri_order_1167 = ((v_routine)->f_revision), _eri_order_1168 = (1), eri_iadd(_eri_order_1167, _eri_order_1168));
    return v_value;
}

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_parameter(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, int64_t v_index) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1169;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1170;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1171;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1172;
    int64_t _eri_order_1173;
    int64_t _eri_order_1174;
    int64_t _eri_order_1175;
    int64_t _eri_order_1176;
    int64_t _eri_order_1177;
    int64_t _eri_order_1178;
    int64_t _eri_order_1179;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1180;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1181;
    int64_t _eri_order_1182;
    int64_t _eri_order_1183;
    int64_t _eri_order_1184;
    int64_t v_offset = (_eri_order_1169 = (v_routine), _eri_order_1170 = (v_block), fn_compiler_u002e_u1_builder_u002e_blockOffset(_eri_order_1169, _eri_order_1170));
    int64_t v_count = (_eri_order_1171 = ((v_routine)->f_blocks), _eri_order_1172 = ((v_routine)->f_phase), _eri_order_1175 = ((_eri_order_1173 = (v_offset), _eri_order_1174 = (1), eri_iadd(_eri_order_1173, _eri_order_1174))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1171, _eri_order_1172, _eri_order_1175));
    if (((_eri_order_1176 = (v_index), _eri_order_1177 = (0), (_eri_order_1176 < _eri_order_1177)) || (_eri_order_1178 = (v_index), _eri_order_1179 = (v_count), (_eri_order_1178 >= _eri_order_1179)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x62, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x65, 0x74, 0x65, 0x72, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x20, 0x6f, 0x75, 0x74, 0x20, 0x6f, 0x66, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 38));
    }
    int64_t v_first = (_eri_order_1180 = ((v_routine)->f_blocks), _eri_order_1181 = ((v_routine)->f_phase), _eri_order_1182 = (v_offset), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1180, _eri_order_1181, _eri_order_1182));
    return (eri_struct_compiler_u002e_u1_builder_u002e_ValueId){.f_owner = (v_routine)->f_key, .f_index = (_eri_order_1183 = (v_first), _eri_order_1184 = (v_index), eri_iadd(_eri_order_1183, _eri_order_1184))};
}

static int64_t fn_compiler_u002e_u1_builder_u002e_openBlock(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1185;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1186;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1187;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1188;
    int64_t _eri_order_1189;
    int64_t _eri_order_1190;
    int64_t _eri_order_1191;
    int64_t _eri_order_1192;
    int64_t _eri_order_1193;
    fn_compiler_u002e_u1_builder_u002e_mutable(v_routine);
    int64_t v_offset = (_eri_order_1185 = (v_routine), _eri_order_1186 = (v_block), fn_compiler_u002e_u1_builder_u002e_blockOffset(_eri_order_1185, _eri_order_1186));
    if ((_eri_order_1192 = ((_eri_order_1187 = ((v_routine)->f_blocks), _eri_order_1188 = ((v_routine)->f_phase), _eri_order_1191 = ((_eri_order_1189 = (v_offset), _eri_order_1190 = (4), eri_iadd(_eri_order_1189, _eri_order_1190))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1187, _eri_order_1188, _eri_order_1191))), _eri_order_1193 = (0), (_eri_order_1192 != _eri_order_1193))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x62, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x61, 0x6c, 0x72, 0x65, 0x61, 0x64, 0x79, 0x20, 0x74, 0x65, 0x72, 0x6d, 0x69, 0x6e, 0x61, 0x74, 0x65, 0x64}, 28));
    }
    return v_offset;
}

static void fn_compiler_u002e_u1_builder_u002e_checkEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_target, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_arguments) {
    int64_t _eri_order_1194;
    int64_t _eri_order_1195;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1196;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1197;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1198;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1199;
    int64_t _eri_order_1200;
    int64_t _eri_order_1201;
    int64_t _eri_order_1202;
    int64_t _eri_order_1203;
    int64_t _eri_order_1204;
    int64_t _eri_order_1205;
    int64_t _eri_order_1206;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1207;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1208;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1209;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1210;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1211;
    int64_t _eri_order_1212;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1213;
    int64_t _eri_order_1214;
    int64_t _eri_order_1215;
    int64_t _eri_order_1216;
    int64_t _eri_order_1217;
    if ((_eri_order_1194 = ((v_target).f_index), _eri_order_1195 = (1), (_eri_order_1194 == _eri_order_1195))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x65, 0x6e, 0x74, 0x72, 0x79, 0x20, 0x63, 0x61, 0x6e, 0x6e, 0x6f, 0x74, 0x20, 0x68, 0x61, 0x76, 0x65, 0x20, 0x70, 0x72, 0x65, 0x64, 0x65, 0x63, 0x65, 0x73, 0x73, 0x6f, 0x72, 0x73}, 34));
    }
    int64_t v_offset = (_eri_order_1196 = (v_routine), _eri_order_1197 = (v_target), fn_compiler_u002e_u1_builder_u002e_blockOffset(_eri_order_1196, _eri_order_1197));
    int64_t v_count = (_eri_order_1198 = ((v_routine)->f_blocks), _eri_order_1199 = ((v_routine)->f_phase), _eri_order_1202 = ((_eri_order_1200 = (v_offset), _eri_order_1201 = (1), eri_iadd(_eri_order_1200, _eri_order_1201))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1198, _eri_order_1199, _eri_order_1202));
    if ((_eri_order_1203 = (v_count), _eri_order_1204 = (((int64_t)(v_arguments).count)), (_eri_order_1203 != _eri_order_1204))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x65, 0x64, 0x67, 0x65, 0x20, 0x61, 0x72, 0x69, 0x74, 0x79, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 23));
    }
    int64_t v_index = 0;
    while ((_eri_order_1205 = (v_index), _eri_order_1206 = (v_count), (_eri_order_1205 < _eri_order_1206))) {
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_actual = (_eri_order_1207 = (v_routine), _eri_order_1208 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_get(v_arguments, v_index)), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1207, _eri_order_1208));
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_expected = (_eri_order_1209 = (v_routine), _eri_order_1213 = ((_eri_order_1210 = (v_routine), _eri_order_1211 = (v_target), _eri_order_1212 = (v_index), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_1210, _eri_order_1211, _eri_order_1212))), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1209, _eri_order_1213));
        if ((_eri_order_1214 = ((v_actual).f_index), _eri_order_1215 = ((v_expected).f_index), (_eri_order_1214 != _eri_order_1215))) {
            fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x65, 0x64, 0x67, 0x65, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 22));
        }
        v_index = (_eri_order_1216 = (v_index), _eri_order_1217 = (1), eri_iadd(_eri_order_1216, _eri_order_1217));
    }
}

static int64_t fn_compiler_u002e_u1_builder_u002e_appendEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_target, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_arguments) {
    int64_t _eri_order_1218;
    int64_t _eri_order_1219;
    int64_t _eri_order_1220;
    int64_t _eri_order_1221;
    int64_t _eri_order_1222;
    int64_t _eri_order_1223;
    int64_t _eri_order_1224;
    int64_t _eri_order_1225;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1226;
    int64_t _eri_order_1227;
    int64_t _eri_order_1228;
    int64_t _eri_order_1229;
    int64_t _eri_order_1230;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1231;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1232;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1233;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1234;
    int64_t _eri_order_1235;
    int64_t _eri_order_1236;
    int64_t _eri_order_1237;
    int64_t _eri_order_1238;
    int64_t _eri_order_1239;
    int64_t _eri_order_1240;
    int64_t _eri_order_1241;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1242;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1243;
    int64_t _eri_order_1244;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1245;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1246;
    int64_t _eri_order_1247;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1248;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1249;
    int64_t _eri_order_1250;
    if (((_eri_order_1220 = ((_eri_order_1218 = (((v_routine)->f_edges)->f_length), _eri_order_1219 = (3), eri_idiv(_eri_order_1218, _eri_order_1219))), _eri_order_1221 = (262144), (_eri_order_1220 >= _eri_order_1221)) || (_eri_order_1222 = (((int64_t)(v_arguments).count)), _eri_order_1225 = ((_eri_order_1223 = (4194304), _eri_order_1224 = (((v_routine)->f_arguments)->f_length), eri_isub(_eri_order_1223, _eri_order_1224))), (_eri_order_1222 > _eri_order_1225)))) {
        (_eri_order_1226 = ((v_routine)->f_owner), _eri_order_1227 = (1), _eri_order_1228 = (0), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_1226, _eri_order_1227, _eri_order_1228));
    }
    int64_t v_first = ((v_routine)->f_arguments)->f_length;
    int64_t v_index = 0;
    while ((_eri_order_1229 = (v_index), _eri_order_1230 = (((int64_t)(v_arguments).count)), (_eri_order_1229 < _eri_order_1230))) {
        eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value = eri_list_compiler_u002e_u1_builder_u002e_ValueId_get(v_arguments, v_index);
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_checked = (_eri_order_1231 = (v_routine), _eri_order_1232 = (v_value), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1231, _eri_order_1232));
        int64_t v_ignored = (_eri_order_1233 = ((v_routine)->f_arguments), _eri_order_1234 = ((v_routine)->f_phase), _eri_order_1235 = ((v_value).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1233, _eri_order_1234, _eri_order_1235));
        v_index = (_eri_order_1236 = (v_index), _eri_order_1237 = (1), eri_iadd(_eri_order_1236, _eri_order_1237));
    }
    int64_t v_result = (_eri_order_1240 = ((_eri_order_1238 = (((v_routine)->f_edges)->f_length), _eri_order_1239 = (3), eri_idiv(_eri_order_1238, _eri_order_1239))), _eri_order_1241 = (1), eri_iadd(_eri_order_1240, _eri_order_1241));
    int64_t v_ignored = (_eri_order_1242 = ((v_routine)->f_edges), _eri_order_1243 = ((v_routine)->f_phase), _eri_order_1244 = ((v_target).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1242, _eri_order_1243, _eri_order_1244));
    v_ignored = (_eri_order_1245 = ((v_routine)->f_edges), _eri_order_1246 = ((v_routine)->f_phase), _eri_order_1247 = (v_first), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1245, _eri_order_1246, _eri_order_1247));
    v_ignored = (_eri_order_1248 = ((v_routine)->f_edges), _eri_order_1249 = ((v_routine)->f_phase), _eri_order_1250 = (((int64_t)(v_arguments).count)), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1248, _eri_order_1249, _eri_order_1250));
    return v_result;
}

static eri_struct_compiler_u002e_u1_builder_u002e_InstId fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, int64_t v_op, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_arguments, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location, int64_t v_payload, int64_t v_extra) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1251;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1252;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_1253;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1254;
    int64_t _eri_order_1255;
    int64_t _eri_order_1256;
    int64_t _eri_order_1257;
    int64_t _eri_order_1258;
    int64_t _eri_order_1259;
    int64_t _eri_order_1260;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1261;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1262;
    int64_t _eri_order_1263;
    int64_t _eri_order_1264;
    int64_t _eri_order_1265;
    int64_t _eri_order_1266;
    int64_t _eri_order_1267;
    int64_t _eri_order_1268;
    int64_t _eri_order_1269;
    int64_t _eri_order_1270;
    int64_t _eri_order_1271;
    int64_t _eri_order_1272;
    int64_t _eri_order_1273;
    int64_t _eri_order_1274;
    int64_t _eri_order_1275;
    int64_t _eri_order_1276;
    int64_t _eri_order_1277;
    int64_t _eri_order_1278;
    int64_t _eri_order_1279;
    int64_t _eri_order_1280;
    int64_t _eri_order_1281;
    int64_t _eri_order_1282;
    int64_t _eri_order_1283;
    int64_t _eri_order_1284;
    int64_t _eri_order_1285;
    int64_t _eri_order_1286;
    int64_t _eri_order_1287;
    int64_t _eri_order_1288;
    int64_t _eri_order_1289;
    int64_t _eri_order_1290;
    int64_t _eri_order_1291;
    int64_t _eri_order_1292;
    int64_t _eri_order_1293;
    int64_t _eri_order_1294;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1295;
    int64_t _eri_order_1296;
    int64_t _eri_order_1297;
    int64_t _eri_order_1298;
    int64_t _eri_order_1299;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1300;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1301;
    int64_t _eri_order_1302;
    int64_t _eri_order_1303;
    int64_t _eri_order_1304;
    int64_t _eri_order_1305;
    int64_t _eri_order_1306;
    int64_t _eri_order_1307;
    int64_t _eri_order_1308;
    int64_t _eri_order_1309;
    int64_t _eri_order_1310;
    int64_t _eri_order_1311;
    int64_t _eri_order_1312;
    int64_t _eri_order_1313;
    int64_t _eri_order_1314;
    int64_t _eri_order_1315;
    int64_t _eri_order_1316;
    int64_t _eri_order_1317;
    int64_t _eri_order_1318;
    int64_t _eri_order_1319;
    int64_t _eri_order_1320;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1321;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1322;
    int64_t _eri_order_1323;
    int64_t _eri_order_1324;
    int64_t _eri_order_1325;
    int64_t _eri_order_1326;
    int64_t _eri_order_1327;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1328;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1329;
    int64_t _eri_order_1330;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1331;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1332;
    int64_t _eri_order_1333;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1334;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1335;
    int64_t _eri_order_1336;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1337;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1338;
    int64_t _eri_order_1339;
    int64_t _eri_order_1340;
    int64_t _eri_order_1341;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1342;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1343;
    int64_t _eri_order_1344;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1345;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1346;
    int64_t _eri_order_1347;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1348;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1349;
    int64_t _eri_order_1350;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1351;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1352;
    int64_t _eri_order_1353;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1354;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1355;
    int64_t _eri_order_1356;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1357;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1358;
    int64_t _eri_order_1359;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1360;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1361;
    int64_t _eri_order_1362;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1363;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1364;
    int64_t _eri_order_1365;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1366;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1367;
    int64_t _eri_order_1368;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1369;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1370;
    int64_t _eri_order_1371;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1372;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1373;
    int64_t _eri_order_1374;
    int64_t _eri_order_1375;
    int64_t _eri_order_1376;
    int64_t _eri_order_1377;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1378;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1379;
    int64_t _eri_order_1380;
    int64_t _eri_order_1381;
    int64_t _eri_order_1382;
    int64_t _eri_order_1383;
    int64_t _eri_order_1384;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1385;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1386;
    int64_t _eri_order_1387;
    int64_t _eri_order_1388;
    int64_t _eri_order_1389;
    int64_t _eri_order_1390;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1391;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1392;
    int64_t _eri_order_1393;
    int64_t _eri_order_1394;
    int64_t _eri_order_1395;
    int64_t _eri_order_1396;
    int64_t _eri_order_1397;
    int64_t _eri_order_1398;
    int64_t _eri_order_1399;
    int64_t _eri_order_1400;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1401;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1402;
    int64_t _eri_order_1403;
    int64_t _eri_order_1404;
    int64_t _eri_order_1405;
    int64_t _eri_order_1406;
    int64_t _eri_order_1407;
    int64_t _eri_order_1408;
    int64_t v_offset = (_eri_order_1251 = (v_routine), _eri_order_1252 = (v_block), fn_compiler_u002e_u1_builder_u002e_openBlock(_eri_order_1251, _eri_order_1252));
    (_eri_order_1253 = ((v_routine)->f_metadata), _eri_order_1254 = (v_location), fn_compiler_u002e_u1_meta_u002e_validLocation(_eri_order_1253, _eri_order_1254));
    if ((!fn_compiler_u002e_u1_ops_u002e_known(v_op))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 25));
    }
    int64_t v_count = fn_compiler_u002e_u1_ops_u002e_operands(v_op);
    if (((_eri_order_1255 = (v_count), _eri_order_1256 = (0), (_eri_order_1255 >= _eri_order_1256)) && (_eri_order_1257 = (((int64_t)(v_arguments).count)), _eri_order_1258 = (v_count), (_eri_order_1257 != _eri_order_1258)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x61, 0x72, 0x69, 0x74, 0x79, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 30));
    }
    int64_t v_index = 0;
    while ((_eri_order_1259 = (v_index), _eri_order_1260 = (((int64_t)(v_arguments).count)), (_eri_order_1259 < _eri_order_1260))) {
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_valueType = (_eri_order_1261 = (v_routine), _eri_order_1262 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_get(v_arguments, v_index)), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1261, _eri_order_1262));
        if (((_eri_order_1263 = (v_op), _eri_order_1264 = (8), (_eri_order_1263 != _eri_order_1264)) && (_eri_order_1265 = (v_op), _eri_order_1266 = (10), (_eri_order_1265 < _eri_order_1266)))) {
            if ((_eri_order_1267 = ((v_valueType).f_index), _eri_order_1270 = ((_eri_order_1268 = (v_op), _eri_order_1269 = (v_index), fn_compiler_u002e_u1_ops_u002e_operandType(_eri_order_1268, _eri_order_1269))), (_eri_order_1267 != _eri_order_1270))) {
                fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x6e, 0x64, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 25));
            }
        }
        v_index = (_eri_order_1271 = (v_index), _eri_order_1272 = (1), eri_iadd(_eri_order_1271, _eri_order_1272));
    }
    if ((((_eri_order_1273 = (v_op), _eri_order_1274 = (2), (_eri_order_1273 == _eri_order_1274)) && (_eri_order_1275 = (v_payload), _eri_order_1276 = (0), (_eri_order_1275 != _eri_order_1276))) && (_eri_order_1277 = (v_payload), _eri_order_1278 = (1), (_eri_order_1277 != _eri_order_1278)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x70, 0x72, 0x65, 0x64, 0x69, 0x63, 0x61, 0x74, 0x65, 0x20, 0x63, 0x6f, 0x6e, 0x73, 0x74, 0x61, 0x6e, 0x74}, 30));
    }
    if (((_eri_order_1279 = (v_op), _eri_order_1280 = (5), (_eri_order_1279 == _eri_order_1280)) && ((_eri_order_1281 = (v_payload), _eri_order_1282 = (1), (_eri_order_1281 < _eri_order_1282)) || (_eri_order_1283 = (v_payload), _eri_order_1284 = (4), (_eri_order_1283 > _eri_order_1284))))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x74, 0x72, 0x61, 0x70, 0x20, 0x63, 0x6f, 0x64, 0x65}, 21));
    }
    if (((_eri_order_1287 = ((_eri_order_1285 = (((v_routine)->f_instructions)->f_length), _eri_order_1286 = (10), eri_idiv(_eri_order_1285, _eri_order_1286))), _eri_order_1288 = (1048576), (_eri_order_1287 >= _eri_order_1288)) || (_eri_order_1289 = (fn_compiler_u002e_u1_ops_u002e_results(v_op)), _eri_order_1294 = ((_eri_order_1290 = (1048576), _eri_order_1293 = ((_eri_order_1291 = (((v_routine)->f_values)->f_length), _eri_order_1292 = (4), eri_idiv(_eri_order_1291, _eri_order_1292))), eri_isub(_eri_order_1290, _eri_order_1293))), (_eri_order_1289 > _eri_order_1294)))) {
        (_eri_order_1295 = ((v_routine)->f_owner), _eri_order_1296 = (1), _eri_order_1297 = (0), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_1295, _eri_order_1296, _eri_order_1297));
    }
    int64_t v_first = ((v_routine)->f_operands)->f_length;
    v_index = 0;
    while ((_eri_order_1298 = (v_index), _eri_order_1299 = (((int64_t)(v_arguments).count)), (_eri_order_1298 < _eri_order_1299))) {
        eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value = eri_list_compiler_u002e_u1_builder_u002e_ValueId_get(v_arguments, v_index);
        int64_t v_ignored = (_eri_order_1300 = ((v_routine)->f_operands), _eri_order_1301 = ((v_routine)->f_phase), _eri_order_1302 = ((v_value).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1300, _eri_order_1301, _eri_order_1302));
        v_index = (_eri_order_1303 = (v_index), _eri_order_1304 = (1), eri_iadd(_eri_order_1303, _eri_order_1304));
    }
    eri_struct_compiler_u002e_u1_builder_u002e_InstId v_result = (eri_struct_compiler_u002e_u1_builder_u002e_InstId){.f_owner = (v_routine)->f_key, .f_index = (_eri_order_1307 = ((_eri_order_1305 = (((v_routine)->f_instructions)->f_length), _eri_order_1306 = (10), eri_idiv(_eri_order_1305, _eri_order_1306))), _eri_order_1308 = (1), eri_iadd(_eri_order_1307, _eri_order_1308))};
    int64_t v_firstResult = 0;
    if ((_eri_order_1309 = (fn_compiler_u002e_u1_ops_u002e_results(v_op)), _eri_order_1310 = (0), (_eri_order_1309 > _eri_order_1310))) {
        v_firstResult = (_eri_order_1313 = ((_eri_order_1311 = (((v_routine)->f_values)->f_length), _eri_order_1312 = (4), eri_idiv(_eri_order_1311, _eri_order_1312))), _eri_order_1314 = (1), eri_iadd(_eri_order_1313, _eri_order_1314));
    }
    v_index = 0;
    while ((_eri_order_1315 = (v_index), _eri_order_1316 = (fn_compiler_u002e_u1_ops_u002e_results(v_op)), (_eri_order_1315 < _eri_order_1316))) {
        int64_t v_resultType = (_eri_order_1317 = (v_op), _eri_order_1318 = (v_index), fn_compiler_u002e_u1_ops_u002e_resultType(_eri_order_1317, _eri_order_1318));
        if ((_eri_order_1319 = (v_op), _eri_order_1320 = (11), (_eri_order_1319 == _eri_order_1320))) {
            v_resultType = (_eri_order_1321 = ((v_routine)->f_cells), _eri_order_1322 = ((v_routine)->f_phase), _eri_order_1327 = ((_eri_order_1325 = ((_eri_order_1323 = (v_payload), _eri_order_1324 = (1), eri_isub(_eri_order_1323, _eri_order_1324))), _eri_order_1326 = (2), eri_imul(_eri_order_1325, _eri_order_1326))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1321, _eri_order_1322, _eri_order_1327));
        }
        int64_t v_ignored = (_eri_order_1328 = ((v_routine)->f_values), _eri_order_1329 = ((v_routine)->f_phase), _eri_order_1330 = (v_resultType), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1328, _eri_order_1329, _eri_order_1330));
        v_ignored = (_eri_order_1331 = ((v_routine)->f_values), _eri_order_1332 = ((v_routine)->f_phase), _eri_order_1333 = (1), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1331, _eri_order_1332, _eri_order_1333));
        v_ignored = (_eri_order_1334 = ((v_routine)->f_values), _eri_order_1335 = ((v_routine)->f_phase), _eri_order_1336 = ((v_result).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1334, _eri_order_1335, _eri_order_1336));
        v_ignored = (_eri_order_1337 = ((v_routine)->f_values), _eri_order_1338 = ((v_routine)->f_phase), _eri_order_1339 = (v_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1337, _eri_order_1338, _eri_order_1339));
        v_index = (_eri_order_1340 = (v_index), _eri_order_1341 = (1), eri_iadd(_eri_order_1340, _eri_order_1341));
    }
    int64_t v_ignored = (_eri_order_1342 = ((v_routine)->f_instructions), _eri_order_1343 = ((v_routine)->f_phase), _eri_order_1344 = (v_op), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1342, _eri_order_1343, _eri_order_1344));
    v_ignored = (_eri_order_1345 = ((v_routine)->f_instructions), _eri_order_1346 = ((v_routine)->f_phase), _eri_order_1347 = ((v_block).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1345, _eri_order_1346, _eri_order_1347));
    v_ignored = (_eri_order_1348 = ((v_routine)->f_instructions), _eri_order_1349 = ((v_routine)->f_phase), _eri_order_1350 = (v_first), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1348, _eri_order_1349, _eri_order_1350));
    v_ignored = (_eri_order_1351 = ((v_routine)->f_instructions), _eri_order_1352 = ((v_routine)->f_phase), _eri_order_1353 = (((int64_t)(v_arguments).count)), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1351, _eri_order_1352, _eri_order_1353));
    v_ignored = (_eri_order_1354 = ((v_routine)->f_instructions), _eri_order_1355 = ((v_routine)->f_phase), _eri_order_1356 = (v_firstResult), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1354, _eri_order_1355, _eri_order_1356));
    v_ignored = (_eri_order_1357 = ((v_routine)->f_instructions), _eri_order_1358 = ((v_routine)->f_phase), _eri_order_1359 = (fn_compiler_u002e_u1_ops_u002e_results(v_op)), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1357, _eri_order_1358, _eri_order_1359));
    v_ignored = (_eri_order_1360 = ((v_routine)->f_instructions), _eri_order_1361 = ((v_routine)->f_phase), _eri_order_1362 = ((v_location).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1360, _eri_order_1361, _eri_order_1362));
    v_ignored = (_eri_order_1363 = ((v_routine)->f_instructions), _eri_order_1364 = ((v_routine)->f_phase), _eri_order_1365 = (v_payload), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1363, _eri_order_1364, _eri_order_1365));
    v_ignored = (_eri_order_1366 = ((v_routine)->f_instructions), _eri_order_1367 = ((v_routine)->f_phase), _eri_order_1368 = (v_extra), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1366, _eri_order_1367, _eri_order_1368));
    v_ignored = (_eri_order_1369 = ((v_routine)->f_instructions), _eri_order_1370 = ((v_routine)->f_phase), _eri_order_1371 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1369, _eri_order_1370, _eri_order_1371));
    if (fn_compiler_u002e_u1_ops_u002e_terminal(v_op)) {
        (_eri_order_1372 = ((v_routine)->f_blocks), _eri_order_1373 = ((v_routine)->f_phase), _eri_order_1376 = ((_eri_order_1374 = (v_offset), _eri_order_1375 = (4), eri_iadd(_eri_order_1374, _eri_order_1375))), _eri_order_1377 = ((v_result).f_index), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1372, _eri_order_1373, _eri_order_1376, _eri_order_1377));
    } else {
        int64_t v_previous = (_eri_order_1378 = ((v_routine)->f_blocks), _eri_order_1379 = ((v_routine)->f_phase), _eri_order_1382 = ((_eri_order_1380 = (v_offset), _eri_order_1381 = (3), eri_iadd(_eri_order_1380, _eri_order_1381))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1378, _eri_order_1379, _eri_order_1382));
        if ((_eri_order_1383 = (v_previous), _eri_order_1384 = (0), (_eri_order_1383 == _eri_order_1384))) {
            (_eri_order_1385 = ((v_routine)->f_blocks), _eri_order_1386 = ((v_routine)->f_phase), _eri_order_1389 = ((_eri_order_1387 = (v_offset), _eri_order_1388 = (2), eri_iadd(_eri_order_1387, _eri_order_1388))), _eri_order_1390 = ((v_result).f_index), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1385, _eri_order_1386, _eri_order_1389, _eri_order_1390));
        } else {
            (_eri_order_1391 = ((v_routine)->f_instructions), _eri_order_1392 = ((v_routine)->f_phase), _eri_order_1399 = ((_eri_order_1397 = ((_eri_order_1395 = ((_eri_order_1393 = (v_previous), _eri_order_1394 = (1), eri_isub(_eri_order_1393, _eri_order_1394))), _eri_order_1396 = (10), eri_imul(_eri_order_1395, _eri_order_1396))), _eri_order_1398 = (9), eri_iadd(_eri_order_1397, _eri_order_1398))), _eri_order_1400 = ((v_result).f_index), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1391, _eri_order_1392, _eri_order_1399, _eri_order_1400));
        }
        (_eri_order_1401 = ((v_routine)->f_blocks), _eri_order_1402 = ((v_routine)->f_phase), _eri_order_1405 = ((_eri_order_1403 = (v_offset), _eri_order_1404 = (3), eri_iadd(_eri_order_1403, _eri_order_1404))), _eri_order_1406 = ((v_result).f_index), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1401, _eri_order_1402, _eri_order_1405, _eri_order_1406));
    }
    (v_routine)->f_revision = (_eri_order_1407 = ((v_routine)->f_revision), _eri_order_1408 = (1), eri_iadd(_eri_order_1407, _eri_order_1408));
    return v_result;
}

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_result(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_InstId v_instruction, int64_t v_index) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1409;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId _eri_order_1410;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1411;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1412;
    int64_t _eri_order_1413;
    int64_t _eri_order_1414;
    int64_t _eri_order_1415;
    int64_t _eri_order_1416;
    int64_t _eri_order_1417;
    int64_t _eri_order_1418;
    int64_t _eri_order_1419;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1420;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1421;
    int64_t _eri_order_1422;
    int64_t _eri_order_1423;
    int64_t _eri_order_1424;
    int64_t _eri_order_1425;
    int64_t _eri_order_1426;
    int64_t v_offset = (_eri_order_1409 = (v_routine), _eri_order_1410 = (v_instruction), fn_compiler_u002e_u1_builder_u002e_instOffset(_eri_order_1409, _eri_order_1410));
    int64_t v_count = (_eri_order_1411 = ((v_routine)->f_instructions), _eri_order_1412 = ((v_routine)->f_phase), _eri_order_1415 = ((_eri_order_1413 = (v_offset), _eri_order_1414 = (5), eri_iadd(_eri_order_1413, _eri_order_1414))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1411, _eri_order_1412, _eri_order_1415));
    if (((_eri_order_1416 = (v_index), _eri_order_1417 = (0), (_eri_order_1416 < _eri_order_1417)) || (_eri_order_1418 = (v_index), _eri_order_1419 = (v_count), (_eri_order_1418 >= _eri_order_1419)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x20, 0x6f, 0x75, 0x74, 0x20, 0x6f, 0x66, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 41));
    }
    int64_t v_first = (_eri_order_1420 = ((v_routine)->f_instructions), _eri_order_1421 = ((v_routine)->f_phase), _eri_order_1424 = ((_eri_order_1422 = (v_offset), _eri_order_1423 = (4), eri_iadd(_eri_order_1422, _eri_order_1423))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1420, _eri_order_1421, _eri_order_1424));
    return (eri_struct_compiler_u002e_u1_builder_u002e_ValueId){.f_owner = (v_routine)->f_key, .f_index = (_eri_order_1425 = (v_first), _eri_order_1426 = (v_index), eri_iadd(_eri_order_1425, _eri_order_1426))};
}

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_integer(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, int64_t v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1427;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1428;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1429;
    int64_t _eri_order_1430;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1431;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1432;
    int64_t _eri_order_1433;
    int64_t _eri_order_1434;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId _eri_order_1435;
    int64_t _eri_order_1436;
    return (_eri_order_1427 = (v_routine), _eri_order_1435 = ((_eri_order_1428 = (v_routine), _eri_order_1429 = (v_block), _eri_order_1430 = (1), _eri_order_1431 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_1432 = (v_location), _eri_order_1433 = (v_value), _eri_order_1434 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1428, _eri_order_1429, _eri_order_1430, _eri_order_1431, _eri_order_1432, _eri_order_1433, _eri_order_1434))), _eri_order_1436 = (0), fn_compiler_u002e_u1_builder_u002e_result(_eri_order_1427, _eri_order_1435, _eri_order_1436));
}

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_predicate(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, bool v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1437;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1438;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1439;
    int64_t _eri_order_1440;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1441;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1442;
    int64_t _eri_order_1443;
    int64_t _eri_order_1444;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId _eri_order_1445;
    int64_t _eri_order_1446;
    int64_t v_bits = 0;
    if (v_value) {
        v_bits = 1;
    }
    return (_eri_order_1437 = (v_routine), _eri_order_1445 = ((_eri_order_1438 = (v_routine), _eri_order_1439 = (v_block), _eri_order_1440 = (2), _eri_order_1441 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_1442 = (v_location), _eri_order_1443 = (v_bits), _eri_order_1444 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1438, _eri_order_1439, _eri_order_1440, _eri_order_1441, _eri_order_1442, _eri_order_1443, _eri_order_1444))), _eri_order_1446 = (0), fn_compiler_u002e_u1_builder_u002e_result(_eri_order_1437, _eri_order_1445, _eri_order_1446));
}

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_floatBits(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, int64_t v_bits, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1447;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1448;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1449;
    int64_t _eri_order_1450;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1451;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1452;
    int64_t _eri_order_1453;
    int64_t _eri_order_1454;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId _eri_order_1455;
    int64_t _eri_order_1456;
    return (_eri_order_1447 = (v_routine), _eri_order_1455 = ((_eri_order_1448 = (v_routine), _eri_order_1449 = (v_block), _eri_order_1450 = (9), _eri_order_1451 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_1452 = (v_location), _eri_order_1453 = (v_bits), _eri_order_1454 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1448, _eri_order_1449, _eri_order_1450, _eri_order_1451, _eri_order_1452, _eri_order_1453, _eri_order_1454))), _eri_order_1456 = (0), fn_compiler_u002e_u1_builder_u002e_result(_eri_order_1447, _eri_order_1455, _eri_order_1456));
}

static eri_struct_compiler_u002e_u1_builder_u002e_Pair fn_compiler_u002e_u1_builder_u002e_addOverflow(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_first, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_second, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1457;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1458;
    int64_t _eri_order_1459;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1460;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1461;
    int64_t _eri_order_1462;
    int64_t _eri_order_1463;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1464;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId _eri_order_1465;
    int64_t _eri_order_1466;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1467;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId _eri_order_1468;
    int64_t _eri_order_1469;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId v_instruction = (_eri_order_1457 = (v_routine), _eri_order_1458 = (v_block), _eri_order_1459 = (3), _eri_order_1460 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(2, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_first, v_second})), _eri_order_1461 = (v_location), _eri_order_1462 = (0), _eri_order_1463 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1457, _eri_order_1458, _eri_order_1459, _eri_order_1460, _eri_order_1461, _eri_order_1462, _eri_order_1463));
    return (eri_struct_compiler_u002e_u1_builder_u002e_Pair){.f_value = (_eri_order_1464 = (v_routine), _eri_order_1465 = (v_instruction), _eri_order_1466 = (0), fn_compiler_u002e_u1_builder_u002e_result(_eri_order_1464, _eri_order_1465, _eri_order_1466)), .f_overflow = (_eri_order_1467 = (v_routine), _eri_order_1468 = (v_instruction), _eri_order_1469 = (1), fn_compiler_u002e_u1_builder_u002e_result(_eri_order_1467, _eri_order_1468, _eri_order_1469))};
}

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_negatePredicate(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1470;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1471;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1472;
    int64_t _eri_order_1473;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1474;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1475;
    int64_t _eri_order_1476;
    int64_t _eri_order_1477;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId _eri_order_1478;
    int64_t _eri_order_1479;
    return (_eri_order_1470 = (v_routine), _eri_order_1478 = ((_eri_order_1471 = (v_routine), _eri_order_1472 = (v_block), _eri_order_1473 = (4), _eri_order_1474 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_value})), _eri_order_1475 = (v_location), _eri_order_1476 = (0), _eri_order_1477 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1471, _eri_order_1472, _eri_order_1473, _eri_order_1474, _eri_order_1475, _eri_order_1476, _eri_order_1477))), _eri_order_1479 = (0), fn_compiler_u002e_u1_builder_u002e_result(_eri_order_1470, _eri_order_1478, _eri_order_1479));
}

static void fn_compiler_u002e_u1_builder_u002e_guard(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value, int64_t v_trap, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1480;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1481;
    int64_t _eri_order_1482;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1483;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1484;
    int64_t _eri_order_1485;
    int64_t _eri_order_1486;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId v_ignored = (_eri_order_1480 = (v_routine), _eri_order_1481 = (v_block), _eri_order_1482 = (5), _eri_order_1483 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_value})), _eri_order_1484 = (v_location), _eri_order_1485 = (v_trap), _eri_order_1486 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1480, _eri_order_1481, _eri_order_1482, _eri_order_1483, _eri_order_1484, _eri_order_1485, _eri_order_1486));
}

static void fn_compiler_u002e_u1_builder_u002e_jump_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_target, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_arguments, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1487;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1488;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_1489;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1490;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1491;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1492;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1493;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1494;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1495;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1496;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1497;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1498;
    int64_t _eri_order_1499;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1500;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1501;
    int64_t _eri_order_1502;
    int64_t _eri_order_1503;
    int64_t v_checked = (_eri_order_1487 = (v_routine), _eri_order_1488 = (v_block), fn_compiler_u002e_u1_builder_u002e_openBlock(_eri_order_1487, _eri_order_1488));
    (_eri_order_1489 = ((v_routine)->f_metadata), _eri_order_1490 = (v_location), fn_compiler_u002e_u1_meta_u002e_validLocation(_eri_order_1489, _eri_order_1490));
    (_eri_order_1491 = (v_routine), _eri_order_1492 = (v_target), _eri_order_1493 = (v_arguments), fn_compiler_u002e_u1_builder_u002e_checkEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(_eri_order_1491, _eri_order_1492, _eri_order_1493));
    int64_t v_edge = (_eri_order_1494 = (v_routine), _eri_order_1495 = (v_target), _eri_order_1496 = (v_arguments), fn_compiler_u002e_u1_builder_u002e_appendEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(_eri_order_1494, _eri_order_1495, _eri_order_1496));
    eri_struct_compiler_u002e_u1_builder_u002e_InstId v_ignored = (_eri_order_1497 = (v_routine), _eri_order_1498 = (v_block), _eri_order_1499 = (6), _eri_order_1500 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_1501 = (v_location), _eri_order_1502 = (v_edge), _eri_order_1503 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1497, _eri_order_1498, _eri_order_1499, _eri_order_1500, _eri_order_1501, _eri_order_1502, _eri_order_1503));
}

static void fn_compiler_u002e_u1_builder_u002e_branch_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_test, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_first, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_firstArguments, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_second, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_secondArguments, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1504;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1505;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_1506;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1507;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1508;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1509;
    int64_t _eri_order_1510;
    int64_t _eri_order_1511;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1512;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1513;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1514;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1515;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1516;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1517;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1518;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1519;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1520;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1521;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1522;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1523;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1524;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1525;
    int64_t _eri_order_1526;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1527;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1528;
    int64_t _eri_order_1529;
    int64_t _eri_order_1530;
    int64_t v_checked = (_eri_order_1504 = (v_routine), _eri_order_1505 = (v_block), fn_compiler_u002e_u1_builder_u002e_openBlock(_eri_order_1504, _eri_order_1505));
    (_eri_order_1506 = ((v_routine)->f_metadata), _eri_order_1507 = (v_location), fn_compiler_u002e_u1_meta_u002e_validLocation(_eri_order_1506, _eri_order_1507));
    eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_valueType = (_eri_order_1508 = (v_routine), _eri_order_1509 = (v_test), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1508, _eri_order_1509));
    if ((_eri_order_1510 = ((v_valueType).f_index), _eri_order_1511 = (1), (_eri_order_1510 != _eri_order_1511))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x62, 0x72, 0x61, 0x6e, 0x63, 0x68, 0x20, 0x72, 0x65, 0x71, 0x75, 0x69, 0x72, 0x65, 0x73, 0x20, 0x70, 0x72, 0x65, 0x64}, 24));
    }
    (_eri_order_1512 = (v_routine), _eri_order_1513 = (v_first), _eri_order_1514 = (v_firstArguments), fn_compiler_u002e_u1_builder_u002e_checkEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(_eri_order_1512, _eri_order_1513, _eri_order_1514));
    (_eri_order_1515 = (v_routine), _eri_order_1516 = (v_second), _eri_order_1517 = (v_secondArguments), fn_compiler_u002e_u1_builder_u002e_checkEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(_eri_order_1515, _eri_order_1516, _eri_order_1517));
    int64_t v_firstEdge = (_eri_order_1518 = (v_routine), _eri_order_1519 = (v_first), _eri_order_1520 = (v_firstArguments), fn_compiler_u002e_u1_builder_u002e_appendEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(_eri_order_1518, _eri_order_1519, _eri_order_1520));
    int64_t v_secondEdge = (_eri_order_1521 = (v_routine), _eri_order_1522 = (v_second), _eri_order_1523 = (v_secondArguments), fn_compiler_u002e_u1_builder_u002e_appendEdge_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId(_eri_order_1521, _eri_order_1522, _eri_order_1523));
    eri_struct_compiler_u002e_u1_builder_u002e_InstId v_ignored = (_eri_order_1524 = (v_routine), _eri_order_1525 = (v_block), _eri_order_1526 = (7), _eri_order_1527 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_test})), _eri_order_1528 = (v_location), _eri_order_1529 = (v_firstEdge), _eri_order_1530 = (v_secondEdge), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1524, _eri_order_1525, _eri_order_1526, _eri_order_1527, _eri_order_1528, _eri_order_1529, _eri_order_1530));
}

static void fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_list_compiler_u002e_u1_builder_u002e_ValueId v_values, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1531;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1532;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_1533;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1534;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_1535;
    int64_t _eri_order_1536;
    int64_t _eri_order_1537;
    int64_t _eri_order_1538;
    int64_t _eri_order_1539;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1540;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1541;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_1542;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1543;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_1544;
    int64_t _eri_order_1545;
    int64_t _eri_order_1546;
    int64_t _eri_order_1547;
    int64_t _eri_order_1548;
    int64_t _eri_order_1549;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1550;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1551;
    int64_t _eri_order_1552;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1553;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1554;
    int64_t _eri_order_1555;
    int64_t _eri_order_1556;
    int64_t v_checked = (_eri_order_1531 = (v_routine), _eri_order_1532 = (v_block), fn_compiler_u002e_u1_builder_u002e_openBlock(_eri_order_1531, _eri_order_1532));
    int64_t v_count = (_eri_order_1533 = ((v_routine)->f_metadata), _eri_order_1534 = ((v_routine)->f_phase), _eri_order_1535 = ((v_routine)->f_signature), fn_compiler_u002e_u1_meta_u002e_resultCount(_eri_order_1533, _eri_order_1534, _eri_order_1535));
    if ((_eri_order_1536 = (((int64_t)(v_values).count)), _eri_order_1537 = (v_count), (_eri_order_1536 != _eri_order_1537))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x72, 0x65, 0x74, 0x75, 0x72, 0x6e, 0x20, 0x61, 0x72, 0x69, 0x74, 0x79, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 25));
    }
    int64_t v_index = 0;
    while ((_eri_order_1538 = (v_index), _eri_order_1539 = (v_count), (_eri_order_1538 < _eri_order_1539))) {
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_valueType = (_eri_order_1540 = (v_routine), _eri_order_1541 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_get(v_values, v_index)), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1540, _eri_order_1541));
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_expected = (_eri_order_1542 = ((v_routine)->f_metadata), _eri_order_1543 = ((v_routine)->f_phase), _eri_order_1544 = ((v_routine)->f_signature), _eri_order_1545 = (v_index), fn_compiler_u002e_u1_meta_u002e_resultType(_eri_order_1542, _eri_order_1543, _eri_order_1544, _eri_order_1545));
        if ((_eri_order_1546 = ((v_valueType).f_index), _eri_order_1547 = ((v_expected).f_index), (_eri_order_1546 != _eri_order_1547))) {
            fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x72, 0x65, 0x74, 0x75, 0x72, 0x6e, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 24));
        }
        v_index = (_eri_order_1548 = (v_index), _eri_order_1549 = (1), eri_iadd(_eri_order_1548, _eri_order_1549));
    }
    eri_struct_compiler_u002e_u1_builder_u002e_InstId v_ignored = (_eri_order_1550 = (v_routine), _eri_order_1551 = (v_block), _eri_order_1552 = (8), _eri_order_1553 = (v_values), _eri_order_1554 = (v_location), _eri_order_1555 = (0), _eri_order_1556 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1550, _eri_order_1551, _eri_order_1552, _eri_order_1553, _eri_order_1554, _eri_order_1555, _eri_order_1556));
}

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_edgeArgument(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, int64_t v_edge, int64_t v_index) {
    int64_t _eri_order_1557;
    int64_t _eri_order_1558;
    int64_t _eri_order_1559;
    int64_t _eri_order_1560;
    int64_t _eri_order_1561;
    int64_t _eri_order_1562;
    int64_t _eri_order_1563;
    int64_t _eri_order_1564;
    int64_t _eri_order_1565;
    int64_t _eri_order_1566;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1567;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1568;
    int64_t _eri_order_1569;
    int64_t _eri_order_1570;
    int64_t _eri_order_1571;
    int64_t _eri_order_1572;
    int64_t _eri_order_1573;
    int64_t _eri_order_1574;
    int64_t _eri_order_1575;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1576;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1577;
    int64_t _eri_order_1578;
    int64_t _eri_order_1579;
    int64_t _eri_order_1580;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1581;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1582;
    int64_t _eri_order_1583;
    int64_t _eri_order_1584;
    int64_t _eri_order_1585;
    if (((_eri_order_1557 = (v_edge), _eri_order_1558 = (1), (_eri_order_1557 < _eri_order_1558)) || (_eri_order_1559 = (v_edge), _eri_order_1562 = ((_eri_order_1560 = (((v_routine)->f_edges)->f_length), _eri_order_1561 = (3), eri_idiv(_eri_order_1560, _eri_order_1561))), (_eri_order_1559 > _eri_order_1562)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x65, 0x64, 0x67, 0x65}, 16));
    }
    int64_t v_offset = (_eri_order_1565 = ((_eri_order_1563 = (v_edge), _eri_order_1564 = (1), eri_isub(_eri_order_1563, _eri_order_1564))), _eri_order_1566 = (3), eri_imul(_eri_order_1565, _eri_order_1566));
    int64_t v_count = (_eri_order_1567 = ((v_routine)->f_edges), _eri_order_1568 = ((v_routine)->f_phase), _eri_order_1571 = ((_eri_order_1569 = (v_offset), _eri_order_1570 = (2), eri_iadd(_eri_order_1569, _eri_order_1570))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1567, _eri_order_1568, _eri_order_1571));
    if (((_eri_order_1572 = (v_index), _eri_order_1573 = (0), (_eri_order_1572 < _eri_order_1573)) || (_eri_order_1574 = (v_index), _eri_order_1575 = (v_count), (_eri_order_1574 >= _eri_order_1575)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x65, 0x64, 0x67, 0x65, 0x20, 0x61, 0x72, 0x67, 0x75, 0x6d, 0x65, 0x6e, 0x74, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78, 0x20, 0x6f, 0x75, 0x74, 0x20, 0x6f, 0x66, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 36));
    }
    int64_t v_first = (_eri_order_1576 = ((v_routine)->f_edges), _eri_order_1577 = ((v_routine)->f_phase), _eri_order_1580 = ((_eri_order_1578 = (v_offset), _eri_order_1579 = (1), eri_iadd(_eri_order_1578, _eri_order_1579))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1576, _eri_order_1577, _eri_order_1580));
    return (eri_struct_compiler_u002e_u1_builder_u002e_ValueId){.f_owner = (v_routine)->f_key, .f_index = (_eri_order_1581 = ((v_routine)->f_arguments), _eri_order_1582 = ((v_routine)->f_phase), _eri_order_1585 = ((_eri_order_1583 = (v_first), _eri_order_1584 = (v_index), eri_iadd(_eri_order_1583, _eri_order_1584))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1581, _eri_order_1582, _eri_order_1585))};
}

static int64_t fn_compiler_u002e_u1_builder_u002e_cellOffset(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_CellId v_cell) {
    int64_t _eri_order_1586;
    int64_t _eri_order_1587;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_1588;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_1589;
    int64_t _eri_order_1590;
    int64_t _eri_order_1591;
    int64_t _eri_order_1592;
    int64_t _eri_order_1593;
    int64_t _eri_order_1594;
    int64_t _eri_order_1595;
    int64_t _eri_order_1596;
    int64_t _eri_order_1597;
    int64_t _eri_order_1598;
    int64_t _eri_order_1599;
    if (((((_eri_order_1586 = ((v_routine)->f_state), _eri_order_1587 = (2), (_eri_order_1586 == _eri_order_1587)) || (_eri_order_1588 = ((v_cell).f_owner), _eri_order_1589 = ((v_routine)->f_key), (!(_eri_order_1588 == _eri_order_1589)))) || (_eri_order_1590 = ((v_cell).f_index), _eri_order_1591 = (1), (_eri_order_1590 < _eri_order_1591))) || (_eri_order_1592 = ((v_cell).f_index), _eri_order_1595 = ((_eri_order_1593 = (((v_routine)->f_cells)->f_length), _eri_order_1594 = (2), eri_idiv(_eri_order_1593, _eri_order_1594))), (_eri_order_1592 > _eri_order_1595)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x43, 0x65, 0x6c, 0x6c, 0x49, 0x64}, 29));
    }
    return (_eri_order_1598 = ((_eri_order_1596 = ((v_cell).f_index), _eri_order_1597 = (1), eri_isub(_eri_order_1596, _eri_order_1597))), _eri_order_1599 = (2), eri_imul(_eri_order_1598, _eri_order_1599));
}

static eri_struct_compiler_u002e_u1_builder_u002e_CellId fn_compiler_u002e_u1_builder_u002e_cell(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_valueType) {
    int64_t _eri_order_1600;
    int64_t _eri_order_1601;
    int64_t _eri_order_1602;
    int64_t _eri_order_1603;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1604;
    int64_t _eri_order_1605;
    int64_t _eri_order_1606;
    int64_t _eri_order_1607;
    int64_t _eri_order_1608;
    int64_t _eri_order_1609;
    int64_t _eri_order_1610;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1611;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1612;
    int64_t _eri_order_1613;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1614;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1615;
    int64_t _eri_order_1616;
    int64_t _eri_order_1617;
    int64_t _eri_order_1618;
    fn_compiler_u002e_u1_builder_u002e_mutable(v_routine);
    fn_compiler_u002e_u1_meta_u002e_validType(v_valueType);
    if ((_eri_order_1602 = ((_eri_order_1600 = (((v_routine)->f_cells)->f_length), _eri_order_1601 = (2), eri_idiv(_eri_order_1600, _eri_order_1601))), _eri_order_1603 = (65536), (_eri_order_1602 >= _eri_order_1603))) {
        (_eri_order_1604 = ((v_routine)->f_owner), _eri_order_1605 = (1), _eri_order_1606 = (0), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_1604, _eri_order_1605, _eri_order_1606));
    }
    eri_struct_compiler_u002e_u1_builder_u002e_CellId v_value = (eri_struct_compiler_u002e_u1_builder_u002e_CellId){.f_owner = (v_routine)->f_key, .f_index = (_eri_order_1609 = ((_eri_order_1607 = (((v_routine)->f_cells)->f_length), _eri_order_1608 = (2), eri_idiv(_eri_order_1607, _eri_order_1608))), _eri_order_1610 = (1), eri_iadd(_eri_order_1609, _eri_order_1610))};
    int64_t v_ignored = (_eri_order_1611 = ((v_routine)->f_cells), _eri_order_1612 = ((v_routine)->f_phase), _eri_order_1613 = ((v_valueType).f_index), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1611, _eri_order_1612, _eri_order_1613));
    v_ignored = (_eri_order_1614 = ((v_routine)->f_cells), _eri_order_1615 = ((v_routine)->f_phase), _eri_order_1616 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1614, _eri_order_1615, _eri_order_1616));
    (v_routine)->f_revision = (_eri_order_1617 = ((v_routine)->f_revision), _eri_order_1618 = (1), eri_iadd(_eri_order_1617, _eri_order_1618));
    return v_value;
}

static void fn_compiler_u002e_u1_builder_u002e_initialize(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_CellId v_cell, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1619;
    eri_struct_compiler_u002e_u1_builder_u002e_CellId _eri_order_1620;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1621;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1622;
    int64_t _eri_order_1623;
    int64_t _eri_order_1624;
    int64_t _eri_order_1625;
    int64_t _eri_order_1626;
    int64_t _eri_order_1627;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1628;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1629;
    int64_t _eri_order_1630;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1631;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1632;
    int64_t _eri_order_1633;
    int64_t _eri_order_1634;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1635;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1636;
    int64_t _eri_order_1637;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1638;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1639;
    int64_t _eri_order_1640;
    int64_t _eri_order_1641;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1642;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1643;
    int64_t _eri_order_1644;
    int64_t _eri_order_1645;
    int64_t _eri_order_1646;
    int64_t _eri_order_1647;
    int64_t v_offset = (_eri_order_1619 = (v_routine), _eri_order_1620 = (v_cell), fn_compiler_u002e_u1_builder_u002e_cellOffset(_eri_order_1619, _eri_order_1620));
    if ((_eri_order_1626 = ((_eri_order_1621 = ((v_routine)->f_cells), _eri_order_1622 = ((v_routine)->f_phase), _eri_order_1625 = ((_eri_order_1623 = (v_offset), _eri_order_1624 = (1), eri_iadd(_eri_order_1623, _eri_order_1624))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1621, _eri_order_1622, _eri_order_1625))), _eri_order_1627 = (0), (_eri_order_1626 != _eri_order_1627))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x64, 0x75, 0x70, 0x6c, 0x69, 0x63, 0x61, 0x74, 0x65, 0x20, 0x63, 0x65, 0x6c, 0x6c, 0x20, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x61, 0x6c, 0x69, 0x7a, 0x65, 0x72}, 26));
    }
    if ((_eri_order_1630 = (((_eri_order_1628 = (v_routine), _eri_order_1629 = (v_value), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1628, _eri_order_1629))).f_index), _eri_order_1634 = ((_eri_order_1631 = ((v_routine)->f_cells), _eri_order_1632 = ((v_routine)->f_phase), _eri_order_1633 = (v_offset), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1631, _eri_order_1632, _eri_order_1633))), (_eri_order_1630 != _eri_order_1634))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x63, 0x65, 0x6c, 0x6c, 0x20, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x61, 0x6c, 0x69, 0x7a, 0x65, 0x72, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 30));
    }
    eri_struct_compiler_u002e_u1_builder_u002e_InstId v_instruction = (_eri_order_1635 = (v_routine), _eri_order_1636 = (v_block), _eri_order_1637 = (10), _eri_order_1638 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_value})), _eri_order_1639 = (v_location), _eri_order_1640 = ((v_cell).f_index), _eri_order_1641 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1635, _eri_order_1636, _eri_order_1637, _eri_order_1638, _eri_order_1639, _eri_order_1640, _eri_order_1641));
    (_eri_order_1642 = ((v_routine)->f_cells), _eri_order_1643 = ((v_routine)->f_phase), _eri_order_1646 = ((_eri_order_1644 = (v_offset), _eri_order_1645 = (1), eri_iadd(_eri_order_1644, _eri_order_1645))), _eri_order_1647 = ((v_instruction).f_index), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1642, _eri_order_1643, _eri_order_1646, _eri_order_1647));
}

static eri_struct_compiler_u002e_u1_builder_u002e_ValueId fn_compiler_u002e_u1_builder_u002e_readCell(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_CellId v_cell, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1648;
    eri_struct_compiler_u002e_u1_builder_u002e_CellId _eri_order_1649;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1650;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1651;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1652;
    int64_t _eri_order_1653;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1654;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1655;
    int64_t _eri_order_1656;
    int64_t _eri_order_1657;
    eri_struct_compiler_u002e_u1_builder_u002e_InstId _eri_order_1658;
    int64_t _eri_order_1659;
    int64_t v_checked = (_eri_order_1648 = (v_routine), _eri_order_1649 = (v_cell), fn_compiler_u002e_u1_builder_u002e_cellOffset(_eri_order_1648, _eri_order_1649));
    return (_eri_order_1650 = (v_routine), _eri_order_1658 = ((_eri_order_1651 = (v_routine), _eri_order_1652 = (v_block), _eri_order_1653 = (11), _eri_order_1654 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_1655 = (v_location), _eri_order_1656 = ((v_cell).f_index), _eri_order_1657 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1651, _eri_order_1652, _eri_order_1653, _eri_order_1654, _eri_order_1655, _eri_order_1656, _eri_order_1657))), _eri_order_1659 = (0), fn_compiler_u002e_u1_builder_u002e_result(_eri_order_1650, _eri_order_1658, _eri_order_1659));
}

static void fn_compiler_u002e_u1_builder_u002e_writeCell(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_block, eri_struct_compiler_u002e_u1_builder_u002e_CellId v_cell, eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_value, eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1660;
    eri_struct_compiler_u002e_u1_builder_u002e_CellId _eri_order_1661;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1662;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1663;
    int64_t _eri_order_1664;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1665;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1666;
    int64_t _eri_order_1667;
    int64_t _eri_order_1668;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1669;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1670;
    int64_t _eri_order_1671;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1672;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_1673;
    int64_t _eri_order_1674;
    int64_t _eri_order_1675;
    int64_t v_offset = (_eri_order_1660 = (v_routine), _eri_order_1661 = (v_cell), fn_compiler_u002e_u1_builder_u002e_cellOffset(_eri_order_1660, _eri_order_1661));
    if ((_eri_order_1664 = (((_eri_order_1662 = (v_routine), _eri_order_1663 = (v_value), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1662, _eri_order_1663))).f_index), _eri_order_1668 = ((_eri_order_1665 = ((v_routine)->f_cells), _eri_order_1666 = ((v_routine)->f_phase), _eri_order_1667 = (v_offset), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1665, _eri_order_1666, _eri_order_1667))), (_eri_order_1664 != _eri_order_1668))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x63, 0x65, 0x6c, 0x6c, 0x20, 0x77, 0x72, 0x69, 0x74, 0x65, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 24));
    }
    eri_struct_compiler_u002e_u1_builder_u002e_InstId v_ignored = (_eri_order_1669 = (v_routine), _eri_order_1670 = (v_block), _eri_order_1671 = (12), _eri_order_1672 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_value})), _eri_order_1673 = (v_location), _eri_order_1674 = ((v_cell).f_index), _eri_order_1675 = (0), fn_compiler_u002e_u1_builder_u002e_append_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_Int_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId_u0024_Int_u0024_Int(_eri_order_1669, _eri_order_1670, _eri_order_1671, _eri_order_1672, _eri_order_1673, _eri_order_1674, _eri_order_1675));
}

static void fn_compiler_u002e_u1_builder_u002e_complete(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine) {
    int64_t _eri_order_1676;
    int64_t _eri_order_1677;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_1678;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1679;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_1680;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1681;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1682;
    int64_t _eri_order_1683;
    int64_t _eri_order_1684;
    int64_t _eri_order_1685;
    int64_t _eri_order_1686;
    int64_t _eri_order_1687;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1688;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_1689;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_1690;
    int64_t _eri_order_1691;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_1692;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_1693;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1694;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_1695;
    int64_t _eri_order_1696;
    int64_t _eri_order_1697;
    int64_t _eri_order_1698;
    int64_t _eri_order_1699;
    int64_t _eri_order_1700;
    int64_t _eri_order_1701;
    int64_t _eri_order_1702;
    int64_t _eri_order_1703;
    int64_t _eri_order_1704;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1705;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1706;
    int64_t _eri_order_1707;
    int64_t _eri_order_1708;
    int64_t _eri_order_1709;
    int64_t _eri_order_1710;
    int64_t _eri_order_1711;
    int64_t _eri_order_1712;
    int64_t _eri_order_1713;
    int64_t _eri_order_1714;
    int64_t _eri_order_1715;
    fn_compiler_u002e_u1_builder_u002e_mutable(v_routine);
    if ((_eri_order_1676 = (((v_routine)->f_blocks)->f_length), _eri_order_1677 = (0), (_eri_order_1676 == _eri_order_1677))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x66, 0x75, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x68, 0x61, 0x73, 0x20, 0x6e, 0x6f, 0x20, 0x65, 0x6e, 0x74, 0x72, 0x79}, 25));
    }
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_entry = (eri_struct_compiler_u002e_u1_builder_u002e_BlockId){.f_owner = (v_routine)->f_key, .f_index = 1};
    int64_t v_count = (_eri_order_1678 = ((v_routine)->f_metadata), _eri_order_1679 = ((v_routine)->f_phase), _eri_order_1680 = ((v_routine)->f_signature), fn_compiler_u002e_u1_meta_u002e_parameterCount(_eri_order_1678, _eri_order_1679, _eri_order_1680));
    if ((_eri_order_1684 = ((_eri_order_1681 = ((v_routine)->f_blocks), _eri_order_1682 = ((v_routine)->f_phase), _eri_order_1683 = (1), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1681, _eri_order_1682, _eri_order_1683))), _eri_order_1685 = (v_count), (_eri_order_1684 != _eri_order_1685))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x65, 0x6e, 0x74, 0x72, 0x79, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 28));
    }
    int64_t v_index = 0;
    while ((_eri_order_1686 = (v_index), _eri_order_1687 = (v_count), (_eri_order_1686 < _eri_order_1687))) {
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_actual = (_eri_order_1688 = (v_routine), _eri_order_1692 = ((_eri_order_1689 = (v_routine), _eri_order_1690 = (v_entry), _eri_order_1691 = (v_index), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_1689, _eri_order_1690, _eri_order_1691))), fn_compiler_u002e_u1_builder_u002e_valueType(_eri_order_1688, _eri_order_1692));
        eri_struct_compiler_u002e_u1_meta_u002e_TypeId v_expected = (_eri_order_1693 = ((v_routine)->f_metadata), _eri_order_1694 = ((v_routine)->f_phase), _eri_order_1695 = ((v_routine)->f_signature), _eri_order_1696 = (v_index), fn_compiler_u002e_u1_meta_u002e_parameterType(_eri_order_1693, _eri_order_1694, _eri_order_1695, _eri_order_1696));
        if ((_eri_order_1697 = ((v_actual).f_index), _eri_order_1698 = ((v_expected).f_index), (_eri_order_1697 != _eri_order_1698))) {
            fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x55, 0x31, 0x61, 0x20, 0x65, 0x6e, 0x74, 0x72, 0x79, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 23));
        }
        v_index = (_eri_order_1699 = (v_index), _eri_order_1700 = (1), eri_iadd(_eri_order_1699, _eri_order_1700));
    }
    v_index = 0;
    while ((_eri_order_1701 = (v_index), _eri_order_1704 = ((_eri_order_1702 = (((v_routine)->f_blocks)->f_length), _eri_order_1703 = (5), eri_idiv(_eri_order_1702, _eri_order_1703))), (_eri_order_1701 < _eri_order_1704))) {
        if ((_eri_order_1712 = ((_eri_order_1705 = ((v_routine)->f_blocks), _eri_order_1706 = ((v_routine)->f_phase), _eri_order_1711 = ((_eri_order_1709 = ((_eri_order_1707 = (v_index), _eri_order_1708 = (5), eri_imul(_eri_order_1707, _eri_order_1708))), _eri_order_1710 = (4), eri_iadd(_eri_order_1709, _eri_order_1710))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1705, _eri_order_1706, _eri_order_1711))), _eri_order_1713 = (0), (_eri_order_1712 == _eri_order_1713))) {
            fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x74, 0x65, 0x72, 0x6d, 0x69, 0x6e, 0x61, 0x74, 0x65, 0x64, 0x20, 0x55, 0x31, 0x61, 0x20, 0x62, 0x6c, 0x6f, 0x63, 0x6b}, 22));
        }
        v_index = (_eri_order_1714 = (v_index), _eri_order_1715 = (1), eri_iadd(_eri_order_1714, _eri_order_1715));
    }
    fn_compiler_u002e_u1_words_u002e_freeze((v_routine)->f_blocks);
    fn_compiler_u002e_u1_words_u002e_freeze((v_routine)->f_values);
    fn_compiler_u002e_u1_words_u002e_freeze((v_routine)->f_instructions);
    fn_compiler_u002e_u1_words_u002e_freeze((v_routine)->f_operands);
    fn_compiler_u002e_u1_words_u002e_freeze((v_routine)->f_edges);
    fn_compiler_u002e_u1_words_u002e_freeze((v_routine)->f_arguments);
    fn_compiler_u002e_u1_words_u002e_freeze((v_routine)->f_cells);
    (v_routine)->f_state = 1;
}

static void fn_compiler_u002e_u1_builder_u002e_close(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine) {
    int64_t _eri_order_1716;
    int64_t _eri_order_1717;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation _eri_order_1718;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation _eri_order_1719;
    if ((_eri_order_1716 = ((v_routine)->f_state), _eri_order_1717 = (2), (_eri_order_1716 == _eri_order_1717))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x64, 0x6f, 0x75, 0x62, 0x6c, 0x65, 0x20, 0x63, 0x6c, 0x6f, 0x73, 0x65, 0x20, 0x6f, 0x66, 0x20, 0x55, 0x31, 0x61, 0x20, 0x66, 0x75, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e}, 28));
    }
    (v_routine)->f_state = 2;
    fn_compiler_u002e_u1_words_u002e_close((v_routine)->f_blocks);
    fn_compiler_u002e_u1_words_u002e_close((v_routine)->f_values);
    fn_compiler_u002e_u1_words_u002e_close((v_routine)->f_instructions);
    fn_compiler_u002e_u1_words_u002e_close((v_routine)->f_operands);
    fn_compiler_u002e_u1_words_u002e_close((v_routine)->f_edges);
    fn_compiler_u002e_u1_words_u002e_close((v_routine)->f_arguments);
    fn_compiler_u002e_u1_words_u002e_close((v_routine)->f_cells);
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation v_control = (v_routine)->f_control;
    (v_routine)->f_control = (eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false};
    if ((_eri_order_1718 = (v_control), _eri_order_1719 = ((eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation){.has=false}), (!eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_eq(_eri_order_1718, _eri_order_1719)))) {
        fn_compiler_u002e_u1_budget_u002e_release(eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Allocation_get(v_control));
    }
}

static eri_struct_compiler_u002e_u1_dominance_u002e_Graph * fn_compiler_u002e_u1_dominance_u002e_create(eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1720;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1721;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1722;
    int64_t _eri_order_1723;
    if ((_eri_order_1720 = ((v_phase)->f_owner), _eri_order_1721 = (v_owner), (!(_eri_order_1720 == _eri_order_1721)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x6e, 0x63, 0x65, 0x20, 0x70, 0x68, 0x61, 0x73, 0x65}, 23));
    }
    return eri_identity_compiler_u002e_u1_dominance_u002e_Graph_new((eri_struct_compiler_u002e_u1_dominance_u002e_Graph){.f_data = (_eri_order_1722 = (v_owner), _eri_order_1723 = (33554432), fn_compiler_u002e_u1_words_u002e_create(_eri_order_1722, _eri_order_1723)), .f_phase = v_phase, .f_blocks = 0, .f_edges = 0, .f_edgeBase = 0, .f_stackBase = 0, .f_reachable = 0, .f_reachableEdges = 0, .f_visits = 0, .f_visitLimit = 0, .f_prepared = false, .f_state = 0});
}

static int64_t fn_compiler_u002e_u1_dominance_u002e_zeros(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_count) {
    int64_t _eri_order_1724;
    int64_t _eri_order_1725;
    int64_t _eri_order_1726;
    int64_t _eri_order_1727;
    int64_t _eri_order_1728;
    int64_t _eri_order_1729;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1730;
    int64_t _eri_order_1731;
    int64_t _eri_order_1732;
    int64_t _eri_order_1733;
    int64_t _eri_order_1734;
    int64_t _eri_order_1735;
    int64_t _eri_order_1736;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1737;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1738;
    int64_t _eri_order_1739;
    int64_t _eri_order_1740;
    int64_t _eri_order_1741;
    if (((_eri_order_1724 = (v_count), _eri_order_1725 = (0), (_eri_order_1724 < _eri_order_1725)) || (_eri_order_1726 = (v_count), _eri_order_1729 = ((_eri_order_1727 = (((v_graph)->f_data)->f_limit), _eri_order_1728 = (((v_graph)->f_data)->f_length), eri_isub(_eri_order_1727, _eri_order_1728))), (_eri_order_1726 > _eri_order_1729)))) {
        (_eri_order_1730 = (((v_graph)->f_phase)->f_owner), _eri_order_1731 = (v_count), _eri_order_1734 = ((_eri_order_1732 = (((v_graph)->f_data)->f_limit), _eri_order_1733 = (((v_graph)->f_data)->f_length), eri_isub(_eri_order_1732, _eri_order_1733))), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_1730, _eri_order_1731, _eri_order_1734));
    }
    int64_t v_first = ((v_graph)->f_data)->f_length;
    int64_t v_index = 0;
    while ((_eri_order_1735 = (v_index), _eri_order_1736 = (v_count), (_eri_order_1735 < _eri_order_1736))) {
        int64_t v_ignored = (_eri_order_1737 = ((v_graph)->f_data), _eri_order_1738 = ((v_graph)->f_phase), _eri_order_1739 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_1737, _eri_order_1738, _eri_order_1739));
        v_index = (_eri_order_1740 = (v_index), _eri_order_1741 = (1), eri_iadd(_eri_order_1740, _eri_order_1741));
    }
    return v_first;
}

static void fn_compiler_u002e_u1_dominance_u002e_prepare(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_blocks, int64_t v_edges) {
    int64_t _eri_order_1742;
    int64_t _eri_order_1743;
    int64_t _eri_order_1744;
    int64_t _eri_order_1745;
    int64_t _eri_order_1746;
    int64_t _eri_order_1747;
    int64_t _eri_order_1748;
    int64_t _eri_order_1749;
    int64_t _eri_order_1750;
    int64_t _eri_order_1751;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1752;
    int64_t _eri_order_1753;
    int64_t _eri_order_1754;
    int64_t _eri_order_1755;
    int64_t _eri_order_1756;
    int64_t _eri_order_1757;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1758;
    int64_t _eri_order_1759;
    int64_t _eri_order_1760;
    int64_t _eri_order_1761;
    int64_t _eri_order_1762;
    int64_t _eri_order_1763;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1764;
    int64_t _eri_order_1765;
    int64_t _eri_order_1766;
    int64_t _eri_order_1767;
    int64_t _eri_order_1768;
    int64_t _eri_order_1769;
    int64_t _eri_order_1770;
    int64_t _eri_order_1771;
    int64_t _eri_order_1772;
    int64_t _eri_order_1773;
    int64_t _eri_order_1774;
    int64_t _eri_order_1775;
    int64_t _eri_order_1776;
    int64_t _eri_order_1777;
    int64_t _eri_order_1778;
    int64_t _eri_order_1779;
    int64_t _eri_order_1780;
    int64_t _eri_order_1781;
    if (((((((v_graph)->f_prepared || (_eri_order_1742 = (((v_graph)->f_data)->f_length), _eri_order_1743 = (0), (_eri_order_1742 != _eri_order_1743))) || (_eri_order_1744 = (v_blocks), _eri_order_1745 = (1), (_eri_order_1744 < _eri_order_1745))) || (_eri_order_1746 = (v_blocks), _eri_order_1747 = (65536), (_eri_order_1746 > _eri_order_1747))) || (_eri_order_1748 = (v_edges), _eri_order_1749 = (0), (_eri_order_1748 < _eri_order_1749))) || (_eri_order_1750 = (v_edges), _eri_order_1751 = (262144), (_eri_order_1750 > _eri_order_1751)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x6e, 0x63, 0x65, 0x20, 0x67, 0x72, 0x61, 0x70, 0x68, 0x20, 0x73, 0x68, 0x61, 0x70, 0x65}, 29));
    }
    (v_graph)->f_blocks = v_blocks;
    (v_graph)->f_edges = v_edges;
    int64_t v_ignored = (_eri_order_1752 = (v_graph), _eri_order_1757 = ((_eri_order_1755 = ((_eri_order_1753 = (v_blocks), _eri_order_1754 = (1), eri_iadd(_eri_order_1753, _eri_order_1754))), _eri_order_1756 = (11), eri_imul(_eri_order_1755, _eri_order_1756))), fn_compiler_u002e_u1_dominance_u002e_zeros(_eri_order_1752, _eri_order_1757));
    (v_graph)->f_edgeBase = (_eri_order_1758 = (v_graph), _eri_order_1763 = ((_eri_order_1761 = ((_eri_order_1759 = (v_edges), _eri_order_1760 = (1), eri_iadd(_eri_order_1759, _eri_order_1760))), _eri_order_1762 = (4), eri_imul(_eri_order_1761, _eri_order_1762))), fn_compiler_u002e_u1_dominance_u002e_zeros(_eri_order_1758, _eri_order_1763));
    (v_graph)->f_stackBase = (_eri_order_1764 = (v_graph), _eri_order_1767 = ((_eri_order_1765 = (v_blocks), _eri_order_1766 = (1), eri_iadd(_eri_order_1765, _eri_order_1766))), fn_compiler_u002e_u1_dominance_u002e_zeros(_eri_order_1764, _eri_order_1767));
    int64_t v_logarithm = 1;
    int64_t v_power = 2;
    while ((_eri_order_1768 = (v_power), _eri_order_1769 = (v_blocks), (_eri_order_1768 < _eri_order_1769))) {
        v_power = (_eri_order_1770 = (v_power), _eri_order_1771 = (2), eri_imul(_eri_order_1770, _eri_order_1771));
        v_logarithm = (_eri_order_1772 = (v_logarithm), _eri_order_1773 = (1), eri_iadd(_eri_order_1772, _eri_order_1773));
    }
    (v_graph)->f_visitLimit = (_eri_order_1780 = ((_eri_order_1774 = (128), _eri_order_1779 = ((_eri_order_1777 = ((_eri_order_1775 = (v_blocks), _eri_order_1776 = (v_edges), eri_iadd(_eri_order_1775, _eri_order_1776))), _eri_order_1778 = (1), eri_iadd(_eri_order_1777, _eri_order_1778))), eri_imul(_eri_order_1774, _eri_order_1779))), _eri_order_1781 = (v_logarithm), eri_imul(_eri_order_1780, _eri_order_1781));
    (v_graph)->f_prepared = true;
}

static void fn_compiler_u002e_u1_dominance_u002e_visit(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph) {
    int64_t _eri_order_1782;
    int64_t _eri_order_1783;
    int64_t _eri_order_1784;
    int64_t _eri_order_1785;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_1786;
    int64_t _eri_order_1787;
    int64_t _eri_order_1788;
    int64_t _eri_order_1789;
    int64_t _eri_order_1790;
    if ((_eri_order_1782 = ((v_graph)->f_state), _eri_order_1783 = (1), (_eri_order_1782 == _eri_order_1783))) {
        if ((_eri_order_1784 = ((v_graph)->f_visits), _eri_order_1785 = ((v_graph)->f_visitLimit), (_eri_order_1784 >= _eri_order_1785))) {
            (_eri_order_1786 = (((v_graph)->f_phase)->f_owner), _eri_order_1787 = (1), _eri_order_1788 = (0), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_1786, _eri_order_1787, _eri_order_1788));
        }
        (v_graph)->f_visits = (_eri_order_1789 = ((v_graph)->f_visits), _eri_order_1790 = (1), eri_iadd(_eri_order_1789, _eri_order_1790));
    }
}

static int64_t fn_compiler_u002e_u1_dominance_u002e_slot(int64_t v_field) {
    int64_t _eri_order_1791;
    int64_t _eri_order_1792;
    int64_t _eri_order_1793;
    int64_t _eri_order_1794;
    int64_t _eri_order_1795;
    int64_t _eri_order_1796;
    int64_t _eri_order_1797;
    int64_t _eri_order_1798;
    int64_t _eri_order_1799;
    int64_t _eri_order_1800;
    int64_t _eri_order_1801;
    int64_t _eri_order_1802;
    int64_t _eri_order_1803;
    int64_t _eri_order_1804;
    int64_t _eri_order_1805;
    int64_t _eri_order_1806;
    if ((_eri_order_1791 = (v_field), _eri_order_1792 = (10), (_eri_order_1791 == _eri_order_1792))) {
        return 3;
    }
    if ((_eri_order_1793 = (v_field), _eri_order_1794 = (11), (_eri_order_1793 == _eri_order_1794))) {
        return 5;
    }
    if ((_eri_order_1795 = (v_field), _eri_order_1796 = (12), (_eri_order_1795 == _eri_order_1796))) {
        return 6;
    }
    if ((_eri_order_1797 = (v_field), _eri_order_1798 = (13), (_eri_order_1797 == _eri_order_1798))) {
        return 8;
    }
    if ((_eri_order_1799 = (v_field), _eri_order_1800 = (14), (_eri_order_1799 == _eri_order_1800))) {
        return 4;
    }
    if (((_eri_order_1801 = (v_field), _eri_order_1802 = (15), (_eri_order_1801 == _eri_order_1802)) || (_eri_order_1803 = (v_field), _eri_order_1804 = (16), (_eri_order_1803 == _eri_order_1804)))) {
        return 9;
    }
    if ((_eri_order_1805 = (v_field), _eri_order_1806 = (17), (_eri_order_1805 == _eri_order_1806))) {
        return 10;
    }
    return v_field;
}

static int64_t fn_compiler_u002e_u1_dominance_u002e_get(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_block, int64_t v_field) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1807;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1808;
    int64_t _eri_order_1809;
    int64_t _eri_order_1810;
    int64_t _eri_order_1811;
    int64_t _eri_order_1812;
    int64_t _eri_order_1813;
    fn_compiler_u002e_u1_dominance_u002e_visit(v_graph);
    return (_eri_order_1807 = ((v_graph)->f_data), _eri_order_1808 = ((v_graph)->f_phase), _eri_order_1813 = ((_eri_order_1811 = ((_eri_order_1809 = (v_block), _eri_order_1810 = (11), eri_imul(_eri_order_1809, _eri_order_1810))), _eri_order_1812 = (fn_compiler_u002e_u1_dominance_u002e_slot(v_field)), eri_iadd(_eri_order_1811, _eri_order_1812))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1807, _eri_order_1808, _eri_order_1813));
}

static void fn_compiler_u002e_u1_dominance_u002e_set(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_block, int64_t v_field, int64_t v_value) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1814;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1815;
    int64_t _eri_order_1816;
    int64_t _eri_order_1817;
    int64_t _eri_order_1818;
    int64_t _eri_order_1819;
    int64_t _eri_order_1820;
    int64_t _eri_order_1821;
    fn_compiler_u002e_u1_dominance_u002e_visit(v_graph);
    (_eri_order_1814 = ((v_graph)->f_data), _eri_order_1815 = ((v_graph)->f_phase), _eri_order_1820 = ((_eri_order_1818 = ((_eri_order_1816 = (v_block), _eri_order_1817 = (11), eri_imul(_eri_order_1816, _eri_order_1817))), _eri_order_1819 = (fn_compiler_u002e_u1_dominance_u002e_slot(v_field)), eri_iadd(_eri_order_1818, _eri_order_1819))), _eri_order_1821 = (v_value), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1814, _eri_order_1815, _eri_order_1820, _eri_order_1821));
}

static int64_t fn_compiler_u002e_u1_dominance_u002e_edgeGet(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_edge, int64_t v_field) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1822;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1823;
    int64_t _eri_order_1824;
    int64_t _eri_order_1825;
    int64_t _eri_order_1826;
    int64_t _eri_order_1827;
    int64_t _eri_order_1828;
    int64_t _eri_order_1829;
    int64_t _eri_order_1830;
    fn_compiler_u002e_u1_dominance_u002e_visit(v_graph);
    return (_eri_order_1822 = ((v_graph)->f_data), _eri_order_1823 = ((v_graph)->f_phase), _eri_order_1830 = ((_eri_order_1828 = ((_eri_order_1824 = ((v_graph)->f_edgeBase), _eri_order_1827 = ((_eri_order_1825 = (v_edge), _eri_order_1826 = (4), eri_imul(_eri_order_1825, _eri_order_1826))), eri_iadd(_eri_order_1824, _eri_order_1827))), _eri_order_1829 = (v_field), eri_iadd(_eri_order_1828, _eri_order_1829))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1822, _eri_order_1823, _eri_order_1830));
}

static void fn_compiler_u002e_u1_dominance_u002e_addEdge(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_edge, int64_t v_source, int64_t v_target) {
    int64_t _eri_order_1831;
    int64_t _eri_order_1832;
    int64_t _eri_order_1833;
    int64_t _eri_order_1834;
    int64_t _eri_order_1835;
    int64_t _eri_order_1836;
    int64_t _eri_order_1837;
    int64_t _eri_order_1838;
    int64_t _eri_order_1839;
    int64_t _eri_order_1840;
    int64_t _eri_order_1841;
    int64_t _eri_order_1842;
    int64_t _eri_order_1843;
    int64_t _eri_order_1844;
    int64_t _eri_order_1845;
    int64_t _eri_order_1846;
    int64_t _eri_order_1847;
    int64_t _eri_order_1848;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1849;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1850;
    int64_t _eri_order_1851;
    int64_t _eri_order_1852;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1853;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1854;
    int64_t _eri_order_1855;
    int64_t _eri_order_1856;
    int64_t _eri_order_1857;
    int64_t _eri_order_1858;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1859;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1860;
    int64_t _eri_order_1861;
    int64_t _eri_order_1862;
    int64_t _eri_order_1863;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1864;
    int64_t _eri_order_1865;
    int64_t _eri_order_1866;
    int64_t _eri_order_1867;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1868;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1869;
    int64_t _eri_order_1870;
    int64_t _eri_order_1871;
    int64_t _eri_order_1872;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1873;
    int64_t _eri_order_1874;
    int64_t _eri_order_1875;
    int64_t _eri_order_1876;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1877;
    int64_t _eri_order_1878;
    int64_t _eri_order_1879;
    int64_t _eri_order_1880;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1881;
    int64_t _eri_order_1882;
    int64_t _eri_order_1883;
    int64_t _eri_order_1884;
    if (((((((((!(v_graph)->f_prepared) || (_eri_order_1831 = ((v_graph)->f_state), _eri_order_1832 = (0), (_eri_order_1831 != _eri_order_1832))) || (_eri_order_1833 = (v_edge), _eri_order_1834 = (1), (_eri_order_1833 < _eri_order_1834))) || (_eri_order_1835 = (v_edge), _eri_order_1836 = ((v_graph)->f_edges), (_eri_order_1835 > _eri_order_1836))) || (_eri_order_1837 = (v_source), _eri_order_1838 = (1), (_eri_order_1837 < _eri_order_1838))) || (_eri_order_1839 = (v_source), _eri_order_1840 = ((v_graph)->f_blocks), (_eri_order_1839 > _eri_order_1840))) || (_eri_order_1841 = (v_target), _eri_order_1842 = (1), (_eri_order_1841 < _eri_order_1842))) || (_eri_order_1843 = (v_target), _eri_order_1844 = ((v_graph)->f_blocks), (_eri_order_1843 > _eri_order_1844)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x6e, 0x63, 0x65, 0x20, 0x61, 0x64, 0x6a, 0x61, 0x63, 0x65, 0x6e, 0x63, 0x79}, 27));
    }
    int64_t v_offset = (_eri_order_1845 = ((v_graph)->f_edgeBase), _eri_order_1848 = ((_eri_order_1846 = (v_edge), _eri_order_1847 = (4), eri_imul(_eri_order_1846, _eri_order_1847))), eri_iadd(_eri_order_1845, _eri_order_1848));
    (_eri_order_1849 = ((v_graph)->f_data), _eri_order_1850 = ((v_graph)->f_phase), _eri_order_1851 = (v_offset), _eri_order_1852 = (v_source), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1849, _eri_order_1850, _eri_order_1851, _eri_order_1852));
    (_eri_order_1853 = ((v_graph)->f_data), _eri_order_1854 = ((v_graph)->f_phase), _eri_order_1857 = ((_eri_order_1855 = (v_offset), _eri_order_1856 = (1), eri_iadd(_eri_order_1855, _eri_order_1856))), _eri_order_1858 = (v_target), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1853, _eri_order_1854, _eri_order_1857, _eri_order_1858));
    (_eri_order_1859 = ((v_graph)->f_data), _eri_order_1860 = ((v_graph)->f_phase), _eri_order_1863 = ((_eri_order_1861 = (v_offset), _eri_order_1862 = (2), eri_iadd(_eri_order_1861, _eri_order_1862))), _eri_order_1867 = ((_eri_order_1864 = (v_graph), _eri_order_1865 = (v_source), _eri_order_1866 = (0), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1864, _eri_order_1865, _eri_order_1866))), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1859, _eri_order_1860, _eri_order_1863, _eri_order_1867));
    (_eri_order_1868 = ((v_graph)->f_data), _eri_order_1869 = ((v_graph)->f_phase), _eri_order_1872 = ((_eri_order_1870 = (v_offset), _eri_order_1871 = (3), eri_iadd(_eri_order_1870, _eri_order_1871))), _eri_order_1876 = ((_eri_order_1873 = (v_graph), _eri_order_1874 = (v_target), _eri_order_1875 = (1), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1873, _eri_order_1874, _eri_order_1875))), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1868, _eri_order_1869, _eri_order_1872, _eri_order_1876));
    (_eri_order_1877 = (v_graph), _eri_order_1878 = (v_source), _eri_order_1879 = (0), _eri_order_1880 = (v_edge), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1877, _eri_order_1878, _eri_order_1879, _eri_order_1880));
    (_eri_order_1881 = (v_graph), _eri_order_1882 = (v_target), _eri_order_1883 = (1), _eri_order_1884 = (v_edge), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1881, _eri_order_1882, _eri_order_1883, _eri_order_1884));
}

static void fn_compiler_u002e_u1_dominance_u002e_stackSet(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_index, int64_t v_value) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1885;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1886;
    int64_t _eri_order_1887;
    int64_t _eri_order_1888;
    int64_t _eri_order_1889;
    int64_t _eri_order_1890;
    fn_compiler_u002e_u1_dominance_u002e_visit(v_graph);
    (_eri_order_1885 = ((v_graph)->f_data), _eri_order_1886 = ((v_graph)->f_phase), _eri_order_1889 = ((_eri_order_1887 = ((v_graph)->f_stackBase), _eri_order_1888 = (v_index), eri_iadd(_eri_order_1887, _eri_order_1888))), _eri_order_1890 = (v_value), fn_compiler_u002e_u1_words_u002e_set(_eri_order_1885, _eri_order_1886, _eri_order_1889, _eri_order_1890));
}

static int64_t fn_compiler_u002e_u1_dominance_u002e_stackGet(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_index) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_1891;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_1892;
    int64_t _eri_order_1893;
    int64_t _eri_order_1894;
    int64_t _eri_order_1895;
    fn_compiler_u002e_u1_dominance_u002e_visit(v_graph);
    return (_eri_order_1891 = ((v_graph)->f_data), _eri_order_1892 = ((v_graph)->f_phase), _eri_order_1895 = ((_eri_order_1893 = ((v_graph)->f_stackBase), _eri_order_1894 = (v_index), eri_iadd(_eri_order_1893, _eri_order_1894))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_1891, _eri_order_1892, _eri_order_1895));
}

static void fn_compiler_u002e_u1_dominance_u002e_discover(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_block, int64_t v_parent) {
    int64_t _eri_order_1896;
    int64_t _eri_order_1897;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1898;
    int64_t _eri_order_1899;
    int64_t _eri_order_1900;
    int64_t _eri_order_1901;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1902;
    int64_t _eri_order_1903;
    int64_t _eri_order_1904;
    int64_t _eri_order_1905;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1906;
    int64_t _eri_order_1907;
    int64_t _eri_order_1908;
    int64_t _eri_order_1909;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1910;
    int64_t _eri_order_1911;
    int64_t _eri_order_1912;
    int64_t _eri_order_1913;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1914;
    int64_t _eri_order_1915;
    int64_t _eri_order_1916;
    int64_t _eri_order_1917;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1918;
    int64_t _eri_order_1919;
    int64_t _eri_order_1920;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1921;
    int64_t _eri_order_1922;
    int64_t _eri_order_1923;
    int64_t _eri_order_1924;
    (v_graph)->f_reachable = (_eri_order_1896 = ((v_graph)->f_reachable), _eri_order_1897 = (1), eri_iadd(_eri_order_1896, _eri_order_1897));
    int64_t v_number = (v_graph)->f_reachable;
    (_eri_order_1898 = (v_graph), _eri_order_1899 = (v_block), _eri_order_1900 = (2), _eri_order_1901 = (v_number), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1898, _eri_order_1899, _eri_order_1900, _eri_order_1901));
    (_eri_order_1902 = (v_graph), _eri_order_1903 = (v_block), _eri_order_1904 = (3), _eri_order_1905 = (v_parent), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1902, _eri_order_1903, _eri_order_1904, _eri_order_1905));
    (_eri_order_1906 = (v_graph), _eri_order_1907 = (v_block), _eri_order_1908 = (4), _eri_order_1909 = (v_number), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1906, _eri_order_1907, _eri_order_1908, _eri_order_1909));
    (_eri_order_1910 = (v_graph), _eri_order_1911 = (v_block), _eri_order_1912 = (6), _eri_order_1913 = (v_block), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1910, _eri_order_1911, _eri_order_1912, _eri_order_1913));
    (_eri_order_1914 = (v_graph), _eri_order_1915 = (v_number), _eri_order_1916 = (17), _eri_order_1917 = (v_block), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1914, _eri_order_1915, _eri_order_1916, _eri_order_1917));
    (_eri_order_1918 = (v_graph), _eri_order_1919 = (v_block), _eri_order_1920 = (15), _eri_order_1924 = ((_eri_order_1921 = (v_graph), _eri_order_1922 = (v_block), _eri_order_1923 = (0), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1921, _eri_order_1922, _eri_order_1923))), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1918, _eri_order_1919, _eri_order_1920, _eri_order_1924));
}

static void fn_compiler_u002e_u1_dominance_u002e_dfs(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph) {
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1925;
    int64_t _eri_order_1926;
    int64_t _eri_order_1927;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1928;
    int64_t _eri_order_1929;
    int64_t _eri_order_1930;
    int64_t _eri_order_1931;
    int64_t _eri_order_1932;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1933;
    int64_t _eri_order_1934;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1935;
    int64_t _eri_order_1936;
    int64_t _eri_order_1937;
    int64_t _eri_order_1938;
    int64_t _eri_order_1939;
    int64_t _eri_order_1940;
    int64_t _eri_order_1941;
    int64_t _eri_order_1942;
    int64_t _eri_order_1943;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1944;
    int64_t _eri_order_1945;
    int64_t _eri_order_1946;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1947;
    int64_t _eri_order_1948;
    int64_t _eri_order_1949;
    int64_t _eri_order_1950;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1951;
    int64_t _eri_order_1952;
    int64_t _eri_order_1953;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1954;
    int64_t _eri_order_1955;
    int64_t _eri_order_1956;
    int64_t _eri_order_1957;
    int64_t _eri_order_1958;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1959;
    int64_t _eri_order_1960;
    int64_t _eri_order_1961;
    int64_t _eri_order_1962;
    int64_t _eri_order_1963;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1964;
    int64_t _eri_order_1965;
    int64_t _eri_order_1966;
    (_eri_order_1925 = (v_graph), _eri_order_1926 = (1), _eri_order_1927 = (0), fn_compiler_u002e_u1_dominance_u002e_discover(_eri_order_1925, _eri_order_1926, _eri_order_1927));
    int64_t v_depth = 1;
    (_eri_order_1928 = (v_graph), _eri_order_1929 = (v_depth), _eri_order_1930 = (1), fn_compiler_u002e_u1_dominance_u002e_stackSet(_eri_order_1928, _eri_order_1929, _eri_order_1930));
    while ((_eri_order_1931 = (v_depth), _eri_order_1932 = (0), (_eri_order_1931 > _eri_order_1932))) {
        int64_t v_block = (_eri_order_1933 = (v_graph), _eri_order_1934 = (v_depth), fn_compiler_u002e_u1_dominance_u002e_stackGet(_eri_order_1933, _eri_order_1934));
        int64_t v_edge = (_eri_order_1935 = (v_graph), _eri_order_1936 = (v_block), _eri_order_1937 = (15), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1935, _eri_order_1936, _eri_order_1937));
        if ((_eri_order_1938 = (v_edge), _eri_order_1939 = (0), (_eri_order_1938 == _eri_order_1939))) {
            v_depth = (_eri_order_1940 = (v_depth), _eri_order_1941 = (1), eri_isub(_eri_order_1940, _eri_order_1941));
        } else {
            (v_graph)->f_reachableEdges = (_eri_order_1942 = ((v_graph)->f_reachableEdges), _eri_order_1943 = (1), eri_iadd(_eri_order_1942, _eri_order_1943));
            (_eri_order_1944 = (v_graph), _eri_order_1945 = (v_block), _eri_order_1946 = (15), _eri_order_1950 = ((_eri_order_1947 = (v_graph), _eri_order_1948 = (v_edge), _eri_order_1949 = (2), fn_compiler_u002e_u1_dominance_u002e_edgeGet(_eri_order_1947, _eri_order_1948, _eri_order_1949))), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_1944, _eri_order_1945, _eri_order_1946, _eri_order_1950));
            int64_t v_target = (_eri_order_1951 = (v_graph), _eri_order_1952 = (v_edge), _eri_order_1953 = (1), fn_compiler_u002e_u1_dominance_u002e_edgeGet(_eri_order_1951, _eri_order_1952, _eri_order_1953));
            if ((_eri_order_1957 = ((_eri_order_1954 = (v_graph), _eri_order_1955 = (v_target), _eri_order_1956 = (2), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1954, _eri_order_1955, _eri_order_1956))), _eri_order_1958 = (0), (_eri_order_1957 == _eri_order_1958))) {
                (_eri_order_1959 = (v_graph), _eri_order_1960 = (v_target), _eri_order_1961 = (v_block), fn_compiler_u002e_u1_dominance_u002e_discover(_eri_order_1959, _eri_order_1960, _eri_order_1961));
                v_depth = (_eri_order_1962 = (v_depth), _eri_order_1963 = (1), eri_iadd(_eri_order_1962, _eri_order_1963));
                (_eri_order_1964 = (v_graph), _eri_order_1965 = (v_depth), _eri_order_1966 = (v_target), fn_compiler_u002e_u1_dominance_u002e_stackSet(_eri_order_1964, _eri_order_1965, _eri_order_1966));
            }
        }
    }
}

static int64_t fn_compiler_u002e_u1_dominance_u002e_evaluate(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_value) {
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1967;
    int64_t _eri_order_1968;
    int64_t _eri_order_1969;
    int64_t _eri_order_1970;
    int64_t _eri_order_1971;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1972;
    int64_t _eri_order_1973;
    int64_t _eri_order_1974;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1975;
    int64_t _eri_order_1976;
    int64_t _eri_order_1977;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1978;
    int64_t _eri_order_1979;
    int64_t _eri_order_1980;
    int64_t _eri_order_1981;
    int64_t _eri_order_1982;
    int64_t _eri_order_1983;
    int64_t _eri_order_1984;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1985;
    int64_t _eri_order_1986;
    int64_t _eri_order_1987;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1988;
    int64_t _eri_order_1989;
    int64_t _eri_order_1990;
    int64_t _eri_order_1991;
    int64_t _eri_order_1992;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1993;
    int64_t _eri_order_1994;
    int64_t _eri_order_1995;
    int64_t _eri_order_1996;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_1997;
    int64_t _eri_order_1998;
    int64_t _eri_order_1999;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2000;
    int64_t _eri_order_2001;
    int64_t _eri_order_2002;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2003;
    int64_t _eri_order_2004;
    int64_t _eri_order_2005;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2006;
    int64_t _eri_order_2007;
    int64_t _eri_order_2008;
    int64_t _eri_order_2009;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2010;
    int64_t _eri_order_2011;
    int64_t _eri_order_2012;
    int64_t _eri_order_2013;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2014;
    int64_t _eri_order_2015;
    int64_t _eri_order_2016;
    int64_t _eri_order_2017;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2018;
    int64_t _eri_order_2019;
    int64_t _eri_order_2020;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2021;
    int64_t _eri_order_2022;
    int64_t _eri_order_2023;
    int64_t _eri_order_2024;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2025;
    int64_t _eri_order_2026;
    int64_t _eri_order_2027;
    if ((_eri_order_1970 = ((_eri_order_1967 = (v_graph), _eri_order_1968 = (v_value), _eri_order_1969 = (5), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1967, _eri_order_1968, _eri_order_1969))), _eri_order_1971 = (0), (_eri_order_1970 == _eri_order_1971))) {
        return (_eri_order_1972 = (v_graph), _eri_order_1973 = (v_value), _eri_order_1974 = (6), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1972, _eri_order_1973, _eri_order_1974));
    }
    int64_t v_cursor = v_value;
    int64_t v_depth = 0;
    int64_t v_ancestor = (_eri_order_1975 = (v_graph), _eri_order_1976 = (v_cursor), _eri_order_1977 = (5), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1975, _eri_order_1976, _eri_order_1977));
    while ((_eri_order_1981 = ((_eri_order_1978 = (v_graph), _eri_order_1979 = (v_ancestor), _eri_order_1980 = (5), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1978, _eri_order_1979, _eri_order_1980))), _eri_order_1982 = (0), (_eri_order_1981 != _eri_order_1982))) {
        v_depth = (_eri_order_1983 = (v_depth), _eri_order_1984 = (1), eri_iadd(_eri_order_1983, _eri_order_1984));
        (_eri_order_1985 = (v_graph), _eri_order_1986 = (v_depth), _eri_order_1987 = (v_cursor), fn_compiler_u002e_u1_dominance_u002e_stackSet(_eri_order_1985, _eri_order_1986, _eri_order_1987));
        v_cursor = v_ancestor;
        v_ancestor = (_eri_order_1988 = (v_graph), _eri_order_1989 = (v_cursor), _eri_order_1990 = (5), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1988, _eri_order_1989, _eri_order_1990));
    }
    while ((_eri_order_1991 = (v_depth), _eri_order_1992 = (0), (_eri_order_1991 > _eri_order_1992))) {
        v_cursor = (_eri_order_1993 = (v_graph), _eri_order_1994 = (v_depth), fn_compiler_u002e_u1_dominance_u002e_stackGet(_eri_order_1993, _eri_order_1994));
        v_depth = (_eri_order_1995 = (v_depth), _eri_order_1996 = (1), eri_isub(_eri_order_1995, _eri_order_1996));
        v_ancestor = (_eri_order_1997 = (v_graph), _eri_order_1998 = (v_cursor), _eri_order_1999 = (5), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_1997, _eri_order_1998, _eri_order_1999));
        int64_t v_upper = (_eri_order_2000 = (v_graph), _eri_order_2001 = (v_ancestor), _eri_order_2002 = (6), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2000, _eri_order_2001, _eri_order_2002));
        int64_t v_own = (_eri_order_2003 = (v_graph), _eri_order_2004 = (v_cursor), _eri_order_2005 = (6), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2003, _eri_order_2004, _eri_order_2005));
        if ((_eri_order_2009 = ((_eri_order_2006 = (v_graph), _eri_order_2007 = (v_upper), _eri_order_2008 = (4), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2006, _eri_order_2007, _eri_order_2008))), _eri_order_2013 = ((_eri_order_2010 = (v_graph), _eri_order_2011 = (v_own), _eri_order_2012 = (4), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2010, _eri_order_2011, _eri_order_2012))), (_eri_order_2009 < _eri_order_2013))) {
            (_eri_order_2014 = (v_graph), _eri_order_2015 = (v_cursor), _eri_order_2016 = (6), _eri_order_2017 = (v_upper), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2014, _eri_order_2015, _eri_order_2016, _eri_order_2017));
        }
        (_eri_order_2018 = (v_graph), _eri_order_2019 = (v_cursor), _eri_order_2020 = (5), _eri_order_2024 = ((_eri_order_2021 = (v_graph), _eri_order_2022 = (v_ancestor), _eri_order_2023 = (5), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2021, _eri_order_2022, _eri_order_2023))), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2018, _eri_order_2019, _eri_order_2020, _eri_order_2024));
    }
    return (_eri_order_2025 = (v_graph), _eri_order_2026 = (v_value), _eri_order_2027 = (6), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2025, _eri_order_2026, _eri_order_2027));
}

static void fn_compiler_u002e_u1_dominance_u002e_compute(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph) {
    int64_t _eri_order_2028;
    int64_t _eri_order_2029;
    int64_t _eri_order_2030;
    int64_t _eri_order_2031;
    int64_t _eri_order_2032;
    int64_t _eri_order_2033;
    int64_t _eri_order_2034;
    int64_t _eri_order_2035;
    int64_t _eri_order_2036;
    int64_t _eri_order_2037;
    int64_t _eri_order_2038;
    int64_t _eri_order_2039;
    int64_t _eri_order_2040;
    int64_t _eri_order_2041;
    int64_t _eri_order_2042;
    int64_t _eri_order_2043;
    int64_t _eri_order_2044;
    int64_t _eri_order_2045;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2046;
    int64_t _eri_order_2047;
    int64_t _eri_order_2048;
    int64_t _eri_order_2049;
    int64_t _eri_order_2050;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2051;
    int64_t _eri_order_2052;
    int64_t _eri_order_2053;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2054;
    int64_t _eri_order_2055;
    int64_t _eri_order_2056;
    int64_t _eri_order_2057;
    int64_t _eri_order_2058;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2059;
    int64_t _eri_order_2060;
    int64_t _eri_order_2061;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2062;
    int64_t _eri_order_2063;
    int64_t _eri_order_2064;
    int64_t _eri_order_2065;
    int64_t _eri_order_2066;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2067;
    int64_t _eri_order_2068;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2069;
    int64_t _eri_order_2070;
    int64_t _eri_order_2071;
    int64_t _eri_order_2072;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2073;
    int64_t _eri_order_2074;
    int64_t _eri_order_2075;
    int64_t _eri_order_2076;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2077;
    int64_t _eri_order_2078;
    int64_t _eri_order_2079;
    int64_t _eri_order_2080;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2081;
    int64_t _eri_order_2082;
    int64_t _eri_order_2083;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2084;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2085;
    int64_t _eri_order_2086;
    int64_t _eri_order_2087;
    int64_t _eri_order_2088;
    int64_t _eri_order_2089;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2090;
    int64_t _eri_order_2091;
    int64_t _eri_order_2092;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2093;
    int64_t _eri_order_2094;
    int64_t _eri_order_2095;
    int64_t _eri_order_2096;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2097;
    int64_t _eri_order_2098;
    int64_t _eri_order_2099;
    int64_t _eri_order_2100;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2101;
    int64_t _eri_order_2102;
    int64_t _eri_order_2103;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2104;
    int64_t _eri_order_2105;
    int64_t _eri_order_2106;
    int64_t _eri_order_2107;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2108;
    int64_t _eri_order_2109;
    int64_t _eri_order_2110;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2111;
    int64_t _eri_order_2112;
    int64_t _eri_order_2113;
    int64_t _eri_order_2114;
    int64_t _eri_order_2115;
    int64_t _eri_order_2116;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2117;
    int64_t _eri_order_2118;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2119;
    int64_t _eri_order_2120;
    int64_t _eri_order_2121;
    int64_t _eri_order_2122;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2123;
    int64_t _eri_order_2124;
    int64_t _eri_order_2125;
    int64_t _eri_order_2126;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2127;
    int64_t _eri_order_2128;
    int64_t _eri_order_2129;
    int64_t _eri_order_2130;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2131;
    int64_t _eri_order_2132;
    int64_t _eri_order_2133;
    int64_t _eri_order_2134;
    int64_t _eri_order_2135;
    int64_t _eri_order_2136;
    int64_t _eri_order_2137;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2138;
    int64_t _eri_order_2139;
    int64_t _eri_order_2140;
    int64_t _eri_order_2141;
    int64_t _eri_order_2142;
    int64_t _eri_order_2143;
    int64_t _eri_order_2144;
    int64_t _eri_order_2145;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2146;
    int64_t _eri_order_2147;
    int64_t _eri_order_2148;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2149;
    int64_t _eri_order_2150;
    int64_t _eri_order_2151;
    int64_t _eri_order_2152;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2153;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2154;
    int64_t _eri_order_2155;
    int64_t _eri_order_2156;
    int64_t _eri_order_2157;
    int64_t _eri_order_2158;
    int64_t _eri_order_2159;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2160;
    int64_t _eri_order_2161;
    int64_t _eri_order_2162;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2163;
    int64_t _eri_order_2164;
    int64_t _eri_order_2165;
    int64_t _eri_order_2166;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2167;
    int64_t _eri_order_2168;
    int64_t _eri_order_2169;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2170;
    int64_t _eri_order_2171;
    int64_t _eri_order_2172;
    int64_t _eri_order_2173;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2174;
    int64_t _eri_order_2175;
    int64_t _eri_order_2176;
    int64_t _eri_order_2177;
    int64_t _eri_order_2178;
    int64_t _eri_order_2179;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2180;
    int64_t _eri_order_2181;
    int64_t _eri_order_2182;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2183;
    int64_t _eri_order_2184;
    int64_t _eri_order_2185;
    int64_t _eri_order_2186;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2187;
    int64_t _eri_order_2188;
    int64_t _eri_order_2189;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2190;
    int64_t _eri_order_2191;
    int64_t _eri_order_2192;
    int64_t _eri_order_2193;
    int64_t _eri_order_2194;
    int64_t _eri_order_2195;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2196;
    int64_t _eri_order_2197;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2198;
    int64_t _eri_order_2199;
    int64_t _eri_order_2200;
    int64_t _eri_order_2201;
    int64_t _eri_order_2202;
    int64_t _eri_order_2203;
    int64_t _eri_order_2204;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2205;
    int64_t _eri_order_2206;
    int64_t _eri_order_2207;
    int64_t _eri_order_2208;
    int64_t _eri_order_2209;
    int64_t _eri_order_2210;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2211;
    int64_t _eri_order_2212;
    int64_t _eri_order_2213;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2214;
    int64_t _eri_order_2215;
    int64_t _eri_order_2216;
    int64_t _eri_order_2217;
    int64_t _eri_order_2218;
    int64_t _eri_order_2219;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2220;
    int64_t _eri_order_2221;
    int64_t _eri_order_2222;
    int64_t _eri_order_2223;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2224;
    int64_t _eri_order_2225;
    int64_t _eri_order_2226;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2227;
    int64_t _eri_order_2228;
    int64_t _eri_order_2229;
    int64_t _eri_order_2230;
    int64_t _eri_order_2231;
    int64_t _eri_order_2232;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2233;
    int64_t _eri_order_2234;
    int64_t _eri_order_2235;
    if (((!(v_graph)->f_prepared) || (_eri_order_2028 = ((v_graph)->f_state), _eri_order_2029 = (0), (_eri_order_2028 != _eri_order_2029)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x6e, 0x63, 0x65, 0x20, 0x67, 0x72, 0x61, 0x70, 0x68, 0x20, 0x61, 0x6c, 0x72, 0x65, 0x61, 0x64, 0x79, 0x20, 0x61, 0x6e, 0x61, 0x6c, 0x79, 0x7a, 0x65, 0x64}, 32));
    }
    (v_graph)->f_state = 1;
    fn_compiler_u002e_u1_dominance_u002e_dfs(v_graph);
    int64_t v_logarithm = 1;
    int64_t v_power = 2;
    while ((_eri_order_2030 = (v_power), _eri_order_2031 = ((v_graph)->f_reachable), (_eri_order_2030 < _eri_order_2031))) {
        v_power = (_eri_order_2032 = (v_power), _eri_order_2033 = (2), eri_imul(_eri_order_2032, _eri_order_2033));
        v_logarithm = (_eri_order_2034 = (v_logarithm), _eri_order_2035 = (1), eri_iadd(_eri_order_2034, _eri_order_2035));
    }
    (v_graph)->f_visitLimit = (_eri_order_2042 = ((_eri_order_2036 = (128), _eri_order_2041 = ((_eri_order_2039 = ((_eri_order_2037 = ((v_graph)->f_reachable), _eri_order_2038 = ((v_graph)->f_reachableEdges), eri_iadd(_eri_order_2037, _eri_order_2038))), _eri_order_2040 = (1), eri_iadd(_eri_order_2039, _eri_order_2040))), eri_imul(_eri_order_2036, _eri_order_2041))), _eri_order_2043 = (v_logarithm), eri_imul(_eri_order_2042, _eri_order_2043));
    if ((_eri_order_2044 = ((v_graph)->f_visits), _eri_order_2045 = ((v_graph)->f_visitLimit), (_eri_order_2044 > _eri_order_2045))) {
        (_eri_order_2046 = (((v_graph)->f_phase)->f_owner), _eri_order_2047 = ((v_graph)->f_visits), _eri_order_2048 = ((v_graph)->f_visitLimit), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_2046, _eri_order_2047, _eri_order_2048));
    }
    int64_t v_number = (v_graph)->f_reachable;
    while ((_eri_order_2049 = (v_number), _eri_order_2050 = (1), (_eri_order_2049 > _eri_order_2050))) {
        int64_t v_block = (_eri_order_2051 = (v_graph), _eri_order_2052 = (v_number), _eri_order_2053 = (17), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2051, _eri_order_2052, _eri_order_2053));
        int64_t v_edge = (_eri_order_2054 = (v_graph), _eri_order_2055 = (v_block), _eri_order_2056 = (1), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2054, _eri_order_2055, _eri_order_2056));
        while ((_eri_order_2057 = (v_edge), _eri_order_2058 = (0), (_eri_order_2057 != _eri_order_2058))) {
            int64_t v_predecessor = (_eri_order_2059 = (v_graph), _eri_order_2060 = (v_edge), _eri_order_2061 = (0), fn_compiler_u002e_u1_dominance_u002e_edgeGet(_eri_order_2059, _eri_order_2060, _eri_order_2061));
            if ((_eri_order_2065 = ((_eri_order_2062 = (v_graph), _eri_order_2063 = (v_predecessor), _eri_order_2064 = (2), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2062, _eri_order_2063, _eri_order_2064))), _eri_order_2066 = (0), (_eri_order_2065 != _eri_order_2066))) {
                int64_t v_label = (_eri_order_2067 = (v_graph), _eri_order_2068 = (v_predecessor), fn_compiler_u002e_u1_dominance_u002e_evaluate(_eri_order_2067, _eri_order_2068));
                int64_t v_semi = (_eri_order_2069 = (v_graph), _eri_order_2070 = (v_label), _eri_order_2071 = (4), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2069, _eri_order_2070, _eri_order_2071));
                if ((_eri_order_2072 = (v_semi), _eri_order_2076 = ((_eri_order_2073 = (v_graph), _eri_order_2074 = (v_block), _eri_order_2075 = (4), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2073, _eri_order_2074, _eri_order_2075))), (_eri_order_2072 < _eri_order_2076))) {
                    (_eri_order_2077 = (v_graph), _eri_order_2078 = (v_block), _eri_order_2079 = (4), _eri_order_2080 = (v_semi), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2077, _eri_order_2078, _eri_order_2079, _eri_order_2080));
                }
            }
            v_edge = (_eri_order_2081 = (v_graph), _eri_order_2082 = (v_edge), _eri_order_2083 = (3), fn_compiler_u002e_u1_dominance_u002e_edgeGet(_eri_order_2081, _eri_order_2082, _eri_order_2083));
        }
        int64_t v_semiBlock = (_eri_order_2084 = (v_graph), _eri_order_2088 = ((_eri_order_2085 = (v_graph), _eri_order_2086 = (v_block), _eri_order_2087 = (4), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2085, _eri_order_2086, _eri_order_2087))), _eri_order_2089 = (17), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2084, _eri_order_2088, _eri_order_2089));
        (_eri_order_2090 = (v_graph), _eri_order_2091 = (v_block), _eri_order_2092 = (9), _eri_order_2096 = ((_eri_order_2093 = (v_graph), _eri_order_2094 = (v_semiBlock), _eri_order_2095 = (8), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2093, _eri_order_2094, _eri_order_2095))), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2090, _eri_order_2091, _eri_order_2092, _eri_order_2096));
        (_eri_order_2097 = (v_graph), _eri_order_2098 = (v_semiBlock), _eri_order_2099 = (8), _eri_order_2100 = (v_block), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2097, _eri_order_2098, _eri_order_2099, _eri_order_2100));
        int64_t v_parent = (_eri_order_2101 = (v_graph), _eri_order_2102 = (v_block), _eri_order_2103 = (3), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2101, _eri_order_2102, _eri_order_2103));
        (_eri_order_2104 = (v_graph), _eri_order_2105 = (v_block), _eri_order_2106 = (5), _eri_order_2107 = (v_parent), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2104, _eri_order_2105, _eri_order_2106, _eri_order_2107));
        int64_t v_cursor = (_eri_order_2108 = (v_graph), _eri_order_2109 = (v_parent), _eri_order_2110 = (8), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2108, _eri_order_2109, _eri_order_2110));
        (_eri_order_2111 = (v_graph), _eri_order_2112 = (v_parent), _eri_order_2113 = (8), _eri_order_2114 = (0), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2111, _eri_order_2112, _eri_order_2113, _eri_order_2114));
        while ((_eri_order_2115 = (v_cursor), _eri_order_2116 = (0), (_eri_order_2115 != _eri_order_2116))) {
            int64_t v_label = (_eri_order_2117 = (v_graph), _eri_order_2118 = (v_cursor), fn_compiler_u002e_u1_dominance_u002e_evaluate(_eri_order_2117, _eri_order_2118));
            int64_t v_candidate = v_parent;
            if ((_eri_order_2122 = ((_eri_order_2119 = (v_graph), _eri_order_2120 = (v_label), _eri_order_2121 = (4), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2119, _eri_order_2120, _eri_order_2121))), _eri_order_2126 = ((_eri_order_2123 = (v_graph), _eri_order_2124 = (v_cursor), _eri_order_2125 = (4), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2123, _eri_order_2124, _eri_order_2125))), (_eri_order_2122 < _eri_order_2126))) {
                v_candidate = v_label;
            }
            (_eri_order_2127 = (v_graph), _eri_order_2128 = (v_cursor), _eri_order_2129 = (7), _eri_order_2130 = (v_candidate), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2127, _eri_order_2128, _eri_order_2129, _eri_order_2130));
            v_cursor = (_eri_order_2131 = (v_graph), _eri_order_2132 = (v_cursor), _eri_order_2133 = (9), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2131, _eri_order_2132, _eri_order_2133));
        }
        v_number = (_eri_order_2134 = (v_number), _eri_order_2135 = (1), eri_isub(_eri_order_2134, _eri_order_2135));
    }
    v_number = 1;
    while ((_eri_order_2136 = (v_number), _eri_order_2137 = ((v_graph)->f_blocks), (_eri_order_2136 <= _eri_order_2137))) {
        (_eri_order_2138 = (v_graph), _eri_order_2139 = (v_number), _eri_order_2140 = (10), _eri_order_2141 = (0), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2138, _eri_order_2139, _eri_order_2140, _eri_order_2141));
        v_number = (_eri_order_2142 = (v_number), _eri_order_2143 = (1), eri_iadd(_eri_order_2142, _eri_order_2143));
    }
    v_number = 2;
    while ((_eri_order_2144 = (v_number), _eri_order_2145 = ((v_graph)->f_reachable), (_eri_order_2144 <= _eri_order_2145))) {
        int64_t v_block = (_eri_order_2146 = (v_graph), _eri_order_2147 = (v_number), _eri_order_2148 = (17), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2146, _eri_order_2147, _eri_order_2148));
        int64_t v_parent = (_eri_order_2149 = (v_graph), _eri_order_2150 = (v_block), _eri_order_2151 = (7), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2149, _eri_order_2150, _eri_order_2151));
        if ((_eri_order_2152 = (v_parent), _eri_order_2159 = ((_eri_order_2153 = (v_graph), _eri_order_2157 = ((_eri_order_2154 = (v_graph), _eri_order_2155 = (v_block), _eri_order_2156 = (4), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2154, _eri_order_2155, _eri_order_2156))), _eri_order_2158 = (17), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2153, _eri_order_2157, _eri_order_2158))), (_eri_order_2152 != _eri_order_2159))) {
            v_parent = (_eri_order_2160 = (v_graph), _eri_order_2161 = (v_parent), _eri_order_2162 = (7), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2160, _eri_order_2161, _eri_order_2162));
            (_eri_order_2163 = (v_graph), _eri_order_2164 = (v_block), _eri_order_2165 = (7), _eri_order_2166 = (v_parent), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2163, _eri_order_2164, _eri_order_2165, _eri_order_2166));
        }
        (_eri_order_2167 = (v_graph), _eri_order_2168 = (v_block), _eri_order_2169 = (11), _eri_order_2173 = ((_eri_order_2170 = (v_graph), _eri_order_2171 = (v_parent), _eri_order_2172 = (10), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2170, _eri_order_2171, _eri_order_2172))), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2167, _eri_order_2168, _eri_order_2169, _eri_order_2173));
        (_eri_order_2174 = (v_graph), _eri_order_2175 = (v_parent), _eri_order_2176 = (10), _eri_order_2177 = (v_block), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2174, _eri_order_2175, _eri_order_2176, _eri_order_2177));
        v_number = (_eri_order_2178 = (v_number), _eri_order_2179 = (1), eri_iadd(_eri_order_2178, _eri_order_2179));
    }
    int64_t v_clock = 1;
    int64_t v_depth = 1;
    (_eri_order_2180 = (v_graph), _eri_order_2181 = (v_depth), _eri_order_2182 = (1), fn_compiler_u002e_u1_dominance_u002e_stackSet(_eri_order_2180, _eri_order_2181, _eri_order_2182));
    (_eri_order_2183 = (v_graph), _eri_order_2184 = (1), _eri_order_2185 = (12), _eri_order_2186 = (v_clock), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2183, _eri_order_2184, _eri_order_2185, _eri_order_2186));
    (_eri_order_2187 = (v_graph), _eri_order_2188 = (1), _eri_order_2189 = (15), _eri_order_2193 = ((_eri_order_2190 = (v_graph), _eri_order_2191 = (1), _eri_order_2192 = (10), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2190, _eri_order_2191, _eri_order_2192))), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2187, _eri_order_2188, _eri_order_2189, _eri_order_2193));
    while ((_eri_order_2194 = (v_depth), _eri_order_2195 = (0), (_eri_order_2194 > _eri_order_2195))) {
        int64_t v_block = (_eri_order_2196 = (v_graph), _eri_order_2197 = (v_depth), fn_compiler_u002e_u1_dominance_u002e_stackGet(_eri_order_2196, _eri_order_2197));
        int64_t v_child = (_eri_order_2198 = (v_graph), _eri_order_2199 = (v_block), _eri_order_2200 = (15), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2198, _eri_order_2199, _eri_order_2200));
        if ((_eri_order_2201 = (v_child), _eri_order_2202 = (0), (_eri_order_2201 == _eri_order_2202))) {
            v_clock = (_eri_order_2203 = (v_clock), _eri_order_2204 = (1), eri_iadd(_eri_order_2203, _eri_order_2204));
            (_eri_order_2205 = (v_graph), _eri_order_2206 = (v_block), _eri_order_2207 = (13), _eri_order_2208 = (v_clock), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2205, _eri_order_2206, _eri_order_2207, _eri_order_2208));
            v_depth = (_eri_order_2209 = (v_depth), _eri_order_2210 = (1), eri_isub(_eri_order_2209, _eri_order_2210));
        } else {
            (_eri_order_2211 = (v_graph), _eri_order_2212 = (v_block), _eri_order_2213 = (15), _eri_order_2217 = ((_eri_order_2214 = (v_graph), _eri_order_2215 = (v_child), _eri_order_2216 = (11), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2214, _eri_order_2215, _eri_order_2216))), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2211, _eri_order_2212, _eri_order_2213, _eri_order_2217));
            v_clock = (_eri_order_2218 = (v_clock), _eri_order_2219 = (1), eri_iadd(_eri_order_2218, _eri_order_2219));
            (_eri_order_2220 = (v_graph), _eri_order_2221 = (v_child), _eri_order_2222 = (12), _eri_order_2223 = (v_clock), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2220, _eri_order_2221, _eri_order_2222, _eri_order_2223));
            (_eri_order_2224 = (v_graph), _eri_order_2225 = (v_child), _eri_order_2226 = (15), _eri_order_2230 = ((_eri_order_2227 = (v_graph), _eri_order_2228 = (v_child), _eri_order_2229 = (10), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2227, _eri_order_2228, _eri_order_2229))), fn_compiler_u002e_u1_dominance_u002e_set(_eri_order_2224, _eri_order_2225, _eri_order_2226, _eri_order_2230));
            v_depth = (_eri_order_2231 = (v_depth), _eri_order_2232 = (1), eri_iadd(_eri_order_2231, _eri_order_2232));
            (_eri_order_2233 = (v_graph), _eri_order_2234 = (v_depth), _eri_order_2235 = (v_child), fn_compiler_u002e_u1_dominance_u002e_stackSet(_eri_order_2233, _eri_order_2234, _eri_order_2235));
        }
    }
    (v_graph)->f_state = 2;
}

static bool fn_compiler_u002e_u1_dominance_u002e_dominates(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph, int64_t v_first, int64_t v_second) {
    int64_t _eri_order_2236;
    int64_t _eri_order_2237;
    int64_t _eri_order_2238;
    int64_t _eri_order_2239;
    int64_t _eri_order_2240;
    int64_t _eri_order_2241;
    int64_t _eri_order_2242;
    int64_t _eri_order_2243;
    int64_t _eri_order_2244;
    int64_t _eri_order_2245;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2246;
    int64_t _eri_order_2247;
    int64_t _eri_order_2248;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2249;
    int64_t _eri_order_2250;
    int64_t _eri_order_2251;
    int64_t _eri_order_2252;
    int64_t _eri_order_2253;
    int64_t _eri_order_2254;
    int64_t _eri_order_2255;
    int64_t _eri_order_2256;
    int64_t _eri_order_2257;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2258;
    int64_t _eri_order_2259;
    int64_t _eri_order_2260;
    int64_t _eri_order_2261;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2262;
    int64_t _eri_order_2263;
    int64_t _eri_order_2264;
    int64_t _eri_order_2265;
    if ((((((_eri_order_2236 = ((v_graph)->f_state), _eri_order_2237 = (2), (_eri_order_2236 != _eri_order_2237)) || (_eri_order_2238 = (v_first), _eri_order_2239 = (1), (_eri_order_2238 < _eri_order_2239))) || (_eri_order_2240 = (v_first), _eri_order_2241 = ((v_graph)->f_blocks), (_eri_order_2240 > _eri_order_2241))) || (_eri_order_2242 = (v_second), _eri_order_2243 = (1), (_eri_order_2242 < _eri_order_2243))) || (_eri_order_2244 = (v_second), _eri_order_2245 = ((v_graph)->f_blocks), (_eri_order_2244 > _eri_order_2245)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x6e, 0x63, 0x65, 0x20, 0x71, 0x75, 0x65, 0x72, 0x79}, 23));
    }
    int64_t v_start = (_eri_order_2246 = (v_graph), _eri_order_2247 = (v_first), _eri_order_2248 = (12), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2246, _eri_order_2247, _eri_order_2248));
    int64_t v_other = (_eri_order_2249 = (v_graph), _eri_order_2250 = (v_second), _eri_order_2251 = (12), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2249, _eri_order_2250, _eri_order_2251));
    return ((((_eri_order_2252 = (v_start), _eri_order_2253 = (0), (_eri_order_2252 != _eri_order_2253)) && (_eri_order_2254 = (v_other), _eri_order_2255 = (0), (_eri_order_2254 != _eri_order_2255))) && (_eri_order_2256 = (v_start), _eri_order_2257 = (v_other), (_eri_order_2256 <= _eri_order_2257))) && (_eri_order_2261 = ((_eri_order_2258 = (v_graph), _eri_order_2259 = (v_second), _eri_order_2260 = (13), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2258, _eri_order_2259, _eri_order_2260))), _eri_order_2265 = ((_eri_order_2262 = (v_graph), _eri_order_2263 = (v_first), _eri_order_2264 = (13), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_2262, _eri_order_2263, _eri_order_2264))), (_eri_order_2261 <= _eri_order_2265)));
}

static void fn_compiler_u002e_u1_dominance_u002e_close(eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph) {
    fn_compiler_u002e_u1_words_u002e_close((v_graph)->f_data);
}

static void fn_compiler_u002e_u1_verify_u002e_invalid(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, eri_text v_message) {
    eri_fail_compiler_u002e_u1_verify_u002e_InvalidIR((eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR){.f_message = v_message, .f_category = eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x2d, 0x69, 0x72}, 10), .f_stage = (v_context)->f_stage, .f_block = (v_context)->f_block, .f_instruction = (v_context)->f_instruction, .f_location = (v_context)->f_location});
}

static void fn_compiler_u002e_u1_verify_u002e_require(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, bool v_condition, eri_text v_message) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2266;
    eri_text _eri_order_2267;
    if ((!v_condition)) {
        (_eri_order_2266 = (v_context), _eri_order_2267 = (v_message), fn_compiler_u002e_u1_verify_u002e_invalid(_eri_order_2266, _eri_order_2267));
    }
}

static int64_t fn_compiler_u002e_u1_verify_u002e_read(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, eri_struct_compiler_u002e_u1_words_u002e_Words * v_table, int64_t v_index) {
    int64_t _eri_order_2268;
    int64_t _eri_order_2269;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2270;
    int64_t _eri_order_2271;
    int64_t _eri_order_2272;
    int64_t _eri_order_2273;
    int64_t _eri_order_2274;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2275;
    int64_t _eri_order_2276;
    int64_t _eri_order_2277;
    int64_t _eri_order_2278;
    int64_t _eri_order_2279;
    bool _eri_order_2280;
    eri_text _eri_order_2281;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2282;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2283;
    int64_t _eri_order_2284;
    if ((_eri_order_2268 = ((v_context)->f_visits), _eri_order_2269 = ((v_context)->f_scanLimit), (_eri_order_2268 >= _eri_order_2269))) {
        (_eri_order_2270 = (((v_context)->f_phase)->f_owner), _eri_order_2271 = (1), _eri_order_2272 = (0), fn_compiler_u002e_u1_budget_u002e_exceed(_eri_order_2270, _eri_order_2271, _eri_order_2272));
    }
    (v_context)->f_visits = (_eri_order_2273 = ((v_context)->f_visits), _eri_order_2274 = (1), eri_iadd(_eri_order_2273, _eri_order_2274));
    (_eri_order_2275 = (v_context), _eri_order_2280 = (((_eri_order_2276 = (v_index), _eri_order_2277 = (0), (_eri_order_2276 >= _eri_order_2277)) && (_eri_order_2278 = (v_index), _eri_order_2279 = ((v_table)->f_length), (_eri_order_2278 < _eri_order_2279)))), _eri_order_2281 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x63, 0x6f, 0x72, 0x64, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x20, 0x6f, 0x75, 0x74, 0x73, 0x69, 0x64, 0x65, 0x20, 0x74, 0x61, 0x62, 0x6c, 0x65}, 26)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2275, _eri_order_2280, _eri_order_2281));
    return (_eri_order_2282 = (v_table), _eri_order_2283 = ((v_context)->f_phase), _eri_order_2284 = (v_index), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2282, _eri_order_2283, _eri_order_2284));
}

static int64_t fn_compiler_u002e_u1_verify_u002e_scratch(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_first, int64_t v_index) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2285;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2286;
    int64_t _eri_order_2287;
    int64_t _eri_order_2288;
    int64_t _eri_order_2289;
    return (_eri_order_2285 = (((v_context)->f_graph)->f_data), _eri_order_2286 = ((v_context)->f_phase), _eri_order_2289 = ((_eri_order_2287 = (v_first), _eri_order_2288 = (v_index), eri_iadd(_eri_order_2287, _eri_order_2288))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2285, _eri_order_2286, _eri_order_2289));
}

static void fn_compiler_u002e_u1_verify_u002e_mark(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_first, int64_t v_index, int64_t v_value) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2290;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2291;
    int64_t _eri_order_2292;
    int64_t _eri_order_2293;
    int64_t _eri_order_2294;
    int64_t _eri_order_2295;
    (_eri_order_2290 = (((v_context)->f_graph)->f_data), _eri_order_2291 = ((v_context)->f_phase), _eri_order_2294 = ((_eri_order_2292 = (v_first), _eri_order_2293 = (v_index), eri_iadd(_eri_order_2292, _eri_order_2293))), _eri_order_2295 = (v_value), fn_compiler_u002e_u1_words_u002e_set(_eri_order_2290, _eri_order_2291, _eri_order_2294, _eri_order_2295));
}

static void fn_compiler_u002e_u1_verify_u002e_range(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_first, int64_t v_count, int64_t v_length) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2296;
    int64_t _eri_order_2297;
    int64_t _eri_order_2298;
    int64_t _eri_order_2299;
    int64_t _eri_order_2300;
    bool _eri_order_2301;
    eri_text _eri_order_2302;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2303;
    int64_t _eri_order_2304;
    int64_t _eri_order_2305;
    int64_t _eri_order_2306;
    int64_t _eri_order_2307;
    int64_t _eri_order_2308;
    int64_t _eri_order_2309;
    bool _eri_order_2310;
    eri_text _eri_order_2311;
    (_eri_order_2296 = (v_context), _eri_order_2301 = (((_eri_order_2297 = (v_first), _eri_order_2298 = (0), (_eri_order_2297 >= _eri_order_2298)) && (_eri_order_2299 = (v_count), _eri_order_2300 = (0), (_eri_order_2299 >= _eri_order_2300)))), _eri_order_2302 = (eri_text_from_bytes((const unsigned char[]){0x6e, 0x65, 0x67, 0x61, 0x74, 0x69, 0x76, 0x65, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 14)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2296, _eri_order_2301, _eri_order_2302));
    (_eri_order_2303 = (v_context), _eri_order_2310 = (((_eri_order_2304 = (v_first), _eri_order_2305 = (v_length), (_eri_order_2304 <= _eri_order_2305)) && (_eri_order_2306 = (v_count), _eri_order_2309 = ((_eri_order_2307 = (v_length), _eri_order_2308 = (v_first), eri_isub(_eri_order_2307, _eri_order_2308))), (_eri_order_2306 <= _eri_order_2309)))), _eri_order_2311 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x63, 0x6f, 0x72, 0x64, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x20, 0x6f, 0x75, 0x74, 0x73, 0x69, 0x64, 0x65, 0x20, 0x74, 0x61, 0x62, 0x6c, 0x65}, 26)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2303, _eri_order_2310, _eri_order_2311));
}

static void fn_compiler_u002e_u1_verify_u002e_store(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, eri_struct_compiler_u002e_u1_words_u002e_Words * v_table, eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner, int64_t v_width, int64_t v_ceiling) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2312;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2313;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2314;
    bool _eri_order_2315;
    eri_text _eri_order_2316;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2317;
    int64_t _eri_order_2318;
    int64_t _eri_order_2319;
    int64_t _eri_order_2320;
    int64_t _eri_order_2321;
    int64_t _eri_order_2322;
    int64_t _eri_order_2323;
    int64_t _eri_order_2324;
    int64_t _eri_order_2325;
    bool _eri_order_2326;
    eri_text _eri_order_2327;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2328;
    int64_t _eri_order_2329;
    int64_t _eri_order_2330;
    int64_t _eri_order_2331;
    int64_t _eri_order_2332;
    int64_t _eri_order_2333;
    int64_t _eri_order_2334;
    bool _eri_order_2335;
    eri_text _eri_order_2336;
    (_eri_order_2312 = (v_context), _eri_order_2315 = ((((_eri_order_2313 = ((v_table)->f_owner), _eri_order_2314 = (v_owner), (_eri_order_2313 == _eri_order_2314)) && (!(v_table)->f_closed)) && (v_table)->f_frozen)), _eri_order_2316 = (eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x2c, 0x20, 0x63, 0x6c, 0x6f, 0x73, 0x65, 0x64, 0x2c, 0x20, 0x6f, 0x72, 0x20, 0x6d, 0x75, 0x74, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x74, 0x61, 0x62, 0x6c, 0x65}, 33)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2312, _eri_order_2315, _eri_order_2316));
    (_eri_order_2317 = (v_context), _eri_order_2326 = (((((_eri_order_2318 = ((v_table)->f_limit), _eri_order_2319 = (0), (_eri_order_2318 >= _eri_order_2319)) && (_eri_order_2320 = ((v_table)->f_limit), _eri_order_2321 = (33554432), (_eri_order_2320 <= _eri_order_2321))) && (_eri_order_2322 = ((v_table)->f_length), _eri_order_2323 = (0), (_eri_order_2322 >= _eri_order_2323))) && (_eri_order_2324 = ((v_table)->f_length), _eri_order_2325 = ((v_table)->f_limit), (_eri_order_2324 <= _eri_order_2325)))), _eri_order_2327 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x74, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x63, 0x61, 0x70, 0x61, 0x63, 0x69, 0x74, 0x79}, 22)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2317, _eri_order_2326, _eri_order_2327));
    (_eri_order_2328 = (v_context), _eri_order_2335 = (((_eri_order_2329 = ((v_table)->f_length), _eri_order_2330 = (v_ceiling), (_eri_order_2329 <= _eri_order_2330)) && (_eri_order_2333 = ((_eri_order_2331 = ((v_table)->f_length), _eri_order_2332 = (v_width), eri_irem(_eri_order_2331, _eri_order_2332))), _eri_order_2334 = (0), (_eri_order_2333 == _eri_order_2334)))), _eri_order_2336 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x74, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x73, 0x68, 0x61, 0x70, 0x65}, 19)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2328, _eri_order_2335, _eri_order_2336));
}

static void fn_compiler_u002e_u1_verify_u002e_bounds(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2337;
    int64_t _eri_order_2338;
    int64_t _eri_order_2339;
    int64_t _eri_order_2340;
    int64_t _eri_order_2341;
    bool _eri_order_2342;
    eri_text _eri_order_2343;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2344;
    bool _eri_order_2345;
    eri_text _eri_order_2346;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2347;
    int64_t _eri_order_2348;
    int64_t _eri_order_2349;
    int64_t _eri_order_2350;
    int64_t _eri_order_2351;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_2352;
    eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner _eri_order_2353;
    bool _eri_order_2354;
    eri_text _eri_order_2355;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2356;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2357;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2358;
    int64_t _eri_order_2359;
    int64_t _eri_order_2360;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2361;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2362;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2363;
    int64_t _eri_order_2364;
    int64_t _eri_order_2365;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2366;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2367;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2368;
    int64_t _eri_order_2369;
    int64_t _eri_order_2370;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2371;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2372;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2373;
    int64_t _eri_order_2374;
    int64_t _eri_order_2375;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2376;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2377;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2378;
    int64_t _eri_order_2379;
    int64_t _eri_order_2380;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2381;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2382;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2383;
    int64_t _eri_order_2384;
    int64_t _eri_order_2385;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2386;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2387;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2388;
    int64_t _eri_order_2389;
    int64_t _eri_order_2390;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2391;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2392;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2393;
    int64_t _eri_order_2394;
    int64_t _eri_order_2395;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2396;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2397;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2398;
    int64_t _eri_order_2399;
    int64_t _eri_order_2400;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2401;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2402;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2403;
    int64_t _eri_order_2404;
    int64_t _eri_order_2405;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2406;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2407;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2408;
    int64_t _eri_order_2409;
    int64_t _eri_order_2410;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2411;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2412;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2413;
    int64_t _eri_order_2414;
    int64_t _eri_order_2415;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2416;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2417;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_2418;
    int64_t _eri_order_2419;
    int64_t _eri_order_2420;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2421;
    int64_t _eri_order_2422;
    int64_t _eri_order_2423;
    int64_t _eri_order_2424;
    int64_t _eri_order_2425;
    bool _eri_order_2426;
    eri_text _eri_order_2427;
    int64_t _eri_order_2428;
    int64_t _eri_order_2429;
    int64_t _eri_order_2430;
    int64_t _eri_order_2431;
    int64_t _eri_order_2432;
    int64_t _eri_order_2433;
    int64_t _eri_order_2434;
    int64_t _eri_order_2435;
    int64_t _eri_order_2436;
    int64_t _eri_order_2437;
    int64_t _eri_order_2438;
    int64_t _eri_order_2439;
    int64_t _eri_order_2440;
    int64_t _eri_order_2441;
    int64_t _eri_order_2442;
    int64_t _eri_order_2443;
    int64_t _eri_order_2444;
    int64_t _eri_order_2445;
    int64_t _eri_order_2446;
    int64_t _eri_order_2447;
    int64_t _eri_order_2448;
    int64_t _eri_order_2449;
    int64_t _eri_order_2450;
    int64_t _eri_order_2451;
    int64_t _eri_order_2452;
    int64_t _eri_order_2453;
    int64_t _eri_order_2454;
    int64_t _eri_order_2455;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2456;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_2457;
    eri_struct_compiler_u002e_u1_meta_u002e_Key * _eri_order_2458;
    int64_t _eri_order_2459;
    int64_t _eri_order_2460;
    int64_t _eri_order_2461;
    int64_t _eri_order_2462;
    int64_t _eri_order_2463;
    int64_t _eri_order_2464;
    bool _eri_order_2465;
    eri_text _eri_order_2466;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_context)->f_routine;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_data = (v_routine)->f_metadata;
    (_eri_order_2337 = (v_context), _eri_order_2342 = (((_eri_order_2338 = ((v_routine)->f_state), _eri_order_2339 = (1), (_eri_order_2338 == _eri_order_2339)) && (_eri_order_2340 = ((v_routine)->f_revision), _eri_order_2341 = (0), (_eri_order_2340 >= _eri_order_2341)))), _eri_order_2343 = (eri_text_from_bytes((const unsigned char[]){0x63, 0x6f, 0x6d, 0x70, 0x6c, 0x65, 0x74, 0x65, 0x20, 0x63, 0x6f, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x72, 0x65, 0x71, 0x75, 0x69, 0x72, 0x65, 0x64}, 30)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2337, _eri_order_2342, _eri_order_2343));
    (_eri_order_2344 = (v_context), _eri_order_2345 = (((v_data)->f_frozen && (!(v_data)->f_closed))), _eri_order_2346 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6d, 0x6d, 0x75, 0x74, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x6d, 0x65, 0x74, 0x61, 0x64, 0x61, 0x74, 0x61, 0x20, 0x72, 0x65, 0x71, 0x75, 0x69, 0x72, 0x65, 0x64}, 27)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2344, _eri_order_2345, _eri_order_2346));
    (_eri_order_2347 = (v_context), _eri_order_2354 = ((((_eri_order_2348 = (((v_routine)->f_owner)->f_kind), _eri_order_2349 = (2), (_eri_order_2348 == _eri_order_2349)) && (_eri_order_2350 = (((v_data)->f_owner)->f_kind), _eri_order_2351 = (1), (_eri_order_2350 == _eri_order_2351))) && (_eri_order_2352 = (((v_routine)->f_owner)->f_parent), _eri_order_2353 = (((v_data)->f_owner)->f_parent), eri_maybe_identity_u0020_compiler_u002e_u1_budget_u002e_Owner_eq(_eri_order_2352, _eri_order_2353)))), _eri_order_2355 = (eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x20, 0x6d, 0x65, 0x74, 0x61, 0x64, 0x61, 0x74, 0x61, 0x20, 0x6f, 0x77, 0x6e, 0x65, 0x72, 0x73, 0x68, 0x69, 0x70}, 26)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2347, _eri_order_2354, _eri_order_2355));
    (_eri_order_2356 = (v_context), _eri_order_2357 = ((v_routine)->f_blocks), _eri_order_2358 = ((v_routine)->f_owner), _eri_order_2359 = (5), _eri_order_2360 = (327680), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2356, _eri_order_2357, _eri_order_2358, _eri_order_2359, _eri_order_2360));
    (_eri_order_2361 = (v_context), _eri_order_2362 = ((v_routine)->f_values), _eri_order_2363 = ((v_routine)->f_owner), _eri_order_2364 = (4), _eri_order_2365 = (4194304), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2361, _eri_order_2362, _eri_order_2363, _eri_order_2364, _eri_order_2365));
    (_eri_order_2366 = (v_context), _eri_order_2367 = ((v_routine)->f_instructions), _eri_order_2368 = ((v_routine)->f_owner), _eri_order_2369 = (10), _eri_order_2370 = (10485760), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2366, _eri_order_2367, _eri_order_2368, _eri_order_2369, _eri_order_2370));
    (_eri_order_2371 = (v_context), _eri_order_2372 = ((v_routine)->f_operands), _eri_order_2373 = ((v_routine)->f_owner), _eri_order_2374 = (1), _eri_order_2375 = (16777216), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2371, _eri_order_2372, _eri_order_2373, _eri_order_2374, _eri_order_2375));
    (_eri_order_2376 = (v_context), _eri_order_2377 = ((v_routine)->f_edges), _eri_order_2378 = ((v_routine)->f_owner), _eri_order_2379 = (3), _eri_order_2380 = (786432), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2376, _eri_order_2377, _eri_order_2378, _eri_order_2379, _eri_order_2380));
    (_eri_order_2381 = (v_context), _eri_order_2382 = ((v_routine)->f_arguments), _eri_order_2383 = ((v_routine)->f_owner), _eri_order_2384 = (1), _eri_order_2385 = (4194304), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2381, _eri_order_2382, _eri_order_2383, _eri_order_2384, _eri_order_2385));
    (_eri_order_2386 = (v_context), _eri_order_2387 = ((v_routine)->f_cells), _eri_order_2388 = ((v_routine)->f_owner), _eri_order_2389 = (2), _eri_order_2390 = (131072), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2386, _eri_order_2387, _eri_order_2388, _eri_order_2389, _eri_order_2390));
    (_eri_order_2391 = (v_context), _eri_order_2392 = ((v_data)->f_signatures), _eri_order_2393 = ((v_data)->f_owner), _eri_order_2394 = (6), _eri_order_2395 = (6291456), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2391, _eri_order_2392, _eri_order_2393, _eri_order_2394, _eri_order_2395));
    (_eri_order_2396 = (v_context), _eri_order_2397 = ((v_data)->f_types), _eri_order_2398 = ((v_data)->f_owner), _eri_order_2399 = (1), _eri_order_2400 = (8388608), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2396, _eri_order_2397, _eri_order_2398, _eri_order_2399, _eri_order_2400));
    (_eri_order_2401 = (v_context), _eri_order_2402 = ((v_data)->f_buckets), _eri_order_2403 = ((v_data)->f_owner), _eri_order_2404 = (1), _eri_order_2405 = (64), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2401, _eri_order_2402, _eri_order_2403, _eri_order_2404, _eri_order_2405));
    (_eri_order_2406 = (v_context), _eri_order_2407 = ((v_data)->f_sources), _eri_order_2408 = ((v_data)->f_owner), _eri_order_2409 = (4), _eri_order_2410 = (524288), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2406, _eri_order_2407, _eri_order_2408, _eri_order_2409, _eri_order_2410));
    (_eri_order_2411 = (v_context), _eri_order_2412 = ((v_data)->f_bytes), _eri_order_2413 = ((v_data)->f_owner), _eri_order_2414 = (1), _eri_order_2415 = (8388608), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2411, _eri_order_2412, _eri_order_2413, _eri_order_2414, _eri_order_2415));
    (_eri_order_2416 = (v_context), _eri_order_2417 = ((v_data)->f_locations), _eri_order_2418 = ((v_data)->f_owner), _eri_order_2419 = (7), _eri_order_2420 = (7340032), fn_compiler_u002e_u1_verify_u002e_store(_eri_order_2416, _eri_order_2417, _eri_order_2418, _eri_order_2419, _eri_order_2420));
    (_eri_order_2421 = (v_context), _eri_order_2426 = (((_eri_order_2422 = (((v_routine)->f_blocks)->f_length), _eri_order_2423 = (0), (_eri_order_2422 > _eri_order_2423)) && (_eri_order_2424 = (((v_data)->f_buckets)->f_length), _eri_order_2425 = (64), (_eri_order_2424 == _eri_order_2425)))), _eri_order_2427 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x69, 0x73, 0x73, 0x69, 0x6e, 0x67, 0x20, 0x65, 0x6e, 0x74, 0x72, 0x79, 0x20, 0x6f, 0x72, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x62, 0x75, 0x63, 0x6b, 0x65, 0x74, 0x73}, 34)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2421, _eri_order_2426, _eri_order_2427));
    int64_t v_records = (_eri_order_2436 = ((_eri_order_2434 = ((_eri_order_2432 = ((_eri_order_2430 = ((_eri_order_2428 = (((v_routine)->f_blocks)->f_length), _eri_order_2429 = (((v_routine)->f_values)->f_length), eri_iadd(_eri_order_2428, _eri_order_2429))), _eri_order_2431 = (((v_routine)->f_instructions)->f_length), eri_iadd(_eri_order_2430, _eri_order_2431))), _eri_order_2433 = (((v_routine)->f_operands)->f_length), eri_iadd(_eri_order_2432, _eri_order_2433))), _eri_order_2435 = (((v_routine)->f_edges)->f_length), eri_iadd(_eri_order_2434, _eri_order_2435))), _eri_order_2437 = (((v_routine)->f_arguments)->f_length), eri_iadd(_eri_order_2436, _eri_order_2437));
    v_records = (_eri_order_2450 = ((_eri_order_2448 = ((_eri_order_2446 = ((_eri_order_2444 = ((_eri_order_2442 = ((_eri_order_2440 = ((_eri_order_2438 = (v_records), _eri_order_2439 = (((v_routine)->f_cells)->f_length), eri_iadd(_eri_order_2438, _eri_order_2439))), _eri_order_2441 = (((v_data)->f_signatures)->f_length), eri_iadd(_eri_order_2440, _eri_order_2441))), _eri_order_2443 = (((v_data)->f_types)->f_length), eri_iadd(_eri_order_2442, _eri_order_2443))), _eri_order_2445 = (((v_data)->f_buckets)->f_length), eri_iadd(_eri_order_2444, _eri_order_2445))), _eri_order_2447 = (((v_data)->f_sources)->f_length), eri_iadd(_eri_order_2446, _eri_order_2447))), _eri_order_2449 = (((v_data)->f_bytes)->f_length), eri_iadd(_eri_order_2448, _eri_order_2449))), _eri_order_2451 = (((v_data)->f_locations)->f_length), eri_iadd(_eri_order_2450, _eri_order_2451));
    (v_context)->f_scanLimit = (_eri_order_2452 = (32), _eri_order_2455 = ((_eri_order_2453 = (v_records), _eri_order_2454 = (1), eri_iadd(_eri_order_2453, _eri_order_2454))), eri_imul(_eri_order_2452, _eri_order_2455));
    (_eri_order_2456 = (v_context), _eri_order_2465 = ((((_eri_order_2457 = (((v_routine)->f_signature).f_owner), _eri_order_2458 = ((v_data)->f_key), (_eri_order_2457 == _eri_order_2458)) && (_eri_order_2459 = (((v_routine)->f_signature).f_index), _eri_order_2460 = (1), (_eri_order_2459 >= _eri_order_2460))) && (_eri_order_2461 = (((v_routine)->f_signature).f_index), _eri_order_2464 = ((_eri_order_2462 = (((v_data)->f_signatures)->f_length), _eri_order_2463 = (6), eri_idiv(_eri_order_2462, _eri_order_2463))), (_eri_order_2461 <= _eri_order_2464)))), _eri_order_2466 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x66, 0x75, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x6f, 0x77, 0x6e, 0x65, 0x72, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x64, 0x65, 0x78}, 41)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2456, _eri_order_2465, _eri_order_2466));
}

static void fn_compiler_u002e_u1_verify_u002e_typeIndex(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_index) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2467;
    int64_t _eri_order_2468;
    int64_t _eri_order_2469;
    int64_t _eri_order_2470;
    int64_t _eri_order_2471;
    bool _eri_order_2472;
    eri_text _eri_order_2473;
    (_eri_order_2467 = (v_context), _eri_order_2472 = (((_eri_order_2468 = (v_index), _eri_order_2469 = (1), (_eri_order_2468 >= _eri_order_2469)) && (_eri_order_2470 = (v_index), _eri_order_2471 = (3), (_eri_order_2470 <= _eri_order_2471)))), _eri_order_2473 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x20, 0x73, 0x63, 0x61, 0x6c, 0x61, 0x72, 0x20, 0x74, 0x79, 0x70, 0x65}, 23)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2467, _eri_order_2472, _eri_order_2473));
}

static bool fn_compiler_u002e_u1_verify_u002e_sameSequence(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, eri_struct_compiler_u002e_u1_words_u002e_Words * v_table, int64_t v_first, int64_t v_second, int64_t v_count) {
    int64_t _eri_order_2474;
    int64_t _eri_order_2475;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2476;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2477;
    int64_t _eri_order_2478;
    int64_t _eri_order_2479;
    int64_t _eri_order_2480;
    int64_t _eri_order_2481;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2482;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2483;
    int64_t _eri_order_2484;
    int64_t _eri_order_2485;
    int64_t _eri_order_2486;
    int64_t _eri_order_2487;
    int64_t _eri_order_2488;
    int64_t _eri_order_2489;
    int64_t v_index = 0;
    while ((_eri_order_2474 = (v_index), _eri_order_2475 = (v_count), (_eri_order_2474 < _eri_order_2475))) {
        if ((_eri_order_2481 = ((_eri_order_2476 = (v_table), _eri_order_2477 = ((v_context)->f_phase), _eri_order_2480 = ((_eri_order_2478 = (v_first), _eri_order_2479 = (v_index), eri_iadd(_eri_order_2478, _eri_order_2479))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2476, _eri_order_2477, _eri_order_2480))), _eri_order_2487 = ((_eri_order_2482 = (v_table), _eri_order_2483 = ((v_context)->f_phase), _eri_order_2486 = ((_eri_order_2484 = (v_second), _eri_order_2485 = (v_index), eri_iadd(_eri_order_2484, _eri_order_2485))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2482, _eri_order_2483, _eri_order_2486))), (_eri_order_2481 != _eri_order_2487))) {
            return false;
        }
        v_index = (_eri_order_2488 = (v_index), _eri_order_2489 = (1), eri_iadd(_eri_order_2488, _eri_order_2489));
    }
    return true;
}

static void fn_compiler_u002e_u1_verify_u002e_signatures(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context) {
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_2490;
    int64_t _eri_order_2491;
    int64_t _eri_order_2492;
    int64_t _eri_order_2493;
    int64_t _eri_order_2494;
    int64_t _eri_order_2495;
    int64_t _eri_order_2496;
    int64_t _eri_order_2497;
    int64_t _eri_order_2498;
    int64_t _eri_order_2499;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2500;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2501;
    int64_t _eri_order_2502;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2503;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2504;
    int64_t _eri_order_2505;
    int64_t _eri_order_2506;
    int64_t _eri_order_2507;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2508;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2509;
    int64_t _eri_order_2510;
    int64_t _eri_order_2511;
    int64_t _eri_order_2512;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2513;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2514;
    int64_t _eri_order_2515;
    int64_t _eri_order_2516;
    int64_t _eri_order_2517;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2518;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2519;
    int64_t _eri_order_2520;
    int64_t _eri_order_2521;
    int64_t _eri_order_2522;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2523;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2524;
    int64_t _eri_order_2525;
    int64_t _eri_order_2526;
    int64_t _eri_order_2527;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2528;
    int64_t _eri_order_2529;
    int64_t _eri_order_2530;
    int64_t _eri_order_2531;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2532;
    int64_t _eri_order_2533;
    int64_t _eri_order_2534;
    int64_t _eri_order_2535;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2536;
    int64_t _eri_order_2537;
    int64_t _eri_order_2538;
    int64_t _eri_order_2539;
    int64_t _eri_order_2540;
    int64_t _eri_order_2541;
    int64_t _eri_order_2542;
    bool _eri_order_2543;
    eri_text _eri_order_2544;
    int64_t _eri_order_2545;
    int64_t _eri_order_2546;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2547;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2548;
    int64_t _eri_order_2549;
    int64_t _eri_order_2550;
    int64_t _eri_order_2551;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2552;
    int64_t _eri_order_2553;
    int64_t _eri_order_2554;
    int64_t _eri_order_2555;
    int64_t _eri_order_2556;
    int64_t _eri_order_2557;
    int64_t _eri_order_2558;
    int64_t _eri_order_2559;
    int64_t _eri_order_2560;
    int64_t _eri_order_2561;
    int64_t _eri_order_2562;
    int64_t _eri_order_2563;
    int64_t _eri_order_2564;
    int64_t _eri_order_2565;
    int64_t _eri_order_2566;
    int64_t _eri_order_2567;
    int64_t _eri_order_2568;
    int64_t _eri_order_2569;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2570;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2571;
    int64_t _eri_order_2572;
    int64_t _eri_order_2573;
    int64_t _eri_order_2574;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2575;
    int64_t _eri_order_2576;
    int64_t _eri_order_2577;
    int64_t _eri_order_2578;
    int64_t _eri_order_2579;
    int64_t _eri_order_2580;
    int64_t _eri_order_2581;
    int64_t _eri_order_2582;
    int64_t _eri_order_2583;
    int64_t _eri_order_2584;
    int64_t _eri_order_2585;
    int64_t _eri_order_2586;
    int64_t _eri_order_2587;
    int64_t _eri_order_2588;
    int64_t _eri_order_2589;
    int64_t _eri_order_2590;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2591;
    int64_t _eri_order_2592;
    int64_t _eri_order_2593;
    bool _eri_order_2594;
    eri_text _eri_order_2595;
    int64_t _eri_order_2596;
    int64_t _eri_order_2597;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2598;
    int64_t _eri_order_2599;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2600;
    int64_t _eri_order_2601;
    int64_t _eri_order_2602;
    int64_t _eri_order_2603;
    bool _eri_order_2604;
    eri_text _eri_order_2605;
    int64_t _eri_order_2606;
    int64_t _eri_order_2607;
    int64_t _eri_order_2608;
    int64_t _eri_order_2609;
    int64_t _eri_order_2610;
    int64_t _eri_order_2611;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2612;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2613;
    int64_t _eri_order_2614;
    int64_t _eri_order_2615;
    int64_t _eri_order_2616;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2617;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2618;
    int64_t _eri_order_2619;
    int64_t _eri_order_2620;
    int64_t _eri_order_2621;
    int64_t _eri_order_2622;
    int64_t _eri_order_2623;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2624;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2625;
    int64_t _eri_order_2626;
    int64_t _eri_order_2627;
    int64_t _eri_order_2628;
    int64_t _eri_order_2629;
    int64_t _eri_order_2630;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2631;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2632;
    int64_t _eri_order_2633;
    int64_t _eri_order_2634;
    int64_t _eri_order_2635;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2636;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2637;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2638;
    int64_t _eri_order_2639;
    int64_t _eri_order_2640;
    int64_t _eri_order_2641;
    int64_t _eri_order_2642;
    int64_t _eri_order_2643;
    bool _eri_order_2644;
    eri_text _eri_order_2645;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2646;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2647;
    int64_t _eri_order_2648;
    int64_t _eri_order_2649;
    int64_t _eri_order_2650;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2651;
    int64_t _eri_order_2652;
    int64_t _eri_order_2653;
    int64_t _eri_order_2654;
    int64_t _eri_order_2655;
    int64_t _eri_order_2656;
    int64_t _eri_order_2657;
    int64_t _eri_order_2658;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2659;
    int64_t _eri_order_2660;
    int64_t _eri_order_2661;
    bool _eri_order_2662;
    eri_text _eri_order_2663;
    int64_t _eri_order_2664;
    int64_t _eri_order_2665;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2666;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2667;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2668;
    int64_t _eri_order_2669;
    int64_t _eri_order_2670;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2671;
    int64_t _eri_order_2672;
    int64_t _eri_order_2673;
    int64_t _eri_order_2674;
    bool _eri_order_2675;
    eri_text _eri_order_2676;
    int64_t _eri_order_2677;
    int64_t _eri_order_2678;
    (v_context)->f_stage = 1;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_data = ((v_context)->f_routine)->f_metadata;
    int64_t v_cursor = 0;
    int64_t v_index = 1;
    (v_context)->f_buckets = (_eri_order_2490 = ((v_context)->f_graph), _eri_order_2491 = (64), fn_compiler_u002e_u1_dominance_u002e_zeros(_eri_order_2490, _eri_order_2491));
    while ((_eri_order_2492 = (v_index), _eri_order_2495 = ((_eri_order_2493 = (((v_data)->f_signatures)->f_length), _eri_order_2494 = (6), eri_idiv(_eri_order_2493, _eri_order_2494))), (_eri_order_2492 <= _eri_order_2495))) {
        int64_t v_offset = (_eri_order_2498 = ((_eri_order_2496 = (v_index), _eri_order_2497 = (1), eri_isub(_eri_order_2496, _eri_order_2497))), _eri_order_2499 = (6), eri_imul(_eri_order_2498, _eri_order_2499));
        int64_t v_hash = (_eri_order_2500 = (v_context), _eri_order_2501 = ((v_data)->f_signatures), _eri_order_2502 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2500, _eri_order_2501, _eri_order_2502));
        int64_t v_previous = (_eri_order_2503 = (v_context), _eri_order_2504 = ((v_data)->f_signatures), _eri_order_2507 = ((_eri_order_2505 = (v_offset), _eri_order_2506 = (1), eri_iadd(_eri_order_2505, _eri_order_2506))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2503, _eri_order_2504, _eri_order_2507));
        int64_t v_first = (_eri_order_2508 = (v_context), _eri_order_2509 = ((v_data)->f_signatures), _eri_order_2512 = ((_eri_order_2510 = (v_offset), _eri_order_2511 = (2), eri_iadd(_eri_order_2510, _eri_order_2511))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2508, _eri_order_2509, _eri_order_2512));
        int64_t v_parameters = (_eri_order_2513 = (v_context), _eri_order_2514 = ((v_data)->f_signatures), _eri_order_2517 = ((_eri_order_2515 = (v_offset), _eri_order_2516 = (3), eri_iadd(_eri_order_2515, _eri_order_2516))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2513, _eri_order_2514, _eri_order_2517));
        int64_t v_second = (_eri_order_2518 = (v_context), _eri_order_2519 = ((v_data)->f_signatures), _eri_order_2522 = ((_eri_order_2520 = (v_offset), _eri_order_2521 = (4), eri_iadd(_eri_order_2520, _eri_order_2521))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2518, _eri_order_2519, _eri_order_2522));
        int64_t v_results = (_eri_order_2523 = (v_context), _eri_order_2524 = ((v_data)->f_signatures), _eri_order_2527 = ((_eri_order_2525 = (v_offset), _eri_order_2526 = (5), eri_iadd(_eri_order_2525, _eri_order_2526))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2523, _eri_order_2524, _eri_order_2527));
        (_eri_order_2528 = (v_context), _eri_order_2529 = (v_first), _eri_order_2530 = (v_parameters), _eri_order_2531 = (((v_data)->f_types)->f_length), fn_compiler_u002e_u1_verify_u002e_range(_eri_order_2528, _eri_order_2529, _eri_order_2530, _eri_order_2531));
        (_eri_order_2532 = (v_context), _eri_order_2533 = (v_second), _eri_order_2534 = (v_results), _eri_order_2535 = (((v_data)->f_types)->f_length), fn_compiler_u002e_u1_verify_u002e_range(_eri_order_2532, _eri_order_2533, _eri_order_2534, _eri_order_2535));
        (_eri_order_2536 = (v_context), _eri_order_2543 = (((_eri_order_2537 = (v_first), _eri_order_2538 = (v_cursor), (_eri_order_2537 == _eri_order_2538)) && (_eri_order_2539 = (v_second), _eri_order_2542 = ((_eri_order_2540 = (v_first), _eri_order_2541 = (v_parameters), eri_iadd(_eri_order_2540, _eri_order_2541))), (_eri_order_2539 == _eri_order_2542)))), _eri_order_2544 = (eri_text_from_bytes((const unsigned char[]){0x6e, 0x6f, 0x6e, 0x63, 0x61, 0x6e, 0x6f, 0x6e, 0x69, 0x63, 0x61, 0x6c, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x73}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2536, _eri_order_2543, _eri_order_2544));
        int64_t v_actual = 17;
        int64_t v_item = 0;
        while ((_eri_order_2545 = (v_item), _eri_order_2546 = (v_parameters), (_eri_order_2545 < _eri_order_2546))) {
            int64_t v_value = (_eri_order_2547 = (v_context), _eri_order_2548 = ((v_data)->f_types), _eri_order_2551 = ((_eri_order_2549 = (v_first), _eri_order_2550 = (v_item), eri_iadd(_eri_order_2549, _eri_order_2550))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2547, _eri_order_2548, _eri_order_2551));
            (_eri_order_2552 = (v_context), _eri_order_2553 = (v_value), fn_compiler_u002e_u1_verify_u002e_typeIndex(_eri_order_2552, _eri_order_2553));
            v_actual = (_eri_order_2558 = ((_eri_order_2556 = ((_eri_order_2554 = (v_actual), _eri_order_2555 = (131), eri_imul(_eri_order_2554, _eri_order_2555))), _eri_order_2557 = (v_value), eri_iadd(_eri_order_2556, _eri_order_2557))), _eri_order_2559 = (2147483629), eri_irem(_eri_order_2558, _eri_order_2559));
            v_item = (_eri_order_2560 = (v_item), _eri_order_2561 = (1), eri_iadd(_eri_order_2560, _eri_order_2561));
        }
        v_actual = (_eri_order_2566 = ((_eri_order_2564 = ((_eri_order_2562 = (v_actual), _eri_order_2563 = (131), eri_imul(_eri_order_2562, _eri_order_2563))), _eri_order_2565 = (v_parameters), eri_iadd(_eri_order_2564, _eri_order_2565))), _eri_order_2567 = (2147483629), eri_irem(_eri_order_2566, _eri_order_2567));
        v_item = 0;
        while ((_eri_order_2568 = (v_item), _eri_order_2569 = (v_results), (_eri_order_2568 < _eri_order_2569))) {
            int64_t v_value = (_eri_order_2570 = (v_context), _eri_order_2571 = ((v_data)->f_types), _eri_order_2574 = ((_eri_order_2572 = (v_second), _eri_order_2573 = (v_item), eri_iadd(_eri_order_2572, _eri_order_2573))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2570, _eri_order_2571, _eri_order_2574));
            (_eri_order_2575 = (v_context), _eri_order_2576 = (v_value), fn_compiler_u002e_u1_verify_u002e_typeIndex(_eri_order_2575, _eri_order_2576));
            v_actual = (_eri_order_2581 = ((_eri_order_2579 = ((_eri_order_2577 = (v_actual), _eri_order_2578 = (131), eri_imul(_eri_order_2577, _eri_order_2578))), _eri_order_2580 = (v_value), eri_iadd(_eri_order_2579, _eri_order_2580))), _eri_order_2582 = (2147483629), eri_irem(_eri_order_2581, _eri_order_2582));
            v_item = (_eri_order_2583 = (v_item), _eri_order_2584 = (1), eri_iadd(_eri_order_2583, _eri_order_2584));
        }
        v_actual = (_eri_order_2589 = ((_eri_order_2587 = ((_eri_order_2585 = (v_actual), _eri_order_2586 = (131), eri_imul(_eri_order_2585, _eri_order_2586))), _eri_order_2588 = (v_results), eri_iadd(_eri_order_2587, _eri_order_2588))), _eri_order_2590 = (2147483629), eri_irem(_eri_order_2589, _eri_order_2590));
        (_eri_order_2591 = (v_context), _eri_order_2594 = ((_eri_order_2592 = (v_hash), _eri_order_2593 = (v_actual), (_eri_order_2592 == _eri_order_2593))), _eri_order_2595 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x68, 0x61, 0x73, 0x68}, 22)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2591, _eri_order_2594, _eri_order_2595));
        int64_t v_bucket = (_eri_order_2596 = (v_hash), _eri_order_2597 = (64), eri_irem(_eri_order_2596, _eri_order_2597));
        (_eri_order_2598 = (v_context), _eri_order_2604 = ((_eri_order_2599 = (v_previous), _eri_order_2603 = ((_eri_order_2600 = (v_context), _eri_order_2601 = ((v_context)->f_buckets), _eri_order_2602 = (v_bucket), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_2600, _eri_order_2601, _eri_order_2602))), (_eri_order_2599 == _eri_order_2603))), _eri_order_2605 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x63, 0x6f, 0x6c, 0x6c, 0x69, 0x73, 0x69, 0x6f, 0x6e, 0x20, 0x63, 0x68, 0x61, 0x69, 0x6e}, 33)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2598, _eri_order_2604, _eri_order_2605));
        int64_t v_collision = v_previous;
        while ((_eri_order_2606 = (v_collision), _eri_order_2607 = (0), (_eri_order_2606 != _eri_order_2607))) {
            int64_t v_other = (_eri_order_2610 = ((_eri_order_2608 = (v_collision), _eri_order_2609 = (1), eri_isub(_eri_order_2608, _eri_order_2609))), _eri_order_2611 = (6), eri_imul(_eri_order_2610, _eri_order_2611));
            if ((((_eri_order_2615 = ((_eri_order_2612 = ((v_data)->f_signatures), _eri_order_2613 = ((v_context)->f_phase), _eri_order_2614 = (v_other), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2612, _eri_order_2613, _eri_order_2614))), _eri_order_2616 = (v_hash), (_eri_order_2615 == _eri_order_2616)) && (_eri_order_2622 = ((_eri_order_2617 = ((v_data)->f_signatures), _eri_order_2618 = ((v_context)->f_phase), _eri_order_2621 = ((_eri_order_2619 = (v_other), _eri_order_2620 = (3), eri_iadd(_eri_order_2619, _eri_order_2620))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2617, _eri_order_2618, _eri_order_2621))), _eri_order_2623 = (v_parameters), (_eri_order_2622 == _eri_order_2623))) && (_eri_order_2629 = ((_eri_order_2624 = ((v_data)->f_signatures), _eri_order_2625 = ((v_context)->f_phase), _eri_order_2628 = ((_eri_order_2626 = (v_other), _eri_order_2627 = (5), eri_iadd(_eri_order_2626, _eri_order_2627))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2624, _eri_order_2625, _eri_order_2628))), _eri_order_2630 = (v_results), (_eri_order_2629 == _eri_order_2630)))) {
                int64_t v_start = (_eri_order_2631 = ((v_data)->f_signatures), _eri_order_2632 = ((v_context)->f_phase), _eri_order_2635 = ((_eri_order_2633 = (v_other), _eri_order_2634 = (2), eri_iadd(_eri_order_2633, _eri_order_2634))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2631, _eri_order_2632, _eri_order_2635));
                (_eri_order_2636 = (v_context), _eri_order_2644 = ((!(_eri_order_2637 = (v_context), _eri_order_2638 = ((v_data)->f_types), _eri_order_2639 = (v_first), _eri_order_2640 = (v_start), _eri_order_2643 = ((_eri_order_2641 = (v_parameters), _eri_order_2642 = (v_results), eri_iadd(_eri_order_2641, _eri_order_2642))), fn_compiler_u002e_u1_verify_u002e_sameSequence(_eri_order_2637, _eri_order_2638, _eri_order_2639, _eri_order_2640, _eri_order_2643)))), _eri_order_2645 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x75, 0x70, 0x6c, 0x69, 0x63, 0x61, 0x74, 0x65, 0x20, 0x63, 0x61, 0x6e, 0x6f, 0x6e, 0x69, 0x63, 0x61, 0x6c, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2636, _eri_order_2644, _eri_order_2645));
            }
            v_collision = (_eri_order_2646 = ((v_data)->f_signatures), _eri_order_2647 = ((v_context)->f_phase), _eri_order_2650 = ((_eri_order_2648 = (v_other), _eri_order_2649 = (1), eri_iadd(_eri_order_2648, _eri_order_2649))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2646, _eri_order_2647, _eri_order_2650));
        }
        (_eri_order_2651 = (v_context), _eri_order_2652 = ((v_context)->f_buckets), _eri_order_2653 = (v_bucket), _eri_order_2654 = (v_index), fn_compiler_u002e_u1_verify_u002e_mark(_eri_order_2651, _eri_order_2652, _eri_order_2653, _eri_order_2654));
        v_cursor = (_eri_order_2655 = (v_second), _eri_order_2656 = (v_results), eri_iadd(_eri_order_2655, _eri_order_2656));
        v_index = (_eri_order_2657 = (v_index), _eri_order_2658 = (1), eri_iadd(_eri_order_2657, _eri_order_2658));
    }
    (_eri_order_2659 = (v_context), _eri_order_2662 = ((_eri_order_2660 = (v_cursor), _eri_order_2661 = (((v_data)->f_types)->f_length), (_eri_order_2660 == _eri_order_2661))), _eri_order_2663 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x63, 0x6c, 0x61, 0x69, 0x6d, 0x65, 0x64, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x65, 0x6e, 0x74, 0x72, 0x69, 0x65, 0x73}, 32)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2659, _eri_order_2662, _eri_order_2663));
    v_index = 0;
    while ((_eri_order_2664 = (v_index), _eri_order_2665 = (64), (_eri_order_2664 < _eri_order_2665))) {
        (_eri_order_2666 = (v_context), _eri_order_2675 = ((_eri_order_2670 = ((_eri_order_2667 = (v_context), _eri_order_2668 = ((v_data)->f_buckets), _eri_order_2669 = (v_index), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2667, _eri_order_2668, _eri_order_2669))), _eri_order_2674 = ((_eri_order_2671 = (v_context), _eri_order_2672 = ((v_context)->f_buckets), _eri_order_2673 = (v_index), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_2671, _eri_order_2672, _eri_order_2673))), (_eri_order_2670 == _eri_order_2674))), _eri_order_2676 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x62, 0x75, 0x63, 0x6b, 0x65, 0x74}, 24)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2666, _eri_order_2675, _eri_order_2676));
        v_index = (_eri_order_2677 = (v_index), _eri_order_2678 = (1), eri_iadd(_eri_order_2677, _eri_order_2678));
    }
}

static void fn_compiler_u002e_u1_verify_u002e_utf8(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_first, int64_t v_count) {
    int64_t _eri_order_2679;
    int64_t _eri_order_2680;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2681;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2682;
    int64_t _eri_order_2683;
    int64_t _eri_order_2684;
    int64_t _eri_order_2685;
    int64_t _eri_order_2686;
    int64_t _eri_order_2687;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2688;
    int64_t _eri_order_2689;
    int64_t _eri_order_2690;
    bool _eri_order_2691;
    eri_text _eri_order_2692;
    int64_t _eri_order_2693;
    int64_t _eri_order_2694;
    int64_t _eri_order_2695;
    int64_t _eri_order_2696;
    int64_t _eri_order_2697;
    int64_t _eri_order_2698;
    int64_t _eri_order_2699;
    int64_t _eri_order_2700;
    int64_t _eri_order_2701;
    int64_t _eri_order_2702;
    int64_t _eri_order_2703;
    int64_t _eri_order_2704;
    int64_t _eri_order_2705;
    int64_t _eri_order_2706;
    int64_t _eri_order_2707;
    int64_t _eri_order_2708;
    int64_t _eri_order_2709;
    int64_t _eri_order_2710;
    int64_t _eri_order_2711;
    int64_t _eri_order_2712;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2713;
    eri_text _eri_order_2714;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2715;
    int64_t _eri_order_2716;
    int64_t _eri_order_2717;
    int64_t _eri_order_2718;
    int64_t _eri_order_2719;
    bool _eri_order_2720;
    eri_text _eri_order_2721;
    int64_t _eri_order_2722;
    int64_t _eri_order_2723;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2724;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2725;
    int64_t _eri_order_2726;
    int64_t _eri_order_2727;
    int64_t _eri_order_2728;
    int64_t _eri_order_2729;
    int64_t _eri_order_2730;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2731;
    int64_t _eri_order_2732;
    int64_t _eri_order_2733;
    int64_t _eri_order_2734;
    int64_t _eri_order_2735;
    bool _eri_order_2736;
    eri_text _eri_order_2737;
    int64_t _eri_order_2738;
    int64_t _eri_order_2739;
    int64_t _eri_order_2740;
    int64_t _eri_order_2741;
    int64_t _eri_order_2742;
    int64_t _eri_order_2743;
    eri_struct_compiler_u002e_u1_words_u002e_Words * v_table = (((v_context)->f_routine)->f_metadata)->f_bytes;
    int64_t v_index = 0;
    while ((_eri_order_2679 = (v_index), _eri_order_2680 = (v_count), (_eri_order_2679 < _eri_order_2680))) {
        int64_t v_value = (_eri_order_2681 = (v_context), _eri_order_2682 = (v_table), _eri_order_2685 = ((_eri_order_2683 = (v_first), _eri_order_2684 = (v_index), eri_iadd(_eri_order_2683, _eri_order_2684))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2681, _eri_order_2682, _eri_order_2685));
        int64_t v_trailing = 0;
        int64_t v_low = 128;
        int64_t v_high = 191;
        if ((_eri_order_2686 = (v_value), _eri_order_2687 = (127), (_eri_order_2686 <= _eri_order_2687))) {
            (_eri_order_2688 = (v_context), _eri_order_2691 = ((_eri_order_2689 = (v_value), _eri_order_2690 = (0), (_eri_order_2689 >= _eri_order_2690))), _eri_order_2692 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x6e, 0x61, 0x6d, 0x65, 0x20, 0x62, 0x79, 0x74, 0x65}, 24)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2688, _eri_order_2691, _eri_order_2692));
        } else {
            if (((_eri_order_2693 = (v_value), _eri_order_2694 = (194), (_eri_order_2693 >= _eri_order_2694)) && (_eri_order_2695 = (v_value), _eri_order_2696 = (223), (_eri_order_2695 <= _eri_order_2696)))) {
                v_trailing = 1;
            } else {
                if (((_eri_order_2697 = (v_value), _eri_order_2698 = (224), (_eri_order_2697 >= _eri_order_2698)) && (_eri_order_2699 = (v_value), _eri_order_2700 = (239), (_eri_order_2699 <= _eri_order_2700)))) {
                    v_trailing = 2;
                    if ((_eri_order_2701 = (v_value), _eri_order_2702 = (224), (_eri_order_2701 == _eri_order_2702))) {
                        v_low = 160;
                    }
                    if ((_eri_order_2703 = (v_value), _eri_order_2704 = (237), (_eri_order_2703 == _eri_order_2704))) {
                        v_high = 159;
                    }
                } else {
                    if (((_eri_order_2705 = (v_value), _eri_order_2706 = (240), (_eri_order_2705 >= _eri_order_2706)) && (_eri_order_2707 = (v_value), _eri_order_2708 = (244), (_eri_order_2707 <= _eri_order_2708)))) {
                        v_trailing = 3;
                        if ((_eri_order_2709 = (v_value), _eri_order_2710 = (240), (_eri_order_2709 == _eri_order_2710))) {
                            v_low = 144;
                        }
                        if ((_eri_order_2711 = (v_value), _eri_order_2712 = (244), (_eri_order_2711 == _eri_order_2712))) {
                            v_high = 143;
                        }
                    } else {
                        (_eri_order_2713 = (v_context), _eri_order_2714 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x54, 0x46, 0x2d, 0x38, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x69, 0x64, 0x65, 0x6e, 0x74, 0x69, 0x74, 0x79}, 29)), fn_compiler_u002e_u1_verify_u002e_invalid(_eri_order_2713, _eri_order_2714));
                    }
                }
            }
            (_eri_order_2715 = (v_context), _eri_order_2720 = ((_eri_order_2716 = (v_trailing), _eri_order_2719 = ((_eri_order_2717 = (v_count), _eri_order_2718 = (v_index), eri_isub(_eri_order_2717, _eri_order_2718))), (_eri_order_2716 < _eri_order_2719))), _eri_order_2721 = (eri_text_from_bytes((const unsigned char[]){0x74, 0x72, 0x75, 0x6e, 0x63, 0x61, 0x74, 0x65, 0x64, 0x20, 0x55, 0x54, 0x46, 0x2d, 0x38, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x69, 0x64, 0x65, 0x6e, 0x74, 0x69, 0x74, 0x79}, 31)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2715, _eri_order_2720, _eri_order_2721));
            int64_t v_part = 1;
            while ((_eri_order_2722 = (v_part), _eri_order_2723 = (v_trailing), (_eri_order_2722 <= _eri_order_2723))) {
                int64_t v_byte = (_eri_order_2724 = (v_context), _eri_order_2725 = (v_table), _eri_order_2730 = ((_eri_order_2728 = ((_eri_order_2726 = (v_first), _eri_order_2727 = (v_index), eri_iadd(_eri_order_2726, _eri_order_2727))), _eri_order_2729 = (v_part), eri_iadd(_eri_order_2728, _eri_order_2729))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2724, _eri_order_2725, _eri_order_2730));
                (_eri_order_2731 = (v_context), _eri_order_2736 = (((_eri_order_2732 = (v_byte), _eri_order_2733 = (v_low), (_eri_order_2732 >= _eri_order_2733)) && (_eri_order_2734 = (v_byte), _eri_order_2735 = (v_high), (_eri_order_2734 <= _eri_order_2735)))), _eri_order_2737 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x55, 0x54, 0x46, 0x2d, 0x38, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x69, 0x64, 0x65, 0x6e, 0x74, 0x69, 0x74, 0x79}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2731, _eri_order_2736, _eri_order_2737));
                v_low = 128;
                v_high = 191;
                v_part = (_eri_order_2738 = (v_part), _eri_order_2739 = (1), eri_iadd(_eri_order_2738, _eri_order_2739));
            }
        }
        v_index = (_eri_order_2742 = ((_eri_order_2740 = (v_index), _eri_order_2741 = (v_trailing), eri_iadd(_eri_order_2740, _eri_order_2741))), _eri_order_2743 = (1), eri_iadd(_eri_order_2742, _eri_order_2743));
    }
}

static void fn_compiler_u002e_u1_verify_u002e_sources(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context) {
    int64_t _eri_order_2744;
    int64_t _eri_order_2745;
    int64_t _eri_order_2746;
    int64_t _eri_order_2747;
    int64_t _eri_order_2748;
    int64_t _eri_order_2749;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2750;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2751;
    int64_t _eri_order_2752;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2753;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2754;
    int64_t _eri_order_2755;
    int64_t _eri_order_2756;
    int64_t _eri_order_2757;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2758;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2759;
    int64_t _eri_order_2760;
    int64_t _eri_order_2761;
    int64_t _eri_order_2762;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2763;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2764;
    int64_t _eri_order_2765;
    int64_t _eri_order_2766;
    int64_t _eri_order_2767;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2768;
    int64_t _eri_order_2769;
    int64_t _eri_order_2770;
    int64_t _eri_order_2771;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2772;
    int64_t _eri_order_2773;
    int64_t _eri_order_2774;
    int64_t _eri_order_2775;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2776;
    int64_t _eri_order_2777;
    int64_t _eri_order_2778;
    int64_t _eri_order_2779;
    int64_t _eri_order_2780;
    int64_t _eri_order_2781;
    int64_t _eri_order_2782;
    int64_t _eri_order_2783;
    int64_t _eri_order_2784;
    int64_t _eri_order_2785;
    int64_t _eri_order_2786;
    bool _eri_order_2787;
    eri_text _eri_order_2788;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2789;
    int64_t _eri_order_2790;
    int64_t _eri_order_2791;
    int64_t _eri_order_2792;
    int64_t _eri_order_2793;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2794;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2795;
    int64_t _eri_order_2796;
    int64_t _eri_order_2797;
    int64_t _eri_order_2798;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2799;
    int64_t _eri_order_2800;
    int64_t _eri_order_2801;
    int64_t _eri_order_2802;
    int64_t _eri_order_2803;
    int64_t _eri_order_2804;
    int64_t _eri_order_2805;
    int64_t _eri_order_2806;
    int64_t _eri_order_2807;
    bool _eri_order_2808;
    eri_text _eri_order_2809;
    int64_t _eri_order_2810;
    int64_t _eri_order_2811;
    int64_t _eri_order_2812;
    int64_t _eri_order_2813;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2814;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2815;
    int64_t _eri_order_2816;
    int64_t _eri_order_2817;
    int64_t _eri_order_2818;
    int64_t _eri_order_2819;
    int64_t _eri_order_2820;
    int64_t _eri_order_2821;
    int64_t _eri_order_2822;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2823;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_2824;
    int64_t _eri_order_2825;
    int64_t _eri_order_2826;
    int64_t _eri_order_2827;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2828;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2829;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2830;
    int64_t _eri_order_2831;
    int64_t _eri_order_2832;
    int64_t _eri_order_2833;
    bool _eri_order_2834;
    eri_text _eri_order_2835;
    int64_t _eri_order_2836;
    int64_t _eri_order_2837;
    int64_t _eri_order_2838;
    int64_t _eri_order_2839;
    int64_t _eri_order_2840;
    int64_t _eri_order_2841;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2842;
    int64_t _eri_order_2843;
    int64_t _eri_order_2844;
    bool _eri_order_2845;
    eri_text _eri_order_2846;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_data = ((v_context)->f_routine)->f_metadata;
    int64_t v_index = 0;
    int64_t v_cursor = 0;
    while ((_eri_order_2744 = (v_index), _eri_order_2747 = ((_eri_order_2745 = (((v_data)->f_sources)->f_length), _eri_order_2746 = (4), eri_idiv(_eri_order_2745, _eri_order_2746))), (_eri_order_2744 < _eri_order_2747))) {
        int64_t v_offset = (_eri_order_2748 = (v_index), _eri_order_2749 = (4), eri_imul(_eri_order_2748, _eri_order_2749));
        int64_t v_first = (_eri_order_2750 = (v_context), _eri_order_2751 = ((v_data)->f_sources), _eri_order_2752 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2750, _eri_order_2751, _eri_order_2752));
        int64_t v_count = (_eri_order_2753 = (v_context), _eri_order_2754 = ((v_data)->f_sources), _eri_order_2757 = ((_eri_order_2755 = (v_offset), _eri_order_2756 = (1), eri_iadd(_eri_order_2755, _eri_order_2756))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2753, _eri_order_2754, _eri_order_2757));
        int64_t v_digest = (_eri_order_2758 = (v_context), _eri_order_2759 = ((v_data)->f_sources), _eri_order_2762 = ((_eri_order_2760 = (v_offset), _eri_order_2761 = (2), eri_iadd(_eri_order_2760, _eri_order_2761))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2758, _eri_order_2759, _eri_order_2762));
        int64_t v_length = (_eri_order_2763 = (v_context), _eri_order_2764 = ((v_data)->f_sources), _eri_order_2767 = ((_eri_order_2765 = (v_offset), _eri_order_2766 = (3), eri_iadd(_eri_order_2765, _eri_order_2766))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2763, _eri_order_2764, _eri_order_2767));
        (_eri_order_2768 = (v_context), _eri_order_2769 = (v_first), _eri_order_2770 = (v_count), _eri_order_2771 = (((v_data)->f_bytes)->f_length), fn_compiler_u002e_u1_verify_u002e_range(_eri_order_2768, _eri_order_2769, _eri_order_2770, _eri_order_2771));
        (_eri_order_2772 = (v_context), _eri_order_2773 = (v_digest), _eri_order_2774 = (64), _eri_order_2775 = (((v_data)->f_bytes)->f_length), fn_compiler_u002e_u1_verify_u002e_range(_eri_order_2772, _eri_order_2773, _eri_order_2774, _eri_order_2775));
        (_eri_order_2776 = (v_context), _eri_order_2787 = (((((_eri_order_2777 = (v_count), _eri_order_2778 = (0), (_eri_order_2777 > _eri_order_2778)) && (_eri_order_2779 = (v_first), _eri_order_2780 = (v_cursor), (_eri_order_2779 == _eri_order_2780))) && (_eri_order_2781 = (v_digest), _eri_order_2784 = ((_eri_order_2782 = (v_first), _eri_order_2783 = (v_count), eri_iadd(_eri_order_2782, _eri_order_2783))), (_eri_order_2781 == _eri_order_2784))) && (_eri_order_2785 = (v_length), _eri_order_2786 = (0), (_eri_order_2785 >= _eri_order_2786)))), _eri_order_2788 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x69, 0x64, 0x65, 0x6e, 0x74, 0x69, 0x74, 0x79, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x73}, 30)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2776, _eri_order_2787, _eri_order_2788));
        (_eri_order_2789 = (v_context), _eri_order_2790 = (v_first), _eri_order_2791 = (v_count), fn_compiler_u002e_u1_verify_u002e_utf8(_eri_order_2789, _eri_order_2790, _eri_order_2791));
        int64_t v_item = 0;
        while ((_eri_order_2792 = (v_item), _eri_order_2793 = (64), (_eri_order_2792 < _eri_order_2793))) {
            int64_t v_byte = (_eri_order_2794 = (v_context), _eri_order_2795 = ((v_data)->f_bytes), _eri_order_2798 = ((_eri_order_2796 = (v_digest), _eri_order_2797 = (v_item), eri_iadd(_eri_order_2796, _eri_order_2797))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2794, _eri_order_2795, _eri_order_2798));
            (_eri_order_2799 = (v_context), _eri_order_2808 = ((((_eri_order_2800 = (v_byte), _eri_order_2801 = (48), (_eri_order_2800 >= _eri_order_2801)) && (_eri_order_2802 = (v_byte), _eri_order_2803 = (57), (_eri_order_2802 <= _eri_order_2803))) || ((_eri_order_2804 = (v_byte), _eri_order_2805 = (97), (_eri_order_2804 >= _eri_order_2805)) && (_eri_order_2806 = (v_byte), _eri_order_2807 = (102), (_eri_order_2806 <= _eri_order_2807))))), _eri_order_2809 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x53, 0x48, 0x41, 0x2d, 0x32, 0x35, 0x36, 0x20, 0x64, 0x69, 0x67, 0x65, 0x73, 0x74}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2799, _eri_order_2808, _eri_order_2809));
            v_item = (_eri_order_2810 = (v_item), _eri_order_2811 = (1), eri_iadd(_eri_order_2810, _eri_order_2811));
        }
        int64_t v_prior = 0;
        while ((_eri_order_2812 = (v_prior), _eri_order_2813 = (v_index), (_eri_order_2812 < _eri_order_2813))) {
            int64_t v_oldCount = (_eri_order_2814 = ((v_data)->f_sources), _eri_order_2815 = ((v_context)->f_phase), _eri_order_2820 = ((_eri_order_2818 = ((_eri_order_2816 = (v_prior), _eri_order_2817 = (4), eri_imul(_eri_order_2816, _eri_order_2817))), _eri_order_2819 = (1), eri_iadd(_eri_order_2818, _eri_order_2819))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2814, _eri_order_2815, _eri_order_2820));
            if ((_eri_order_2821 = (v_oldCount), _eri_order_2822 = (v_count), (_eri_order_2821 == _eri_order_2822))) {
                int64_t v_oldFirst = (_eri_order_2823 = ((v_data)->f_sources), _eri_order_2824 = ((v_context)->f_phase), _eri_order_2827 = ((_eri_order_2825 = (v_prior), _eri_order_2826 = (4), eri_imul(_eri_order_2825, _eri_order_2826))), fn_compiler_u002e_u1_words_u002e_get(_eri_order_2823, _eri_order_2824, _eri_order_2827));
                (_eri_order_2828 = (v_context), _eri_order_2834 = ((!(_eri_order_2829 = (v_context), _eri_order_2830 = ((v_data)->f_bytes), _eri_order_2831 = (v_first), _eri_order_2832 = (v_oldFirst), _eri_order_2833 = (v_count), fn_compiler_u002e_u1_verify_u002e_sameSequence(_eri_order_2829, _eri_order_2830, _eri_order_2831, _eri_order_2832, _eri_order_2833)))), _eri_order_2835 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x75, 0x70, 0x6c, 0x69, 0x63, 0x61, 0x74, 0x65, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x69, 0x64, 0x65, 0x6e, 0x74, 0x69, 0x74, 0x79}, 25)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2828, _eri_order_2834, _eri_order_2835));
            }
            v_prior = (_eri_order_2836 = (v_prior), _eri_order_2837 = (1), eri_iadd(_eri_order_2836, _eri_order_2837));
        }
        v_cursor = (_eri_order_2838 = (v_digest), _eri_order_2839 = (64), eri_iadd(_eri_order_2838, _eri_order_2839));
        v_index = (_eri_order_2840 = (v_index), _eri_order_2841 = (1), eri_iadd(_eri_order_2840, _eri_order_2841));
    }
    (_eri_order_2842 = (v_context), _eri_order_2845 = ((_eri_order_2843 = (v_cursor), _eri_order_2844 = (((v_data)->f_bytes)->f_length), (_eri_order_2843 == _eri_order_2844))), _eri_order_2846 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x63, 0x6c, 0x61, 0x69, 0x6d, 0x65, 0x64, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x62, 0x79, 0x74, 0x65, 0x73}, 22)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2842, _eri_order_2845, _eri_order_2846));
}

static void fn_compiler_u002e_u1_verify_u002e_locations(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context) {
    int64_t _eri_order_2847;
    int64_t _eri_order_2848;
    int64_t _eri_order_2849;
    int64_t _eri_order_2850;
    int64_t _eri_order_2851;
    int64_t _eri_order_2852;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2853;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2854;
    int64_t _eri_order_2855;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2856;
    int64_t _eri_order_2857;
    int64_t _eri_order_2858;
    int64_t _eri_order_2859;
    int64_t _eri_order_2860;
    int64_t _eri_order_2861;
    int64_t _eri_order_2862;
    bool _eri_order_2863;
    eri_text _eri_order_2864;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2865;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2866;
    int64_t _eri_order_2867;
    int64_t _eri_order_2868;
    int64_t _eri_order_2869;
    int64_t _eri_order_2870;
    int64_t _eri_order_2871;
    int64_t _eri_order_2872;
    int64_t _eri_order_2873;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2874;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2875;
    int64_t _eri_order_2876;
    int64_t _eri_order_2877;
    int64_t _eri_order_2878;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2879;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2880;
    int64_t _eri_order_2881;
    int64_t _eri_order_2882;
    int64_t _eri_order_2883;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2884;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2885;
    int64_t _eri_order_2886;
    int64_t _eri_order_2887;
    int64_t _eri_order_2888;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2889;
    int64_t _eri_order_2890;
    int64_t _eri_order_2891;
    int64_t _eri_order_2892;
    int64_t _eri_order_2893;
    int64_t _eri_order_2894;
    int64_t _eri_order_2895;
    int64_t _eri_order_2896;
    int64_t _eri_order_2897;
    int64_t _eri_order_2898;
    int64_t _eri_order_2899;
    bool _eri_order_2900;
    eri_text _eri_order_2901;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2902;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2903;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2904;
    int64_t _eri_order_2905;
    int64_t _eri_order_2906;
    int64_t _eri_order_2907;
    int64_t _eri_order_2908;
    int64_t _eri_order_2909;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2910;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2911;
    int64_t _eri_order_2912;
    int64_t _eri_order_2913;
    int64_t _eri_order_2914;
    int64_t _eri_order_2915;
    int64_t _eri_order_2916;
    bool _eri_order_2917;
    eri_text _eri_order_2918;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2919;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2920;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2921;
    int64_t _eri_order_2922;
    int64_t _eri_order_2923;
    int64_t _eri_order_2924;
    int64_t _eri_order_2925;
    int64_t _eri_order_2926;
    bool _eri_order_2927;
    eri_text _eri_order_2928;
    int64_t _eri_order_2929;
    int64_t _eri_order_2930;
    int64_t _eri_order_2931;
    int64_t _eri_order_2932;
    int64_t _eri_order_2933;
    int64_t _eri_order_2934;
    int64_t _eri_order_2935;
    int64_t _eri_order_2936;
    int64_t _eri_order_2937;
    int64_t _eri_order_2938;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2939;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2940;
    int64_t _eri_order_2941;
    int64_t _eri_order_2942;
    int64_t _eri_order_2943;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2944;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2945;
    int64_t _eri_order_2946;
    int64_t _eri_order_2947;
    int64_t _eri_order_2948;
    int64_t _eri_order_2949;
    int64_t _eri_order_2950;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2951;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2952;
    int64_t _eri_order_2953;
    int64_t _eri_order_2954;
    int64_t _eri_order_2955;
    int64_t _eri_order_2956;
    int64_t _eri_order_2957;
    int64_t _eri_order_2958;
    int64_t _eri_order_2959;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2960;
    int64_t _eri_order_2961;
    int64_t _eri_order_2962;
    int64_t _eri_order_2963;
    int64_t _eri_order_2964;
    int64_t _eri_order_2965;
    int64_t _eri_order_2966;
    bool _eri_order_2967;
    eri_text _eri_order_2968;
    int64_t _eri_order_2969;
    int64_t _eri_order_2970;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2971;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2972;
    int64_t _eri_order_2973;
    int64_t _eri_order_2974;
    int64_t _eri_order_2975;
    int64_t _eri_order_2976;
    int64_t _eri_order_2977;
    int64_t _eri_order_2978;
    int64_t _eri_order_2979;
    int64_t _eri_order_2980;
    int64_t _eri_order_2981;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2982;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2983;
    int64_t _eri_order_2984;
    int64_t _eri_order_2985;
    int64_t _eri_order_2986;
    int64_t _eri_order_2987;
    int64_t _eri_order_2988;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2989;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_2990;
    int64_t _eri_order_2991;
    int64_t _eri_order_2992;
    int64_t _eri_order_2993;
    int64_t _eri_order_2994;
    int64_t _eri_order_2995;
    int64_t _eri_order_2996;
    int64_t _eri_order_2997;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_2998;
    int64_t _eri_order_2999;
    int64_t _eri_order_3000;
    int64_t _eri_order_3001;
    int64_t _eri_order_3002;
    int64_t _eri_order_3003;
    int64_t _eri_order_3004;
    bool _eri_order_3005;
    eri_text _eri_order_3006;
    int64_t _eri_order_3007;
    int64_t _eri_order_3008;
    (v_context)->f_stage = 3;
    (v_context)->f_block = 0;
    (v_context)->f_instruction = 0;
    (v_context)->f_location = 0;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_data = ((v_context)->f_routine)->f_metadata;
    int64_t v_index = 0;
    while ((_eri_order_2847 = (v_index), _eri_order_2850 = ((_eri_order_2848 = (((v_data)->f_locations)->f_length), _eri_order_2849 = (7), eri_idiv(_eri_order_2848, _eri_order_2849))), (_eri_order_2847 < _eri_order_2850))) {
        int64_t v_offset = (_eri_order_2851 = (v_index), _eri_order_2852 = (7), eri_imul(_eri_order_2851, _eri_order_2852));
        int64_t v_source = (_eri_order_2853 = (v_context), _eri_order_2854 = ((v_data)->f_locations), _eri_order_2855 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2853, _eri_order_2854, _eri_order_2855));
        (_eri_order_2856 = (v_context), _eri_order_2863 = (((_eri_order_2857 = (v_source), _eri_order_2858 = (1), (_eri_order_2857 >= _eri_order_2858)) && (_eri_order_2859 = (v_source), _eri_order_2862 = ((_eri_order_2860 = (((v_data)->f_sources)->f_length), _eri_order_2861 = (4), eri_idiv(_eri_order_2860, _eri_order_2861))), (_eri_order_2859 <= _eri_order_2862)))), _eri_order_2864 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x6c, 0x6f, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65}, 23)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2856, _eri_order_2863, _eri_order_2864));
        int64_t v_length = (_eri_order_2865 = (v_context), _eri_order_2866 = ((v_data)->f_sources), _eri_order_2873 = ((_eri_order_2871 = ((_eri_order_2869 = ((_eri_order_2867 = (v_source), _eri_order_2868 = (1), eri_isub(_eri_order_2867, _eri_order_2868))), _eri_order_2870 = (4), eri_imul(_eri_order_2869, _eri_order_2870))), _eri_order_2872 = (3), eri_iadd(_eri_order_2871, _eri_order_2872))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2865, _eri_order_2866, _eri_order_2873));
        int64_t v_start = (_eri_order_2874 = (v_context), _eri_order_2875 = ((v_data)->f_locations), _eri_order_2878 = ((_eri_order_2876 = (v_offset), _eri_order_2877 = (1), eri_iadd(_eri_order_2876, _eri_order_2877))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2874, _eri_order_2875, _eri_order_2878));
        int64_t v_end = (_eri_order_2879 = (v_context), _eri_order_2880 = ((v_data)->f_locations), _eri_order_2883 = ((_eri_order_2881 = (v_offset), _eri_order_2882 = (2), eri_iadd(_eri_order_2881, _eri_order_2882))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2879, _eri_order_2880, _eri_order_2883));
        int64_t v_anchor = (_eri_order_2884 = (v_context), _eri_order_2885 = ((v_data)->f_locations), _eri_order_2888 = ((_eri_order_2886 = (v_offset), _eri_order_2887 = (3), eri_iadd(_eri_order_2886, _eri_order_2887))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2884, _eri_order_2885, _eri_order_2888));
        (_eri_order_2889 = (v_context), _eri_order_2900 = ((((((_eri_order_2890 = (v_start), _eri_order_2891 = (0), (_eri_order_2890 >= _eri_order_2891)) && (_eri_order_2892 = (v_end), _eri_order_2893 = (v_start), (_eri_order_2892 >= _eri_order_2893))) && (_eri_order_2894 = (v_end), _eri_order_2895 = (v_length), (_eri_order_2894 <= _eri_order_2895))) && (_eri_order_2896 = (v_anchor), _eri_order_2897 = (v_start), (_eri_order_2896 >= _eri_order_2897))) && (_eri_order_2898 = (v_anchor), _eri_order_2899 = (v_end), (_eri_order_2898 <= _eri_order_2899)))), _eri_order_2901 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x73, 0x70, 0x61, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x61, 0x6e, 0x63, 0x68, 0x6f, 0x72}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2889, _eri_order_2900, _eri_order_2901));
        (_eri_order_2902 = (v_context), _eri_order_2917 = (((_eri_order_2908 = ((_eri_order_2903 = (v_context), _eri_order_2904 = ((v_data)->f_locations), _eri_order_2907 = ((_eri_order_2905 = (v_offset), _eri_order_2906 = (4), eri_iadd(_eri_order_2905, _eri_order_2906))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2903, _eri_order_2904, _eri_order_2907))), _eri_order_2909 = (1), (_eri_order_2908 >= _eri_order_2909)) && (_eri_order_2915 = ((_eri_order_2910 = (v_context), _eri_order_2911 = ((v_data)->f_locations), _eri_order_2914 = ((_eri_order_2912 = (v_offset), _eri_order_2913 = (5), eri_iadd(_eri_order_2912, _eri_order_2913))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2910, _eri_order_2911, _eri_order_2914))), _eri_order_2916 = (1), (_eri_order_2915 >= _eri_order_2916)))), _eri_order_2918 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x20, 0x6c, 0x69, 0x6e, 0x65, 0x20, 0x6f, 0x72, 0x20, 0x63, 0x6f, 0x6c, 0x75, 0x6d, 0x6e}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2902, _eri_order_2917, _eri_order_2918));
        (_eri_order_2919 = (v_context), _eri_order_2927 = ((_eri_order_2925 = ((_eri_order_2920 = (v_context), _eri_order_2921 = ((v_data)->f_locations), _eri_order_2924 = ((_eri_order_2922 = (v_offset), _eri_order_2923 = (6), eri_iadd(_eri_order_2922, _eri_order_2923))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2920, _eri_order_2921, _eri_order_2924))), _eri_order_2926 = (0), (_eri_order_2925 == _eri_order_2926))), _eri_order_2928 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x69, 0x67, 0x69, 0x6e, 0x20, 0x63, 0x68, 0x61, 0x69, 0x6e, 0x73, 0x20, 0x75, 0x6e, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x20, 0x69, 0x6e, 0x20, 0x66, 0x6f, 0x75, 0x6e, 0x64, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x70, 0x72, 0x6f, 0x66, 0x69, 0x6c, 0x65}, 47)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2919, _eri_order_2927, _eri_order_2928));
        v_index = (_eri_order_2929 = (v_index), _eri_order_2930 = (1), eri_iadd(_eri_order_2929, _eri_order_2930));
    }
    (v_context)->f_block = 1;
    while ((_eri_order_2931 = ((v_context)->f_block), _eri_order_2934 = ((_eri_order_2932 = ((((v_context)->f_routine)->f_blocks)->f_length), _eri_order_2933 = (5), eri_idiv(_eri_order_2932, _eri_order_2933))), (_eri_order_2931 <= _eri_order_2934))) {
        int64_t v_offset = (_eri_order_2937 = ((_eri_order_2935 = ((v_context)->f_block), _eri_order_2936 = (1), eri_isub(_eri_order_2935, _eri_order_2936))), _eri_order_2938 = (5), eri_imul(_eri_order_2937, _eri_order_2938));
        int64_t v_instruction = (_eri_order_2939 = (v_context), _eri_order_2940 = (((v_context)->f_routine)->f_blocks), _eri_order_2943 = ((_eri_order_2941 = (v_offset), _eri_order_2942 = (2), eri_iadd(_eri_order_2941, _eri_order_2942))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2939, _eri_order_2940, _eri_order_2943));
        int64_t v_terminator = (_eri_order_2944 = (v_context), _eri_order_2945 = (((v_context)->f_routine)->f_blocks), _eri_order_2948 = ((_eri_order_2946 = (v_offset), _eri_order_2947 = (4), eri_iadd(_eri_order_2946, _eri_order_2947))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2944, _eri_order_2945, _eri_order_2948));
        while ((_eri_order_2949 = (v_instruction), _eri_order_2950 = (0), (_eri_order_2949 != _eri_order_2950))) {
            (v_context)->f_instruction = v_instruction;
            (v_context)->f_location = 0;
            int64_t v_location = (_eri_order_2951 = (v_context), _eri_order_2952 = (((v_context)->f_routine)->f_instructions), _eri_order_2959 = ((_eri_order_2957 = ((_eri_order_2955 = ((_eri_order_2953 = (v_instruction), _eri_order_2954 = (1), eri_isub(_eri_order_2953, _eri_order_2954))), _eri_order_2956 = (10), eri_imul(_eri_order_2955, _eri_order_2956))), _eri_order_2958 = (6), eri_iadd(_eri_order_2957, _eri_order_2958))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2951, _eri_order_2952, _eri_order_2959));
            (_eri_order_2960 = (v_context), _eri_order_2967 = (((_eri_order_2961 = (v_location), _eri_order_2962 = (1), (_eri_order_2961 >= _eri_order_2962)) && (_eri_order_2963 = (v_location), _eri_order_2966 = ((_eri_order_2964 = (((v_data)->f_locations)->f_length), _eri_order_2965 = (7), eri_idiv(_eri_order_2964, _eri_order_2965))), (_eri_order_2963 <= _eri_order_2966)))), _eri_order_2968 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x69, 0x73, 0x73, 0x69, 0x6e, 0x67, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x6c, 0x6f, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 39)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2960, _eri_order_2967, _eri_order_2968));
            (v_context)->f_location = v_location;
            if ((_eri_order_2969 = (v_instruction), _eri_order_2970 = (v_terminator), (_eri_order_2969 == _eri_order_2970))) {
                v_instruction = 0;
            } else {
                v_instruction = (_eri_order_2971 = (v_context), _eri_order_2972 = (((v_context)->f_routine)->f_instructions), _eri_order_2979 = ((_eri_order_2977 = ((_eri_order_2975 = ((_eri_order_2973 = (v_instruction), _eri_order_2974 = (1), eri_isub(_eri_order_2973, _eri_order_2974))), _eri_order_2976 = (10), eri_imul(_eri_order_2975, _eri_order_2976))), _eri_order_2978 = (9), eri_iadd(_eri_order_2977, _eri_order_2978))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2971, _eri_order_2972, _eri_order_2979));
                if ((_eri_order_2980 = (v_instruction), _eri_order_2981 = (0), (_eri_order_2980 == _eri_order_2981))) {
                    v_instruction = v_terminator;
                }
            }
        }
        if ((_eri_order_2987 = ((_eri_order_2982 = (v_context), _eri_order_2983 = (((v_context)->f_routine)->f_blocks), _eri_order_2986 = ((_eri_order_2984 = (v_offset), _eri_order_2985 = (2), eri_iadd(_eri_order_2984, _eri_order_2985))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2982, _eri_order_2983, _eri_order_2986))), _eri_order_2988 = (0), (_eri_order_2987 == _eri_order_2988))) {
            (v_context)->f_instruction = v_terminator;
            int64_t v_location = (_eri_order_2989 = (v_context), _eri_order_2990 = (((v_context)->f_routine)->f_instructions), _eri_order_2997 = ((_eri_order_2995 = ((_eri_order_2993 = ((_eri_order_2991 = (v_terminator), _eri_order_2992 = (1), eri_isub(_eri_order_2991, _eri_order_2992))), _eri_order_2994 = (10), eri_imul(_eri_order_2993, _eri_order_2994))), _eri_order_2996 = (6), eri_iadd(_eri_order_2995, _eri_order_2996))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_2989, _eri_order_2990, _eri_order_2997));
            (_eri_order_2998 = (v_context), _eri_order_3005 = (((_eri_order_2999 = (v_location), _eri_order_3000 = (1), (_eri_order_2999 >= _eri_order_3000)) && (_eri_order_3001 = (v_location), _eri_order_3004 = ((_eri_order_3002 = (((v_data)->f_locations)->f_length), _eri_order_3003 = (7), eri_idiv(_eri_order_3002, _eri_order_3003))), (_eri_order_3001 <= _eri_order_3004)))), _eri_order_3006 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x69, 0x73, 0x73, 0x69, 0x6e, 0x67, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x74, 0x65, 0x72, 0x6d, 0x69, 0x6e, 0x61, 0x74, 0x6f, 0x72, 0x20, 0x6c, 0x6f, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 38)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_2998, _eri_order_3005, _eri_order_3006));
            (v_context)->f_location = v_location;
        }
        (v_context)->f_location = 0;
        (v_context)->f_block = (_eri_order_3007 = ((v_context)->f_block), _eri_order_3008 = (1), eri_iadd(_eri_order_3007, _eri_order_3008));
    }
}

static void fn_compiler_u002e_u1_verify_u002e_claimValue(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_value, int64_t v_valueTypeIndex, int64_t v_kind, int64_t v_definition, int64_t v_ordinal) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3009;
    int64_t _eri_order_3010;
    int64_t _eri_order_3011;
    int64_t _eri_order_3012;
    int64_t _eri_order_3013;
    int64_t _eri_order_3014;
    int64_t _eri_order_3015;
    bool _eri_order_3016;
    eri_text _eri_order_3017;
    int64_t _eri_order_3018;
    int64_t _eri_order_3019;
    int64_t _eri_order_3020;
    int64_t _eri_order_3021;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3022;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3023;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3024;
    int64_t _eri_order_3025;
    int64_t _eri_order_3026;
    int64_t _eri_order_3027;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3028;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3029;
    int64_t _eri_order_3030;
    int64_t _eri_order_3031;
    int64_t _eri_order_3032;
    int64_t _eri_order_3033;
    int64_t _eri_order_3034;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3035;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3036;
    int64_t _eri_order_3037;
    int64_t _eri_order_3038;
    int64_t _eri_order_3039;
    int64_t _eri_order_3040;
    int64_t _eri_order_3041;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3042;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3043;
    int64_t _eri_order_3044;
    int64_t _eri_order_3045;
    int64_t _eri_order_3046;
    int64_t _eri_order_3047;
    int64_t _eri_order_3048;
    bool _eri_order_3049;
    eri_text _eri_order_3050;
    eri_struct_compiler_u002e_u1_words_u002e_Words * v_table = ((v_context)->f_routine)->f_values;
    (_eri_order_3009 = (v_context), _eri_order_3016 = (((_eri_order_3010 = (v_value), _eri_order_3011 = (1), (_eri_order_3010 >= _eri_order_3011)) && (_eri_order_3012 = (v_value), _eri_order_3015 = ((_eri_order_3013 = ((v_table)->f_length), _eri_order_3014 = (4), eri_idiv(_eri_order_3013, _eri_order_3014))), (_eri_order_3012 <= _eri_order_3015)))), _eri_order_3017 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x20, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e}, 24)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3009, _eri_order_3016, _eri_order_3017));
    int64_t v_offset = (_eri_order_3020 = ((_eri_order_3018 = (v_value), _eri_order_3019 = (1), eri_isub(_eri_order_3018, _eri_order_3019))), _eri_order_3021 = (4), eri_imul(_eri_order_3020, _eri_order_3021));
    (_eri_order_3022 = (v_context), _eri_order_3049 = (((((_eri_order_3026 = ((_eri_order_3023 = (v_context), _eri_order_3024 = (v_table), _eri_order_3025 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3023, _eri_order_3024, _eri_order_3025))), _eri_order_3027 = (v_valueTypeIndex), (_eri_order_3026 == _eri_order_3027)) && (_eri_order_3033 = ((_eri_order_3028 = (v_context), _eri_order_3029 = (v_table), _eri_order_3032 = ((_eri_order_3030 = (v_offset), _eri_order_3031 = (1), eri_iadd(_eri_order_3030, _eri_order_3031))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3028, _eri_order_3029, _eri_order_3032))), _eri_order_3034 = (v_kind), (_eri_order_3033 == _eri_order_3034))) && (_eri_order_3040 = ((_eri_order_3035 = (v_context), _eri_order_3036 = (v_table), _eri_order_3039 = ((_eri_order_3037 = (v_offset), _eri_order_3038 = (2), eri_iadd(_eri_order_3037, _eri_order_3038))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3035, _eri_order_3036, _eri_order_3039))), _eri_order_3041 = (v_definition), (_eri_order_3040 == _eri_order_3041))) && (_eri_order_3047 = ((_eri_order_3042 = (v_context), _eri_order_3043 = (v_table), _eri_order_3046 = ((_eri_order_3044 = (v_offset), _eri_order_3045 = (3), eri_iadd(_eri_order_3044, _eri_order_3045))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3042, _eri_order_3043, _eri_order_3046))), _eri_order_3048 = (v_ordinal), (_eri_order_3047 == _eri_order_3048)))), _eri_order_3050 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x63, 0x6f, 0x6e, 0x73, 0x69, 0x73, 0x74, 0x65, 0x6e, 0x74, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x20, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3022, _eri_order_3049, _eri_order_3050));
}

static int64_t fn_compiler_u002e_u1_verify_u002e_valueType(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_value) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3051;
    int64_t _eri_order_3052;
    int64_t _eri_order_3053;
    int64_t _eri_order_3054;
    int64_t _eri_order_3055;
    int64_t _eri_order_3056;
    int64_t _eri_order_3057;
    bool _eri_order_3058;
    eri_text _eri_order_3059;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3060;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3061;
    int64_t _eri_order_3062;
    int64_t _eri_order_3063;
    int64_t _eri_order_3064;
    int64_t _eri_order_3065;
    int64_t _eri_order_3066;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3067;
    int64_t _eri_order_3068;
    (_eri_order_3051 = (v_context), _eri_order_3058 = (((_eri_order_3052 = (v_value), _eri_order_3053 = (1), (_eri_order_3052 >= _eri_order_3053)) && (_eri_order_3054 = (v_value), _eri_order_3057 = ((_eri_order_3055 = ((((v_context)->f_routine)->f_values)->f_length), _eri_order_3056 = (4), eri_idiv(_eri_order_3055, _eri_order_3056))), (_eri_order_3054 <= _eri_order_3057)))), _eri_order_3059 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x20, 0x75, 0x73, 0x65}, 17)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3051, _eri_order_3058, _eri_order_3059));
    int64_t v_valueTypeIndex = (_eri_order_3060 = (v_context), _eri_order_3061 = (((v_context)->f_routine)->f_values), _eri_order_3066 = ((_eri_order_3064 = ((_eri_order_3062 = (v_value), _eri_order_3063 = (1), eri_isub(_eri_order_3062, _eri_order_3063))), _eri_order_3065 = (4), eri_imul(_eri_order_3064, _eri_order_3065))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3060, _eri_order_3061, _eri_order_3066));
    (_eri_order_3067 = (v_context), _eri_order_3068 = (v_valueTypeIndex), fn_compiler_u002e_u1_verify_u002e_typeIndex(_eri_order_3067, _eri_order_3068));
    return v_valueTypeIndex;
}

static void fn_compiler_u002e_u1_verify_u002e_edge(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_index) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3069;
    int64_t _eri_order_3070;
    int64_t _eri_order_3071;
    int64_t _eri_order_3072;
    int64_t _eri_order_3073;
    int64_t _eri_order_3074;
    int64_t _eri_order_3075;
    bool _eri_order_3076;
    eri_text _eri_order_3077;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3078;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3079;
    int64_t _eri_order_3080;
    int64_t _eri_order_3081;
    int64_t _eri_order_3082;
    int64_t _eri_order_3083;
    int64_t _eri_order_3084;
    int64_t _eri_order_3085;
    int64_t _eri_order_3086;
    int64_t _eri_order_3087;
    bool _eri_order_3088;
    eri_text _eri_order_3089;
    int64_t _eri_order_3090;
    int64_t _eri_order_3091;
    int64_t _eri_order_3092;
    int64_t _eri_order_3093;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3094;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3095;
    int64_t _eri_order_3096;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3097;
    int64_t _eri_order_3098;
    int64_t _eri_order_3099;
    int64_t _eri_order_3100;
    int64_t _eri_order_3101;
    int64_t _eri_order_3102;
    int64_t _eri_order_3103;
    bool _eri_order_3104;
    eri_text _eri_order_3105;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3106;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3107;
    int64_t _eri_order_3108;
    int64_t _eri_order_3109;
    int64_t _eri_order_3110;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3111;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3112;
    int64_t _eri_order_3113;
    int64_t _eri_order_3114;
    int64_t _eri_order_3115;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3116;
    int64_t _eri_order_3117;
    int64_t _eri_order_3118;
    int64_t _eri_order_3119;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3120;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3121;
    int64_t _eri_order_3122;
    int64_t _eri_order_3123;
    int64_t _eri_order_3124;
    int64_t _eri_order_3125;
    int64_t _eri_order_3126;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3127;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3128;
    int64_t _eri_order_3129;
    int64_t _eri_order_3130;
    int64_t _eri_order_3131;
    int64_t _eri_order_3132;
    int64_t _eri_order_3133;
    int64_t _eri_order_3134;
    int64_t _eri_order_3135;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3136;
    int64_t _eri_order_3137;
    int64_t _eri_order_3138;
    bool _eri_order_3139;
    eri_text _eri_order_3140;
    int64_t _eri_order_3141;
    int64_t _eri_order_3142;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3143;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3144;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3145;
    int64_t _eri_order_3146;
    int64_t _eri_order_3147;
    int64_t _eri_order_3148;
    int64_t _eri_order_3149;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3150;
    int64_t _eri_order_3151;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3152;
    int64_t _eri_order_3153;
    int64_t _eri_order_3154;
    int64_t _eri_order_3155;
    int64_t _eri_order_3156;
    bool _eri_order_3157;
    eri_text _eri_order_3158;
    int64_t _eri_order_3159;
    int64_t _eri_order_3160;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_3161;
    int64_t _eri_order_3162;
    int64_t _eri_order_3163;
    int64_t _eri_order_3164;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_context)->f_routine;
    (_eri_order_3069 = (v_context), _eri_order_3076 = (((_eri_order_3070 = (v_index), _eri_order_3071 = (1), (_eri_order_3070 >= _eri_order_3071)) && (_eri_order_3072 = (v_index), _eri_order_3075 = ((_eri_order_3073 = (((v_routine)->f_edges)->f_length), _eri_order_3074 = (3), eri_idiv(_eri_order_3073, _eri_order_3074))), (_eri_order_3072 <= _eri_order_3075)))), _eri_order_3077 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x43, 0x46, 0x47, 0x20, 0x65, 0x64, 0x67, 0x65}, 16)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3069, _eri_order_3076, _eri_order_3077));
    (_eri_order_3078 = (v_context), _eri_order_3088 = ((_eri_order_3086 = ((_eri_order_3079 = (v_context), _eri_order_3084 = ((_eri_order_3080 = (((v_context)->f_graph)->f_edgeBase), _eri_order_3083 = ((_eri_order_3081 = (v_index), _eri_order_3082 = (4), eri_imul(_eri_order_3081, _eri_order_3082))), eri_iadd(_eri_order_3080, _eri_order_3083))), _eri_order_3085 = (0), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_3079, _eri_order_3084, _eri_order_3085))), _eri_order_3087 = (0), (_eri_order_3086 == _eri_order_3087))), _eri_order_3089 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x64, 0x67, 0x65, 0x20, 0x72, 0x65, 0x63, 0x6f, 0x72, 0x64, 0x20, 0x68, 0x61, 0x73, 0x20, 0x6d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x65, 0x20, 0x6f, 0x77, 0x6e, 0x65, 0x72, 0x73}, 31)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3078, _eri_order_3088, _eri_order_3089));
    int64_t v_offset = (_eri_order_3092 = ((_eri_order_3090 = (v_index), _eri_order_3091 = (1), eri_isub(_eri_order_3090, _eri_order_3091))), _eri_order_3093 = (3), eri_imul(_eri_order_3092, _eri_order_3093));
    int64_t v_target = (_eri_order_3094 = (v_context), _eri_order_3095 = ((v_routine)->f_edges), _eri_order_3096 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3094, _eri_order_3095, _eri_order_3096));
    (_eri_order_3097 = (v_context), _eri_order_3104 = (((_eri_order_3098 = (v_target), _eri_order_3099 = (2), (_eri_order_3098 >= _eri_order_3099)) && (_eri_order_3100 = (v_target), _eri_order_3103 = ((_eri_order_3101 = (((v_routine)->f_blocks)->f_length), _eri_order_3102 = (5), eri_idiv(_eri_order_3101, _eri_order_3102))), (_eri_order_3100 <= _eri_order_3103)))), _eri_order_3105 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x6f, 0x72, 0x20, 0x65, 0x6e, 0x74, 0x72, 0x79, 0x2d, 0x74, 0x61, 0x72, 0x67, 0x65, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x65, 0x64, 0x67, 0x65}, 31)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3097, _eri_order_3104, _eri_order_3105));
    int64_t v_first = (_eri_order_3106 = (v_context), _eri_order_3107 = ((v_routine)->f_edges), _eri_order_3110 = ((_eri_order_3108 = (v_offset), _eri_order_3109 = (1), eri_iadd(_eri_order_3108, _eri_order_3109))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3106, _eri_order_3107, _eri_order_3110));
    int64_t v_count = (_eri_order_3111 = (v_context), _eri_order_3112 = ((v_routine)->f_edges), _eri_order_3115 = ((_eri_order_3113 = (v_offset), _eri_order_3114 = (2), eri_iadd(_eri_order_3113, _eri_order_3114))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3111, _eri_order_3112, _eri_order_3115));
    (_eri_order_3116 = (v_context), _eri_order_3117 = (v_first), _eri_order_3118 = (v_count), _eri_order_3119 = (((v_routine)->f_arguments)->f_length), fn_compiler_u002e_u1_verify_u002e_range(_eri_order_3116, _eri_order_3117, _eri_order_3118, _eri_order_3119));
    int64_t v_parameter = (_eri_order_3120 = (v_context), _eri_order_3121 = ((v_routine)->f_blocks), _eri_order_3126 = ((_eri_order_3124 = ((_eri_order_3122 = (v_target), _eri_order_3123 = (1), eri_isub(_eri_order_3122, _eri_order_3123))), _eri_order_3125 = (5), eri_imul(_eri_order_3124, _eri_order_3125))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3120, _eri_order_3121, _eri_order_3126));
    int64_t v_expected = (_eri_order_3127 = (v_context), _eri_order_3128 = ((v_routine)->f_blocks), _eri_order_3135 = ((_eri_order_3133 = ((_eri_order_3131 = ((_eri_order_3129 = (v_target), _eri_order_3130 = (1), eri_isub(_eri_order_3129, _eri_order_3130))), _eri_order_3132 = (5), eri_imul(_eri_order_3131, _eri_order_3132))), _eri_order_3134 = (1), eri_iadd(_eri_order_3133, _eri_order_3134))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3127, _eri_order_3128, _eri_order_3135));
    (_eri_order_3136 = (v_context), _eri_order_3139 = ((_eri_order_3137 = (v_count), _eri_order_3138 = (v_expected), (_eri_order_3137 == _eri_order_3138))), _eri_order_3140 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x64, 0x67, 0x65, 0x20, 0x61, 0x72, 0x69, 0x74, 0x79, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 19)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3136, _eri_order_3139, _eri_order_3140));
    int64_t v_item = 0;
    while ((_eri_order_3141 = (v_item), _eri_order_3142 = (v_count), (_eri_order_3141 < _eri_order_3142))) {
        int64_t v_valueTypeIndex = (_eri_order_3143 = (v_context), _eri_order_3149 = ((_eri_order_3144 = (v_context), _eri_order_3145 = ((v_routine)->f_arguments), _eri_order_3148 = ((_eri_order_3146 = (v_first), _eri_order_3147 = (v_item), eri_iadd(_eri_order_3146, _eri_order_3147))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3144, _eri_order_3145, _eri_order_3148))), fn_compiler_u002e_u1_verify_u002e_valueType(_eri_order_3143, _eri_order_3149));
        (_eri_order_3150 = (v_context), _eri_order_3157 = ((_eri_order_3151 = (v_valueTypeIndex), _eri_order_3156 = ((_eri_order_3152 = (v_context), _eri_order_3155 = ((_eri_order_3153 = (v_parameter), _eri_order_3154 = (v_item), eri_iadd(_eri_order_3153, _eri_order_3154))), fn_compiler_u002e_u1_verify_u002e_valueType(_eri_order_3152, _eri_order_3155))), (_eri_order_3151 == _eri_order_3156))), _eri_order_3158 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x64, 0x67, 0x65, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 18)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3150, _eri_order_3157, _eri_order_3158));
        v_item = (_eri_order_3159 = (v_item), _eri_order_3160 = (1), eri_iadd(_eri_order_3159, _eri_order_3160));
    }
    (_eri_order_3161 = ((v_context)->f_graph), _eri_order_3162 = (v_index), _eri_order_3163 = ((v_context)->f_block), _eri_order_3164 = (v_target), fn_compiler_u002e_u1_dominance_u002e_addEdge(_eri_order_3161, _eri_order_3162, _eri_order_3163, _eri_order_3164));
}

static void fn_compiler_u002e_u1_verify_u002e_instruction(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_index, bool v_terminal, int64_t v_position) {
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3165;
    int64_t _eri_order_3166;
    int64_t _eri_order_3167;
    int64_t _eri_order_3168;
    int64_t _eri_order_3169;
    int64_t _eri_order_3170;
    int64_t _eri_order_3171;
    bool _eri_order_3172;
    eri_text _eri_order_3173;
    int64_t _eri_order_3174;
    int64_t _eri_order_3175;
    int64_t _eri_order_3176;
    int64_t _eri_order_3177;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3178;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3179;
    int64_t _eri_order_3180;
    int64_t _eri_order_3181;
    int64_t _eri_order_3182;
    int64_t _eri_order_3183;
    bool _eri_order_3184;
    eri_text _eri_order_3185;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3186;
    int64_t _eri_order_3187;
    int64_t _eri_order_3188;
    int64_t _eri_order_3189;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3190;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3191;
    int64_t _eri_order_3192;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3193;
    bool _eri_order_3194;
    eri_text _eri_order_3195;
    int64_t _eri_order_3196;
    int64_t _eri_order_3197;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3198;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3199;
    int64_t _eri_order_3200;
    int64_t _eri_order_3201;
    int64_t _eri_order_3202;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3203;
    int64_t _eri_order_3204;
    int64_t _eri_order_3205;
    int64_t _eri_order_3206;
    int64_t _eri_order_3207;
    int64_t _eri_order_3208;
    int64_t _eri_order_3209;
    bool _eri_order_3210;
    eri_text _eri_order_3211;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3212;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3213;
    int64_t _eri_order_3214;
    int64_t _eri_order_3215;
    int64_t _eri_order_3216;
    int64_t _eri_order_3217;
    int64_t _eri_order_3218;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3219;
    int64_t _eri_order_3220;
    int64_t _eri_order_3221;
    int64_t _eri_order_3222;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3223;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3224;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3225;
    int64_t _eri_order_3226;
    int64_t _eri_order_3227;
    int64_t _eri_order_3228;
    int64_t _eri_order_3229;
    int64_t _eri_order_3230;
    int64_t _eri_order_3231;
    int64_t _eri_order_3232;
    int64_t _eri_order_3233;
    int64_t _eri_order_3234;
    bool _eri_order_3235;
    eri_text _eri_order_3236;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3237;
    bool _eri_order_3238;
    bool _eri_order_3239;
    bool _eri_order_3240;
    eri_text _eri_order_3241;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3242;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3243;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3244;
    int64_t _eri_order_3245;
    int64_t _eri_order_3246;
    int64_t _eri_order_3247;
    int64_t _eri_order_3248;
    int64_t _eri_order_3249;
    bool _eri_order_3250;
    eri_text _eri_order_3251;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3252;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3253;
    int64_t _eri_order_3254;
    int64_t _eri_order_3255;
    int64_t _eri_order_3256;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3257;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3258;
    int64_t _eri_order_3259;
    int64_t _eri_order_3260;
    int64_t _eri_order_3261;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3262;
    int64_t _eri_order_3263;
    int64_t _eri_order_3264;
    int64_t _eri_order_3265;
    int64_t _eri_order_3266;
    int64_t _eri_order_3267;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3268;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3269;
    int64_t _eri_order_3270;
    int64_t _eri_order_3271;
    int64_t _eri_order_3272;
    int64_t _eri_order_3273;
    int64_t _eri_order_3274;
    int64_t _eri_order_3275;
    int64_t _eri_order_3276;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3277;
    int64_t _eri_order_3278;
    int64_t _eri_order_3279;
    bool _eri_order_3280;
    eri_text _eri_order_3281;
    int64_t _eri_order_3282;
    int64_t _eri_order_3283;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3284;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3285;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3286;
    int64_t _eri_order_3287;
    int64_t _eri_order_3288;
    int64_t _eri_order_3289;
    int64_t _eri_order_3290;
    int64_t _eri_order_3291;
    int64_t _eri_order_3292;
    int64_t _eri_order_3293;
    int64_t _eri_order_3294;
    int64_t _eri_order_3295;
    int64_t _eri_order_3296;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3297;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3298;
    int64_t _eri_order_3299;
    int64_t _eri_order_3300;
    int64_t _eri_order_3301;
    int64_t _eri_order_3302;
    int64_t _eri_order_3303;
    int64_t _eri_order_3304;
    int64_t _eri_order_3305;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3306;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3307;
    int64_t _eri_order_3308;
    int64_t _eri_order_3309;
    int64_t _eri_order_3310;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3311;
    int64_t _eri_order_3312;
    int64_t _eri_order_3313;
    bool _eri_order_3314;
    eri_text _eri_order_3315;
    int64_t _eri_order_3316;
    int64_t _eri_order_3317;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3318;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3319;
    int64_t _eri_order_3320;
    int64_t _eri_order_3321;
    int64_t _eri_order_3322;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3323;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3324;
    int64_t _eri_order_3325;
    int64_t _eri_order_3326;
    int64_t _eri_order_3327;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3328;
    int64_t _eri_order_3329;
    int64_t _eri_order_3330;
    bool _eri_order_3331;
    eri_text _eri_order_3332;
    int64_t _eri_order_3333;
    int64_t _eri_order_3334;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3335;
    int64_t _eri_order_3336;
    int64_t _eri_order_3337;
    bool _eri_order_3338;
    eri_text _eri_order_3339;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3340;
    int64_t _eri_order_3341;
    int64_t _eri_order_3342;
    int64_t _eri_order_3343;
    int64_t _eri_order_3344;
    int64_t _eri_order_3345;
    int64_t _eri_order_3346;
    int64_t _eri_order_3347;
    int64_t _eri_order_3348;
    int64_t _eri_order_3349;
    int64_t _eri_order_3350;
    int64_t _eri_order_3351;
    int64_t _eri_order_3352;
    int64_t _eri_order_3353;
    int64_t _eri_order_3354;
    bool _eri_order_3355;
    eri_text _eri_order_3356;
    int64_t _eri_order_3357;
    int64_t _eri_order_3358;
    int64_t _eri_order_3359;
    int64_t _eri_order_3360;
    int64_t _eri_order_3361;
    int64_t _eri_order_3362;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3363;
    int64_t _eri_order_3364;
    int64_t _eri_order_3365;
    int64_t _eri_order_3366;
    int64_t _eri_order_3367;
    int64_t _eri_order_3368;
    int64_t _eri_order_3369;
    int64_t _eri_order_3370;
    int64_t _eri_order_3371;
    int64_t _eri_order_3372;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3373;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3374;
    int64_t _eri_order_3375;
    int64_t _eri_order_3376;
    int64_t _eri_order_3377;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3378;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3379;
    int64_t _eri_order_3380;
    int64_t _eri_order_3381;
    int64_t _eri_order_3382;
    int64_t _eri_order_3383;
    int64_t _eri_order_3384;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3385;
    int64_t _eri_order_3386;
    int64_t _eri_order_3387;
    int64_t _eri_order_3388;
    int64_t _eri_order_3389;
    bool _eri_order_3390;
    eri_text _eri_order_3391;
    int64_t _eri_order_3392;
    int64_t _eri_order_3393;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3394;
    int64_t _eri_order_3395;
    int64_t _eri_order_3396;
    int64_t _eri_order_3397;
    int64_t _eri_order_3398;
    bool _eri_order_3399;
    eri_text _eri_order_3400;
    int64_t _eri_order_3401;
    int64_t _eri_order_3402;
    int64_t _eri_order_3403;
    int64_t _eri_order_3404;
    int64_t _eri_order_3405;
    int64_t _eri_order_3406;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3407;
    int64_t _eri_order_3408;
    int64_t _eri_order_3409;
    bool _eri_order_3410;
    eri_text _eri_order_3411;
    int64_t _eri_order_3412;
    int64_t _eri_order_3413;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3414;
    int64_t _eri_order_3415;
    int64_t _eri_order_3416;
    bool _eri_order_3417;
    eri_text _eri_order_3418;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3419;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3420;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3421;
    int64_t _eri_order_3422;
    int64_t _eri_order_3423;
    int64_t _eri_order_3424;
    int64_t _eri_order_3425;
    int64_t _eri_order_3426;
    bool _eri_order_3427;
    eri_text _eri_order_3428;
    int64_t _eri_order_3429;
    int64_t _eri_order_3430;
    int64_t _eri_order_3431;
    int64_t _eri_order_3432;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3433;
    int64_t _eri_order_3434;
    int64_t _eri_order_3435;
    int64_t _eri_order_3436;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3437;
    int64_t _eri_order_3438;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_context)->f_routine;
    (v_context)->f_instruction = v_index;
    (_eri_order_3165 = (v_context), _eri_order_3172 = (((_eri_order_3166 = (v_index), _eri_order_3167 = (1), (_eri_order_3166 >= _eri_order_3167)) && (_eri_order_3168 = (v_index), _eri_order_3171 = ((_eri_order_3169 = (((v_routine)->f_instructions)->f_length), _eri_order_3170 = (10), eri_idiv(_eri_order_3169, _eri_order_3170))), (_eri_order_3168 <= _eri_order_3171)))), _eri_order_3173 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x49, 0x44}, 22)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3165, _eri_order_3172, _eri_order_3173));
    int64_t v_offset = (_eri_order_3176 = ((_eri_order_3174 = (v_index), _eri_order_3175 = (1), eri_isub(_eri_order_3174, _eri_order_3175))), _eri_order_3177 = (10), eri_imul(_eri_order_3176, _eri_order_3177));
    (_eri_order_3178 = (v_context), _eri_order_3184 = ((_eri_order_3182 = ((_eri_order_3179 = (v_context), _eri_order_3180 = ((v_context)->f_positions), _eri_order_3181 = (v_index), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_3179, _eri_order_3180, _eri_order_3181))), _eri_order_3183 = (0), (_eri_order_3182 == _eri_order_3183))), _eri_order_3185 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x75, 0x70, 0x6c, 0x69, 0x63, 0x61, 0x74, 0x65, 0x20, 0x6f, 0x72, 0x20, 0x63, 0x79, 0x63, 0x6c, 0x69, 0x63, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x6c, 0x69, 0x73, 0x74}, 36)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3178, _eri_order_3184, _eri_order_3185));
    (_eri_order_3186 = (v_context), _eri_order_3187 = ((v_context)->f_positions), _eri_order_3188 = (v_index), _eri_order_3189 = (v_position), fn_compiler_u002e_u1_verify_u002e_mark(_eri_order_3186, _eri_order_3187, _eri_order_3188, _eri_order_3189));
    int64_t v_op = (_eri_order_3190 = (v_context), _eri_order_3191 = ((v_routine)->f_instructions), _eri_order_3192 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3190, _eri_order_3191, _eri_order_3192));
    (_eri_order_3193 = (v_context), _eri_order_3194 = (fn_compiler_u002e_u1_ops_u002e_known(v_op)), _eri_order_3195 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x20, 0x66, 0x6f, 0x75, 0x6e, 0x64, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 32)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3193, _eri_order_3194, _eri_order_3195));
    int64_t v_cellType = 0;
    if ((_eri_order_3196 = (v_op), _eri_order_3197 = (10), (_eri_order_3196 >= _eri_order_3197))) {
        int64_t v_cell = (_eri_order_3198 = (v_context), _eri_order_3199 = ((v_routine)->f_instructions), _eri_order_3202 = ((_eri_order_3200 = (v_offset), _eri_order_3201 = (7), eri_iadd(_eri_order_3200, _eri_order_3201))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3198, _eri_order_3199, _eri_order_3202));
        (_eri_order_3203 = (v_context), _eri_order_3210 = (((_eri_order_3204 = (v_cell), _eri_order_3205 = (1), (_eri_order_3204 >= _eri_order_3205)) && (_eri_order_3206 = (v_cell), _eri_order_3209 = ((_eri_order_3207 = (((v_routine)->f_cells)->f_length), _eri_order_3208 = (2), eri_idiv(_eri_order_3207, _eri_order_3208))), (_eri_order_3206 <= _eri_order_3209)))), _eri_order_3211 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x63, 0x65, 0x6c, 0x6c, 0x20, 0x49, 0x44}, 15)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3203, _eri_order_3210, _eri_order_3211));
        v_cellType = (_eri_order_3212 = (v_context), _eri_order_3213 = ((v_routine)->f_cells), _eri_order_3218 = ((_eri_order_3216 = ((_eri_order_3214 = (v_cell), _eri_order_3215 = (1), eri_isub(_eri_order_3214, _eri_order_3215))), _eri_order_3217 = (2), eri_imul(_eri_order_3216, _eri_order_3217))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3212, _eri_order_3213, _eri_order_3218));
        (_eri_order_3219 = (v_context), _eri_order_3220 = (v_cellType), fn_compiler_u002e_u1_verify_u002e_typeIndex(_eri_order_3219, _eri_order_3220));
        if ((_eri_order_3221 = (v_op), _eri_order_3222 = (10), (_eri_order_3221 == _eri_order_3222))) {
            (_eri_order_3223 = (v_context), _eri_order_3235 = ((_eri_order_3233 = ((_eri_order_3224 = (v_context), _eri_order_3225 = ((v_routine)->f_cells), _eri_order_3232 = ((_eri_order_3230 = ((_eri_order_3228 = ((_eri_order_3226 = (v_cell), _eri_order_3227 = (1), eri_isub(_eri_order_3226, _eri_order_3227))), _eri_order_3229 = (2), eri_imul(_eri_order_3228, _eri_order_3229))), _eri_order_3231 = (1), eri_iadd(_eri_order_3230, _eri_order_3231))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3224, _eri_order_3225, _eri_order_3232))), _eri_order_3234 = (v_index), (_eri_order_3233 == _eri_order_3234))), _eri_order_3236 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x75, 0x70, 0x6c, 0x69, 0x63, 0x61, 0x74, 0x65, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x63, 0x6f, 0x6e, 0x73, 0x69, 0x73, 0x74, 0x65, 0x6e, 0x74, 0x20, 0x63, 0x65, 0x6c, 0x6c, 0x20, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x61, 0x6c, 0x69, 0x7a, 0x65, 0x72}, 42)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3223, _eri_order_3235, _eri_order_3236));
        }
    }
    (_eri_order_3237 = (v_context), _eri_order_3240 = ((_eri_order_3238 = (fn_compiler_u002e_u1_ops_u002e_terminal(v_op)), _eri_order_3239 = (v_terminal), (_eri_order_3238 == _eri_order_3239))), _eri_order_3241 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x74, 0x65, 0x72, 0x6d, 0x69, 0x6e, 0x61, 0x74, 0x6f, 0x72, 0x20, 0x70, 0x6c, 0x61, 0x63, 0x65, 0x6d, 0x65, 0x6e, 0x74}, 28)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3237, _eri_order_3240, _eri_order_3241));
    (_eri_order_3242 = (v_context), _eri_order_3250 = ((_eri_order_3248 = ((_eri_order_3243 = (v_context), _eri_order_3244 = ((v_routine)->f_instructions), _eri_order_3247 = ((_eri_order_3245 = (v_offset), _eri_order_3246 = (1), eri_iadd(_eri_order_3245, _eri_order_3246))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3243, _eri_order_3244, _eri_order_3247))), _eri_order_3249 = ((v_context)->f_block), (_eri_order_3248 == _eri_order_3249))), _eri_order_3251 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x62, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x6f, 0x77, 0x6e, 0x65, 0x72, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 32)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3242, _eri_order_3250, _eri_order_3251));
    int64_t v_first = (_eri_order_3252 = (v_context), _eri_order_3253 = ((v_routine)->f_instructions), _eri_order_3256 = ((_eri_order_3254 = (v_offset), _eri_order_3255 = (2), eri_iadd(_eri_order_3254, _eri_order_3255))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3252, _eri_order_3253, _eri_order_3256));
    int64_t v_count = (_eri_order_3257 = (v_context), _eri_order_3258 = ((v_routine)->f_instructions), _eri_order_3261 = ((_eri_order_3259 = (v_offset), _eri_order_3260 = (3), eri_iadd(_eri_order_3259, _eri_order_3260))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3257, _eri_order_3258, _eri_order_3261));
    (_eri_order_3262 = (v_context), _eri_order_3263 = (v_first), _eri_order_3264 = (v_count), _eri_order_3265 = (((v_routine)->f_operands)->f_length), fn_compiler_u002e_u1_verify_u002e_range(_eri_order_3262, _eri_order_3263, _eri_order_3264, _eri_order_3265));
    int64_t v_expected = fn_compiler_u002e_u1_ops_u002e_operands(v_op);
    if ((_eri_order_3266 = (v_op), _eri_order_3267 = (8), (_eri_order_3266 == _eri_order_3267))) {
        v_expected = (_eri_order_3268 = (v_context), _eri_order_3269 = (((v_routine)->f_metadata)->f_signatures), _eri_order_3276 = ((_eri_order_3274 = ((_eri_order_3272 = ((_eri_order_3270 = (((v_routine)->f_signature).f_index), _eri_order_3271 = (1), eri_isub(_eri_order_3270, _eri_order_3271))), _eri_order_3273 = (6), eri_imul(_eri_order_3272, _eri_order_3273))), _eri_order_3275 = (5), eri_iadd(_eri_order_3274, _eri_order_3275))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3268, _eri_order_3269, _eri_order_3276));
    }
    (_eri_order_3277 = (v_context), _eri_order_3280 = ((_eri_order_3278 = (v_count), _eri_order_3279 = (v_expected), (_eri_order_3278 == _eri_order_3279))), _eri_order_3281 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x6e, 0x64, 0x20, 0x61, 0x72, 0x69, 0x74, 0x79, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 34)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3277, _eri_order_3280, _eri_order_3281));
    int64_t v_item = 0;
    while ((_eri_order_3282 = (v_item), _eri_order_3283 = (v_count), (_eri_order_3282 < _eri_order_3283))) {
        int64_t v_actual = (_eri_order_3284 = (v_context), _eri_order_3290 = ((_eri_order_3285 = (v_context), _eri_order_3286 = ((v_routine)->f_operands), _eri_order_3289 = ((_eri_order_3287 = (v_first), _eri_order_3288 = (v_item), eri_iadd(_eri_order_3287, _eri_order_3288))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3285, _eri_order_3286, _eri_order_3289))), fn_compiler_u002e_u1_verify_u002e_valueType(_eri_order_3284, _eri_order_3290));
        int64_t v_valueTypeIndex = (_eri_order_3291 = (v_op), _eri_order_3292 = (v_item), fn_compiler_u002e_u1_ops_u002e_operandType(_eri_order_3291, _eri_order_3292));
        if ((_eri_order_3293 = (v_op), _eri_order_3294 = (10), (_eri_order_3293 >= _eri_order_3294))) {
            v_valueTypeIndex = v_cellType;
        }
        if ((_eri_order_3295 = (v_op), _eri_order_3296 = (8), (_eri_order_3295 == _eri_order_3296))) {
            int64_t v_resultStart = (_eri_order_3297 = (v_context), _eri_order_3298 = (((v_routine)->f_metadata)->f_signatures), _eri_order_3305 = ((_eri_order_3303 = ((_eri_order_3301 = ((_eri_order_3299 = (((v_routine)->f_signature).f_index), _eri_order_3300 = (1), eri_isub(_eri_order_3299, _eri_order_3300))), _eri_order_3302 = (6), eri_imul(_eri_order_3301, _eri_order_3302))), _eri_order_3304 = (4), eri_iadd(_eri_order_3303, _eri_order_3304))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3297, _eri_order_3298, _eri_order_3305));
            v_valueTypeIndex = (_eri_order_3306 = (v_context), _eri_order_3307 = (((v_routine)->f_metadata)->f_types), _eri_order_3310 = ((_eri_order_3308 = (v_resultStart), _eri_order_3309 = (v_item), eri_iadd(_eri_order_3308, _eri_order_3309))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3306, _eri_order_3307, _eri_order_3310));
        }
        (_eri_order_3311 = (v_context), _eri_order_3314 = ((_eri_order_3312 = (v_actual), _eri_order_3313 = (v_valueTypeIndex), (_eri_order_3312 == _eri_order_3313))), _eri_order_3315 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x6e, 0x64, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 33)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3311, _eri_order_3314, _eri_order_3315));
        v_item = (_eri_order_3316 = (v_item), _eri_order_3317 = (1), eri_iadd(_eri_order_3316, _eri_order_3317));
    }
    v_first = (_eri_order_3318 = (v_context), _eri_order_3319 = ((v_routine)->f_instructions), _eri_order_3322 = ((_eri_order_3320 = (v_offset), _eri_order_3321 = (4), eri_iadd(_eri_order_3320, _eri_order_3321))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3318, _eri_order_3319, _eri_order_3322));
    v_count = (_eri_order_3323 = (v_context), _eri_order_3324 = ((v_routine)->f_instructions), _eri_order_3327 = ((_eri_order_3325 = (v_offset), _eri_order_3326 = (5), eri_iadd(_eri_order_3325, _eri_order_3326))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3323, _eri_order_3324, _eri_order_3327));
    (_eri_order_3328 = (v_context), _eri_order_3331 = ((_eri_order_3329 = (v_count), _eri_order_3330 = (fn_compiler_u002e_u1_ops_u002e_results(v_op)), (_eri_order_3329 == _eri_order_3330))), _eri_order_3332 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x20, 0x61, 0x72, 0x69, 0x74, 0x79, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 33)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3328, _eri_order_3331, _eri_order_3332));
    if ((_eri_order_3333 = (v_count), _eri_order_3334 = (0), (_eri_order_3333 == _eri_order_3334))) {
        (_eri_order_3335 = (v_context), _eri_order_3338 = ((_eri_order_3336 = (v_first), _eri_order_3337 = (0), (_eri_order_3336 == _eri_order_3337))), _eri_order_3339 = (eri_text_from_bytes((const unsigned char[]){0x7a, 0x65, 0x72, 0x6f, 0x2d, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x68, 0x61, 0x73, 0x20, 0x61, 0x20, 0x66, 0x61, 0x6b, 0x65, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65}, 40)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3335, _eri_order_3338, _eri_order_3339));
    } else {
        (_eri_order_3340 = (v_context), _eri_order_3355 = ((((_eri_order_3341 = (v_first), _eri_order_3342 = (1), (_eri_order_3341 >= _eri_order_3342)) && (_eri_order_3343 = (v_first), _eri_order_3346 = ((_eri_order_3344 = (((v_routine)->f_values)->f_length), _eri_order_3345 = (4), eri_idiv(_eri_order_3344, _eri_order_3345))), (_eri_order_3343 <= _eri_order_3346))) && (_eri_order_3347 = (v_count), _eri_order_3354 = ((_eri_order_3352 = ((_eri_order_3350 = ((_eri_order_3348 = (((v_routine)->f_values)->f_length), _eri_order_3349 = (4), eri_idiv(_eri_order_3348, _eri_order_3349))), _eri_order_3351 = (v_first), eri_isub(_eri_order_3350, _eri_order_3351))), _eri_order_3353 = (1), eri_iadd(_eri_order_3352, _eri_order_3353))), (_eri_order_3347 <= _eri_order_3354)))), _eri_order_3356 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 20)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3340, _eri_order_3355, _eri_order_3356));
    }
    v_item = 0;
    while ((_eri_order_3357 = (v_item), _eri_order_3358 = (v_count), (_eri_order_3357 < _eri_order_3358))) {
        int64_t v_resultType = (_eri_order_3359 = (v_op), _eri_order_3360 = (v_item), fn_compiler_u002e_u1_ops_u002e_resultType(_eri_order_3359, _eri_order_3360));
        if ((_eri_order_3361 = (v_op), _eri_order_3362 = (11), (_eri_order_3361 == _eri_order_3362))) {
            v_resultType = v_cellType;
        }
        (_eri_order_3363 = (v_context), _eri_order_3366 = ((_eri_order_3364 = (v_first), _eri_order_3365 = (v_item), eri_iadd(_eri_order_3364, _eri_order_3365))), _eri_order_3367 = (v_resultType), _eri_order_3368 = (1), _eri_order_3369 = (v_index), _eri_order_3370 = (v_item), fn_compiler_u002e_u1_verify_u002e_claimValue(_eri_order_3363, _eri_order_3366, _eri_order_3367, _eri_order_3368, _eri_order_3369, _eri_order_3370));
        v_item = (_eri_order_3371 = (v_item), _eri_order_3372 = (1), eri_iadd(_eri_order_3371, _eri_order_3372));
    }
    int64_t v_payload = (_eri_order_3373 = (v_context), _eri_order_3374 = ((v_routine)->f_instructions), _eri_order_3377 = ((_eri_order_3375 = (v_offset), _eri_order_3376 = (7), eri_iadd(_eri_order_3375, _eri_order_3376))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3373, _eri_order_3374, _eri_order_3377));
    int64_t v_extra = (_eri_order_3378 = (v_context), _eri_order_3379 = ((v_routine)->f_instructions), _eri_order_3382 = ((_eri_order_3380 = (v_offset), _eri_order_3381 = (8), eri_iadd(_eri_order_3380, _eri_order_3381))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3378, _eri_order_3379, _eri_order_3382));
    if ((_eri_order_3383 = (v_op), _eri_order_3384 = (2), (_eri_order_3383 == _eri_order_3384))) {
        (_eri_order_3385 = (v_context), _eri_order_3390 = (((_eri_order_3386 = (v_payload), _eri_order_3387 = (0), (_eri_order_3386 == _eri_order_3387)) || (_eri_order_3388 = (v_payload), _eri_order_3389 = (1), (_eri_order_3388 == _eri_order_3389)))), _eri_order_3391 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x70, 0x72, 0x65, 0x64, 0x69, 0x63, 0x61, 0x74, 0x65, 0x20, 0x62, 0x69, 0x74, 0x73}, 22)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3385, _eri_order_3390, _eri_order_3391));
    }
    if ((_eri_order_3392 = (v_op), _eri_order_3393 = (5), (_eri_order_3392 == _eri_order_3393))) {
        (_eri_order_3394 = (v_context), _eri_order_3399 = (((_eri_order_3395 = (v_payload), _eri_order_3396 = (1), (_eri_order_3395 >= _eri_order_3396)) && (_eri_order_3397 = (v_payload), _eri_order_3398 = (4), (_eri_order_3397 <= _eri_order_3398)))), _eri_order_3400 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x74, 0x72, 0x61, 0x70, 0x20, 0x63, 0x6f, 0x64, 0x65}, 17)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3394, _eri_order_3399, _eri_order_3400));
    }
    if ((((_eri_order_3401 = (v_op), _eri_order_3402 = (3), (_eri_order_3401 == _eri_order_3402)) || (_eri_order_3403 = (v_op), _eri_order_3404 = (4), (_eri_order_3403 == _eri_order_3404))) || (_eri_order_3405 = (v_op), _eri_order_3406 = (8), (_eri_order_3405 == _eri_order_3406)))) {
        (_eri_order_3407 = (v_context), _eri_order_3410 = ((_eri_order_3408 = (v_payload), _eri_order_3409 = (0), (_eri_order_3408 == _eri_order_3409))), _eri_order_3411 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x70, 0x61, 0x79, 0x6c, 0x6f, 0x61, 0x64}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3407, _eri_order_3410, _eri_order_3411));
    }
    if ((_eri_order_3412 = (v_op), _eri_order_3413 = (7), (_eri_order_3412 != _eri_order_3413))) {
        (_eri_order_3414 = (v_context), _eri_order_3417 = ((_eri_order_3415 = (v_extra), _eri_order_3416 = (0), (_eri_order_3415 == _eri_order_3416))), _eri_order_3418 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x61, 0x74, 0x74, 0x72, 0x69, 0x62, 0x75, 0x74, 0x65}, 31)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3414, _eri_order_3417, _eri_order_3418));
    }
    if (v_terminal) {
        (_eri_order_3419 = (v_context), _eri_order_3427 = ((_eri_order_3425 = ((_eri_order_3420 = (v_context), _eri_order_3421 = ((v_routine)->f_instructions), _eri_order_3424 = ((_eri_order_3422 = (v_offset), _eri_order_3423 = (9), eri_iadd(_eri_order_3422, _eri_order_3423))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3420, _eri_order_3421, _eri_order_3424))), _eri_order_3426 = (0), (_eri_order_3425 == _eri_order_3426))), _eri_order_3428 = (eri_text_from_bytes((const unsigned char[]){0x74, 0x65, 0x72, 0x6d, 0x69, 0x6e, 0x61, 0x74, 0x6f, 0x72, 0x20, 0x68, 0x61, 0x73, 0x20, 0x61, 0x20, 0x73, 0x75, 0x63, 0x63, 0x65, 0x73, 0x73, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e}, 38)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3419, _eri_order_3427, _eri_order_3428));
    }
    if (((_eri_order_3429 = (v_op), _eri_order_3430 = (6), (_eri_order_3429 == _eri_order_3430)) || (_eri_order_3431 = (v_op), _eri_order_3432 = (7), (_eri_order_3431 == _eri_order_3432)))) {
        (_eri_order_3433 = (v_context), _eri_order_3434 = (v_payload), fn_compiler_u002e_u1_verify_u002e_edge(_eri_order_3433, _eri_order_3434));
        if ((_eri_order_3435 = (v_op), _eri_order_3436 = (7), (_eri_order_3435 == _eri_order_3436))) {
            (_eri_order_3437 = (v_context), _eri_order_3438 = (v_extra), fn_compiler_u002e_u1_verify_u002e_edge(_eri_order_3437, _eri_order_3438));
        }
    }
}

static void fn_compiler_u002e_u1_verify_u002e_structure(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context) {
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_3439;
    int64_t _eri_order_3440;
    int64_t _eri_order_3441;
    int64_t _eri_order_3442;
    int64_t _eri_order_3443;
    int64_t _eri_order_3444;
    int64_t _eri_order_3445;
    int64_t _eri_order_3446;
    int64_t _eri_order_3447;
    int64_t _eri_order_3448;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3449;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3450;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3451;
    int64_t _eri_order_3452;
    int64_t _eri_order_3453;
    int64_t _eri_order_3454;
    int64_t _eri_order_3455;
    int64_t _eri_order_3456;
    int64_t _eri_order_3457;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3458;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3459;
    int64_t _eri_order_3460;
    int64_t _eri_order_3461;
    int64_t _eri_order_3462;
    int64_t _eri_order_3463;
    int64_t _eri_order_3464;
    int64_t _eri_order_3465;
    int64_t _eri_order_3466;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3467;
    int64_t _eri_order_3468;
    int64_t _eri_order_3469;
    int64_t _eri_order_3470;
    int64_t _eri_order_3471;
    int64_t _eri_order_3472;
    int64_t _eri_order_3473;
    bool _eri_order_3474;
    eri_text _eri_order_3475;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3476;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3477;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3478;
    int64_t _eri_order_3479;
    int64_t _eri_order_3480;
    int64_t _eri_order_3481;
    int64_t _eri_order_3482;
    int64_t _eri_order_3483;
    int64_t _eri_order_3484;
    int64_t _eri_order_3485;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3486;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3487;
    int64_t _eri_order_3488;
    int64_t _eri_order_3489;
    int64_t _eri_order_3490;
    int64_t _eri_order_3491;
    int64_t _eri_order_3492;
    int64_t _eri_order_3493;
    int64_t _eri_order_3494;
    int64_t _eri_order_3495;
    int64_t _eri_order_3496;
    bool _eri_order_3497;
    eri_text _eri_order_3498;
    int64_t _eri_order_3499;
    int64_t _eri_order_3500;
    int64_t _eri_order_3501;
    int64_t _eri_order_3502;
    int64_t _eri_order_3503;
    int64_t _eri_order_3504;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3505;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3506;
    int64_t _eri_order_3507;
    int64_t _eri_order_3508;
    int64_t _eri_order_3509;
    int64_t _eri_order_3510;
    int64_t _eri_order_3511;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3512;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3513;
    int64_t _eri_order_3514;
    int64_t _eri_order_3515;
    int64_t _eri_order_3516;
    int64_t _eri_order_3517;
    int64_t _eri_order_3518;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3519;
    int64_t _eri_order_3520;
    int64_t _eri_order_3521;
    int64_t _eri_order_3522;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3523;
    int64_t _eri_order_3524;
    int64_t _eri_order_3525;
    bool _eri_order_3526;
    eri_text _eri_order_3527;
    int64_t _eri_order_3528;
    int64_t _eri_order_3529;
    int64_t _eri_order_3530;
    int64_t _eri_order_3531;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3532;
    int64_t _eri_order_3533;
    int64_t _eri_order_3534;
    bool _eri_order_3535;
    eri_text _eri_order_3536;
    int64_t _eri_order_3537;
    int64_t _eri_order_3538;
    int64_t _eri_order_3539;
    int64_t _eri_order_3540;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3541;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3542;
    int64_t _eri_order_3543;
    int64_t _eri_order_3544;
    int64_t _eri_order_3545;
    int64_t _eri_order_3546;
    int64_t _eri_order_3547;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3548;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3549;
    int64_t _eri_order_3550;
    int64_t _eri_order_3551;
    int64_t _eri_order_3552;
    int64_t _eri_order_3553;
    int64_t _eri_order_3554;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3555;
    int64_t _eri_order_3556;
    int64_t _eri_order_3557;
    int64_t _eri_order_3558;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3559;
    int64_t _eri_order_3560;
    int64_t _eri_order_3561;
    bool _eri_order_3562;
    eri_text _eri_order_3563;
    int64_t _eri_order_3564;
    int64_t _eri_order_3565;
    int64_t _eri_order_3566;
    int64_t _eri_order_3567;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3568;
    int64_t _eri_order_3569;
    int64_t _eri_order_3570;
    bool _eri_order_3571;
    eri_text _eri_order_3572;
    int64_t _eri_order_3573;
    int64_t _eri_order_3574;
    int64_t _eri_order_3575;
    int64_t _eri_order_3576;
    int64_t _eri_order_3577;
    int64_t _eri_order_3578;
    int64_t _eri_order_3579;
    int64_t _eri_order_3580;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3581;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3582;
    int64_t _eri_order_3583;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3584;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3585;
    int64_t _eri_order_3586;
    int64_t _eri_order_3587;
    int64_t _eri_order_3588;
    int64_t _eri_order_3589;
    int64_t _eri_order_3590;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3591;
    int64_t _eri_order_3592;
    int64_t _eri_order_3593;
    bool _eri_order_3594;
    eri_text _eri_order_3595;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3596;
    int64_t _eri_order_3597;
    int64_t _eri_order_3598;
    int64_t _eri_order_3599;
    int64_t _eri_order_3600;
    int64_t _eri_order_3601;
    int64_t _eri_order_3602;
    int64_t _eri_order_3603;
    int64_t _eri_order_3604;
    int64_t _eri_order_3605;
    int64_t _eri_order_3606;
    int64_t _eri_order_3607;
    int64_t _eri_order_3608;
    int64_t _eri_order_3609;
    int64_t _eri_order_3610;
    int64_t _eri_order_3611;
    int64_t _eri_order_3612;
    bool _eri_order_3613;
    eri_text _eri_order_3614;
    int64_t _eri_order_3615;
    int64_t _eri_order_3616;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3617;
    int64_t _eri_order_3618;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3619;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3620;
    int64_t _eri_order_3621;
    int64_t _eri_order_3622;
    int64_t _eri_order_3623;
    int64_t _eri_order_3624;
    int64_t _eri_order_3625;
    int64_t _eri_order_3626;
    int64_t _eri_order_3627;
    int64_t _eri_order_3628;
    bool _eri_order_3629;
    eri_text _eri_order_3630;
    int64_t _eri_order_3631;
    int64_t _eri_order_3632;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3633;
    int64_t _eri_order_3634;
    int64_t _eri_order_3635;
    int64_t _eri_order_3636;
    int64_t _eri_order_3637;
    int64_t _eri_order_3638;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3639;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3640;
    int64_t _eri_order_3641;
    int64_t _eri_order_3642;
    int64_t _eri_order_3643;
    int64_t _eri_order_3644;
    int64_t _eri_order_3645;
    int64_t _eri_order_3646;
    int64_t _eri_order_3647;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3648;
    int64_t _eri_order_3649;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3650;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3651;
    int64_t _eri_order_3652;
    int64_t _eri_order_3653;
    int64_t _eri_order_3654;
    int64_t _eri_order_3655;
    bool _eri_order_3656;
    eri_text _eri_order_3657;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3658;
    int64_t _eri_order_3659;
    int64_t _eri_order_3660;
    int64_t _eri_order_3661;
    int64_t _eri_order_3662;
    int64_t _eri_order_3663;
    int64_t _eri_order_3664;
    int64_t _eri_order_3665;
    int64_t _eri_order_3666;
    int64_t _eri_order_3667;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3668;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3669;
    int64_t _eri_order_3670;
    int64_t _eri_order_3671;
    int64_t _eri_order_3672;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3673;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3674;
    int64_t _eri_order_3675;
    int64_t _eri_order_3676;
    int64_t _eri_order_3677;
    int64_t _eri_order_3678;
    int64_t _eri_order_3679;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3680;
    int64_t _eri_order_3681;
    bool _eri_order_3682;
    int64_t _eri_order_3683;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3684;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3685;
    int64_t _eri_order_3686;
    int64_t _eri_order_3687;
    int64_t _eri_order_3688;
    int64_t _eri_order_3689;
    int64_t _eri_order_3690;
    int64_t _eri_order_3691;
    int64_t _eri_order_3692;
    int64_t _eri_order_3693;
    int64_t _eri_order_3694;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3695;
    int64_t _eri_order_3696;
    int64_t _eri_order_3697;
    bool _eri_order_3698;
    eri_text _eri_order_3699;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3700;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3701;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3702;
    int64_t _eri_order_3703;
    int64_t _eri_order_3704;
    int64_t _eri_order_3705;
    int64_t _eri_order_3706;
    bool _eri_order_3707;
    int64_t _eri_order_3708;
    int64_t _eri_order_3709;
    int64_t _eri_order_3710;
    int64_t _eri_order_3711;
    int64_t _eri_order_3712;
    int64_t _eri_order_3713;
    int64_t _eri_order_3714;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3715;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3716;
    int64_t _eri_order_3717;
    int64_t _eri_order_3718;
    int64_t _eri_order_3719;
    int64_t _eri_order_3720;
    bool _eri_order_3721;
    eri_text _eri_order_3722;
    int64_t _eri_order_3723;
    int64_t _eri_order_3724;
    int64_t _eri_order_3725;
    int64_t _eri_order_3726;
    int64_t _eri_order_3727;
    int64_t _eri_order_3728;
    int64_t _eri_order_3729;
    int64_t _eri_order_3730;
    int64_t _eri_order_3731;
    int64_t _eri_order_3732;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3733;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3734;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3735;
    int64_t _eri_order_3736;
    int64_t _eri_order_3737;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3738;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3739;
    int64_t _eri_order_3740;
    int64_t _eri_order_3741;
    int64_t _eri_order_3742;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3743;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3744;
    int64_t _eri_order_3745;
    int64_t _eri_order_3746;
    int64_t _eri_order_3747;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3748;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3749;
    int64_t _eri_order_3750;
    int64_t _eri_order_3751;
    int64_t _eri_order_3752;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3753;
    int64_t _eri_order_3754;
    int64_t _eri_order_3755;
    bool _eri_order_3756;
    eri_text _eri_order_3757;
    int64_t _eri_order_3758;
    int64_t _eri_order_3759;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3760;
    int64_t _eri_order_3761;
    int64_t _eri_order_3762;
    int64_t _eri_order_3763;
    int64_t _eri_order_3764;
    int64_t _eri_order_3765;
    int64_t _eri_order_3766;
    bool _eri_order_3767;
    eri_text _eri_order_3768;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3769;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3770;
    int64_t _eri_order_3771;
    int64_t _eri_order_3772;
    int64_t _eri_order_3773;
    int64_t _eri_order_3774;
    int64_t _eri_order_3775;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3776;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3777;
    int64_t _eri_order_3778;
    int64_t _eri_order_3779;
    int64_t _eri_order_3780;
    int64_t _eri_order_3781;
    int64_t _eri_order_3782;
    int64_t _eri_order_3783;
    int64_t _eri_order_3784;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3785;
    int64_t _eri_order_3786;
    int64_t _eri_order_3787;
    int64_t _eri_order_3788;
    int64_t _eri_order_3789;
    int64_t _eri_order_3790;
    int64_t _eri_order_3791;
    int64_t _eri_order_3792;
    int64_t _eri_order_3793;
    bool _eri_order_3794;
    eri_text _eri_order_3795;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3796;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3797;
    int64_t _eri_order_3798;
    int64_t _eri_order_3799;
    int64_t _eri_order_3800;
    int64_t _eri_order_3801;
    int64_t _eri_order_3802;
    int64_t _eri_order_3803;
    int64_t _eri_order_3804;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3805;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3806;
    int64_t _eri_order_3807;
    int64_t _eri_order_3808;
    int64_t _eri_order_3809;
    int64_t _eri_order_3810;
    int64_t _eri_order_3811;
    int64_t _eri_order_3812;
    int64_t _eri_order_3813;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3814;
    int64_t _eri_order_3815;
    int64_t _eri_order_3816;
    int64_t _eri_order_3817;
    int64_t _eri_order_3818;
    int64_t _eri_order_3819;
    int64_t _eri_order_3820;
    int64_t _eri_order_3821;
    int64_t _eri_order_3822;
    bool _eri_order_3823;
    eri_text _eri_order_3824;
    int64_t _eri_order_3825;
    int64_t _eri_order_3826;
    int64_t _eri_order_3827;
    int64_t _eri_order_3828;
    int64_t _eri_order_3829;
    int64_t _eri_order_3830;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3831;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3832;
    int64_t _eri_order_3833;
    int64_t _eri_order_3834;
    int64_t _eri_order_3835;
    int64_t _eri_order_3836;
    int64_t _eri_order_3837;
    int64_t _eri_order_3838;
    int64_t _eri_order_3839;
    int64_t _eri_order_3840;
    bool _eri_order_3841;
    eri_text _eri_order_3842;
    int64_t _eri_order_3843;
    int64_t _eri_order_3844;
    (v_context)->f_stage = 2;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_context)->f_routine;
    (v_context)->f_positions = (_eri_order_3439 = ((v_context)->f_graph), _eri_order_3444 = ((_eri_order_3442 = ((_eri_order_3440 = (((v_routine)->f_instructions)->f_length), _eri_order_3441 = (10), eri_idiv(_eri_order_3440, _eri_order_3441))), _eri_order_3443 = (1), eri_iadd(_eri_order_3442, _eri_order_3443))), fn_compiler_u002e_u1_dominance_u002e_zeros(_eri_order_3439, _eri_order_3444));
    int64_t v_cell = 1;
    while ((_eri_order_3445 = (v_cell), _eri_order_3448 = ((_eri_order_3446 = (((v_routine)->f_cells)->f_length), _eri_order_3447 = (2), eri_idiv(_eri_order_3446, _eri_order_3447))), (_eri_order_3445 <= _eri_order_3448))) {
        (_eri_order_3449 = (v_context), _eri_order_3457 = ((_eri_order_3450 = (v_context), _eri_order_3451 = ((v_routine)->f_cells), _eri_order_3456 = ((_eri_order_3454 = ((_eri_order_3452 = (v_cell), _eri_order_3453 = (1), eri_isub(_eri_order_3452, _eri_order_3453))), _eri_order_3455 = (2), eri_imul(_eri_order_3454, _eri_order_3455))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3450, _eri_order_3451, _eri_order_3456))), fn_compiler_u002e_u1_verify_u002e_typeIndex(_eri_order_3449, _eri_order_3457));
        int64_t v_initializer = (_eri_order_3458 = (v_context), _eri_order_3459 = ((v_routine)->f_cells), _eri_order_3466 = ((_eri_order_3464 = ((_eri_order_3462 = ((_eri_order_3460 = (v_cell), _eri_order_3461 = (1), eri_isub(_eri_order_3460, _eri_order_3461))), _eri_order_3463 = (2), eri_imul(_eri_order_3462, _eri_order_3463))), _eri_order_3465 = (1), eri_iadd(_eri_order_3464, _eri_order_3465))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3458, _eri_order_3459, _eri_order_3466));
        (_eri_order_3467 = (v_context), _eri_order_3474 = (((_eri_order_3468 = (v_initializer), _eri_order_3469 = (1), (_eri_order_3468 >= _eri_order_3469)) && (_eri_order_3470 = (v_initializer), _eri_order_3473 = ((_eri_order_3471 = (((v_routine)->f_instructions)->f_length), _eri_order_3472 = (10), eri_idiv(_eri_order_3471, _eri_order_3472))), (_eri_order_3470 <= _eri_order_3473)))), _eri_order_3475 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x69, 0x73, 0x73, 0x69, 0x6e, 0x67, 0x20, 0x63, 0x65, 0x6c, 0x6c, 0x20, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x61, 0x6c, 0x69, 0x7a, 0x65, 0x72}, 24)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3467, _eri_order_3474, _eri_order_3475));
        (_eri_order_3476 = (v_context), _eri_order_3497 = (((_eri_order_3484 = ((_eri_order_3477 = (v_context), _eri_order_3478 = ((v_routine)->f_instructions), _eri_order_3483 = ((_eri_order_3481 = ((_eri_order_3479 = (v_initializer), _eri_order_3480 = (1), eri_isub(_eri_order_3479, _eri_order_3480))), _eri_order_3482 = (10), eri_imul(_eri_order_3481, _eri_order_3482))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3477, _eri_order_3478, _eri_order_3483))), _eri_order_3485 = (10), (_eri_order_3484 == _eri_order_3485)) && (_eri_order_3495 = ((_eri_order_3486 = (v_context), _eri_order_3487 = ((v_routine)->f_instructions), _eri_order_3494 = ((_eri_order_3492 = ((_eri_order_3490 = ((_eri_order_3488 = (v_initializer), _eri_order_3489 = (1), eri_isub(_eri_order_3488, _eri_order_3489))), _eri_order_3491 = (10), eri_imul(_eri_order_3490, _eri_order_3491))), _eri_order_3493 = (7), eri_iadd(_eri_order_3492, _eri_order_3493))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3486, _eri_order_3487, _eri_order_3494))), _eri_order_3496 = (v_cell), (_eri_order_3495 == _eri_order_3496)))), _eri_order_3498 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x61, 0x6c, 0x69, 0x7a, 0x65, 0x72, 0x20, 0x64, 0x65, 0x63, 0x6c, 0x61, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 31)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3476, _eri_order_3497, _eri_order_3498));
        v_cell = (_eri_order_3499 = (v_cell), _eri_order_3500 = (1), eri_iadd(_eri_order_3499, _eri_order_3500));
    }
    int64_t v_cursor = 0;
    int64_t v_item = 0;
    while ((_eri_order_3501 = (v_item), _eri_order_3504 = ((_eri_order_3502 = (((v_routine)->f_instructions)->f_length), _eri_order_3503 = (10), eri_idiv(_eri_order_3502, _eri_order_3503))), (_eri_order_3501 < _eri_order_3504))) {
        int64_t v_first = (_eri_order_3505 = (v_context), _eri_order_3506 = ((v_routine)->f_instructions), _eri_order_3511 = ((_eri_order_3509 = ((_eri_order_3507 = (v_item), _eri_order_3508 = (10), eri_imul(_eri_order_3507, _eri_order_3508))), _eri_order_3510 = (2), eri_iadd(_eri_order_3509, _eri_order_3510))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3505, _eri_order_3506, _eri_order_3511));
        int64_t v_count = (_eri_order_3512 = (v_context), _eri_order_3513 = ((v_routine)->f_instructions), _eri_order_3518 = ((_eri_order_3516 = ((_eri_order_3514 = (v_item), _eri_order_3515 = (10), eri_imul(_eri_order_3514, _eri_order_3515))), _eri_order_3517 = (3), eri_iadd(_eri_order_3516, _eri_order_3517))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3512, _eri_order_3513, _eri_order_3518));
        (_eri_order_3519 = (v_context), _eri_order_3520 = (v_first), _eri_order_3521 = (v_count), _eri_order_3522 = (((v_routine)->f_operands)->f_length), fn_compiler_u002e_u1_verify_u002e_range(_eri_order_3519, _eri_order_3520, _eri_order_3521, _eri_order_3522));
        (_eri_order_3523 = (v_context), _eri_order_3526 = ((_eri_order_3524 = (v_first), _eri_order_3525 = (v_cursor), (_eri_order_3524 == _eri_order_3525))), _eri_order_3527 = (eri_text_from_bytes((const unsigned char[]){0x6e, 0x6f, 0x6e, 0x63, 0x61, 0x6e, 0x6f, 0x6e, 0x69, 0x63, 0x61, 0x6c, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x6e, 0x64, 0x20, 0x70, 0x6f, 0x6f, 0x6c}, 25)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3523, _eri_order_3526, _eri_order_3527));
        v_cursor = (_eri_order_3528 = (v_first), _eri_order_3529 = (v_count), eri_iadd(_eri_order_3528, _eri_order_3529));
        v_item = (_eri_order_3530 = (v_item), _eri_order_3531 = (1), eri_iadd(_eri_order_3530, _eri_order_3531));
    }
    (_eri_order_3532 = (v_context), _eri_order_3535 = ((_eri_order_3533 = (v_cursor), _eri_order_3534 = (((v_routine)->f_operands)->f_length), (_eri_order_3533 == _eri_order_3534))), _eri_order_3536 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x63, 0x6c, 0x61, 0x69, 0x6d, 0x65, 0x64, 0x20, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x6e, 0x64, 0x73}, 18)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3532, _eri_order_3535, _eri_order_3536));
    v_cursor = 0;
    v_item = 0;
    while ((_eri_order_3537 = (v_item), _eri_order_3540 = ((_eri_order_3538 = (((v_routine)->f_edges)->f_length), _eri_order_3539 = (3), eri_idiv(_eri_order_3538, _eri_order_3539))), (_eri_order_3537 < _eri_order_3540))) {
        int64_t v_first = (_eri_order_3541 = (v_context), _eri_order_3542 = ((v_routine)->f_edges), _eri_order_3547 = ((_eri_order_3545 = ((_eri_order_3543 = (v_item), _eri_order_3544 = (3), eri_imul(_eri_order_3543, _eri_order_3544))), _eri_order_3546 = (1), eri_iadd(_eri_order_3545, _eri_order_3546))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3541, _eri_order_3542, _eri_order_3547));
        int64_t v_count = (_eri_order_3548 = (v_context), _eri_order_3549 = ((v_routine)->f_edges), _eri_order_3554 = ((_eri_order_3552 = ((_eri_order_3550 = (v_item), _eri_order_3551 = (3), eri_imul(_eri_order_3550, _eri_order_3551))), _eri_order_3553 = (2), eri_iadd(_eri_order_3552, _eri_order_3553))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3548, _eri_order_3549, _eri_order_3554));
        (_eri_order_3555 = (v_context), _eri_order_3556 = (v_first), _eri_order_3557 = (v_count), _eri_order_3558 = (((v_routine)->f_arguments)->f_length), fn_compiler_u002e_u1_verify_u002e_range(_eri_order_3555, _eri_order_3556, _eri_order_3557, _eri_order_3558));
        (_eri_order_3559 = (v_context), _eri_order_3562 = ((_eri_order_3560 = (v_first), _eri_order_3561 = (v_cursor), (_eri_order_3560 == _eri_order_3561))), _eri_order_3563 = (eri_text_from_bytes((const unsigned char[]){0x6e, 0x6f, 0x6e, 0x63, 0x61, 0x6e, 0x6f, 0x6e, 0x69, 0x63, 0x61, 0x6c, 0x20, 0x65, 0x64, 0x67, 0x65, 0x2d, 0x61, 0x72, 0x67, 0x75, 0x6d, 0x65, 0x6e, 0x74, 0x20, 0x70, 0x6f, 0x6f, 0x6c}, 31)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3559, _eri_order_3562, _eri_order_3563));
        v_cursor = (_eri_order_3564 = (v_first), _eri_order_3565 = (v_count), eri_iadd(_eri_order_3564, _eri_order_3565));
        v_item = (_eri_order_3566 = (v_item), _eri_order_3567 = (1), eri_iadd(_eri_order_3566, _eri_order_3567));
    }
    (_eri_order_3568 = (v_context), _eri_order_3571 = ((_eri_order_3569 = (v_cursor), _eri_order_3570 = (((v_routine)->f_arguments)->f_length), (_eri_order_3569 == _eri_order_3570))), _eri_order_3572 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x63, 0x6c, 0x61, 0x69, 0x6d, 0x65, 0x64, 0x20, 0x65, 0x64, 0x67, 0x65, 0x20, 0x61, 0x72, 0x67, 0x75, 0x6d, 0x65, 0x6e, 0x74, 0x73}, 24)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3568, _eri_order_3571, _eri_order_3572));
    (v_context)->f_block = 1;
    while ((_eri_order_3573 = ((v_context)->f_block), _eri_order_3576 = ((_eri_order_3574 = (((v_routine)->f_blocks)->f_length), _eri_order_3575 = (5), eri_idiv(_eri_order_3574, _eri_order_3575))), (_eri_order_3573 <= _eri_order_3576))) {
        (v_context)->f_instruction = 0;
        int64_t v_offset = (_eri_order_3579 = ((_eri_order_3577 = ((v_context)->f_block), _eri_order_3578 = (1), eri_isub(_eri_order_3577, _eri_order_3578))), _eri_order_3580 = (5), eri_imul(_eri_order_3579, _eri_order_3580));
        int64_t v_first = (_eri_order_3581 = (v_context), _eri_order_3582 = ((v_routine)->f_blocks), _eri_order_3583 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3581, _eri_order_3582, _eri_order_3583));
        int64_t v_count = (_eri_order_3584 = (v_context), _eri_order_3585 = ((v_routine)->f_blocks), _eri_order_3588 = ((_eri_order_3586 = (v_offset), _eri_order_3587 = (1), eri_iadd(_eri_order_3586, _eri_order_3587))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3584, _eri_order_3585, _eri_order_3588));
        if ((_eri_order_3589 = (v_count), _eri_order_3590 = (0), (_eri_order_3589 == _eri_order_3590))) {
            (_eri_order_3591 = (v_context), _eri_order_3594 = ((_eri_order_3592 = (v_first), _eri_order_3593 = (0), (_eri_order_3592 == _eri_order_3593))), _eri_order_3595 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x6d, 0x70, 0x74, 0x79, 0x20, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x65, 0x74, 0x65, 0x72, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65, 0x20, 0x68, 0x61, 0x73, 0x20, 0x61, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65}, 33)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3591, _eri_order_3594, _eri_order_3595));
        } else {
            (_eri_order_3596 = (v_context), _eri_order_3613 = (((((_eri_order_3597 = (v_count), _eri_order_3598 = (0), (_eri_order_3597 > _eri_order_3598)) && (_eri_order_3599 = (v_first), _eri_order_3600 = (1), (_eri_order_3599 >= _eri_order_3600))) && (_eri_order_3601 = (v_first), _eri_order_3604 = ((_eri_order_3602 = (((v_routine)->f_values)->f_length), _eri_order_3603 = (4), eri_idiv(_eri_order_3602, _eri_order_3603))), (_eri_order_3601 <= _eri_order_3604))) && (_eri_order_3605 = (v_count), _eri_order_3612 = ((_eri_order_3610 = ((_eri_order_3608 = ((_eri_order_3606 = (((v_routine)->f_values)->f_length), _eri_order_3607 = (4), eri_idiv(_eri_order_3606, _eri_order_3607))), _eri_order_3609 = (v_first), eri_isub(_eri_order_3608, _eri_order_3609))), _eri_order_3611 = (1), eri_iadd(_eri_order_3610, _eri_order_3611))), (_eri_order_3605 <= _eri_order_3612)))), _eri_order_3614 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x65, 0x74, 0x65, 0x72, 0x20, 0x72, 0x61, 0x6e, 0x67, 0x65}, 23)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3596, _eri_order_3613, _eri_order_3614));
        }
        if ((_eri_order_3615 = ((v_context)->f_block), _eri_order_3616 = (1), (_eri_order_3615 == _eri_order_3616))) {
            (_eri_order_3617 = (v_context), _eri_order_3629 = ((_eri_order_3618 = (v_count), _eri_order_3628 = ((_eri_order_3619 = (v_context), _eri_order_3620 = (((v_routine)->f_metadata)->f_signatures), _eri_order_3627 = ((_eri_order_3625 = ((_eri_order_3623 = ((_eri_order_3621 = (((v_routine)->f_signature).f_index), _eri_order_3622 = (1), eri_isub(_eri_order_3621, _eri_order_3622))), _eri_order_3624 = (6), eri_imul(_eri_order_3623, _eri_order_3624))), _eri_order_3626 = (3), eri_iadd(_eri_order_3625, _eri_order_3626))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3619, _eri_order_3620, _eri_order_3627))), (_eri_order_3618 == _eri_order_3628))), _eri_order_3630 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x6e, 0x74, 0x72, 0x79, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x61, 0x72, 0x69, 0x74, 0x79, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 30)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3617, _eri_order_3629, _eri_order_3630));
        }
        v_item = 0;
        while ((_eri_order_3631 = (v_item), _eri_order_3632 = (v_count), (_eri_order_3631 < _eri_order_3632))) {
            int64_t v_valueTypeIndex = (_eri_order_3633 = (v_context), _eri_order_3636 = ((_eri_order_3634 = (v_first), _eri_order_3635 = (v_item), eri_iadd(_eri_order_3634, _eri_order_3635))), fn_compiler_u002e_u1_verify_u002e_valueType(_eri_order_3633, _eri_order_3636));
            if ((_eri_order_3637 = ((v_context)->f_block), _eri_order_3638 = (1), (_eri_order_3637 == _eri_order_3638))) {
                int64_t v_start = (_eri_order_3639 = (v_context), _eri_order_3640 = (((v_routine)->f_metadata)->f_signatures), _eri_order_3647 = ((_eri_order_3645 = ((_eri_order_3643 = ((_eri_order_3641 = (((v_routine)->f_signature).f_index), _eri_order_3642 = (1), eri_isub(_eri_order_3641, _eri_order_3642))), _eri_order_3644 = (6), eri_imul(_eri_order_3643, _eri_order_3644))), _eri_order_3646 = (2), eri_iadd(_eri_order_3645, _eri_order_3646))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3639, _eri_order_3640, _eri_order_3647));
                (_eri_order_3648 = (v_context), _eri_order_3656 = ((_eri_order_3649 = (v_valueTypeIndex), _eri_order_3655 = ((_eri_order_3650 = (v_context), _eri_order_3651 = (((v_routine)->f_metadata)->f_types), _eri_order_3654 = ((_eri_order_3652 = (v_start), _eri_order_3653 = (v_item), eri_iadd(_eri_order_3652, _eri_order_3653))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3650, _eri_order_3651, _eri_order_3654))), (_eri_order_3649 == _eri_order_3655))), _eri_order_3657 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x6e, 0x74, 0x72, 0x79, 0x20, 0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x20, 0x74, 0x79, 0x70, 0x65, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3648, _eri_order_3656, _eri_order_3657));
            }
            (_eri_order_3658 = (v_context), _eri_order_3661 = ((_eri_order_3659 = (v_first), _eri_order_3660 = (v_item), eri_iadd(_eri_order_3659, _eri_order_3660))), _eri_order_3662 = (v_valueTypeIndex), _eri_order_3663 = (0), _eri_order_3664 = ((v_context)->f_block), _eri_order_3665 = (v_item), fn_compiler_u002e_u1_verify_u002e_claimValue(_eri_order_3658, _eri_order_3661, _eri_order_3662, _eri_order_3663, _eri_order_3664, _eri_order_3665));
            v_item = (_eri_order_3666 = (v_item), _eri_order_3667 = (1), eri_iadd(_eri_order_3666, _eri_order_3667));
        }
        int64_t v_current = (_eri_order_3668 = (v_context), _eri_order_3669 = ((v_routine)->f_blocks), _eri_order_3672 = ((_eri_order_3670 = (v_offset), _eri_order_3671 = (2), eri_iadd(_eri_order_3670, _eri_order_3671))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3668, _eri_order_3669, _eri_order_3672));
        int64_t v_last = (_eri_order_3673 = (v_context), _eri_order_3674 = ((v_routine)->f_blocks), _eri_order_3677 = ((_eri_order_3675 = (v_offset), _eri_order_3676 = (3), eri_iadd(_eri_order_3675, _eri_order_3676))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3673, _eri_order_3674, _eri_order_3677));
        int64_t v_position = 1;
        int64_t v_previous = 0;
        while ((_eri_order_3678 = (v_current), _eri_order_3679 = (0), (_eri_order_3678 != _eri_order_3679))) {
            (_eri_order_3680 = (v_context), _eri_order_3681 = (v_current), _eri_order_3682 = (false), _eri_order_3683 = (v_position), fn_compiler_u002e_u1_verify_u002e_instruction(_eri_order_3680, _eri_order_3681, _eri_order_3682, _eri_order_3683));
            v_previous = v_current;
            v_current = (_eri_order_3684 = (v_context), _eri_order_3685 = ((v_routine)->f_instructions), _eri_order_3692 = ((_eri_order_3690 = ((_eri_order_3688 = ((_eri_order_3686 = (v_current), _eri_order_3687 = (1), eri_isub(_eri_order_3686, _eri_order_3687))), _eri_order_3689 = (10), eri_imul(_eri_order_3688, _eri_order_3689))), _eri_order_3691 = (9), eri_iadd(_eri_order_3690, _eri_order_3691))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3684, _eri_order_3685, _eri_order_3692));
            v_position = (_eri_order_3693 = (v_position), _eri_order_3694 = (1), eri_iadd(_eri_order_3693, _eri_order_3694));
        }
        (_eri_order_3695 = (v_context), _eri_order_3698 = ((_eri_order_3696 = (v_last), _eri_order_3697 = (v_previous), (_eri_order_3696 == _eri_order_3697))), _eri_order_3699 = (eri_text_from_bytes((const unsigned char[]){0x62, 0x6c, 0x6f, 0x63, 0x6b, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x74, 0x61, 0x69, 0x6c, 0x20, 0x6d, 0x69, 0x73, 0x6d, 0x61, 0x74, 0x63, 0x68}, 31)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3695, _eri_order_3698, _eri_order_3699));
        (_eri_order_3700 = (v_context), _eri_order_3706 = ((_eri_order_3701 = (v_context), _eri_order_3702 = ((v_routine)->f_blocks), _eri_order_3705 = ((_eri_order_3703 = (v_offset), _eri_order_3704 = (4), eri_iadd(_eri_order_3703, _eri_order_3704))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3701, _eri_order_3702, _eri_order_3705))), _eri_order_3707 = (true), _eri_order_3708 = (v_position), fn_compiler_u002e_u1_verify_u002e_instruction(_eri_order_3700, _eri_order_3706, _eri_order_3707, _eri_order_3708));
        (v_context)->f_block = (_eri_order_3709 = ((v_context)->f_block), _eri_order_3710 = (1), eri_iadd(_eri_order_3709, _eri_order_3710));
    }
    (v_context)->f_block = 0;
    (v_context)->f_instruction = 0;
    v_item = 1;
    while ((_eri_order_3711 = (v_item), _eri_order_3714 = ((_eri_order_3712 = (((v_routine)->f_instructions)->f_length), _eri_order_3713 = (10), eri_idiv(_eri_order_3712, _eri_order_3713))), (_eri_order_3711 <= _eri_order_3714))) {
        (_eri_order_3715 = (v_context), _eri_order_3721 = ((_eri_order_3719 = ((_eri_order_3716 = (v_context), _eri_order_3717 = ((v_context)->f_positions), _eri_order_3718 = (v_item), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_3716, _eri_order_3717, _eri_order_3718))), _eri_order_3720 = (0), (_eri_order_3719 != _eri_order_3720))), _eri_order_3722 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x70, 0x68, 0x61, 0x6e, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e}, 18)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3715, _eri_order_3721, _eri_order_3722));
        v_item = (_eri_order_3723 = (v_item), _eri_order_3724 = (1), eri_iadd(_eri_order_3723, _eri_order_3724));
    }
    v_item = 1;
    while ((_eri_order_3725 = (v_item), _eri_order_3728 = ((_eri_order_3726 = (((v_routine)->f_values)->f_length), _eri_order_3727 = (4), eri_idiv(_eri_order_3726, _eri_order_3727))), (_eri_order_3725 <= _eri_order_3728))) {
        int64_t v_offset = (_eri_order_3731 = ((_eri_order_3729 = (v_item), _eri_order_3730 = (1), eri_isub(_eri_order_3729, _eri_order_3730))), _eri_order_3732 = (4), eri_imul(_eri_order_3731, _eri_order_3732));
        (_eri_order_3733 = (v_context), _eri_order_3737 = ((_eri_order_3734 = (v_context), _eri_order_3735 = ((v_routine)->f_values), _eri_order_3736 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3734, _eri_order_3735, _eri_order_3736))), fn_compiler_u002e_u1_verify_u002e_typeIndex(_eri_order_3733, _eri_order_3737));
        int64_t v_kind = (_eri_order_3738 = (v_context), _eri_order_3739 = ((v_routine)->f_values), _eri_order_3742 = ((_eri_order_3740 = (v_offset), _eri_order_3741 = (1), eri_iadd(_eri_order_3740, _eri_order_3741))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3738, _eri_order_3739, _eri_order_3742));
        int64_t v_definition = (_eri_order_3743 = (v_context), _eri_order_3744 = ((v_routine)->f_values), _eri_order_3747 = ((_eri_order_3745 = (v_offset), _eri_order_3746 = (2), eri_iadd(_eri_order_3745, _eri_order_3746))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3743, _eri_order_3744, _eri_order_3747));
        int64_t v_ordinal = (_eri_order_3748 = (v_context), _eri_order_3749 = ((v_routine)->f_values), _eri_order_3752 = ((_eri_order_3750 = (v_offset), _eri_order_3751 = (3), eri_iadd(_eri_order_3750, _eri_order_3751))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3748, _eri_order_3749, _eri_order_3752));
        (_eri_order_3753 = (v_context), _eri_order_3756 = ((_eri_order_3754 = (v_ordinal), _eri_order_3755 = (0), (_eri_order_3754 >= _eri_order_3755))), _eri_order_3757 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x6f, 0x72, 0x64, 0x69, 0x6e, 0x61, 0x6c}, 26)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3753, _eri_order_3756, _eri_order_3757));
        int64_t v_first = 0;
        int64_t v_count = 0;
        if ((_eri_order_3758 = (v_kind), _eri_order_3759 = (0), (_eri_order_3758 == _eri_order_3759))) {
            (_eri_order_3760 = (v_context), _eri_order_3767 = (((_eri_order_3761 = (v_definition), _eri_order_3762 = (1), (_eri_order_3761 >= _eri_order_3762)) && (_eri_order_3763 = (v_definition), _eri_order_3766 = ((_eri_order_3764 = (((v_routine)->f_blocks)->f_length), _eri_order_3765 = (5), eri_idiv(_eri_order_3764, _eri_order_3765))), (_eri_order_3763 <= _eri_order_3766)))), _eri_order_3768 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x70, 0x68, 0x61, 0x6e, 0x20, 0x70, 0x61, 0x72, 0x61, 0x6d, 0x65, 0x74, 0x65, 0x72, 0x20, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e}, 27)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3760, _eri_order_3767, _eri_order_3768));
            v_first = (_eri_order_3769 = (v_context), _eri_order_3770 = ((v_routine)->f_blocks), _eri_order_3775 = ((_eri_order_3773 = ((_eri_order_3771 = (v_definition), _eri_order_3772 = (1), eri_isub(_eri_order_3771, _eri_order_3772))), _eri_order_3774 = (5), eri_imul(_eri_order_3773, _eri_order_3774))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3769, _eri_order_3770, _eri_order_3775));
            v_count = (_eri_order_3776 = (v_context), _eri_order_3777 = ((v_routine)->f_blocks), _eri_order_3784 = ((_eri_order_3782 = ((_eri_order_3780 = ((_eri_order_3778 = (v_definition), _eri_order_3779 = (1), eri_isub(_eri_order_3778, _eri_order_3779))), _eri_order_3781 = (5), eri_imul(_eri_order_3780, _eri_order_3781))), _eri_order_3783 = (1), eri_iadd(_eri_order_3782, _eri_order_3783))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3776, _eri_order_3777, _eri_order_3784));
        } else {
            (_eri_order_3785 = (v_context), _eri_order_3794 = ((((_eri_order_3786 = (v_kind), _eri_order_3787 = (1), (_eri_order_3786 == _eri_order_3787)) && (_eri_order_3788 = (v_definition), _eri_order_3789 = (1), (_eri_order_3788 >= _eri_order_3789))) && (_eri_order_3790 = (v_definition), _eri_order_3793 = ((_eri_order_3791 = (((v_routine)->f_instructions)->f_length), _eri_order_3792 = (10), eri_idiv(_eri_order_3791, _eri_order_3792))), (_eri_order_3790 <= _eri_order_3793)))), _eri_order_3795 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x70, 0x68, 0x61, 0x6e, 0x20, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e}, 29)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3785, _eri_order_3794, _eri_order_3795));
            v_first = (_eri_order_3796 = (v_context), _eri_order_3797 = ((v_routine)->f_instructions), _eri_order_3804 = ((_eri_order_3802 = ((_eri_order_3800 = ((_eri_order_3798 = (v_definition), _eri_order_3799 = (1), eri_isub(_eri_order_3798, _eri_order_3799))), _eri_order_3801 = (10), eri_imul(_eri_order_3800, _eri_order_3801))), _eri_order_3803 = (4), eri_iadd(_eri_order_3802, _eri_order_3803))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3796, _eri_order_3797, _eri_order_3804));
            v_count = (_eri_order_3805 = (v_context), _eri_order_3806 = ((v_routine)->f_instructions), _eri_order_3813 = ((_eri_order_3811 = ((_eri_order_3809 = ((_eri_order_3807 = (v_definition), _eri_order_3808 = (1), eri_isub(_eri_order_3807, _eri_order_3808))), _eri_order_3810 = (10), eri_imul(_eri_order_3809, _eri_order_3810))), _eri_order_3812 = (5), eri_iadd(_eri_order_3811, _eri_order_3812))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3805, _eri_order_3806, _eri_order_3813));
        }
        (_eri_order_3814 = (v_context), _eri_order_3823 = ((((_eri_order_3815 = (v_ordinal), _eri_order_3816 = (v_count), (_eri_order_3815 < _eri_order_3816)) && (_eri_order_3817 = (v_first), _eri_order_3818 = (v_item), (_eri_order_3817 <= _eri_order_3818))) && (_eri_order_3821 = ((_eri_order_3819 = (v_item), _eri_order_3820 = (v_first), eri_isub(_eri_order_3819, _eri_order_3820))), _eri_order_3822 = (v_ordinal), (_eri_order_3821 == _eri_order_3822)))), _eri_order_3824 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x70, 0x68, 0x61, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x64, 0x75, 0x70, 0x6c, 0x69, 0x63, 0x61, 0x74, 0x65, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x20, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e}, 36)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3814, _eri_order_3823, _eri_order_3824));
        v_item = (_eri_order_3825 = (v_item), _eri_order_3826 = (1), eri_iadd(_eri_order_3825, _eri_order_3826));
    }
    v_item = 1;
    while ((_eri_order_3827 = (v_item), _eri_order_3830 = ((_eri_order_3828 = (((v_routine)->f_edges)->f_length), _eri_order_3829 = (3), eri_idiv(_eri_order_3828, _eri_order_3829))), (_eri_order_3827 <= _eri_order_3830))) {
        (_eri_order_3831 = (v_context), _eri_order_3841 = ((_eri_order_3839 = ((_eri_order_3832 = (v_context), _eri_order_3837 = ((_eri_order_3833 = (((v_context)->f_graph)->f_edgeBase), _eri_order_3836 = ((_eri_order_3834 = (v_item), _eri_order_3835 = (4), eri_imul(_eri_order_3834, _eri_order_3835))), eri_iadd(_eri_order_3833, _eri_order_3836))), _eri_order_3838 = (0), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_3832, _eri_order_3837, _eri_order_3838))), _eri_order_3840 = (0), (_eri_order_3839 != _eri_order_3840))), _eri_order_3842 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x70, 0x68, 0x61, 0x6e, 0x20, 0x43, 0x46, 0x47, 0x20, 0x65, 0x64, 0x67, 0x65}, 15)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3831, _eri_order_3841, _eri_order_3842));
        v_item = (_eri_order_3843 = (v_item), _eri_order_3844 = (1), eri_iadd(_eri_order_3843, _eri_order_3844));
    }
}

static void fn_compiler_u002e_u1_verify_u002e_use(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_value, int64_t v_position) {
    int64_t _eri_order_3845;
    int64_t _eri_order_3846;
    int64_t _eri_order_3847;
    int64_t _eri_order_3848;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3849;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3850;
    int64_t _eri_order_3851;
    int64_t _eri_order_3852;
    int64_t _eri_order_3853;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3854;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3855;
    int64_t _eri_order_3856;
    int64_t _eri_order_3857;
    int64_t _eri_order_3858;
    int64_t _eri_order_3859;
    int64_t _eri_order_3860;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3861;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3862;
    int64_t _eri_order_3863;
    int64_t _eri_order_3864;
    int64_t _eri_order_3865;
    int64_t _eri_order_3866;
    int64_t _eri_order_3867;
    int64_t _eri_order_3868;
    int64_t _eri_order_3869;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3870;
    int64_t _eri_order_3871;
    int64_t _eri_order_3872;
    int64_t _eri_order_3873;
    int64_t _eri_order_3874;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3875;
    int64_t _eri_order_3876;
    int64_t _eri_order_3877;
    bool _eri_order_3878;
    eri_text _eri_order_3879;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3880;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_3881;
    int64_t _eri_order_3882;
    int64_t _eri_order_3883;
    bool _eri_order_3884;
    eri_text _eri_order_3885;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_context)->f_routine;
    int64_t v_offset = (_eri_order_3847 = ((_eri_order_3845 = (v_value), _eri_order_3846 = (1), eri_isub(_eri_order_3845, _eri_order_3846))), _eri_order_3848 = (4), eri_imul(_eri_order_3847, _eri_order_3848));
    int64_t v_kind = (_eri_order_3849 = (v_context), _eri_order_3850 = ((v_routine)->f_values), _eri_order_3853 = ((_eri_order_3851 = (v_offset), _eri_order_3852 = (1), eri_iadd(_eri_order_3851, _eri_order_3852))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3849, _eri_order_3850, _eri_order_3853));
    int64_t v_definition = (_eri_order_3854 = (v_context), _eri_order_3855 = ((v_routine)->f_values), _eri_order_3858 = ((_eri_order_3856 = (v_offset), _eri_order_3857 = (2), eri_iadd(_eri_order_3856, _eri_order_3857))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3854, _eri_order_3855, _eri_order_3858));
    int64_t v_block = v_definition;
    int64_t v_before = 0;
    if ((_eri_order_3859 = (v_kind), _eri_order_3860 = (1), (_eri_order_3859 == _eri_order_3860))) {
        v_block = (_eri_order_3861 = (v_context), _eri_order_3862 = ((v_routine)->f_instructions), _eri_order_3869 = ((_eri_order_3867 = ((_eri_order_3865 = ((_eri_order_3863 = (v_definition), _eri_order_3864 = (1), eri_isub(_eri_order_3863, _eri_order_3864))), _eri_order_3866 = (10), eri_imul(_eri_order_3865, _eri_order_3866))), _eri_order_3868 = (1), eri_iadd(_eri_order_3867, _eri_order_3868))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3861, _eri_order_3862, _eri_order_3869));
        v_before = (_eri_order_3870 = (v_context), _eri_order_3871 = ((v_context)->f_positions), _eri_order_3872 = (v_definition), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_3870, _eri_order_3871, _eri_order_3872));
    }
    if ((_eri_order_3873 = (v_block), _eri_order_3874 = ((v_context)->f_block), (_eri_order_3873 == _eri_order_3874))) {
        (_eri_order_3875 = (v_context), _eri_order_3878 = ((_eri_order_3876 = (v_before), _eri_order_3877 = (v_position), (_eri_order_3876 < _eri_order_3877))), _eri_order_3879 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x73, 0x65, 0x20, 0x62, 0x65, 0x66, 0x6f, 0x72, 0x65, 0x20, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x6f, 0x72, 0x20, 0x6f, 0x77, 0x6e, 0x2d, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x20, 0x75, 0x73, 0x65}, 39)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3875, _eri_order_3878, _eri_order_3879));
    } else {
        (_eri_order_3880 = (v_context), _eri_order_3884 = ((_eri_order_3881 = ((v_context)->f_graph), _eri_order_3882 = (v_block), _eri_order_3883 = ((v_context)->f_block), fn_compiler_u002e_u1_dominance_u002e_dominates(_eri_order_3881, _eri_order_3882, _eri_order_3883))), _eri_order_3885 = (eri_text_from_bytes((const unsigned char[]){0x6e, 0x6f, 0x6e, 0x2d, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x74, 0x69, 0x6e, 0x67, 0x20, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x20, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e}, 31)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3880, _eri_order_3884, _eri_order_3885));
    }
}

static void fn_compiler_u002e_u1_verify_u002e_ssaInstruction(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context, int64_t v_index) {
    int64_t _eri_order_3886;
    int64_t _eri_order_3887;
    int64_t _eri_order_3888;
    int64_t _eri_order_3889;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3890;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3891;
    int64_t _eri_order_3892;
    int64_t _eri_order_3893;
    int64_t _eri_order_3894;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3895;
    int64_t _eri_order_3896;
    int64_t _eri_order_3897;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3898;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3899;
    int64_t _eri_order_3900;
    int64_t _eri_order_3901;
    int64_t _eri_order_3902;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3903;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3904;
    int64_t _eri_order_3905;
    int64_t _eri_order_3906;
    int64_t _eri_order_3907;
    int64_t _eri_order_3908;
    int64_t _eri_order_3909;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3910;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3911;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3912;
    int64_t _eri_order_3913;
    int64_t _eri_order_3914;
    int64_t _eri_order_3915;
    int64_t _eri_order_3916;
    int64_t _eri_order_3917;
    int64_t _eri_order_3918;
    int64_t _eri_order_3919;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3920;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3921;
    int64_t _eri_order_3922;
    int64_t _eri_order_3923;
    int64_t _eri_order_3924;
    int64_t _eri_order_3925;
    int64_t _eri_order_3926;
    int64_t _eri_order_3927;
    int64_t _eri_order_3928;
    int64_t _eri_order_3929;
    int64_t _eri_order_3930;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3931;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3932;
    int64_t _eri_order_3933;
    int64_t _eri_order_3934;
    int64_t _eri_order_3935;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3936;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3937;
    int64_t _eri_order_3938;
    int64_t _eri_order_3939;
    int64_t _eri_order_3940;
    int64_t _eri_order_3941;
    int64_t _eri_order_3942;
    int64_t _eri_order_3943;
    int64_t _eri_order_3944;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3945;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3946;
    int64_t _eri_order_3947;
    int64_t _eri_order_3948;
    int64_t _eri_order_3949;
    int64_t _eri_order_3950;
    int64_t _eri_order_3951;
    int64_t _eri_order_3952;
    int64_t _eri_order_3953;
    int64_t _eri_order_3954;
    int64_t _eri_order_3955;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3956;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3957;
    int64_t _eri_order_3958;
    int64_t _eri_order_3959;
    int64_t _eri_order_3960;
    int64_t _eri_order_3961;
    bool _eri_order_3962;
    eri_text _eri_order_3963;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3964;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_3965;
    int64_t _eri_order_3966;
    int64_t _eri_order_3967;
    bool _eri_order_3968;
    eri_text _eri_order_3969;
    int64_t _eri_order_3970;
    int64_t _eri_order_3971;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3972;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3973;
    int64_t _eri_order_3974;
    int64_t _eri_order_3975;
    int64_t _eri_order_3976;
    int64_t _eri_order_3977;
    int64_t _eri_order_3978;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3979;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3980;
    int64_t _eri_order_3981;
    int64_t _eri_order_3982;
    int64_t _eri_order_3983;
    int64_t _eri_order_3984;
    int64_t _eri_order_3985;
    int64_t _eri_order_3986;
    int64_t _eri_order_3987;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3988;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_3989;
    int64_t _eri_order_3990;
    int64_t _eri_order_3991;
    int64_t _eri_order_3992;
    int64_t _eri_order_3993;
    int64_t _eri_order_3994;
    int64_t _eri_order_3995;
    int64_t _eri_order_3996;
    int64_t _eri_order_3997;
    int64_t _eri_order_3998;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_3999;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_4000;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4001;
    int64_t _eri_order_4002;
    int64_t _eri_order_4003;
    int64_t _eri_order_4004;
    int64_t _eri_order_4005;
    int64_t _eri_order_4006;
    int64_t _eri_order_4007;
    int64_t _eri_order_4008;
    int64_t _eri_order_4009;
    int64_t _eri_order_4010;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_context)->f_routine;
    (v_context)->f_instruction = v_index;
    int64_t v_offset = (_eri_order_3888 = ((_eri_order_3886 = (v_index), _eri_order_3887 = (1), eri_isub(_eri_order_3886, _eri_order_3887))), _eri_order_3889 = (10), eri_imul(_eri_order_3888, _eri_order_3889));
    (v_context)->f_location = (_eri_order_3890 = (v_context), _eri_order_3891 = ((v_routine)->f_instructions), _eri_order_3894 = ((_eri_order_3892 = (v_offset), _eri_order_3893 = (6), eri_iadd(_eri_order_3892, _eri_order_3893))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3890, _eri_order_3891, _eri_order_3894));
    int64_t v_position = (_eri_order_3895 = (v_context), _eri_order_3896 = ((v_context)->f_positions), _eri_order_3897 = (v_index), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_3895, _eri_order_3896, _eri_order_3897));
    int64_t v_first = (_eri_order_3898 = (v_context), _eri_order_3899 = ((v_routine)->f_instructions), _eri_order_3902 = ((_eri_order_3900 = (v_offset), _eri_order_3901 = (2), eri_iadd(_eri_order_3900, _eri_order_3901))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3898, _eri_order_3899, _eri_order_3902));
    int64_t v_count = (_eri_order_3903 = (v_context), _eri_order_3904 = ((v_routine)->f_instructions), _eri_order_3907 = ((_eri_order_3905 = (v_offset), _eri_order_3906 = (3), eri_iadd(_eri_order_3905, _eri_order_3906))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3903, _eri_order_3904, _eri_order_3907));
    int64_t v_item = 0;
    while ((_eri_order_3908 = (v_item), _eri_order_3909 = (v_count), (_eri_order_3908 < _eri_order_3909))) {
        (_eri_order_3910 = (v_context), _eri_order_3916 = ((_eri_order_3911 = (v_context), _eri_order_3912 = ((v_routine)->f_operands), _eri_order_3915 = ((_eri_order_3913 = (v_first), _eri_order_3914 = (v_item), eri_iadd(_eri_order_3913, _eri_order_3914))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3911, _eri_order_3912, _eri_order_3915))), _eri_order_3917 = (v_position), fn_compiler_u002e_u1_verify_u002e_use(_eri_order_3910, _eri_order_3916, _eri_order_3917));
        v_item = (_eri_order_3918 = (v_item), _eri_order_3919 = (1), eri_iadd(_eri_order_3918, _eri_order_3919));
    }
    int64_t v_op = (_eri_order_3920 = (v_context), _eri_order_3921 = ((v_routine)->f_instructions), _eri_order_3922 = (v_offset), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3920, _eri_order_3921, _eri_order_3922));
    int64_t v_number = 0;
    if ((_eri_order_3923 = (v_op), _eri_order_3924 = (6), (_eri_order_3923 == _eri_order_3924))) {
        v_number = 1;
    }
    if ((_eri_order_3925 = (v_op), _eri_order_3926 = (7), (_eri_order_3925 == _eri_order_3926))) {
        v_number = 2;
    }
    if (((_eri_order_3927 = (v_op), _eri_order_3928 = (11), (_eri_order_3927 == _eri_order_3928)) || (_eri_order_3929 = (v_op), _eri_order_3930 = (12), (_eri_order_3929 == _eri_order_3930)))) {
        int64_t v_cell = (_eri_order_3931 = (v_context), _eri_order_3932 = ((v_routine)->f_instructions), _eri_order_3935 = ((_eri_order_3933 = (v_offset), _eri_order_3934 = (7), eri_iadd(_eri_order_3933, _eri_order_3934))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3931, _eri_order_3932, _eri_order_3935));
        int64_t v_initializer = (_eri_order_3936 = (v_context), _eri_order_3937 = ((v_routine)->f_cells), _eri_order_3944 = ((_eri_order_3942 = ((_eri_order_3940 = ((_eri_order_3938 = (v_cell), _eri_order_3939 = (1), eri_isub(_eri_order_3938, _eri_order_3939))), _eri_order_3941 = (2), eri_imul(_eri_order_3940, _eri_order_3941))), _eri_order_3943 = (1), eri_iadd(_eri_order_3942, _eri_order_3943))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3936, _eri_order_3937, _eri_order_3944));
        int64_t v_initBlock = (_eri_order_3945 = (v_context), _eri_order_3946 = ((v_routine)->f_instructions), _eri_order_3953 = ((_eri_order_3951 = ((_eri_order_3949 = ((_eri_order_3947 = (v_initializer), _eri_order_3948 = (1), eri_isub(_eri_order_3947, _eri_order_3948))), _eri_order_3950 = (10), eri_imul(_eri_order_3949, _eri_order_3950))), _eri_order_3952 = (1), eri_iadd(_eri_order_3951, _eri_order_3952))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3945, _eri_order_3946, _eri_order_3953));
        if ((_eri_order_3954 = (v_initBlock), _eri_order_3955 = ((v_context)->f_block), (_eri_order_3954 == _eri_order_3955))) {
            (_eri_order_3956 = (v_context), _eri_order_3962 = ((_eri_order_3960 = ((_eri_order_3957 = (v_context), _eri_order_3958 = ((v_context)->f_positions), _eri_order_3959 = (v_initializer), fn_compiler_u002e_u1_verify_u002e_scratch(_eri_order_3957, _eri_order_3958, _eri_order_3959))), _eri_order_3961 = (v_position), (_eri_order_3960 < _eri_order_3961))), _eri_order_3963 = (eri_text_from_bytes((const unsigned char[]){0x63, 0x65, 0x6c, 0x6c, 0x20, 0x61, 0x63, 0x63, 0x65, 0x73, 0x73, 0x20, 0x70, 0x72, 0x65, 0x63, 0x65, 0x64, 0x65, 0x73, 0x20, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x61, 0x6c, 0x69, 0x7a, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 35)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3956, _eri_order_3962, _eri_order_3963));
        } else {
            (_eri_order_3964 = (v_context), _eri_order_3968 = ((_eri_order_3965 = ((v_context)->f_graph), _eri_order_3966 = (v_initBlock), _eri_order_3967 = ((v_context)->f_block), fn_compiler_u002e_u1_dominance_u002e_dominates(_eri_order_3965, _eri_order_3966, _eri_order_3967))), _eri_order_3969 = (eri_text_from_bytes((const unsigned char[]){0x63, 0x65, 0x6c, 0x6c, 0x20, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x61, 0x6c, 0x69, 0x7a, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x64, 0x6f, 0x65, 0x73, 0x20, 0x6e, 0x6f, 0x74, 0x20, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x74, 0x65, 0x20, 0x61, 0x63, 0x63, 0x65, 0x73, 0x73}, 44)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_3964, _eri_order_3968, _eri_order_3969));
        }
    }
    v_item = 0;
    while ((_eri_order_3970 = (v_item), _eri_order_3971 = (v_number), (_eri_order_3970 < _eri_order_3971))) {
        int64_t v_edge = (_eri_order_3972 = (v_context), _eri_order_3973 = ((v_routine)->f_instructions), _eri_order_3978 = ((_eri_order_3976 = ((_eri_order_3974 = (v_offset), _eri_order_3975 = (7), eri_iadd(_eri_order_3974, _eri_order_3975))), _eri_order_3977 = (v_item), eri_iadd(_eri_order_3976, _eri_order_3977))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3972, _eri_order_3973, _eri_order_3978));
        v_first = (_eri_order_3979 = (v_context), _eri_order_3980 = ((v_routine)->f_edges), _eri_order_3987 = ((_eri_order_3985 = ((_eri_order_3983 = ((_eri_order_3981 = (v_edge), _eri_order_3982 = (1), eri_isub(_eri_order_3981, _eri_order_3982))), _eri_order_3984 = (3), eri_imul(_eri_order_3983, _eri_order_3984))), _eri_order_3986 = (1), eri_iadd(_eri_order_3985, _eri_order_3986))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3979, _eri_order_3980, _eri_order_3987));
        v_count = (_eri_order_3988 = (v_context), _eri_order_3989 = ((v_routine)->f_edges), _eri_order_3996 = ((_eri_order_3994 = ((_eri_order_3992 = ((_eri_order_3990 = (v_edge), _eri_order_3991 = (1), eri_isub(_eri_order_3990, _eri_order_3991))), _eri_order_3993 = (3), eri_imul(_eri_order_3992, _eri_order_3993))), _eri_order_3995 = (2), eri_iadd(_eri_order_3994, _eri_order_3995))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_3988, _eri_order_3989, _eri_order_3996));
        int64_t v_argument = 0;
        while ((_eri_order_3997 = (v_argument), _eri_order_3998 = (v_count), (_eri_order_3997 < _eri_order_3998))) {
            (_eri_order_3999 = (v_context), _eri_order_4005 = ((_eri_order_4000 = (v_context), _eri_order_4001 = ((v_routine)->f_arguments), _eri_order_4004 = ((_eri_order_4002 = (v_first), _eri_order_4003 = (v_argument), eri_iadd(_eri_order_4002, _eri_order_4003))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_4000, _eri_order_4001, _eri_order_4004))), _eri_order_4006 = (v_position), fn_compiler_u002e_u1_verify_u002e_use(_eri_order_3999, _eri_order_4005, _eri_order_4006));
            v_argument = (_eri_order_4007 = (v_argument), _eri_order_4008 = (1), eri_iadd(_eri_order_4007, _eri_order_4008));
        }
        v_item = (_eri_order_4009 = (v_item), _eri_order_4010 = (1), eri_iadd(_eri_order_4009, _eri_order_4010));
    }
}

static void fn_compiler_u002e_u1_verify_u002e_reachableSSA(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context) {
    int64_t _eri_order_4011;
    int64_t _eri_order_4012;
    int64_t _eri_order_4013;
    int64_t _eri_order_4014;
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_4015;
    int64_t _eri_order_4016;
    int64_t _eri_order_4017;
    int64_t _eri_order_4018;
    int64_t _eri_order_4019;
    int64_t _eri_order_4020;
    int64_t _eri_order_4021;
    int64_t _eri_order_4022;
    int64_t _eri_order_4023;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_4024;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4025;
    int64_t _eri_order_4026;
    int64_t _eri_order_4027;
    int64_t _eri_order_4028;
    int64_t _eri_order_4029;
    int64_t _eri_order_4030;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_4031;
    int64_t _eri_order_4032;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_4033;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4034;
    int64_t _eri_order_4035;
    int64_t _eri_order_4036;
    int64_t _eri_order_4037;
    int64_t _eri_order_4038;
    int64_t _eri_order_4039;
    int64_t _eri_order_4040;
    int64_t _eri_order_4041;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_4042;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_4043;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4044;
    int64_t _eri_order_4045;
    int64_t _eri_order_4046;
    int64_t _eri_order_4047;
    int64_t _eri_order_4048;
    int64_t _eri_order_4049;
    int64_t _eri_order_4050;
    (v_context)->f_stage = 4;
    (v_context)->f_block = 0;
    (v_context)->f_instruction = 0;
    (v_context)->f_location = 0;
    fn_compiler_u002e_u1_dominance_u002e_compute((v_context)->f_graph);
    (v_context)->f_block = 1;
    while ((_eri_order_4011 = ((v_context)->f_block), _eri_order_4014 = ((_eri_order_4012 = ((((v_context)->f_routine)->f_blocks)->f_length), _eri_order_4013 = (5), eri_idiv(_eri_order_4012, _eri_order_4013))), (_eri_order_4011 <= _eri_order_4014))) {
        if ((_eri_order_4018 = ((_eri_order_4015 = ((v_context)->f_graph), _eri_order_4016 = ((v_context)->f_block), _eri_order_4017 = (2), fn_compiler_u002e_u1_dominance_u002e_get(_eri_order_4015, _eri_order_4016, _eri_order_4017))), _eri_order_4019 = (0), (_eri_order_4018 != _eri_order_4019))) {
            int64_t v_offset = (_eri_order_4022 = ((_eri_order_4020 = ((v_context)->f_block), _eri_order_4021 = (1), eri_isub(_eri_order_4020, _eri_order_4021))), _eri_order_4023 = (5), eri_imul(_eri_order_4022, _eri_order_4023));
            int64_t v_current = (_eri_order_4024 = (v_context), _eri_order_4025 = (((v_context)->f_routine)->f_blocks), _eri_order_4028 = ((_eri_order_4026 = (v_offset), _eri_order_4027 = (2), eri_iadd(_eri_order_4026, _eri_order_4027))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_4024, _eri_order_4025, _eri_order_4028));
            while ((_eri_order_4029 = (v_current), _eri_order_4030 = (0), (_eri_order_4029 != _eri_order_4030))) {
                (_eri_order_4031 = (v_context), _eri_order_4032 = (v_current), fn_compiler_u002e_u1_verify_u002e_ssaInstruction(_eri_order_4031, _eri_order_4032));
                v_current = (_eri_order_4033 = (v_context), _eri_order_4034 = (((v_context)->f_routine)->f_instructions), _eri_order_4041 = ((_eri_order_4039 = ((_eri_order_4037 = ((_eri_order_4035 = (v_current), _eri_order_4036 = (1), eri_isub(_eri_order_4035, _eri_order_4036))), _eri_order_4038 = (10), eri_imul(_eri_order_4037, _eri_order_4038))), _eri_order_4040 = (9), eri_iadd(_eri_order_4039, _eri_order_4040))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_4033, _eri_order_4034, _eri_order_4041));
            }
            (_eri_order_4042 = (v_context), _eri_order_4048 = ((_eri_order_4043 = (v_context), _eri_order_4044 = (((v_context)->f_routine)->f_blocks), _eri_order_4047 = ((_eri_order_4045 = (v_offset), _eri_order_4046 = (4), eri_iadd(_eri_order_4045, _eri_order_4046))), fn_compiler_u002e_u1_verify_u002e_read(_eri_order_4043, _eri_order_4044, _eri_order_4047))), fn_compiler_u002e_u1_verify_u002e_ssaInstruction(_eri_order_4042, _eri_order_4048));
        }
        (v_context)->f_location = 0;
        (v_context)->f_block = (_eri_order_4049 = ((v_context)->f_block), _eri_order_4050 = (1), eri_iadd(_eri_order_4049, _eri_order_4050));
    }
}

static eri_struct_compiler_u002e_u1_verify_u002e_Report fn_compiler_u002e_u1_verify_u002e_inspect(eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context) {
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * _eri_order_4051;
    int64_t _eri_order_4052;
    int64_t _eri_order_4053;
    int64_t _eri_order_4054;
    int64_t _eri_order_4055;
    int64_t _eri_order_4056;
    int64_t _eri_order_4057;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_4058;
    int64_t _eri_order_4059;
    int64_t _eri_order_4060;
    bool _eri_order_4061;
    eri_text _eri_order_4062;
    fn_compiler_u002e_u1_verify_u002e_bounds(v_context);
    (_eri_order_4051 = ((v_context)->f_graph), _eri_order_4054 = ((_eri_order_4052 = ((((v_context)->f_routine)->f_blocks)->f_length), _eri_order_4053 = (5), eri_idiv(_eri_order_4052, _eri_order_4053))), _eri_order_4057 = ((_eri_order_4055 = ((((v_context)->f_routine)->f_edges)->f_length), _eri_order_4056 = (3), eri_idiv(_eri_order_4055, _eri_order_4056))), fn_compiler_u002e_u1_dominance_u002e_prepare(_eri_order_4051, _eri_order_4054, _eri_order_4057));
    fn_compiler_u002e_u1_verify_u002e_signatures(v_context);
    fn_compiler_u002e_u1_verify_u002e_sources(v_context);
    fn_compiler_u002e_u1_verify_u002e_structure(v_context);
    fn_compiler_u002e_u1_verify_u002e_locations(v_context);
    fn_compiler_u002e_u1_verify_u002e_reachableSSA(v_context);
    if ((!(v_context)->f_construction)) {
        (v_context)->f_stage = 5;
        (v_context)->f_block = 0;
        (v_context)->f_instruction = 0;
        (v_context)->f_location = 0;
        (_eri_order_4058 = (v_context), _eri_order_4061 = ((_eri_order_4059 = ((((v_context)->f_routine)->f_cells)->f_length), _eri_order_4060 = (0), (_eri_order_4059 == _eri_order_4060))), _eri_order_4062 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x70, 0x72, 0x6f, 0x6d, 0x6f, 0x74, 0x65, 0x64, 0x20, 0x63, 0x65, 0x6c, 0x6c, 0x73, 0x20, 0x69, 0x6e, 0x20, 0x63, 0x61, 0x6e, 0x6f, 0x6e, 0x69, 0x63, 0x61, 0x6c, 0x20, 0x55, 0x31}, 32)), fn_compiler_u002e_u1_verify_u002e_require(_eri_order_4058, _eri_order_4061, _eri_order_4062));
    }
    return (eri_struct_compiler_u002e_u1_verify_u002e_Report){.f_reachableBlocks = ((v_context)->f_graph)->f_reachable, .f_structuralVisits = (v_context)->f_visits, .f_dominanceVisits = ((v_context)->f_graph)->f_visits, .f_work = ((v_context)->f_phase)->f_used, .f_revision = ((v_context)->f_routine)->f_revision};
}

static eri_struct_compiler_u002e_u1_verify_u002e_Report fn_compiler_u002e_u1_verify_u002e_verifyMode(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, bool v_construction) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_4063;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_4064;
    int64_t _eri_order_4065;
    int64_t _eri_order_4066;
    int64_t _eri_order_4067;
    int64_t _eri_order_4068;
    int64_t _eri_order_4069;
    int64_t _eri_order_4070;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_4071;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4072;
    eri_text _eri_order_4074;
    eri_text _eri_order_4075;
    eri_struct_compiler_u002e_u1_verify_u002e_Context * _eri_order_4076;
    eri_text _eri_order_4077;
    fn_compiler_u002e_u1_budget_u002e_poll((v_routine)->f_owner);
    if (((((_eri_order_4063 = ((v_phase)->f_owner), _eri_order_4064 = ((v_routine)->f_owner), (!(_eri_order_4063 == _eri_order_4064))) || (_eri_order_4065 = ((v_phase)->f_used), _eri_order_4066 = (0), (_eri_order_4065 != _eri_order_4066))) || (_eri_order_4067 = ((v_phase)->f_prepaid), _eri_order_4068 = (0), (_eri_order_4067 != _eri_order_4068))) || (_eri_order_4069 = ((v_phase)->f_state), _eri_order_4070 = (0), (_eri_order_4069 != _eri_order_4070)))) {
        fn_compiler_u002e_u1_budget_u002e_reject(eri_text_from_bytes((const unsigned char[]){0x76, 0x65, 0x72, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x72, 0x65, 0x71, 0x75, 0x69, 0x72, 0x65, 0x73, 0x20, 0x61, 0x20, 0x66, 0x72, 0x65, 0x73, 0x68, 0x20, 0x66, 0x75, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x70, 0x68, 0x61, 0x73, 0x65}, 44));
    }
    eri_struct_compiler_u002e_u1_dominance_u002e_Graph * v_graph = (_eri_order_4071 = ((v_routine)->f_owner), _eri_order_4072 = (v_phase), fn_compiler_u002e_u1_dominance_u002e_create(_eri_order_4071, _eri_order_4072));
    eri_struct_compiler_u002e_u1_verify_u002e_Context * v_context = eri_identity_compiler_u002e_u1_verify_u002e_Context_new((eri_struct_compiler_u002e_u1_verify_u002e_Context){.f_routine = v_routine, .f_phase = v_phase, .f_graph = v_graph, .f_stage = 0, .f_block = 0, .f_instruction = 0, .f_location = 0, .f_visits = 0, .f_scanLimit = 0, .f_positions = 0, .f_buckets = 0, .f_construction = v_construction});
    eri_struct_compiler_u002e_u1_verify_u002e_Report v_report;
    eri_handler_frame _eri_h_4073; _eri_h_4073.prev=eri_handler_top; eri_handler_top=&_eri_h_4073;
    if (setjmp(_eri_h_4073.env)==0) {
        v_report = fn_compiler_u002e_u1_verify_u002e_inspect(v_context);
        eri_handler_top = _eri_h_4073.prev;
    } else {
        eri_handler_top = _eri_h_4073.prev;
        eri_failure_value _eri_failure_4073 = eri_failure;
        if (strcmp(_eri_failure_4073.type, "compiler.u1_verify.InvalidIR") == 0) {
            eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR v_error = *(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR*)_eri_failure_4073.payload;
            fn_compiler_u002e_u1_dominance_u002e_close(v_graph);
            fn_compiler_u002e_u1_budget_u002e_finishPhase(v_phase);
            eri_fail_compiler_u002e_u1_verify_u002e_InvalidIR(v_error);
            eri_fault("value error handler completed without terminating");
        }
        else if (strcmp(_eri_failure_4073.type, "compiler.u1_budget.LimitError") == 0) {
            eri_struct_compiler_u002e_u1_budget_u002e_LimitError v_error = *(eri_struct_compiler_u002e_u1_budget_u002e_LimitError*)_eri_failure_4073.payload;
            fn_compiler_u002e_u1_dominance_u002e_close(v_graph);
            fn_compiler_u002e_u1_budget_u002e_finishPhase(v_phase);
            if ((_eri_order_4074 = ((v_error).f_category), _eri_order_4075 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x2d, 0x73, 0x74, 0x61, 0x74, 0x65}, 13)), eri_text_eq(_eri_order_4074, _eri_order_4075))) {
                (_eri_order_4076 = (v_context), _eri_order_4077 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x61, 0x6c, 0x66, 0x6f, 0x72, 0x6d, 0x65, 0x64, 0x20, 0x74, 0x61, 0x62, 0x6c, 0x65, 0x20, 0x62, 0x61, 0x63, 0x6b, 0x69, 0x6e, 0x67, 0x20, 0x6f, 0x72, 0x20, 0x63, 0x6f, 0x6e, 0x74, 0x65, 0x78, 0x74}, 34)), fn_compiler_u002e_u1_verify_u002e_invalid(_eri_order_4076, _eri_order_4077));
            }
            eri_fail_compiler_u002e_u1_budget_u002e_LimitError(v_error);
            eri_fault("value error handler completed without terminating");
        }
        else { eri_propagate_saved(_eri_failure_4073); }
    }
    fn_compiler_u002e_u1_dominance_u002e_close(v_graph);
    fn_compiler_u002e_u1_budget_u002e_finishPhase(v_phase);
    return v_report;
}

static eri_struct_compiler_u002e_u1_verify_u002e_Report fn_compiler_u002e_u1_verify_u002e_verify(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4078;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4079;
    bool _eri_order_4080;
    return (_eri_order_4078 = (v_routine), _eri_order_4079 = (v_phase), _eri_order_4080 = (false), fn_compiler_u002e_u1_verify_u002e_verifyMode(_eri_order_4078, _eri_order_4079, _eri_order_4080));
}

static eri_struct_compiler_u002e_u1_verify_u002e_Report fn_compiler_u002e_u1_verify_u002e_construction(eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4081;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4082;
    bool _eri_order_4083;
    return (_eri_order_4081 = (v_routine), _eri_order_4082 = (v_phase), _eri_order_4083 = (true), fn_compiler_u002e_u1_verify_u002e_verifyMode(_eri_order_4081, _eri_order_4082, _eri_order_4083));
}

static void fn_verifier_u002d_debug_u002e_check(bool v_condition, eri_text v_message) {
    if ((!v_condition)) {
        eri_fail_verifier_u002d_debug_u002e_ProbeError((eri_struct_verifier_u002d_debug_u002e_ProbeError){.f_message = v_message});
    }
}

static eri_struct_verifier_u002d_debug_u002e_Harness * fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(eri_list_compiler_u002e_u1_meta_u002e_TypeId v_parameters, eri_list_compiler_u002e_u1_meta_u002e_TypeId v_results) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_4084;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4085;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_4086;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4087;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4088;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4089;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_4090;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4091;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4092;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4093;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_4094;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4095;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4096;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4097;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_4098;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4099;
    eri_text _eri_order_4100;
    eri_text _eri_order_4101;
    int64_t _eri_order_4102;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_4103;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4104;
    eri_struct_compiler_u002e_u1_meta_u002e_SourceId _eri_order_4105;
    int64_t _eri_order_4106;
    int64_t _eri_order_4107;
    int64_t _eri_order_4108;
    int64_t _eri_order_4109;
    int64_t _eri_order_4110;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_4111;
    bool _eri_order_4112;
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * _eri_order_4113;
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId _eri_order_4114;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_4115;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4116;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_root = fn_compiler_u002e_u1_budget_u002e_developmentRequest();
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_shared = fn_compiler_u002e_u1_budget_u002e_metadataOwner(v_root);
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase = fn_compiler_u002e_u1_budget_u002e_constructionPhase(v_shared);
    eri_struct_compiler_u002e_u1_meta_u002e_Metadata * v_data = (_eri_order_4084 = (v_shared), _eri_order_4085 = (v_phase), fn_compiler_u002e_u1_meta_u002e_create(_eri_order_4084, _eri_order_4085));
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_signature = (_eri_order_4086 = (v_data), _eri_order_4087 = (v_phase), _eri_order_4088 = (v_parameters), _eri_order_4089 = (v_results), fn_compiler_u002e_u1_meta_u002e_signature_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4086, _eri_order_4087, _eri_order_4088, _eri_order_4089));
    eri_struct_compiler_u002e_u1_meta_u002e_SignatureId v_collision = (_eri_order_4090 = (v_data), _eri_order_4091 = (v_phase), _eri_order_4092 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(2, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_pred(), fn_compiler_u002e_u1_meta_u002e_pred()})), _eri_order_4093 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_meta_u002e_signature_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4090, _eri_order_4091, _eri_order_4092, _eri_order_4093));
    v_collision = (_eri_order_4094 = (v_data), _eri_order_4095 = (v_phase), _eri_order_4096 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(3, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_pred(), fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_f64()})), _eri_order_4097 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_meta_u002e_signature_u0024_identity_u0020_compiler_u002e_u1_meta_u002e_Metadata_u0024_identity_u0020_compiler_u002e_u1_budget_u002e_Phase_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4094, _eri_order_4095, _eri_order_4096, _eri_order_4097));
    eri_struct_compiler_u002e_u1_meta_u002e_SourceId v_source = (_eri_order_4098 = (v_data), _eri_order_4099 = (v_phase), _eri_order_4100 = (eri_text_from_bytes((const unsigned char[]){0x76, 0x65, 0x72, 0x69, 0x66, 0x69, 0x65, 0x72, 0x2d, 0xce, 0xb1}, 11)), _eri_order_4101 = (eri_text_from_bytes((const unsigned char[]){0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66}, 64)), _eri_order_4102 = (32), fn_compiler_u002e_u1_meta_u002e_source(_eri_order_4098, _eri_order_4099, _eri_order_4100, _eri_order_4101, _eri_order_4102));
    eri_struct_compiler_u002e_u1_meta_u002e_LocId v_location = (_eri_order_4103 = (v_data), _eri_order_4104 = (v_phase), _eri_order_4105 = (v_source), _eri_order_4106 = (0), _eri_order_4107 = (8), _eri_order_4108 = (3), _eri_order_4109 = (1), _eri_order_4110 = (4), fn_compiler_u002e_u1_meta_u002e_location(_eri_order_4103, _eri_order_4104, _eri_order_4105, _eri_order_4106, _eri_order_4107, _eri_order_4108, _eri_order_4109, _eri_order_4110));
    fn_compiler_u002e_u1_meta_u002e_freeze(v_data);
    fn_compiler_u002e_u1_budget_u002e_finishPhase(v_phase);
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_owner = (_eri_order_4111 = (v_root), _eri_order_4112 = (false), fn_compiler_u002e_u1_budget_u002e_functionOwner(_eri_order_4111, _eri_order_4112));
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_construct = fn_compiler_u002e_u1_budget_u002e_constructionPhase(v_owner);
    return eri_identity_verifier_u002d_debug_u002e_Harness_new((eri_struct_verifier_u002d_debug_u002e_Harness){.f_root = v_root, .f_shared = v_shared, .f_data = v_data, .f_owner = v_owner, .f_construct = v_construct, .f_routine = (_eri_order_4113 = (v_data), _eri_order_4114 = (v_signature), _eri_order_4115 = (v_owner), _eri_order_4116 = (v_construct), fn_compiler_u002e_u1_builder_u002e_create(_eri_order_4113, _eri_order_4114, _eri_order_4115, _eri_order_4116)), .f_location = v_location});
}

static void fn_verifier_u002d_debug_u002e_close(eri_struct_verifier_u002d_debug_u002e_Harness * v_harness) {
    int64_t _eri_order_4117;
    int64_t _eri_order_4118;
    int64_t _eri_order_4119;
    int64_t _eri_order_4120;
    bool _eri_order_4121;
    eri_text _eri_order_4122;
    fn_compiler_u002e_u1_builder_u002e_close((v_harness)->f_routine);
    fn_compiler_u002e_u1_meta_u002e_close((v_harness)->f_data);
    (_eri_order_4121 = (((_eri_order_4117 = (((v_harness)->f_root)->f_live), _eri_order_4118 = (0), (_eri_order_4117 == _eri_order_4118)) && (_eri_order_4119 = (((v_harness)->f_root)->f_pending), _eri_order_4120 = (0), (_eri_order_4119 == _eri_order_4120)))), _eri_order_4122 = (eri_text_from_bytes((const unsigned char[]){0x77, 0x6f, 0x72, 0x6b, 0x73, 0x70, 0x61, 0x63, 0x65, 0x20, 0x6f, 0x72, 0x20, 0x69, 0x6e, 0x70, 0x75, 0x74, 0x20, 0x63, 0x68, 0x61, 0x72, 0x67, 0x65, 0x20, 0x6c, 0x65, 0x61, 0x6b}, 30)), fn_verifier_u002d_debug_u002e_check(_eri_order_4121, _eri_order_4122));
    fn_compiler_u002e_u1_budget_u002e_close((v_harness)->f_owner);
    fn_compiler_u002e_u1_budget_u002e_close((v_harness)->f_shared);
    fn_compiler_u002e_u1_budget_u002e_close((v_harness)->f_root);
}

static void fn_verifier_u002d_debug_u002e_change(eri_struct_compiler_u002e_u1_words_u002e_Words * v_table, eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase, int64_t v_index, int64_t v_value) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4123;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4124;
    int64_t _eri_order_4125;
    int64_t _eri_order_4126;
    (v_table)->f_frozen = false;
    (_eri_order_4123 = (v_table), _eri_order_4124 = (v_phase), _eri_order_4125 = (v_index), _eri_order_4126 = (v_value), fn_compiler_u002e_u1_words_u002e_set(_eri_order_4123, _eri_order_4124, _eri_order_4125, _eri_order_4126));
    (v_table)->f_frozen = true;
}

static void fn_verifier_u002d_debug_u002e_accepted(eri_struct_verifier_u002d_debug_u002e_Harness * v_harness, int64_t v_reachable, eri_text v_label) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4127;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4128;
    int64_t _eri_order_4129;
    int64_t _eri_order_4130;
    int64_t _eri_order_4131;
    int64_t _eri_order_4132;
    int64_t _eri_order_4133;
    int64_t _eri_order_4134;
    int64_t _eri_order_4135;
    int64_t _eri_order_4136;
    bool _eri_order_4137;
    eri_text _eri_order_4138;
    int64_t _eri_order_4139;
    int64_t _eri_order_4140;
    int64_t _eri_order_4141;
    int64_t _eri_order_4142;
    int64_t _eri_order_4143;
    int64_t _eri_order_4144;
    int64_t _eri_order_4145;
    int64_t _eri_order_4146;
    bool _eri_order_4147;
    eri_text _eri_order_4148;
    eri_text _eri_order_4149;
    eri_text _eri_order_4150;
    int64_t v_live = ((v_harness)->f_owner)->f_live;
    int64_t v_revision = ((v_harness)->f_routine)->f_revision;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase = fn_compiler_u002e_u1_budget_u002e_verificationPhase((v_harness)->f_owner);
    eri_struct_compiler_u002e_u1_verify_u002e_Report v_result = (_eri_order_4127 = ((v_harness)->f_routine), _eri_order_4128 = (v_phase), fn_compiler_u002e_u1_verify_u002e_verify(_eri_order_4127, _eri_order_4128));
    (_eri_order_4137 = (((((_eri_order_4129 = ((v_result).f_reachableBlocks), _eri_order_4130 = (v_reachable), (_eri_order_4129 == _eri_order_4130)) && (_eri_order_4131 = ((v_result).f_revision), _eri_order_4132 = (v_revision), (_eri_order_4131 == _eri_order_4132))) && (_eri_order_4133 = ((v_result).f_structuralVisits), _eri_order_4134 = (0), (_eri_order_4133 > _eri_order_4134))) && (_eri_order_4135 = ((v_result).f_dominanceVisits), _eri_order_4136 = (0), (_eri_order_4135 > _eri_order_4136)))), _eri_order_4138 = (eri_text_from_bytes((const unsigned char[]){0x76, 0x65, 0x72, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x72, 0x65, 0x70, 0x6f, 0x72, 0x74}, 19)), fn_verifier_u002d_debug_u002e_check(_eri_order_4137, _eri_order_4138));
    (_eri_order_4147 = (((((_eri_order_4139 = (((v_harness)->f_owner)->f_live), _eri_order_4140 = (v_live), (_eri_order_4139 == _eri_order_4140)) && (_eri_order_4141 = (((v_harness)->f_owner)->f_pending), _eri_order_4142 = (0), (_eri_order_4141 == _eri_order_4142))) && (_eri_order_4143 = (((v_harness)->f_routine)->f_revision), _eri_order_4144 = (v_revision), (_eri_order_4143 == _eri_order_4144))) && (_eri_order_4145 = ((v_phase)->f_state), _eri_order_4146 = (1), (_eri_order_4145 == _eri_order_4146)))), _eri_order_4148 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x61, 0x64, 0x2d, 0x6f, 0x6e, 0x6c, 0x79, 0x20, 0x76, 0x65, 0x72, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x61, 0x6e, 0x64, 0x20, 0x73, 0x63, 0x72, 0x61, 0x74, 0x63, 0x68, 0x20, 0x72, 0x65, 0x6c, 0x65, 0x61, 0x73, 0x65}, 42)), fn_verifier_u002d_debug_u002e_check(_eri_order_4147, _eri_order_4148));
    eri_out_text((_eri_order_4149 = (v_label), _eri_order_4150 = (eri_text_from_bytes((const unsigned char[]){0x3a, 0x6f, 0x6b}, 3)), eri_text_add(_eri_order_4149, _eri_order_4150)));
}

static void fn_verifier_u002d_debug_u002e_rejected(eri_struct_verifier_u002d_debug_u002e_Harness * v_harness, int64_t v_stage, int64_t v_block, eri_text v_label) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4152;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4153;
    eri_text _eri_order_4154;
    eri_text _eri_order_4155;
    int64_t _eri_order_4156;
    int64_t _eri_order_4157;
    int64_t _eri_order_4158;
    int64_t _eri_order_4159;
    bool _eri_order_4160;
    eri_text _eri_order_4161;
    eri_text _eri_order_4162;
    eri_text _eri_order_4163;
    int64_t _eri_order_4164;
    int64_t _eri_order_4165;
    int64_t _eri_order_4166;
    int64_t _eri_order_4167;
    int64_t _eri_order_4168;
    int64_t _eri_order_4169;
    bool _eri_order_4170;
    eri_text _eri_order_4171;
    eri_text _eri_order_4172;
    eri_text _eri_order_4173;
    eri_text _eri_order_4174;
    eri_text _eri_order_4175;
    int64_t v_live = ((v_harness)->f_owner)->f_live;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase = fn_compiler_u002e_u1_budget_u002e_verificationPhase((v_harness)->f_owner);
    eri_struct_compiler_u002e_u1_verify_u002e_Report v_unexpected;
    eri_handler_frame _eri_h_4151; _eri_h_4151.prev=eri_handler_top; eri_handler_top=&_eri_h_4151;
    if (setjmp(_eri_h_4151.env)==0) {
        v_unexpected = (_eri_order_4152 = ((v_harness)->f_routine), _eri_order_4153 = (v_phase), fn_compiler_u002e_u1_verify_u002e_verify(_eri_order_4152, _eri_order_4153));
        eri_handler_top = _eri_h_4151.prev;
    } else {
        eri_handler_top = _eri_h_4151.prev;
        eri_failure_value _eri_failure_4151 = eri_failure;
        if (strcmp(_eri_failure_4151.type, "compiler.u1_verify.InvalidIR") == 0) {
            eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR v_error = *(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR*)_eri_failure_4151.payload;
            (_eri_order_4160 = ((((_eri_order_4154 = ((v_error).f_category), _eri_order_4155 = (eri_text_from_bytes((const unsigned char[]){0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x2d, 0x69, 0x72}, 10)), eri_text_eq(_eri_order_4154, _eri_order_4155)) && (_eri_order_4156 = ((v_error).f_stage), _eri_order_4157 = (v_stage), (_eri_order_4156 == _eri_order_4157))) && (_eri_order_4158 = ((v_error).f_block), _eri_order_4159 = (v_block), (_eri_order_4158 == _eri_order_4159)))), _eri_order_4163 = ((_eri_order_4161 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x65, 0x74, 0x65, 0x72, 0x6d, 0x69, 0x6e, 0x69, 0x73, 0x74, 0x69, 0x63, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x49, 0x52, 0x20, 0x63, 0x61, 0x74, 0x65, 0x67, 0x6f, 0x72, 0x79, 0x2f, 0x73, 0x74, 0x61, 0x67, 0x65, 0x2f, 0x62, 0x6c, 0x6f, 0x63, 0x6b, 0x3a, 0x20}, 47)), _eri_order_4162 = (v_label), eri_text_add(_eri_order_4161, _eri_order_4162))), fn_verifier_u002d_debug_u002e_check(_eri_order_4160, _eri_order_4163));
            eri_out_text(eri_text_from_bytes((const unsigned char[]){0x63, 0x6c, 0x65, 0x61, 0x6e, 0x75, 0x70, 0x2d, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x73}, 14));
            eri_out_int(((v_harness)->f_owner)->f_live);
            eri_out_int(v_live);
            eri_out_int(((v_harness)->f_owner)->f_pending);
            eri_out_int((v_phase)->f_state);
            (_eri_order_4170 = ((((_eri_order_4164 = (((v_harness)->f_owner)->f_live), _eri_order_4165 = (v_live), (_eri_order_4164 == _eri_order_4165)) && (_eri_order_4166 = (((v_harness)->f_owner)->f_pending), _eri_order_4167 = (0), (_eri_order_4166 == _eri_order_4167))) && (_eri_order_4168 = ((v_phase)->f_state), _eri_order_4169 = (1), (_eri_order_4168 == _eri_order_4169)))), _eri_order_4171 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x6a, 0x65, 0x63, 0x74, 0x65, 0x64, 0x20, 0x77, 0x6f, 0x72, 0x6b, 0x73, 0x70, 0x61, 0x63, 0x65, 0x20, 0x63, 0x6c, 0x65, 0x61, 0x6e, 0x75, 0x70}, 26)), fn_verifier_u002d_debug_u002e_check(_eri_order_4170, _eri_order_4171));
            eri_out_text((_eri_order_4172 = (v_label), _eri_order_4173 = (eri_text_from_bytes((const unsigned char[]){0x3a, 0x6f, 0x6b}, 3)), eri_text_add(_eri_order_4172, _eri_order_4173)));
            return;
            eri_fault("value error handler completed without terminating");
        }
        else if (strcmp(_eri_failure_4151.type, "compiler.u1_budget.LimitError") == 0) {
            eri_struct_compiler_u002e_u1_budget_u002e_LimitError v_error = *(eri_struct_compiler_u002e_u1_budget_u002e_LimitError*)_eri_failure_4151.payload;
            eri_fail_compiler_u002e_u1_budget_u002e_LimitError(v_error);
            eri_fault("value error handler completed without terminating");
        }
        else { eri_propagate_saved(_eri_failure_4151); }
    }
    eri_fail_verifier_u002d_debug_u002e_ProbeError((eri_struct_verifier_u002d_debug_u002e_ProbeError){.f_message = (_eri_order_4174 = (eri_text_from_bytes((const unsigned char[]){0x61, 0x63, 0x63, 0x65, 0x70, 0x74, 0x65, 0x64, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x49, 0x52, 0x3a, 0x20}, 21)), _eri_order_4175 = (v_label), eri_text_add(_eri_order_4174, _eri_order_4175))});
}

static eri_struct_verifier_u002d_debug_u002e_Harness * fn_verifier_u002d_debug_u002e_straight(void) {
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4176;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4177;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4178;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4179;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4180;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4181;
    int64_t _eri_order_4182;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4183;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4184;
    int64_t _eri_order_4185;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4186;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4187;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4188;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4189;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4190;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4191;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4192;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4193;
    int64_t _eri_order_4194;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4195;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4196;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4197;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4198;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4199;
    int64_t _eri_order_4200;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4201;
    int64_t _eri_order_4202;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4203;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4204;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4205;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4206;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4207;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = (_eri_order_4176 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(2, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_pred()})), _eri_order_4177 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4176, _eri_order_4177));
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_harness)->f_routine;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_entry = (_eri_order_4178 = (v_routine), _eri_order_4179 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(2, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_pred()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4178, _eri_order_4179));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_first = (_eri_order_4180 = (v_routine), _eri_order_4181 = (v_entry), _eri_order_4182 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4180, _eri_order_4181, _eri_order_4182));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_one = (_eri_order_4183 = (v_routine), _eri_order_4184 = (v_entry), _eri_order_4185 = (1), _eri_order_4186 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_integer(_eri_order_4183, _eri_order_4184, _eri_order_4185, _eri_order_4186));
    eri_struct_compiler_u002e_u1_builder_u002e_Pair v_sum = (_eri_order_4187 = (v_routine), _eri_order_4188 = (v_entry), _eri_order_4189 = (v_first), _eri_order_4190 = (v_one), _eri_order_4191 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_addOverflow(_eri_order_4187, _eri_order_4188, _eri_order_4189, _eri_order_4190, _eri_order_4191));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_later = (_eri_order_4192 = (v_routine), _eri_order_4193 = (v_entry), _eri_order_4194 = (2), _eri_order_4195 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_integer(_eri_order_4192, _eri_order_4193, _eri_order_4194, _eri_order_4195));
    (_eri_order_4196 = (v_routine), _eri_order_4197 = (v_entry), _eri_order_4201 = ((_eri_order_4198 = (v_routine), _eri_order_4199 = (v_entry), _eri_order_4200 = (1), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4198, _eri_order_4199, _eri_order_4200))), _eri_order_4202 = (1), _eri_order_4203 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_guard(_eri_order_4196, _eri_order_4197, _eri_order_4201, _eri_order_4202, _eri_order_4203));
    (_eri_order_4204 = (v_routine), _eri_order_4205 = (v_entry), _eri_order_4206 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){(v_sum).f_value})), _eri_order_4207 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4204, _eri_order_4205, _eri_order_4206, _eri_order_4207));
    fn_compiler_u002e_u1_builder_u002e_complete(v_routine);
    fn_compiler_u002e_u1_budget_u002e_finishPhase((v_harness)->f_construct);
    return v_harness;
}

static void fn_verifier_u002d_debug_u002e_mutations(void) {
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4208;
    int64_t _eri_order_4209;
    eri_text _eri_order_4210;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4211;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4212;
    int64_t _eri_order_4213;
    int64_t _eri_order_4214;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4215;
    int64_t _eri_order_4216;
    int64_t _eri_order_4217;
    eri_text _eri_order_4218;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4219;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4220;
    int64_t _eri_order_4221;
    int64_t _eri_order_4222;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4223;
    int64_t _eri_order_4224;
    int64_t _eri_order_4225;
    eri_text _eri_order_4226;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4227;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4228;
    int64_t _eri_order_4229;
    int64_t _eri_order_4230;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4231;
    int64_t _eri_order_4232;
    eri_text _eri_order_4233;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4234;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4235;
    int64_t _eri_order_4236;
    int64_t _eri_order_4237;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4238;
    int64_t _eri_order_4239;
    int64_t _eri_order_4240;
    eri_text _eri_order_4241;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4242;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4243;
    int64_t _eri_order_4244;
    int64_t _eri_order_4245;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4246;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4247;
    int64_t _eri_order_4248;
    int64_t _eri_order_4249;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4250;
    int64_t _eri_order_4251;
    int64_t _eri_order_4252;
    eri_text _eri_order_4253;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4254;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4255;
    int64_t _eri_order_4256;
    int64_t _eri_order_4257;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4258;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4259;
    int64_t _eri_order_4260;
    int64_t _eri_order_4261;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4262;
    int64_t _eri_order_4263;
    int64_t _eri_order_4264;
    eri_text _eri_order_4265;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4266;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4267;
    int64_t _eri_order_4268;
    int64_t _eri_order_4269;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4270;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4271;
    int64_t _eri_order_4272;
    int64_t _eri_order_4273;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4274;
    int64_t _eri_order_4275;
    int64_t _eri_order_4276;
    eri_text _eri_order_4277;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4278;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4279;
    int64_t _eri_order_4280;
    int64_t _eri_order_4281;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4282;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4283;
    int64_t _eri_order_4284;
    int64_t _eri_order_4285;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4286;
    int64_t _eri_order_4287;
    int64_t _eri_order_4288;
    eri_text _eri_order_4289;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4290;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4291;
    int64_t _eri_order_4292;
    int64_t _eri_order_4293;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4294;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4295;
    int64_t _eri_order_4296;
    int64_t _eri_order_4297;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4298;
    int64_t _eri_order_4299;
    int64_t _eri_order_4300;
    eri_text _eri_order_4301;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4302;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4303;
    int64_t _eri_order_4304;
    int64_t _eri_order_4305;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4306;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4307;
    int64_t _eri_order_4308;
    int64_t _eri_order_4309;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4310;
    int64_t _eri_order_4311;
    int64_t _eri_order_4312;
    eri_text _eri_order_4313;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4314;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4315;
    int64_t _eri_order_4316;
    int64_t _eri_order_4317;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4318;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4319;
    int64_t _eri_order_4320;
    int64_t _eri_order_4321;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4322;
    int64_t _eri_order_4323;
    int64_t _eri_order_4324;
    eri_text _eri_order_4325;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4326;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4327;
    int64_t _eri_order_4328;
    int64_t _eri_order_4329;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4330;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4331;
    int64_t _eri_order_4332;
    int64_t _eri_order_4333;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4334;
    int64_t _eri_order_4335;
    int64_t _eri_order_4336;
    eri_text _eri_order_4337;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4338;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4339;
    int64_t _eri_order_4340;
    int64_t _eri_order_4341;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4342;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4343;
    int64_t _eri_order_4344;
    int64_t _eri_order_4345;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4346;
    int64_t _eri_order_4347;
    int64_t _eri_order_4348;
    eri_text _eri_order_4349;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4350;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4351;
    int64_t _eri_order_4352;
    int64_t _eri_order_4353;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4354;
    int64_t _eri_order_4355;
    int64_t _eri_order_4356;
    eri_text _eri_order_4357;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_4358;
    bool _eri_order_4359;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4360;
    int64_t _eri_order_4361;
    int64_t _eri_order_4362;
    eri_text _eri_order_4363;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4364;
    int64_t _eri_order_4365;
    int64_t _eri_order_4366;
    eri_text _eri_order_4367;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4368;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4369;
    int64_t _eri_order_4370;
    int64_t _eri_order_4371;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4372;
    int64_t _eri_order_4373;
    int64_t _eri_order_4374;
    eri_text _eri_order_4375;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4376;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4377;
    int64_t _eri_order_4378;
    int64_t _eri_order_4379;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4380;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4381;
    int64_t _eri_order_4382;
    int64_t _eri_order_4383;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4384;
    int64_t _eri_order_4385;
    int64_t _eri_order_4386;
    eri_text _eri_order_4387;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4388;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4389;
    int64_t _eri_order_4390;
    int64_t _eri_order_4391;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4392;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4393;
    int64_t _eri_order_4394;
    int64_t _eri_order_4395;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4396;
    int64_t _eri_order_4397;
    int64_t _eri_order_4398;
    eri_text _eri_order_4399;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4400;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4401;
    int64_t _eri_order_4402;
    int64_t _eri_order_4403;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4404;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4405;
    int64_t _eri_order_4406;
    int64_t _eri_order_4407;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4408;
    int64_t _eri_order_4409;
    int64_t _eri_order_4410;
    eri_text _eri_order_4411;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4412;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4413;
    int64_t _eri_order_4414;
    int64_t _eri_order_4415;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4416;
    int64_t _eri_order_4417;
    eri_text _eri_order_4418;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = fn_verifier_u002d_debug_u002e_straight();
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_harness)->f_routine;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_edit = fn_compiler_u002e_u1_budget_u002e_constructionPhase((v_harness)->f_owner);
    (_eri_order_4208 = (v_harness), _eri_order_4209 = (1), _eri_order_4210 = (eri_text_from_bytes((const unsigned char[]){0x73, 0x74, 0x72, 0x61, 0x69, 0x67, 0x68, 0x74}, 8)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4208, _eri_order_4209, _eri_order_4210));
    (_eri_order_4211 = ((v_routine)->f_operands), _eri_order_4212 = (v_edit), _eri_order_4213 = (0), _eri_order_4214 = (4), fn_verifier_u002d_debug_u002e_change(_eri_order_4211, _eri_order_4212, _eri_order_4213, _eri_order_4214));
    (_eri_order_4215 = (v_harness), _eri_order_4216 = (4), _eri_order_4217 = (1), _eri_order_4218 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x77, 0x6e, 0x2d, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74}, 10)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4215, _eri_order_4216, _eri_order_4217, _eri_order_4218));
    (_eri_order_4219 = ((v_routine)->f_operands), _eri_order_4220 = (v_edit), _eri_order_4221 = (0), _eri_order_4222 = (6), fn_verifier_u002d_debug_u002e_change(_eri_order_4219, _eri_order_4220, _eri_order_4221, _eri_order_4222));
    (_eri_order_4223 = (v_harness), _eri_order_4224 = (4), _eri_order_4225 = (1), _eri_order_4226 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x73, 0x65, 0x2d, 0x62, 0x65, 0x66, 0x6f, 0x72, 0x65, 0x2d, 0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e}, 21)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4223, _eri_order_4224, _eri_order_4225, _eri_order_4226));
    (_eri_order_4227 = ((v_routine)->f_operands), _eri_order_4228 = (v_edit), _eri_order_4229 = (0), _eri_order_4230 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4227, _eri_order_4228, _eri_order_4229, _eri_order_4230));
    (_eri_order_4231 = (v_harness), _eri_order_4232 = (1), _eri_order_4233 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x76, 0x65, 0x72, 0x69, 0x66, 0x79, 0x2d, 0x61, 0x66, 0x74, 0x65, 0x72, 0x2d, 0x72, 0x65, 0x73, 0x74, 0x6f, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 26)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4231, _eri_order_4232, _eri_order_4233));
    (_eri_order_4234 = ((v_routine)->f_values), _eri_order_4235 = (v_edit), _eri_order_4236 = (12), _eri_order_4237 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4234, _eri_order_4235, _eri_order_4236, _eri_order_4237));
    (_eri_order_4238 = (v_harness), _eri_order_4239 = (2), _eri_order_4240 = (1), _eri_order_4241 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x2d, 0x74, 0x79, 0x70, 0x65}, 11)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4238, _eri_order_4239, _eri_order_4240, _eri_order_4241));
    (_eri_order_4242 = ((v_routine)->f_values), _eri_order_4243 = (v_edit), _eri_order_4244 = (12), _eri_order_4245 = (2), fn_verifier_u002d_debug_u002e_change(_eri_order_4242, _eri_order_4243, _eri_order_4244, _eri_order_4245));
    (_eri_order_4246 = ((v_routine)->f_values), _eri_order_4247 = (v_edit), _eri_order_4248 = (14), _eri_order_4249 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4246, _eri_order_4247, _eri_order_4248, _eri_order_4249));
    (_eri_order_4250 = (v_harness), _eri_order_4251 = (2), _eri_order_4252 = (1), _eri_order_4253 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x65, 0x66, 0x69, 0x6e, 0x69, 0x74, 0x69, 0x6f, 0x6e, 0x2d, 0x6f, 0x77, 0x6e, 0x65, 0x72}, 16)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4250, _eri_order_4251, _eri_order_4252, _eri_order_4253));
    (_eri_order_4254 = ((v_routine)->f_values), _eri_order_4255 = (v_edit), _eri_order_4256 = (14), _eri_order_4257 = (2), fn_verifier_u002d_debug_u002e_change(_eri_order_4254, _eri_order_4255, _eri_order_4256, _eri_order_4257));
    (_eri_order_4258 = ((v_routine)->f_instructions), _eri_order_4259 = (v_edit), _eri_order_4260 = (10), _eri_order_4261 = (99), fn_verifier_u002d_debug_u002e_change(_eri_order_4258, _eri_order_4259, _eri_order_4260, _eri_order_4261));
    (_eri_order_4262 = (v_harness), _eri_order_4263 = (2), _eri_order_4264 = (1), _eri_order_4265 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x6b, 0x6e, 0x6f, 0x77, 0x6e, 0x2d, 0x6f, 0x70, 0x65, 0x72, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 17)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4262, _eri_order_4263, _eri_order_4264, _eri_order_4265));
    (_eri_order_4266 = ((v_routine)->f_instructions), _eri_order_4267 = (v_edit), _eri_order_4268 = (10), _eri_order_4269 = (3), fn_verifier_u002d_debug_u002e_change(_eri_order_4266, _eri_order_4267, _eri_order_4268, _eri_order_4269));
    (_eri_order_4270 = ((v_routine)->f_instructions), _eri_order_4271 = (v_edit), _eri_order_4272 = (9), _eri_order_4273 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4270, _eri_order_4271, _eri_order_4272, _eri_order_4273));
    (_eri_order_4274 = (v_harness), _eri_order_4275 = (2), _eri_order_4276 = (1), _eri_order_4277 = (eri_text_from_bytes((const unsigned char[]){0x63, 0x79, 0x63, 0x6c, 0x69, 0x63, 0x2d, 0x6f, 0x72, 0x64, 0x65, 0x72}, 12)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4274, _eri_order_4275, _eri_order_4276, _eri_order_4277));
    (_eri_order_4278 = ((v_routine)->f_instructions), _eri_order_4279 = (v_edit), _eri_order_4280 = (9), _eri_order_4281 = (2), fn_verifier_u002d_debug_u002e_change(_eri_order_4278, _eri_order_4279, _eri_order_4280, _eri_order_4281));
    (_eri_order_4282 = ((v_routine)->f_instructions), _eri_order_4283 = (v_edit), _eri_order_4284 = (19), _eri_order_4285 = (2), fn_verifier_u002d_debug_u002e_change(_eri_order_4282, _eri_order_4283, _eri_order_4284, _eri_order_4285));
    (_eri_order_4286 = (v_harness), _eri_order_4287 = (2), _eri_order_4288 = (1), _eri_order_4289 = (eri_text_from_bytes((const unsigned char[]){0x63, 0x79, 0x63, 0x6c, 0x69, 0x63, 0x2d, 0x6c, 0x61, 0x74, 0x65, 0x72, 0x2d, 0x70, 0x6f, 0x73, 0x69, 0x74, 0x69, 0x6f, 0x6e}, 21)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4286, _eri_order_4287, _eri_order_4288, _eri_order_4289));
    (_eri_order_4290 = ((v_routine)->f_instructions), _eri_order_4291 = (v_edit), _eri_order_4292 = (19), _eri_order_4293 = (3), fn_verifier_u002d_debug_u002e_change(_eri_order_4290, _eri_order_4291, _eri_order_4292, _eri_order_4293));
    (_eri_order_4294 = ((v_routine)->f_instructions), _eri_order_4295 = (v_edit), _eri_order_4296 = (35), _eri_order_4297 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4294, _eri_order_4295, _eri_order_4296, _eri_order_4297));
    (_eri_order_4298 = (v_harness), _eri_order_4299 = (2), _eri_order_4300 = (1), _eri_order_4301 = (eri_text_from_bytes((const unsigned char[]){0x66, 0x61, 0x6b, 0x65, 0x2d, 0x76, 0x6f, 0x69, 0x64, 0x2d, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74}, 16)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4298, _eri_order_4299, _eri_order_4300, _eri_order_4301));
    (_eri_order_4302 = ((v_routine)->f_instructions), _eri_order_4303 = (v_edit), _eri_order_4304 = (35), _eri_order_4305 = (0), fn_verifier_u002d_debug_u002e_change(_eri_order_4302, _eri_order_4303, _eri_order_4304, _eri_order_4305));
    (_eri_order_4306 = ((v_routine)->f_instructions), _eri_order_4307 = (v_edit), _eri_order_4308 = (6), _eri_order_4309 = (0), fn_verifier_u002d_debug_u002e_change(_eri_order_4306, _eri_order_4307, _eri_order_4308, _eri_order_4309));
    (_eri_order_4310 = (v_harness), _eri_order_4311 = (3), _eri_order_4312 = (1), _eri_order_4313 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x71, 0x75, 0x69, 0x72, 0x65, 0x64, 0x2d, 0x6c, 0x6f, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e}, 17)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4310, _eri_order_4311, _eri_order_4312, _eri_order_4313));
    (_eri_order_4314 = ((v_routine)->f_instructions), _eri_order_4315 = (v_edit), _eri_order_4316 = (6), _eri_order_4317 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4314, _eri_order_4315, _eri_order_4316, _eri_order_4317));
    (_eri_order_4318 = ((v_routine)->f_instructions), _eri_order_4319 = (v_edit), _eri_order_4320 = (37), _eri_order_4321 = (5), fn_verifier_u002d_debug_u002e_change(_eri_order_4318, _eri_order_4319, _eri_order_4320, _eri_order_4321));
    (_eri_order_4322 = (v_harness), _eri_order_4323 = (2), _eri_order_4324 = (1), _eri_order_4325 = (eri_text_from_bytes((const unsigned char[]){0x74, 0x72, 0x61, 0x70, 0x2d, 0x63, 0x6f, 0x64, 0x65}, 9)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4322, _eri_order_4323, _eri_order_4324, _eri_order_4325));
    (_eri_order_4326 = ((v_routine)->f_instructions), _eri_order_4327 = (v_edit), _eri_order_4328 = (37), _eri_order_4329 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4326, _eri_order_4327, _eri_order_4328, _eri_order_4329));
    (_eri_order_4330 = ((v_routine)->f_instructions), _eri_order_4331 = (v_edit), _eri_order_4332 = (12), _eri_order_4333 = (9223372036854775807), fn_verifier_u002d_debug_u002e_change(_eri_order_4330, _eri_order_4331, _eri_order_4332, _eri_order_4333));
    (_eri_order_4334 = (v_harness), _eri_order_4335 = (2), _eri_order_4336 = (0), _eri_order_4337 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x76, 0x65, 0x72, 0x66, 0x6c, 0x6f, 0x77, 0x69, 0x6e, 0x67, 0x2d, 0x72, 0x61, 0x6e, 0x67, 0x65}, 17)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4334, _eri_order_4335, _eri_order_4336, _eri_order_4337));
    (_eri_order_4338 = ((v_routine)->f_instructions), _eri_order_4339 = (v_edit), _eri_order_4340 = (12), _eri_order_4341 = (0), fn_verifier_u002d_debug_u002e_change(_eri_order_4338, _eri_order_4339, _eri_order_4340, _eri_order_4341));
    (_eri_order_4342 = ((v_routine)->f_blocks), _eri_order_4343 = (v_edit), _eri_order_4344 = (4), _eri_order_4345 = (9223372036854775807), fn_verifier_u002d_debug_u002e_change(_eri_order_4342, _eri_order_4343, _eri_order_4344, _eri_order_4345));
    (_eri_order_4346 = (v_harness), _eri_order_4347 = (2), _eri_order_4348 = (1), _eri_order_4349 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x76, 0x65, 0x72, 0x66, 0x6c, 0x6f, 0x77, 0x69, 0x6e, 0x67, 0x2d, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x2d, 0x69, 0x64}, 26)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4346, _eri_order_4347, _eri_order_4348, _eri_order_4349));
    (_eri_order_4350 = ((v_routine)->f_blocks), _eri_order_4351 = (v_edit), _eri_order_4352 = (4), _eri_order_4353 = (5), fn_verifier_u002d_debug_u002e_change(_eri_order_4350, _eri_order_4351, _eri_order_4352, _eri_order_4353));
    int64_t v_length = ((v_routine)->f_values)->f_length;
    ((v_routine)->f_values)->f_length = 9223372036854775807;
    (_eri_order_4354 = (v_harness), _eri_order_4355 = (0), _eri_order_4356 = (0), _eri_order_4357 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x76, 0x65, 0x72, 0x66, 0x6c, 0x6f, 0x77, 0x69, 0x6e, 0x67, 0x2d, 0x63, 0x6f, 0x75, 0x6e, 0x74}, 17)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4354, _eri_order_4355, _eri_order_4356, _eri_order_4357));
    ((v_routine)->f_values)->f_length = v_length;
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * v_foreign = (_eri_order_4358 = ((v_harness)->f_root), _eri_order_4359 = (false), fn_compiler_u002e_u1_budget_u002e_functionOwner(_eri_order_4358, _eri_order_4359));
    ((v_routine)->f_values)->f_owner = v_foreign;
    (_eri_order_4360 = (v_harness), _eri_order_4361 = (0), _eri_order_4362 = (0), _eri_order_4363 = (eri_text_from_bytes((const unsigned char[]){0x66, 0x6f, 0x72, 0x65, 0x69, 0x67, 0x6e, 0x2d, 0x74, 0x61, 0x62, 0x6c, 0x65}, 13)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4360, _eri_order_4361, _eri_order_4362, _eri_order_4363));
    ((v_routine)->f_values)->f_owner = (v_harness)->f_owner;
    fn_compiler_u002e_u1_budget_u002e_close(v_foreign);
    eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node v_oldRoot = ((v_routine)->f_values)->f_root;
    ((v_routine)->f_values)->f_root = (eri_maybe_identity_u0020_compiler_u002e_u1_words_u002e_Node){.has=false};
    (_eri_order_4364 = (v_harness), _eri_order_4365 = (2), _eri_order_4366 = (1), _eri_order_4367 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x69, 0x73, 0x73, 0x69, 0x6e, 0x67, 0x2d, 0x70, 0x61, 0x67, 0x65}, 12)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4364, _eri_order_4365, _eri_order_4366, _eri_order_4367));
    ((v_routine)->f_values)->f_root = v_oldRoot;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_metadataEdit = fn_compiler_u002e_u1_budget_u002e_constructionPhase((v_harness)->f_shared);
    (_eri_order_4368 = (((v_harness)->f_data)->f_locations), _eri_order_4369 = (v_metadataEdit), _eri_order_4370 = (3), _eri_order_4371 = (33), fn_verifier_u002d_debug_u002e_change(_eri_order_4368, _eri_order_4369, _eri_order_4370, _eri_order_4371));
    (_eri_order_4372 = (v_harness), _eri_order_4373 = (3), _eri_order_4374 = (0), _eri_order_4375 = (eri_text_from_bytes((const unsigned char[]){0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x2d, 0x61, 0x6e, 0x63, 0x68, 0x6f, 0x72}, 13)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4372, _eri_order_4373, _eri_order_4374, _eri_order_4375));
    (_eri_order_4376 = (((v_harness)->f_data)->f_locations), _eri_order_4377 = (v_metadataEdit), _eri_order_4378 = (3), _eri_order_4379 = (3), fn_verifier_u002d_debug_u002e_change(_eri_order_4376, _eri_order_4377, _eri_order_4378, _eri_order_4379));
    (_eri_order_4380 = (((v_harness)->f_data)->f_locations), _eri_order_4381 = (v_metadataEdit), _eri_order_4382 = (6), _eri_order_4383 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4380, _eri_order_4381, _eri_order_4382, _eri_order_4383));
    (_eri_order_4384 = (v_harness), _eri_order_4385 = (3), _eri_order_4386 = (0), _eri_order_4387 = (eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x73, 0x75, 0x70, 0x70, 0x6f, 0x72, 0x74, 0x65, 0x64, 0x2d, 0x6f, 0x72, 0x69, 0x67, 0x69, 0x6e}, 18)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4384, _eri_order_4385, _eri_order_4386, _eri_order_4387));
    (_eri_order_4388 = (((v_harness)->f_data)->f_locations), _eri_order_4389 = (v_metadataEdit), _eri_order_4390 = (6), _eri_order_4391 = (0), fn_verifier_u002d_debug_u002e_change(_eri_order_4388, _eri_order_4389, _eri_order_4390, _eri_order_4391));
    (_eri_order_4392 = (((v_harness)->f_data)->f_bytes), _eri_order_4393 = (v_metadataEdit), _eri_order_4394 = (12), _eri_order_4395 = (71), fn_verifier_u002d_debug_u002e_change(_eri_order_4392, _eri_order_4393, _eri_order_4394, _eri_order_4395));
    (_eri_order_4396 = (v_harness), _eri_order_4397 = (1), _eri_order_4398 = (0), _eri_order_4399 = (eri_text_from_bytes((const unsigned char[]){0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x2d, 0x64, 0x69, 0x67, 0x65, 0x73, 0x74}, 13)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4396, _eri_order_4397, _eri_order_4398, _eri_order_4399));
    (_eri_order_4400 = (((v_harness)->f_data)->f_bytes), _eri_order_4401 = (v_metadataEdit), _eri_order_4402 = (12), _eri_order_4403 = (49), fn_verifier_u002d_debug_u002e_change(_eri_order_4400, _eri_order_4401, _eri_order_4402, _eri_order_4403));
    (_eri_order_4404 = (((v_harness)->f_data)->f_signatures), _eri_order_4405 = (v_metadataEdit), _eri_order_4406 = (1), _eri_order_4407 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4404, _eri_order_4405, _eri_order_4406, _eri_order_4407));
    (_eri_order_4408 = (v_harness), _eri_order_4409 = (1), _eri_order_4410 = (0), _eri_order_4411 = (eri_text_from_bytes((const unsigned char[]){0x73, 0x69, 0x67, 0x6e, 0x61, 0x74, 0x75, 0x72, 0x65, 0x2d, 0x63, 0x68, 0x61, 0x69, 0x6e}, 15)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4408, _eri_order_4409, _eri_order_4410, _eri_order_4411));
    (_eri_order_4412 = (((v_harness)->f_data)->f_signatures), _eri_order_4413 = (v_metadataEdit), _eri_order_4414 = (1), _eri_order_4415 = (0), fn_verifier_u002d_debug_u002e_change(_eri_order_4412, _eri_order_4413, _eri_order_4414, _eri_order_4415));
    (_eri_order_4416 = (v_harness), _eri_order_4417 = (1), _eri_order_4418 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x65, 0x74, 0x61, 0x64, 0x61, 0x74, 0x61, 0x2d, 0x72, 0x65, 0x73, 0x74, 0x6f, 0x72, 0x65, 0x64}, 17)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4416, _eri_order_4417, _eri_order_4418));
    fn_verifier_u002d_debug_u002e_close(v_harness);
}

static void fn_verifier_u002d_debug_u002e_orphanRecords(void) {
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4419;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4420;
    int64_t _eri_order_4421;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4422;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4423;
    int64_t _eri_order_4424;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4425;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4426;
    int64_t _eri_order_4427;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4428;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4429;
    int64_t _eri_order_4430;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4431;
    int64_t _eri_order_4432;
    int64_t _eri_order_4433;
    eri_text _eri_order_4434;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4435;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4436;
    int64_t _eri_order_4437;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4438;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4439;
    int64_t _eri_order_4440;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4441;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4442;
    int64_t _eri_order_4443;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4444;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4445;
    int64_t _eri_order_4446;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4447;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4448;
    int64_t _eri_order_4449;
    int64_t _eri_order_4450;
    int64_t _eri_order_4451;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4452;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4453;
    int64_t _eri_order_4454;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4455;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4456;
    int64_t _eri_order_4457;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4458;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4459;
    int64_t _eri_order_4460;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4461;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4462;
    int64_t _eri_order_4463;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4464;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4465;
    int64_t _eri_order_4466;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4467;
    int64_t _eri_order_4468;
    int64_t _eri_order_4469;
    eri_text _eri_order_4470;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4471;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4472;
    int64_t _eri_order_4473;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4474;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4475;
    int64_t _eri_order_4476;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4477;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4478;
    int64_t _eri_order_4479;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4480;
    int64_t _eri_order_4481;
    int64_t _eri_order_4482;
    eri_text _eri_order_4483;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = fn_verifier_u002d_debug_u002e_straight();
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_harness)->f_routine;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_edit = fn_compiler_u002e_u1_budget_u002e_constructionPhase((v_harness)->f_owner);
    int64_t v_length = ((v_routine)->f_values)->f_length;
    ((v_routine)->f_values)->f_frozen = false;
    int64_t v_ignored = (_eri_order_4419 = ((v_routine)->f_values), _eri_order_4420 = (v_edit), _eri_order_4421 = (2), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4419, _eri_order_4420, _eri_order_4421));
    v_ignored = (_eri_order_4422 = ((v_routine)->f_values), _eri_order_4423 = (v_edit), _eri_order_4424 = (1), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4422, _eri_order_4423, _eri_order_4424));
    v_ignored = (_eri_order_4425 = ((v_routine)->f_values), _eri_order_4426 = (v_edit), _eri_order_4427 = (2), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4425, _eri_order_4426, _eri_order_4427));
    v_ignored = (_eri_order_4428 = ((v_routine)->f_values), _eri_order_4429 = (v_edit), _eri_order_4430 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4428, _eri_order_4429, _eri_order_4430));
    ((v_routine)->f_values)->f_frozen = true;
    (_eri_order_4431 = (v_harness), _eri_order_4432 = (2), _eri_order_4433 = (0), _eri_order_4434 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x70, 0x68, 0x61, 0x6e, 0x2d, 0x76, 0x61, 0x6c, 0x75, 0x65}, 12)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4431, _eri_order_4432, _eri_order_4433, _eri_order_4434));
    ((v_routine)->f_values)->f_length = v_length;
    v_length = ((v_routine)->f_instructions)->f_length;
    ((v_routine)->f_instructions)->f_frozen = false;
    v_ignored = (_eri_order_4435 = ((v_routine)->f_instructions), _eri_order_4436 = (v_edit), _eri_order_4437 = (1), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4435, _eri_order_4436, _eri_order_4437));
    v_ignored = (_eri_order_4438 = ((v_routine)->f_instructions), _eri_order_4439 = (v_edit), _eri_order_4440 = (1), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4438, _eri_order_4439, _eri_order_4440));
    v_ignored = (_eri_order_4441 = ((v_routine)->f_instructions), _eri_order_4442 = (v_edit), _eri_order_4443 = (((v_routine)->f_operands)->f_length), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4441, _eri_order_4442, _eri_order_4443));
    v_ignored = (_eri_order_4444 = ((v_routine)->f_instructions), _eri_order_4445 = (v_edit), _eri_order_4446 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4444, _eri_order_4445, _eri_order_4446));
    v_ignored = (_eri_order_4447 = ((v_routine)->f_instructions), _eri_order_4448 = (v_edit), _eri_order_4451 = ((_eri_order_4449 = (eri_ineg(9223372036854775807)), _eri_order_4450 = (1), eri_isub(_eri_order_4449, _eri_order_4450))), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4447, _eri_order_4448, _eri_order_4451));
    v_ignored = (_eri_order_4452 = ((v_routine)->f_instructions), _eri_order_4453 = (v_edit), _eri_order_4454 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4452, _eri_order_4453, _eri_order_4454));
    v_ignored = (_eri_order_4455 = ((v_routine)->f_instructions), _eri_order_4456 = (v_edit), _eri_order_4457 = (1), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4455, _eri_order_4456, _eri_order_4457));
    v_ignored = (_eri_order_4458 = ((v_routine)->f_instructions), _eri_order_4459 = (v_edit), _eri_order_4460 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4458, _eri_order_4459, _eri_order_4460));
    v_ignored = (_eri_order_4461 = ((v_routine)->f_instructions), _eri_order_4462 = (v_edit), _eri_order_4463 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4461, _eri_order_4462, _eri_order_4463));
    v_ignored = (_eri_order_4464 = ((v_routine)->f_instructions), _eri_order_4465 = (v_edit), _eri_order_4466 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4464, _eri_order_4465, _eri_order_4466));
    ((v_routine)->f_instructions)->f_frozen = true;
    (_eri_order_4467 = (v_harness), _eri_order_4468 = (2), _eri_order_4469 = (0), _eri_order_4470 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x70, 0x68, 0x61, 0x6e, 0x2d, 0x69, 0x6e, 0x73, 0x74, 0x72, 0x75, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x2d, 0x62, 0x65, 0x66, 0x6f, 0x72, 0x65, 0x2d, 0x62, 0x61, 0x63, 0x6b, 0x6c, 0x69, 0x6e, 0x6b}, 34)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4467, _eri_order_4468, _eri_order_4469, _eri_order_4470));
    ((v_routine)->f_instructions)->f_length = v_length;
    v_length = ((v_routine)->f_edges)->f_length;
    ((v_routine)->f_edges)->f_frozen = false;
    v_ignored = (_eri_order_4471 = ((v_routine)->f_edges), _eri_order_4472 = (v_edit), _eri_order_4473 = (1), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4471, _eri_order_4472, _eri_order_4473));
    v_ignored = (_eri_order_4474 = ((v_routine)->f_edges), _eri_order_4475 = (v_edit), _eri_order_4476 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4474, _eri_order_4475, _eri_order_4476));
    v_ignored = (_eri_order_4477 = ((v_routine)->f_edges), _eri_order_4478 = (v_edit), _eri_order_4479 = (0), fn_compiler_u002e_u1_words_u002e_push(_eri_order_4477, _eri_order_4478, _eri_order_4479));
    ((v_routine)->f_edges)->f_frozen = true;
    (_eri_order_4480 = (v_harness), _eri_order_4481 = (2), _eri_order_4482 = (0), _eri_order_4483 = (eri_text_from_bytes((const unsigned char[]){0x6f, 0x72, 0x70, 0x68, 0x61, 0x6e, 0x2d, 0x65, 0x64, 0x67, 0x65}, 11)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4480, _eri_order_4481, _eri_order_4482, _eri_order_4483));
    ((v_routine)->f_edges)->f_length = v_length;
    fn_verifier_u002d_debug_u002e_close(v_harness);
}

static void fn_verifier_u002d_debug_u002e_diamond(void) {
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4484;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4485;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4486;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4487;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4488;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4489;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4490;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4491;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4492;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4493;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4494;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4495;
    int64_t _eri_order_4496;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4497;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4498;
    int64_t _eri_order_4499;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4500;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4501;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4502;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4503;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4504;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4505;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4506;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4507;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4508;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4509;
    int64_t _eri_order_4510;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4511;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4512;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4513;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4514;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4515;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4516;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4517;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4518;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4519;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4520;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4521;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4522;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4523;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4524;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4525;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4526;
    int64_t _eri_order_4527;
    int64_t _eri_order_4528;
    eri_text _eri_order_4529;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4530;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4531;
    int64_t _eri_order_4532;
    int64_t _eri_order_4533;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4534;
    int64_t _eri_order_4535;
    eri_text _eri_order_4536;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4537;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4538;
    int64_t _eri_order_4539;
    int64_t _eri_order_4540;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4541;
    int64_t _eri_order_4542;
    int64_t _eri_order_4543;
    eri_text _eri_order_4544;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4545;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4546;
    int64_t _eri_order_4547;
    int64_t _eri_order_4548;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4549;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4550;
    int64_t _eri_order_4551;
    int64_t _eri_order_4552;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4553;
    int64_t _eri_order_4554;
    int64_t _eri_order_4555;
    eri_text _eri_order_4556;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = (_eri_order_4484 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(2, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_pred(), fn_compiler_u002e_u1_meta_u002e_i64()})), _eri_order_4485 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4484, _eri_order_4485));
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_harness)->f_routine;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_entry = (_eri_order_4486 = (v_routine), _eri_order_4487 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(2, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_pred(), fn_compiler_u002e_u1_meta_u002e_i64()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4486, _eri_order_4487));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_left = (_eri_order_4488 = (v_routine), _eri_order_4489 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4488, _eri_order_4489));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_right = (_eri_order_4490 = (v_routine), _eri_order_4491 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4490, _eri_order_4491));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_join = (_eri_order_4492 = (v_routine), _eri_order_4493 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4492, _eri_order_4493));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_test = (_eri_order_4494 = (v_routine), _eri_order_4495 = (v_entry), _eri_order_4496 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4494, _eri_order_4495, _eri_order_4496));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_initial = (_eri_order_4497 = (v_routine), _eri_order_4498 = (v_entry), _eri_order_4499 = (1), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4497, _eri_order_4498, _eri_order_4499));
    (_eri_order_4500 = (v_routine), _eri_order_4501 = (v_entry), _eri_order_4502 = (v_test), _eri_order_4503 = (v_left), _eri_order_4504 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_4505 = (v_right), _eri_order_4506 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_4507 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_branch_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4500, _eri_order_4501, _eri_order_4502, _eri_order_4503, _eri_order_4504, _eri_order_4505, _eri_order_4506, _eri_order_4507));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_partial = (_eri_order_4508 = (v_routine), _eri_order_4509 = (v_left), _eri_order_4510 = (9), _eri_order_4511 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_integer(_eri_order_4508, _eri_order_4509, _eri_order_4510, _eri_order_4511));
    (_eri_order_4512 = (v_routine), _eri_order_4513 = (v_left), _eri_order_4514 = (v_join), _eri_order_4515 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_4516 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_jump_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4512, _eri_order_4513, _eri_order_4514, _eri_order_4515, _eri_order_4516));
    (_eri_order_4517 = (v_routine), _eri_order_4518 = (v_right), _eri_order_4519 = (v_join), _eri_order_4520 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_4521 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_jump_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4517, _eri_order_4518, _eri_order_4519, _eri_order_4520, _eri_order_4521));
    (_eri_order_4522 = (v_routine), _eri_order_4523 = (v_join), _eri_order_4524 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_partial})), _eri_order_4525 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4522, _eri_order_4523, _eri_order_4524, _eri_order_4525));
    fn_compiler_u002e_u1_builder_u002e_complete(v_routine);
    (_eri_order_4526 = (v_harness), _eri_order_4527 = (4), _eri_order_4528 = (4), _eri_order_4529 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x69, 0x61, 0x6d, 0x6f, 0x6e, 0x64, 0x2d, 0x6e, 0x6f, 0x6e, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x6e, 0x63, 0x65}, 20)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4526, _eri_order_4527, _eri_order_4528, _eri_order_4529));
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_edit = fn_compiler_u002e_u1_budget_u002e_constructionPhase((v_harness)->f_owner);
    (_eri_order_4530 = ((v_routine)->f_operands), _eri_order_4531 = (v_edit), _eri_order_4532 = (1), _eri_order_4533 = ((v_initial).f_index), fn_verifier_u002d_debug_u002e_change(_eri_order_4530, _eri_order_4531, _eri_order_4532, _eri_order_4533));
    (_eri_order_4534 = (v_harness), _eri_order_4535 = (4), _eri_order_4536 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x69, 0x61, 0x6d, 0x6f, 0x6e, 0x64, 0x2d, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x6e, 0x63, 0x65}, 17)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4534, _eri_order_4535, _eri_order_4536));
    (_eri_order_4537 = ((v_routine)->f_edges), _eri_order_4538 = (v_edit), _eri_order_4539 = (0), _eri_order_4540 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4537, _eri_order_4538, _eri_order_4539, _eri_order_4540));
    (_eri_order_4541 = (v_harness), _eri_order_4542 = (2), _eri_order_4543 = (1), _eri_order_4544 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x6e, 0x74, 0x72, 0x79, 0x2d, 0x70, 0x72, 0x65, 0x64, 0x65, 0x63, 0x65, 0x73, 0x73, 0x6f, 0x72}, 17)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4541, _eri_order_4542, _eri_order_4543, _eri_order_4544));
    (_eri_order_4545 = ((v_routine)->f_edges), _eri_order_4546 = (v_edit), _eri_order_4547 = (0), _eri_order_4548 = ((v_left).f_index), fn_verifier_u002d_debug_u002e_change(_eri_order_4545, _eri_order_4546, _eri_order_4547, _eri_order_4548));
    (_eri_order_4549 = ((v_routine)->f_instructions), _eri_order_4550 = (v_edit), _eri_order_4551 = (8), _eri_order_4552 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4549, _eri_order_4550, _eri_order_4551, _eri_order_4552));
    (_eri_order_4553 = (v_harness), _eri_order_4554 = (2), _eri_order_4555 = (1), _eri_order_4556 = (eri_text_from_bytes((const unsigned char[]){0x64, 0x75, 0x70, 0x6c, 0x69, 0x63, 0x61, 0x74, 0x65, 0x2d, 0x65, 0x64, 0x67, 0x65, 0x2d, 0x6f, 0x77, 0x6e, 0x65, 0x72}, 20)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4553, _eri_order_4554, _eri_order_4555, _eri_order_4556));
    fn_verifier_u002d_debug_u002e_close(v_harness);
}

static void fn_verifier_u002d_debug_u002e_loop(void) {
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4557;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4558;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4559;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4560;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4561;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4562;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4563;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4564;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4565;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4566;
    int64_t _eri_order_4567;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4568;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4569;
    int64_t _eri_order_4570;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4571;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4572;
    int64_t _eri_order_4573;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4574;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4575;
    int64_t _eri_order_4576;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4577;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4578;
    int64_t _eri_order_4579;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4580;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4581;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4582;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4583;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4584;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4585;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4586;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4587;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4588;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4589;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4590;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4591;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4592;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4593;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4594;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4595;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4596;
    int64_t _eri_order_4597;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4598;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4599;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4600;
    int64_t _eri_order_4601;
    eri_text _eri_order_4602;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4603;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4604;
    int64_t _eri_order_4605;
    int64_t _eri_order_4606;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4607;
    int64_t _eri_order_4608;
    int64_t _eri_order_4609;
    eri_text _eri_order_4610;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4611;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4612;
    int64_t _eri_order_4613;
    int64_t _eri_order_4614;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4615;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4616;
    int64_t _eri_order_4617;
    int64_t _eri_order_4618;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4619;
    int64_t _eri_order_4620;
    int64_t _eri_order_4621;
    eri_text _eri_order_4622;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4623;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4624;
    int64_t _eri_order_4625;
    int64_t _eri_order_4626;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4627;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4628;
    int64_t _eri_order_4629;
    int64_t _eri_order_4630;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4631;
    int64_t _eri_order_4632;
    int64_t _eri_order_4633;
    eri_text _eri_order_4634;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = (_eri_order_4557 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(3, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_pred()})), _eri_order_4558 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4557, _eri_order_4558));
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_harness)->f_routine;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_entry = (_eri_order_4559 = (v_routine), _eri_order_4560 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(3, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_pred()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4559, _eri_order_4560));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_header = (_eri_order_4561 = (v_routine), _eri_order_4562 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(2, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_i64()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4561, _eri_order_4562));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_done = (_eri_order_4563 = (v_routine), _eri_order_4564 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4563, _eri_order_4564));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_a = (_eri_order_4565 = (v_routine), _eri_order_4566 = (v_entry), _eri_order_4567 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4565, _eri_order_4566, _eri_order_4567));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_b = (_eri_order_4568 = (v_routine), _eri_order_4569 = (v_entry), _eri_order_4570 = (1), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4568, _eri_order_4569, _eri_order_4570));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_test = (_eri_order_4571 = (v_routine), _eri_order_4572 = (v_entry), _eri_order_4573 = (2), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4571, _eri_order_4572, _eri_order_4573));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_x = (_eri_order_4574 = (v_routine), _eri_order_4575 = (v_header), _eri_order_4576 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4574, _eri_order_4575, _eri_order_4576));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_y = (_eri_order_4577 = (v_routine), _eri_order_4578 = (v_header), _eri_order_4579 = (1), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4577, _eri_order_4578, _eri_order_4579));
    (_eri_order_4580 = (v_routine), _eri_order_4581 = (v_entry), _eri_order_4582 = (v_header), _eri_order_4583 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(2, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_a, v_b})), _eri_order_4584 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_jump_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4580, _eri_order_4581, _eri_order_4582, _eri_order_4583, _eri_order_4584));
    (_eri_order_4585 = (v_routine), _eri_order_4586 = (v_header), _eri_order_4587 = (v_test), _eri_order_4588 = (v_header), _eri_order_4589 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(2, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_y, v_x})), _eri_order_4590 = (v_done), _eri_order_4591 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_x})), _eri_order_4592 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_branch_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4585, _eri_order_4586, _eri_order_4587, _eri_order_4588, _eri_order_4589, _eri_order_4590, _eri_order_4591, _eri_order_4592));
    (_eri_order_4593 = (v_routine), _eri_order_4594 = (v_done), _eri_order_4598 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){(_eri_order_4595 = (v_routine), _eri_order_4596 = (v_done), _eri_order_4597 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4595, _eri_order_4596, _eri_order_4597))})), _eri_order_4599 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4593, _eri_order_4594, _eri_order_4598, _eri_order_4599));
    fn_compiler_u002e_u1_builder_u002e_complete(v_routine);
    (_eri_order_4600 = (v_harness), _eri_order_4601 = (3), _eri_order_4602 = (eri_text_from_bytes((const unsigned char[]){0x6c, 0x6f, 0x6f, 0x70, 0x2d, 0x73, 0x77, 0x61, 0x70}, 9)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4600, _eri_order_4601, _eri_order_4602));
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_edit = fn_compiler_u002e_u1_budget_u002e_constructionPhase((v_harness)->f_owner);
    (_eri_order_4603 = ((v_routine)->f_arguments), _eri_order_4604 = (v_edit), _eri_order_4605 = (0), _eri_order_4606 = ((v_x).f_index), fn_verifier_u002d_debug_u002e_change(_eri_order_4603, _eri_order_4604, _eri_order_4605, _eri_order_4606));
    (_eri_order_4607 = (v_harness), _eri_order_4608 = (4), _eri_order_4609 = (1), _eri_order_4610 = (eri_text_from_bytes((const unsigned char[]){0x68, 0x65, 0x61, 0x64, 0x65, 0x72, 0x2d, 0x76, 0x61, 0x6c, 0x75, 0x65, 0x2d, 0x69, 0x6e, 0x2d, 0x70, 0x72, 0x65, 0x64, 0x65, 0x63, 0x65, 0x73, 0x73, 0x6f, 0x72}, 27)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4607, _eri_order_4608, _eri_order_4609, _eri_order_4610));
    (_eri_order_4611 = ((v_routine)->f_arguments), _eri_order_4612 = (v_edit), _eri_order_4613 = (0), _eri_order_4614 = ((v_a).f_index), fn_verifier_u002d_debug_u002e_change(_eri_order_4611, _eri_order_4612, _eri_order_4613, _eri_order_4614));
    (_eri_order_4615 = ((v_routine)->f_arguments), _eri_order_4616 = (v_edit), _eri_order_4617 = (0), _eri_order_4618 = ((v_test).f_index), fn_verifier_u002d_debug_u002e_change(_eri_order_4615, _eri_order_4616, _eri_order_4617, _eri_order_4618));
    (_eri_order_4619 = (v_harness), _eri_order_4620 = (2), _eri_order_4621 = (1), _eri_order_4622 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x64, 0x67, 0x65, 0x2d, 0x74, 0x79, 0x70, 0x65}, 9)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4619, _eri_order_4620, _eri_order_4621, _eri_order_4622));
    (_eri_order_4623 = ((v_routine)->f_arguments), _eri_order_4624 = (v_edit), _eri_order_4625 = (0), _eri_order_4626 = ((v_a).f_index), fn_verifier_u002d_debug_u002e_change(_eri_order_4623, _eri_order_4624, _eri_order_4625, _eri_order_4626));
    (_eri_order_4627 = ((v_routine)->f_edges), _eri_order_4628 = (v_edit), _eri_order_4629 = (2), _eri_order_4630 = (1), fn_verifier_u002d_debug_u002e_change(_eri_order_4627, _eri_order_4628, _eri_order_4629, _eri_order_4630));
    (_eri_order_4631 = (v_harness), _eri_order_4632 = (2), _eri_order_4633 = (0), _eri_order_4634 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x64, 0x67, 0x65, 0x2d, 0x72, 0x61, 0x6e, 0x67, 0x65}, 10)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4631, _eri_order_4632, _eri_order_4633, _eri_order_4634));
    fn_verifier_u002d_debug_u002e_close(v_harness);
}

static void fn_verifier_u002d_debug_u002e_dead(void) {
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4635;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4636;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4637;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4638;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4639;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4640;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4641;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4642;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4643;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4644;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4645;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4646;
    int64_t _eri_order_4647;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4648;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4649;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4650;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4651;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4652;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4653;
    int64_t _eri_order_4654;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4655;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4656;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4657;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4658;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4659;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4660;
    int64_t _eri_order_4661;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4662;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4663;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4664;
    int64_t _eri_order_4665;
    eri_text _eri_order_4666;
    eri_struct_compiler_u002e_u1_words_u002e_Words * _eri_order_4667;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4668;
    int64_t _eri_order_4669;
    int64_t _eri_order_4670;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4671;
    int64_t _eri_order_4672;
    int64_t _eri_order_4673;
    eri_text _eri_order_4674;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = (_eri_order_4635 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), _eri_order_4636 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4635, _eri_order_4636));
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_harness)->f_routine;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_entry = (_eri_order_4637 = (v_routine), _eri_order_4638 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4637, _eri_order_4638));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_first = (_eri_order_4639 = (v_routine), _eri_order_4640 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4639, _eri_order_4640));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_second = (_eri_order_4641 = (v_routine), _eri_order_4642 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4641, _eri_order_4642));
    (_eri_order_4643 = (v_routine), _eri_order_4644 = (v_entry), _eri_order_4648 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){(_eri_order_4645 = (v_routine), _eri_order_4646 = (v_entry), _eri_order_4647 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4645, _eri_order_4646, _eri_order_4647))})), _eri_order_4649 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4643, _eri_order_4644, _eri_order_4648, _eri_order_4649));
    (_eri_order_4650 = (v_routine), _eri_order_4651 = (v_first), _eri_order_4655 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){(_eri_order_4652 = (v_routine), _eri_order_4653 = (v_first), _eri_order_4654 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4652, _eri_order_4653, _eri_order_4654))})), _eri_order_4656 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4650, _eri_order_4651, _eri_order_4655, _eri_order_4656));
    (_eri_order_4657 = (v_routine), _eri_order_4658 = (v_second), _eri_order_4662 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){(_eri_order_4659 = (v_routine), _eri_order_4660 = (v_first), _eri_order_4661 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4659, _eri_order_4660, _eri_order_4661))})), _eri_order_4663 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4657, _eri_order_4658, _eri_order_4662, _eri_order_4663));
    fn_compiler_u002e_u1_builder_u002e_complete(v_routine);
    (_eri_order_4664 = (v_harness), _eri_order_4665 = (1), _eri_order_4666 = (eri_text_from_bytes((const unsigned char[]){0x74, 0x79, 0x70, 0x65, 0x64, 0x2d, 0x75, 0x6e, 0x72, 0x65, 0x61, 0x63, 0x68, 0x61, 0x62, 0x6c, 0x65}, 17)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4664, _eri_order_4665, _eri_order_4666));
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_edit = fn_compiler_u002e_u1_budget_u002e_constructionPhase((v_harness)->f_owner);
    (_eri_order_4667 = ((v_routine)->f_instructions), _eri_order_4668 = (v_edit), _eri_order_4669 = (20), _eri_order_4670 = (99), fn_verifier_u002d_debug_u002e_change(_eri_order_4667, _eri_order_4668, _eri_order_4669, _eri_order_4670));
    (_eri_order_4671 = (v_harness), _eri_order_4672 = (2), _eri_order_4673 = (3), _eri_order_4674 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x61, 0x6c, 0x66, 0x6f, 0x72, 0x6d, 0x65, 0x64, 0x2d, 0x75, 0x6e, 0x72, 0x65, 0x61, 0x63, 0x68, 0x61, 0x62, 0x6c, 0x65}, 21)), fn_verifier_u002d_debug_u002e_rejected(_eri_order_4671, _eri_order_4672, _eri_order_4673, _eri_order_4674));
    fn_verifier_u002d_debug_u002e_close(v_harness);
}

static void fn_verifier_u002d_debug_u002e_repeatedTarget(void) {
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4675;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4676;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4677;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4678;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4679;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4680;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4681;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4682;
    int64_t _eri_order_4683;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4684;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4685;
    int64_t _eri_order_4686;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4687;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4688;
    int64_t _eri_order_4689;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4690;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4691;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4692;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4693;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4694;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4695;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4696;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4697;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4698;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4699;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4700;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4701;
    int64_t _eri_order_4702;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4703;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4704;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4705;
    int64_t _eri_order_4706;
    eri_text _eri_order_4707;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4708;
    int64_t _eri_order_4709;
    int64_t _eri_order_4710;
    int64_t _eri_order_4711;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4712;
    int64_t _eri_order_4713;
    int64_t _eri_order_4714;
    int64_t _eri_order_4715;
    bool _eri_order_4716;
    eri_text _eri_order_4717;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = (_eri_order_4675 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(3, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_pred()})), _eri_order_4676 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4675, _eri_order_4676));
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_harness)->f_routine;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_entry = (_eri_order_4677 = (v_routine), _eri_order_4678 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(3, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_i64(), fn_compiler_u002e_u1_meta_u002e_pred()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4677, _eri_order_4678));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_target = (_eri_order_4679 = (v_routine), _eri_order_4680 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_i64()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4679, _eri_order_4680));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_a = (_eri_order_4681 = (v_routine), _eri_order_4682 = (v_entry), _eri_order_4683 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4681, _eri_order_4682, _eri_order_4683));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_b = (_eri_order_4684 = (v_routine), _eri_order_4685 = (v_entry), _eri_order_4686 = (1), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4684, _eri_order_4685, _eri_order_4686));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_test = (_eri_order_4687 = (v_routine), _eri_order_4688 = (v_entry), _eri_order_4689 = (2), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4687, _eri_order_4688, _eri_order_4689));
    (_eri_order_4690 = (v_routine), _eri_order_4691 = (v_entry), _eri_order_4692 = (v_test), _eri_order_4693 = (v_target), _eri_order_4694 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_a})), _eri_order_4695 = (v_target), _eri_order_4696 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_b})), _eri_order_4697 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_branch_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4690, _eri_order_4691, _eri_order_4692, _eri_order_4693, _eri_order_4694, _eri_order_4695, _eri_order_4696, _eri_order_4697));
    (_eri_order_4698 = (v_routine), _eri_order_4699 = (v_target), _eri_order_4703 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(1, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){(_eri_order_4700 = (v_routine), _eri_order_4701 = (v_target), _eri_order_4702 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4700, _eri_order_4701, _eri_order_4702))})), _eri_order_4704 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4698, _eri_order_4699, _eri_order_4703, _eri_order_4704));
    fn_compiler_u002e_u1_builder_u002e_complete(v_routine);
    (_eri_order_4705 = (v_harness), _eri_order_4706 = (2), _eri_order_4707 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x70, 0x65, 0x61, 0x74, 0x65, 0x64, 0x2d, 0x74, 0x61, 0x72, 0x67, 0x65, 0x74, 0x2d, 0x61, 0x72, 0x67, 0x75, 0x6d, 0x65, 0x6e, 0x74, 0x73}, 25)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4705, _eri_order_4706, _eri_order_4707));
    (_eri_order_4716 = ((_eri_order_4711 = (((_eri_order_4708 = (v_routine), _eri_order_4709 = (1), _eri_order_4710 = (0), fn_compiler_u002e_u1_builder_u002e_edgeArgument(_eri_order_4708, _eri_order_4709, _eri_order_4710))).f_index), _eri_order_4715 = (((_eri_order_4712 = (v_routine), _eri_order_4713 = (2), _eri_order_4714 = (0), fn_compiler_u002e_u1_builder_u002e_edgeArgument(_eri_order_4712, _eri_order_4713, _eri_order_4714))).f_index), (_eri_order_4711 != _eri_order_4715))), _eri_order_4717 = (eri_text_from_bytes((const unsigned char[]){0x65, 0x64, 0x67, 0x65, 0x20, 0x64, 0x69, 0x73, 0x74, 0x69, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e, 0x73, 0x20, 0x70, 0x72, 0x65, 0x73, 0x65, 0x72, 0x76, 0x65, 0x64}, 27)), fn_verifier_u002d_debug_u002e_check(_eri_order_4716, _eri_order_4717));
    fn_verifier_u002d_debug_u002e_close(v_harness);
}

static void fn_verifier_u002d_debug_u002e_limits(void) {
    eri_struct_compiler_u002e_u1_budget_u002e_Owner * _eri_order_4718;
    int64_t _eri_order_4719;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4721;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4722;
    eri_text _eri_order_4723;
    eri_text _eri_order_4724;
    int64_t _eri_order_4725;
    int64_t _eri_order_4726;
    int64_t _eri_order_4727;
    int64_t _eri_order_4728;
    int64_t _eri_order_4729;
    int64_t _eri_order_4730;
    int64_t _eri_order_4731;
    int64_t _eri_order_4732;
    bool _eri_order_4733;
    eri_text _eri_order_4734;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = fn_verifier_u002d_debug_u002e_straight();
    int64_t v_live = ((v_harness)->f_owner)->f_live;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase = (_eri_order_4718 = ((v_harness)->f_owner), _eri_order_4719 = (100), fn_compiler_u002e_u1_budget_u002e_phase(_eri_order_4718, _eri_order_4719));
    eri_struct_compiler_u002e_u1_verify_u002e_Report v_unexpected;
    eri_handler_frame _eri_h_4720; _eri_h_4720.prev=eri_handler_top; eri_handler_top=&_eri_h_4720;
    if (setjmp(_eri_h_4720.env)==0) {
        v_unexpected = (_eri_order_4721 = ((v_harness)->f_routine), _eri_order_4722 = (v_phase), fn_compiler_u002e_u1_verify_u002e_verify(_eri_order_4721, _eri_order_4722));
        eri_handler_top = _eri_h_4720.prev;
    } else {
        eri_handler_top = _eri_h_4720.prev;
        eri_failure_value _eri_failure_4720 = eri_failure;
        if (strcmp(_eri_failure_4720.type, "compiler.u1_budget.LimitError") == 0) {
            eri_struct_compiler_u002e_u1_budget_u002e_LimitError v_error = *(eri_struct_compiler_u002e_u1_budget_u002e_LimitError*)_eri_failure_4720.payload;
            (_eri_order_4733 = ((((((_eri_order_4723 = ((v_error).f_category), _eri_order_4724 = (eri_text_from_bytes((const unsigned char[]){0x72, 0x65, 0x73, 0x6f, 0x75, 0x72, 0x63, 0x65, 0x2d, 0x6c, 0x69, 0x6d, 0x69, 0x74}, 14)), eri_text_eq(_eri_order_4723, _eri_order_4724)) && (_eri_order_4725 = (((v_harness)->f_owner)->f_live), _eri_order_4726 = (v_live), (_eri_order_4725 == _eri_order_4726))) && (_eri_order_4727 = (((v_harness)->f_owner)->f_pending), _eri_order_4728 = (0), (_eri_order_4727 == _eri_order_4728))) && (_eri_order_4729 = ((v_phase)->f_state), _eri_order_4730 = (1), (_eri_order_4729 == _eri_order_4730))) && (_eri_order_4731 = (((v_harness)->f_routine)->f_state), _eri_order_4732 = (1), (_eri_order_4731 == _eri_order_4732)))), _eri_order_4734 = (eri_text_from_bytes((const unsigned char[]){0x66, 0x61, 0x69, 0x6c, 0x65, 0x64, 0x20, 0x76, 0x65, 0x72, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x72, 0x65, 0x6c, 0x65, 0x61, 0x73, 0x65, 0x73, 0x20, 0x70, 0x61, 0x72, 0x74, 0x69, 0x61, 0x6c, 0x20, 0x73, 0x63, 0x72, 0x61, 0x74, 0x63, 0x68}, 44)), fn_verifier_u002d_debug_u002e_check(_eri_order_4733, _eri_order_4734));
            fn_verifier_u002d_debug_u002e_close(v_harness);
            eri_out_text(eri_text_from_bytes((const unsigned char[]){0x77, 0x6f, 0x72, 0x6b, 0x2d, 0x65, 0x78, 0x68, 0x61, 0x75, 0x73, 0x74, 0x69, 0x6f, 0x6e, 0x3a, 0x6f, 0x6b}, 18));
            return;
            eri_fault("value error handler completed without terminating");
        }
        else if (strcmp(_eri_failure_4720.type, "compiler.u1_verify.InvalidIR") == 0) {
            eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR v_error = *(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR*)_eri_failure_4720.payload;
            eri_fail_compiler_u002e_u1_verify_u002e_InvalidIR(v_error);
            eri_fault("value error handler completed without terminating");
        }
        else { eri_propagate_saved(_eri_failure_4720); }
    }
    eri_fail_verifier_u002d_debug_u002e_ProbeError((eri_struct_verifier_u002d_debug_u002e_ProbeError){.f_message = eri_text_from_bytes((const unsigned char[]){0x76, 0x65, 0x72, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x73, 0x68, 0x6f, 0x75, 0x6c, 0x64, 0x20, 0x65, 0x78, 0x68, 0x61, 0x75, 0x73, 0x74, 0x20, 0x69, 0x74, 0x73, 0x20, 0x70, 0x68, 0x61, 0x73, 0x65}, 37)});
}

static void fn_verifier_u002d_debug_u002e_cancellation(void) {
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4736;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * _eri_order_4737;
    eri_text _eri_order_4738;
    eri_text _eri_order_4739;
    int64_t _eri_order_4740;
    int64_t _eri_order_4741;
    bool _eri_order_4742;
    eri_text _eri_order_4743;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = fn_verifier_u002d_debug_u002e_straight();
    int64_t v_live = ((v_harness)->f_owner)->f_live;
    eri_struct_compiler_u002e_u1_budget_u002e_Phase * v_phase = fn_compiler_u002e_u1_budget_u002e_verificationPhase((v_harness)->f_owner);
    fn_compiler_u002e_u1_budget_u002e_cancel((v_harness)->f_owner);
    eri_struct_compiler_u002e_u1_verify_u002e_Report v_unexpected;
    eri_handler_frame _eri_h_4735; _eri_h_4735.prev=eri_handler_top; eri_handler_top=&_eri_h_4735;
    if (setjmp(_eri_h_4735.env)==0) {
        v_unexpected = (_eri_order_4736 = ((v_harness)->f_routine), _eri_order_4737 = (v_phase), fn_compiler_u002e_u1_verify_u002e_verify(_eri_order_4736, _eri_order_4737));
        eri_handler_top = _eri_h_4735.prev;
    } else {
        eri_handler_top = _eri_h_4735.prev;
        eri_failure_value _eri_failure_4735 = eri_failure;
        if (strcmp(_eri_failure_4735.type, "compiler.u1_budget.LimitError") == 0) {
            eri_struct_compiler_u002e_u1_budget_u002e_LimitError v_error = *(eri_struct_compiler_u002e_u1_budget_u002e_LimitError*)_eri_failure_4735.payload;
            (_eri_order_4742 = (((_eri_order_4738 = ((v_error).f_category), _eri_order_4739 = (eri_text_from_bytes((const unsigned char[]){0x63, 0x61, 0x6e, 0x63, 0x65, 0x6c, 0x6c, 0x65, 0x64}, 9)), eri_text_eq(_eri_order_4738, _eri_order_4739)) && (_eri_order_4740 = (((v_harness)->f_owner)->f_live), _eri_order_4741 = (v_live), (_eri_order_4740 == _eri_order_4741)))), _eri_order_4743 = (eri_text_from_bytes((const unsigned char[]){0x63, 0x61, 0x6e, 0x63, 0x65, 0x6c, 0x6c, 0x65, 0x64, 0x20, 0x76, 0x65, 0x72, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x64, 0x6f, 0x65, 0x73, 0x20, 0x6e, 0x6f, 0x74, 0x20, 0x70, 0x75, 0x62, 0x6c, 0x69, 0x73, 0x68, 0x20, 0x6f, 0x72, 0x20, 0x61, 0x6c, 0x6c, 0x6f, 0x63, 0x61, 0x74, 0x65}, 51)), fn_verifier_u002d_debug_u002e_check(_eri_order_4742, _eri_order_4743));
            fn_verifier_u002d_debug_u002e_close(v_harness);
            eri_out_text(eri_text_from_bytes((const unsigned char[]){0x63, 0x61, 0x6e, 0x63, 0x65, 0x6c, 0x6c, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x3a, 0x6f, 0x6b}, 15));
            return;
            eri_fault("value error handler completed without terminating");
        }
        else if (strcmp(_eri_failure_4735.type, "compiler.u1_verify.InvalidIR") == 0) {
            eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR v_error = *(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR*)_eri_failure_4735.payload;
            eri_fail_compiler_u002e_u1_verify_u002e_InvalidIR(v_error);
            eri_fault("value error handler completed without terminating");
        }
        else { eri_propagate_saved(_eri_failure_4735); }
    }
    eri_fail_verifier_u002d_debug_u002e_ProbeError((eri_struct_verifier_u002d_debug_u002e_ProbeError){.f_message = eri_text_from_bytes((const unsigned char[]){0x76, 0x65, 0x72, 0x69, 0x66, 0x69, 0x63, 0x61, 0x74, 0x69, 0x6f, 0x6e, 0x20, 0x73, 0x68, 0x6f, 0x75, 0x6c, 0x64, 0x20, 0x62, 0x65, 0x20, 0x63, 0x61, 0x6e, 0x63, 0x65, 0x6c, 0x6c, 0x65, 0x64}, 32)});
}

static void fn_verifier_u002d_debug_u002e_scalarShapes(void) {
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4744;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4745;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4746;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4747;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4748;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4749;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4750;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4751;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4752;
    int64_t _eri_order_4753;
    eri_text _eri_order_4754;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4755;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4756;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4757;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4758;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4759;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4760;
    int64_t _eri_order_4761;
    int64_t _eri_order_4762;
    int64_t _eri_order_4763;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4764;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4765;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4766;
    int64_t _eri_order_4767;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4768;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4769;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4770;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4771;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4772;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4773;
    int64_t _eri_order_4774;
    eri_text _eri_order_4775;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = (_eri_order_4744 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), _eri_order_4745 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4744, _eri_order_4745));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_entry = (_eri_order_4746 = ((v_harness)->f_routine), _eri_order_4747 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4746, _eri_order_4747));
    (_eri_order_4748 = ((v_harness)->f_routine), _eri_order_4749 = (v_entry), _eri_order_4750 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_4751 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4748, _eri_order_4749, _eri_order_4750, _eri_order_4751));
    fn_compiler_u002e_u1_builder_u002e_complete((v_harness)->f_routine);
    (_eri_order_4752 = (v_harness), _eri_order_4753 = (1), _eri_order_4754 = (eri_text_from_bytes((const unsigned char[]){0x7a, 0x65, 0x72, 0x6f, 0x2d, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x2d, 0x66, 0x75, 0x6e, 0x63, 0x74, 0x69, 0x6f, 0x6e}, 20)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4752, _eri_order_4753, _eri_order_4754));
    fn_verifier_u002d_debug_u002e_close(v_harness);
    v_harness = (_eri_order_4755 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), _eri_order_4756 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(2, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_f64(), fn_compiler_u002e_u1_meta_u002e_f64()})), fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4755, _eri_order_4756));
    v_entry = (_eri_order_4757 = ((v_harness)->f_routine), _eri_order_4758 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4757, _eri_order_4758));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_negativeZero = (_eri_order_4759 = ((v_harness)->f_routine), _eri_order_4760 = (v_entry), _eri_order_4763 = ((_eri_order_4761 = (eri_ineg(9223372036854775807)), _eri_order_4762 = (1), eri_isub(_eri_order_4761, _eri_order_4762))), _eri_order_4764 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_floatBits(_eri_order_4759, _eri_order_4760, _eri_order_4763, _eri_order_4764));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_nan = (_eri_order_4765 = ((v_harness)->f_routine), _eri_order_4766 = (v_entry), _eri_order_4767 = (9221120237041090560), _eri_order_4768 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_floatBits(_eri_order_4765, _eri_order_4766, _eri_order_4767, _eri_order_4768));
    (_eri_order_4769 = ((v_harness)->f_routine), _eri_order_4770 = (v_entry), _eri_order_4771 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(2, (eri_struct_compiler_u002e_u1_builder_u002e_ValueId[]){v_negativeZero, v_nan})), _eri_order_4772 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4769, _eri_order_4770, _eri_order_4771, _eri_order_4772));
    fn_compiler_u002e_u1_builder_u002e_complete((v_harness)->f_routine);
    (_eri_order_4773 = (v_harness), _eri_order_4774 = (1), _eri_order_4775 = (eri_text_from_bytes((const unsigned char[]){0x66, 0x6c, 0x6f, 0x61, 0x74, 0x2d, 0x62, 0x69, 0x74, 0x73, 0x2d, 0x6d, 0x75, 0x6c, 0x74, 0x69, 0x70, 0x6c, 0x65, 0x2d, 0x72, 0x65, 0x73, 0x75, 0x6c, 0x74, 0x73}, 27)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4773, _eri_order_4774, _eri_order_4775));
    fn_verifier_u002d_debug_u002e_close(v_harness);
}

static void fn_verifier_u002d_debug_u002e_manyUses(void) {
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4776;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4777;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4778;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4779;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4780;
    eri_list_compiler_u002e_u1_meta_u002e_TypeId _eri_order_4781;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4782;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4783;
    int64_t _eri_order_4784;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4785;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4786;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4787;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4788;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4789;
    int64_t _eri_order_4790;
    int64_t _eri_order_4791;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4792;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4793;
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4794;
    int64_t _eri_order_4795;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4796;
    int64_t _eri_order_4797;
    int64_t _eri_order_4798;
    eri_struct_compiler_u002e_u1_builder_u002e_Function * _eri_order_4799;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId _eri_order_4800;
    eri_list_compiler_u002e_u1_builder_u002e_ValueId _eri_order_4801;
    eri_struct_compiler_u002e_u1_meta_u002e_LocId _eri_order_4802;
    eri_struct_verifier_u002d_debug_u002e_Harness * _eri_order_4803;
    int64_t _eri_order_4804;
    eri_text _eri_order_4805;
    eri_struct_verifier_u002d_debug_u002e_Harness * v_harness = (_eri_order_4776 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_pred()})), _eri_order_4777 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_verifier_u002d_debug_u002e_create_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4776, _eri_order_4777));
    eri_struct_compiler_u002e_u1_builder_u002e_Function * v_routine = (v_harness)->f_routine;
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_entry = (_eri_order_4778 = (v_routine), _eri_order_4779 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(1, (eri_struct_compiler_u002e_u1_meta_u002e_TypeId[]){fn_compiler_u002e_u1_meta_u002e_pred()})), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4778, _eri_order_4779));
    eri_struct_compiler_u002e_u1_builder_u002e_BlockId v_body = (_eri_order_4780 = (v_routine), _eri_order_4781 = (eri_list_compiler_u002e_u1_meta_u002e_TypeId_make(0, NULL)), fn_compiler_u002e_u1_builder_u002e_block_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_List_u0020_of_u0020_compiler_u002e_u1_meta_u002e_TypeId(_eri_order_4780, _eri_order_4781));
    eri_struct_compiler_u002e_u1_builder_u002e_ValueId v_test = (_eri_order_4782 = (v_routine), _eri_order_4783 = (v_entry), _eri_order_4784 = (0), fn_compiler_u002e_u1_builder_u002e_parameter(_eri_order_4782, _eri_order_4783, _eri_order_4784));
    (_eri_order_4785 = (v_routine), _eri_order_4786 = (v_entry), _eri_order_4787 = (v_body), _eri_order_4788 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_4789 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_jump_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4785, _eri_order_4786, _eri_order_4787, _eri_order_4788, _eri_order_4789));
    int64_t v_index = 0;
    while ((_eri_order_4790 = (v_index), _eri_order_4791 = (128), (_eri_order_4790 < _eri_order_4791))) {
        (_eri_order_4792 = (v_routine), _eri_order_4793 = (v_body), _eri_order_4794 = (v_test), _eri_order_4795 = (1), _eri_order_4796 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_guard(_eri_order_4792, _eri_order_4793, _eri_order_4794, _eri_order_4795, _eri_order_4796));
        v_index = (_eri_order_4797 = (v_index), _eri_order_4798 = (1), eri_iadd(_eri_order_4797, _eri_order_4798));
    }
    (_eri_order_4799 = (v_routine), _eri_order_4800 = (v_body), _eri_order_4801 = (eri_list_compiler_u002e_u1_builder_u002e_ValueId_make(0, NULL)), _eri_order_4802 = ((v_harness)->f_location), fn_compiler_u002e_u1_builder_u002e_returnValues_u0024_identity_u0020_compiler_u002e_u1_builder_u002e_Function_u0024_compiler_u002e_u1_builder_u002e_BlockId_u0024_List_u0020_of_u0020_compiler_u002e_u1_builder_u002e_ValueId_u0024_compiler_u002e_u1_meta_u002e_LocId(_eri_order_4799, _eri_order_4800, _eri_order_4801, _eri_order_4802));
    fn_compiler_u002e_u1_builder_u002e_complete(v_routine);
    (_eri_order_4803 = (v_harness), _eri_order_4804 = (2), _eri_order_4805 = (eri_text_from_bytes((const unsigned char[]){0x6d, 0x61, 0x6e, 0x79, 0x2d, 0x64, 0x6f, 0x6d, 0x69, 0x6e, 0x61, 0x74, 0x65, 0x64, 0x2d, 0x75, 0x73, 0x65, 0x73}, 19)), fn_verifier_u002d_debug_u002e_accepted(_eri_order_4803, _eri_order_4804, _eri_order_4805));
    fn_verifier_u002d_debug_u002e_close(v_harness);
}

static bool fn_verifier_u002d_debug_u002e_run(void) {
    fn_verifier_u002d_debug_u002e_mutations();
    fn_verifier_u002d_debug_u002e_orphanRecords();
    fn_verifier_u002d_debug_u002e_diamond();
    fn_verifier_u002d_debug_u002e_loop();
    fn_verifier_u002d_debug_u002e_dead();
    fn_verifier_u002d_debug_u002e_repeatedTarget();
    fn_verifier_u002d_debug_u002e_limits();
    fn_verifier_u002d_debug_u002e_cancellation();
    fn_verifier_u002d_debug_u002e_scalarShapes();
    fn_verifier_u002d_debug_u002e_manyUses();
    return true;
}

static void fn_verifier_u002d_debug_u002e_main(void) {
    eri_text _eri_order_4807;
    eri_text _eri_order_4808;
    eri_text _eri_order_4809;
    eri_text _eri_order_4810;
    bool v_done;
    eri_handler_frame _eri_h_4806; _eri_h_4806.prev=eri_handler_top; eri_handler_top=&_eri_h_4806;
    if (setjmp(_eri_h_4806.env)==0) {
        v_done = fn_verifier_u002d_debug_u002e_run();
        eri_handler_top = _eri_h_4806.prev;
    } else {
        eri_handler_top = _eri_h_4806.prev;
        eri_failure_value _eri_failure_4806 = eri_failure;
        if (strcmp(_eri_failure_4806.type, "compiler.u1_budget.LimitError") == 0) {
            eri_struct_compiler_u002e_u1_budget_u002e_LimitError v_error = *(eri_struct_compiler_u002e_u1_budget_u002e_LimitError*)_eri_failure_4806.payload;
            eri_out_text((_eri_order_4809 = ((_eri_order_4807 = ((v_error).f_category), _eri_order_4808 = (eri_text_from_bytes((const unsigned char[]){0x3a}, 1)), eri_text_add(_eri_order_4807, _eri_order_4808))), _eri_order_4810 = ((v_error).f_message), eri_text_add(_eri_order_4809, _eri_order_4810)));
            eri_process_setExitCode(1);
            return;
            eri_fault("value error handler completed without terminating");
        }
        else if (strcmp(_eri_failure_4806.type, "compiler.u1_verify.InvalidIR") == 0) {
            eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR v_error = *(eri_struct_compiler_u002e_u1_verify_u002e_InvalidIR*)_eri_failure_4806.payload;
            eri_out_text(eri_text_from_bytes((const unsigned char[]){0x75, 0x6e, 0x65, 0x78, 0x70, 0x65, 0x63, 0x74, 0x65, 0x64, 0x20, 0x69, 0x6e, 0x76, 0x61, 0x6c, 0x69, 0x64, 0x20, 0x49, 0x52}, 21));
            eri_out_text((v_error).f_message);
            eri_out_int((v_error).f_stage);
            eri_out_int((v_error).f_block);
            eri_out_int((v_error).f_instruction);
            eri_process_setExitCode(1);
            return;
            eri_fault("value error handler completed without terminating");
        }
        else if (strcmp(_eri_failure_4806.type, "verifier-debug.ProbeError") == 0) {
            eri_struct_verifier_u002d_debug_u002e_ProbeError v_error = *(eri_struct_verifier_u002d_debug_u002e_ProbeError*)_eri_failure_4806.payload;
            eri_out_text((v_error).f_message);
            eri_process_setExitCode(1);
            return;
            eri_fault("value error handler completed without terminating");
        }
        else { eri_propagate_saved(_eri_failure_4806); }
    }
}

int main(int argc,char **argv) {
    eri_process_argc=argc; eri_process_argv=argv;
    fesetround(FE_TONEAREST);
    fn_verifier_u002d_debug_u002e_main();
    return eri_process_exit_code;
}
