.globl erist_entry
.text
.p2align 4
.type f0, @function
f0:
pushq %rbp
movq %rsp, %rbp
subq $336, %rsp
movq %rdi, -328(%rbp)
movq %rsi, -336(%rbp)
leaq -320(%rbp), %rdi
movq $40, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf0_b0
.Lf0_b10:
movabsq $1, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call evn_int@PLT
movq %rax, -312(%rbp)
movq -8(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rax
leave
ret
.Lf0_b9:
jmp .Lf0_b10
.Lf0_b8:
movabsq $3, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf0_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $9, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
movabsq $5, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -232(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf0_b9
jmp .Lf0_b8
.Lf0_b6:
jmp .Lf0_b7
.Lf0_b5:
movabsq $2, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movq -8(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rax
leave
ret
.Lf0_b4:
movq -144(%rbp), %rax
movq %rax, -88(%rbp)
jmp .Lf0_b2
.Lf0_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $5, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rax
movq %rax, -144(%rbp)
jmp .Lf0_b4
.Lf0_b2:
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf0_b6
jmp .Lf0_b5
.Lf0_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $3, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -104(%rbp), %rsi
movq -120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf0_b4
jmp .Lf0_b3
.Lf0_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -336(%rbp), %rsi
leaq .Lroots_f0(%rip), %rdx
movq $42, %rcx
call evn_bind_roots@PLT
movq -328(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -336(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $1, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $5, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -96(%rbp)
cmpq $0, -96(%rbp)
je .Lf0_b1
jmp .Lf0_b2
.size f0, .-f0
.text
.p2align 4
.type f1, @function
f1:
pushq %rbp
movq %rsp, %rbp
subq $160, %rsp
movq %rdi, -144(%rbp)
movq %rsi, -152(%rbp)
leaq -136(%rbp), %rdi
movq $17, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf1_b0
.Lf1_b3:
movabsq $1, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movq -8(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
leave
ret
.Lf1_b2:
jmp .Lf1_b3
.Lf1_b1:
movabsq $2, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movq -8(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rax
leave
ret
.Lf1_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -152(%rbp), %rsi
leaq .Lroots_f1(%rip), %rdx
movq $19, %rcx
call evn_bind_roots@PLT
movq -144(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -152(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $3, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $5, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf1_b2
jmp .Lf1_b1
.size f1, .-f1
.text
.p2align 4
.type f2, @function
f2:
pushq %rbp
movq %rsp, %rbp
subq $368, %rsp
movq %rdi, -368(%rbp)
leaq -360(%rbp), %rdi
movq $45, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf2_b0
.Lf2_b12:
movabsq $0, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movq -8(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rax
leave
ret
.Lf2_b11:
jmp .Lf2_b12
.Lf2_b10:
movabsq $1, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movq -8(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rax
leave
ret
.Lf2_b9:
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -312(%rbp)
cmpq $0, -312(%rbp)
je .Lf2_b11
jmp .Lf2_b10
.Lf2_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $9, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movabsq $5, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -272(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -256(%rbp)
jmp .Lf2_b9
.Lf2_b7:
movq -200(%rbp), %rax
movq %rax, -256(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf2_b8
jmp .Lf2_b9
.Lf2_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $4, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $5, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -200(%rbp)
jmp .Lf2_b7
.Lf2_b5:
movq -144(%rbp), %rax
movq %rax, -200(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf2_b6
jmp .Lf2_b7
.Lf2_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $2, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $5, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rax
movq %rax, -144(%rbp)
jmp .Lf2_b5
.Lf2_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $1, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -104(%rbp), %rsi
movq -120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf2_b4
jmp .Lf2_b5
.Lf2_b2:
jmp .Lf2_b3
.Lf2_b1:
movabsq $2, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movq -8(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
leave
ret
.Lf2_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -368(%rbp), %rsi
leaq .Lroots_f2(%rip), %rdx
movq $46, %rcx
call evn_bind_roots@PLT
movq -368(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $3, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $5, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -72(%rbp)
cmpq $0, -72(%rbp)
je .Lf2_b2
jmp .Lf2_b1
.size f2, .-f2
.text
.p2align 4
.type f3, @function
f3:
pushq %rbp
movq %rsp, %rbp
subq $400, %rsp
movq %rdi, -400(%rbp)
leaq -392(%rbp), %rdi
movq $49, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf3_b0
.Lf3_b13:
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movq -8(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rax
leave
ret
.Lf3_b12:
jmp .Lf3_b13
.Lf3_b11:
movabsq $1, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $0, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_unary@PLT
movq %rax, -360(%rbp)
movq -8(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
leave
ret
.Lf3_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $8, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movabsq $5, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -288(%rbp), %rsi
movq -304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_truth@PLT
movq %rax, -328(%rbp)
cmpq $0, -328(%rbp)
je .Lf3_b12
jmp .Lf3_b11
.Lf3_b9:
jmp .Lf3_b10
.Lf3_b8:
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movq -8(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rax
leave
ret
.Lf3_b7:
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -256(%rbp)
cmpq $0, -256(%rbp)
je .Lf3_b9
jmp .Lf3_b8
.Lf3_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $7, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $5, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -200(%rbp)
jmp .Lf3_b7
.Lf3_b5:
movq -144(%rbp), %rax
movq %rax, -200(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf3_b6
jmp .Lf3_b7
.Lf3_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $5, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $5, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rax
movq %rax, -144(%rbp)
jmp .Lf3_b5
.Lf3_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -104(%rbp), %rsi
movq -120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf3_b4
jmp .Lf3_b5
.Lf3_b2:
jmp .Lf3_b3
.Lf3_b1:
movabsq $2, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movq -8(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
leave
ret
.Lf3_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -400(%rbp), %rsi
leaq .Lroots_f3(%rip), %rdx
movq $50, %rcx
call evn_bind_roots@PLT
movq -400(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $3, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $5, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -72(%rbp)
cmpq $0, -72(%rbp)
je .Lf3_b2
jmp .Lf3_b1
.size f3, .-f3
.text
.p2align 4
.type f4, @function
f4:
pushq %rbp
movq %rsp, %rbp
subq $144, %rsp
movq %rdi, -136(%rbp)
leaq -128(%rbp), %rdi
movq $16, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf4_b0
.Lf4_b2:
movq -8(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
leave
ret
.Lf4_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $8, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movabsq $8, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rax
movq %rax, -72(%rbp)
jmp .Lf4_b2
.Lf4_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -136(%rbp), %rsi
leaq .Lroots_f4(%rip), %rdx
movq $17, %rcx
call evn_bind_roots@PLT
movq -136(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $6, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $10, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -80(%rbp)
cmpq $0, -80(%rbp)
je .Lf4_b2
jmp .Lf4_b1
.size f4, .-f4
.text
.p2align 4
.type f5, @function
f5:
pushq %rbp
movq %rsp, %rbp
subq $144, %rsp
movq %rdi, -136(%rbp)
leaq -128(%rbp), %rdi
movq $16, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf5_b0
.Lf5_b2:
movq -8(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
leave
ret
.Lf5_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $9, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movabsq $8, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rax
movq %rax, -72(%rbp)
jmp .Lf5_b2
.Lf5_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -136(%rbp), %rsi
leaq .Lroots_f5(%rip), %rdx
movq $17, %rcx
call evn_bind_roots@PLT
movq -136(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $1, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $10, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -80(%rbp)
cmpq $0, -80(%rbp)
je .Lf5_b2
jmp .Lf5_b1
.size f5, .-f5
.text
.p2align 4
.type f6, @function
f6:
pushq %rbp
movq %rsp, %rbp
subq $480, %rsp
movq %rdi, -472(%rbp)
leaq -464(%rbp), %rdi
movq $58, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf6_b0
.Lf6_b8:
movabsq $0, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movabsq $6, %rax
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movabsq $0, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $5, %rax
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -24(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_store@PLT
movq %rax, -408(%rbp)
movabsq $3, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movabsq $10, %rax
movq %rax, -432(%rbp)
movq -24(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_store@PLT
movq %rax, -448(%rbp)
call evn_void@PLT
movq %rax, -456(%rbp)
movq -8(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
leave
ret
.Lf6_b7:
jmp .Lf6_b8
.Lf6_b6:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_get@PLT
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call f7@PLT
movq %rax, -288(%rbp)
jmp .Lf6_b8
.Lf6_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $12, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movq -32(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $8, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_none@PLT
movq %rax, -232(%rbp)
movabsq $6, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_truth@PLT
movq %rax, -256(%rbp)
cmpq $0, -256(%rbp)
je .Lf6_b7
jmp .Lf6_b6
.Lf6_b4:
jmp .Lf6_b5
.Lf6_b3:
call f34@PLT
movq %rax, -176(%rbp)
jmp .Lf6_b5
.Lf6_b2:
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -168(%rbp)
cmpq $0, -168(%rbp)
je .Lf6_b4
jmp .Lf6_b3
.Lf6_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $12, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $8, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_none@PLT
movq %rax, -144(%rbp)
movabsq $5, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
movq %rax, -96(%rbp)
jmp .Lf6_b2
.Lf6_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -472(%rbp), %rsi
leaq .Lroots_f6(%rip), %rdx
movq $59, %rcx
call evn_bind_roots@PLT
movq -472(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $10, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_member@PLT
movq %rax, -56(%rbp)
movabsq $3, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $5, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -56(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf6_b1
jmp .Lf6_b2
.size f6, .-f6
.text
.p2align 4
.type f7, @function
f7:
pushq %rbp
movq %rsp, %rbp
subq $576, %rsp
movq %rdi, -568(%rbp)
movq %rsi, -576(%rbp)
leaq -560(%rbp), %rdi
movq $70, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf7_b0
.Lf7_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $6, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_member@PLT
movq %rax, -304(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movabsq $6, %rax
movq %rax, -320(%rbp)
movq -312(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_member@PLT
movq %rax, -328(%rbp)
movabsq $1, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -304(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movabsq $6, %rax
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -368(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $5, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $5, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movabsq $1, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -392(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_binary@PLT
movq %rax, -432(%rbp)
movabsq $5, %rax
movq %rax, -440(%rbp)
movq -24(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_store@PLT
movq %rax, -456(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $1, %rax
movq %rax, -472(%rbp)
movq -464(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_member@PLT
movq %rax, -480(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $1, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movabsq $1, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
movq -480(%rbp), %rsi
movq -504(%rbp), %rdx
call evn_binary@PLT
movq %rax, -520(%rbp)
movabsq $1, %rax
movq %rax, -528(%rbp)
movq -24(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_store@PLT
movq %rax, -544(%rbp)
call evn_void@PLT
movq %rax, -552(%rbp)
movq -8(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rax
leave
ret
.Lf7_b6:
jmp .Lf7_b7
.Lf7_b5:
call f34@PLT
movq %rax, -280(%rbp)
jmp .Lf7_b7
.Lf7_b4:
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf7_b6
jmp .Lf7_b5
.Lf7_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movabsq $9, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -224(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
movq %rax, -192(%rbp)
jmp .Lf7_b4
.Lf7_b2:
movq -112(%rbp), %rax
movq %rax, -192(%rbp)
movq -112(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf7_b3
jmp .Lf7_b4
.Lf7_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $5, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $5, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movabsq $9, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -144(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -112(%rbp)
jmp .Lf7_b2
.Lf7_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -576(%rbp), %rsi
leaq .Lroots_f7(%rip), %rdx
movq $72, %rcx
call evn_bind_roots@PLT
movq -568(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -576(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $6, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $6, %rax
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_member@PLT
movq %rax, -88(%rbp)
movabsq $9, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -64(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -120(%rbp)
cmpq $0, -120(%rbp)
je .Lf7_b1
jmp .Lf7_b2
.size f7, .-f7
.text
.p2align 4
.type f8, @function
f8:
pushq %rbp
movq %rsp, %rbp
subq $384, %rsp
movq %rdi, -376(%rbp)
leaq -368(%rbp), %rdi
movq $46, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf8_b0
.Lf8_b9:
movabsq $3, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $10, %rax
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
call evn_void@PLT
movq %rax, -360(%rbp)
movq -8(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
leave
ret
.Lf8_b8:
jmp .Lf8_b9
.Lf8_b7:
call f34@PLT
movq %rax, -312(%rbp)
jmp .Lf8_b9
.Lf8_b6:
movq -232(%rbp), %rdi
call evn_truth@PLT
movq %rax, -304(%rbp)
cmpq $0, -304(%rbp)
je .Lf8_b8
jmp .Lf8_b7
.Lf8_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movabsq $0, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_int@PLT
movq %rax, -280(%rbp)
movabsq $6, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -264(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
movq %rax, -232(%rbp)
jmp .Lf8_b6
.Lf8_b4:
movq -160(%rbp), %rax
movq %rax, -232(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -240(%rbp)
cmpq $0, -240(%rbp)
je .Lf8_b5
jmp .Lf8_b6
.Lf8_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $5, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $0, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movabsq $6, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rax
movq %rax, -160(%rbp)
jmp .Lf8_b4
.Lf8_b2:
movq -88(%rbp), %rax
movq %rax, -160(%rbp)
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -168(%rbp)
cmpq $0, -168(%rbp)
je .Lf8_b3
jmp .Lf8_b4
.Lf8_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $6, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $6, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
movq %rax, -88(%rbp)
jmp .Lf8_b2
.Lf8_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -376(%rbp), %rsi
leaq .Lroots_f8(%rip), %rdx
movq $47, %rcx
call evn_bind_roots@PLT
movq -376(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $10, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movabsq $3, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $5, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -96(%rbp)
cmpq $0, -96(%rbp)
je .Lf8_b1
jmp .Lf8_b2
.size f8, .-f8
.text
.p2align 4
.type f9, @function
f9:
pushq %rbp
movq %rsp, %rbp
subq $64, %rsp
movq %rdi, -64(%rbp)
leaq -56(%rbp), %rdi
movq $7, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf9_b0
.Lf9_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -64(%rbp), %rsi
leaq .Lroots_f9(%rip), %rdx
movq $8, %rcx
call evn_bind_roots@PLT
movq -64(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call f32@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -8(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rax
leave
ret
.size f9, .-f9
.text
.p2align 4
.type f10, @function
f10:
pushq %rbp
movq %rsp, %rbp
subq $96, %rsp
movq %rdi, -88(%rbp)
leaq -80(%rbp), %rdi
movq $10, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf10_b0
.Lf10_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -88(%rbp), %rsi
leaq .Lroots_f10(%rip), %rdx
movq $11, %rcx
call evn_bind_roots@PLT
movq -88(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movabsq $2, %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_int@PLT
movq %rax, -40(%rbp)
movabsq $10, %rax
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_store@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -8(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rax
leave
ret
.size f10, .-f10
.text
.p2align 4
.type f11, @function
f11:
pushq %rbp
movq %rsp, %rbp
subq $336, %rsp
movq %rdi, -320(%rbp)
movq %rsi, -328(%rbp)
leaq -312(%rbp), %rdi
movq $39, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf11_b0
.Lf11_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call f12@PLT
movq %rax, -296(%rbp)
call evn_void@PLT
movq %rax, -304(%rbp)
movq -8(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
leave
ret
.Lf11_b7:
jmp .Lf11_b8
.Lf11_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -224(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -264(%rbp)
movq -216(%rbp), %rdi
movq -264(%rbp), %rsi
call f13@PLT
movq %rax, -272(%rbp)
jmp .Lf11_b8
.Lf11_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $7, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -176(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf11_b7
jmp .Lf11_b6
.Lf11_b4:
jmp .Lf11_b5
.Lf11_b3:
call f34@PLT
movq %rax, -152(%rbp)
jmp .Lf11_b5
.Lf11_b2:
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf11_b4
jmp .Lf11_b3
.Lf11_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $1024, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movabsq $9, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -104(%rbp), %rsi
movq -120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
movq %rax, -88(%rbp)
jmp .Lf11_b2
.Lf11_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -328(%rbp), %rsi
leaq .Lroots_f11(%rip), %rdx
movq $41, %rcx
call evn_bind_roots@PLT
movq -320(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -328(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $7, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -96(%rbp)
cmpq $0, -96(%rbp)
je .Lf11_b1
jmp .Lf11_b2
.size f11, .-f11
.text
.p2align 4
.type f12, @function
f12:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
movq %rdi, -488(%rbp)
movq %rsi, -496(%rbp)
leaq -480(%rbp), %rdi
movq $60, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf12_b0
.Lf12_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $1, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member@PLT
movq %rax, -344(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $1, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -344(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movabsq $1, %rax
movq %rax, -376(%rbp)
movq -24(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_store@PLT
movq %rax, -392(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $2, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -416(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movabsq $2, %rax
movq %rax, -448(%rbp)
movq -24(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_store@PLT
movq %rax, -464(%rbp)
call evn_void@PLT
movq %rax, -472(%rbp)
movq -8(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
leave
ret
.Lf12_b8:
jmp .Lf12_b9
.Lf12_b7:
call f34@PLT
movq %rax, -320(%rbp)
jmp .Lf12_b9
.Lf12_b6:
movq -248(%rbp), %rdi
call evn_truth@PLT
movq %rax, -312(%rbp)
cmpq $0, -312(%rbp)
je .Lf12_b8
jmp .Lf12_b7
.Lf12_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movabsq $9, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -264(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -248(%rbp)
jmp .Lf12_b6
.Lf12_b4:
movq -192(%rbp), %rax
movq %rax, -248(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -256(%rbp)
cmpq $0, -256(%rbp)
je .Lf12_b5
jmp .Lf12_b6
.Lf12_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1024, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $9, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rax
movq %rax, -192(%rbp)
jmp .Lf12_b4
.Lf12_b2:
movq -136(%rbp), %rax
movq %rax, -192(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf12_b3
jmp .Lf12_b4
.Lf12_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $7, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -136(%rbp)
jmp .Lf12_b2
.Lf12_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -496(%rbp), %rsi
leaq .Lroots_f12(%rip), %rdx
movq $62, %rcx
call evn_bind_roots@PLT
movq -488(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -496(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $4, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call f32@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf12_b1
jmp .Lf12_b2
.size f12, .-f12
.text
.p2align 4
.type f13, @function
f13:
pushq %rbp
movq %rsp, %rbp
subq $1392, %rsp
movq %rdi, -1376(%rbp)
movq %rsi, -1384(%rbp)
leaq -1368(%rbp), %rdi
movq $171, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf13_b0
.Lf13_b22:
call evn_void@PLT
movq %rax, -1360(%rbp)
movq -8(%rbp), %rdi
movq -1360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1368(%rbp)
movq -1368(%rbp), %rax
leave
ret
.Lf13_b21:
jmp .Lf13_b22
.Lf13_b20:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rdi
call evn_get@PLT
movq %rax, -1280(%rbp)
movabsq $0, %rax
movq %rax, -1288(%rbp)
movq -1280(%rbp), %rdi
movq -1288(%rbp), %rsi
call evn_member@PLT
movq %rax, -1296(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1304(%rbp)
movabsq $0, %rax
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
movq -1296(%rbp), %rsi
movq -1304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1320(%rbp)
movq -56(%rbp), %rdi
call evn_get_ref@PLT
movq %rax, -1328(%rbp)
movabsq $0, %rax
movq %rax, -1336(%rbp)
movq -1328(%rbp), %rdi
movq -1336(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1344(%rbp)
movq -1344(%rbp), %rdi
movq -1320(%rbp), %rsi
call evn_store@PLT
movq %rax, -1352(%rbp)
jmp .Lf13_b22
.Lf13_b19:
jmp .Lf13_b16
.Lf13_b18:
jmp .Lf13_b19
.Lf13_b17:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -984(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
call evn_get@PLT
movq %rax, -1000(%rbp)
movabsq $7, %rax
movq %rax, -1008(%rbp)
movq -1000(%rbp), %rdi
movq -1008(%rbp), %rsi
call evn_member@PLT
movq %rax, -1016(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movq -1024(%rbp), %rdi
call evn_get@PLT
movq %rax, -1032(%rbp)
movabsq $0, %rax
movq %rax, -1040(%rbp)
movq -1032(%rbp), %rdi
movq -1040(%rbp), %rsi
call evn_member@PLT
movq %rax, -1048(%rbp)
movabsq $1, %rax
movq %rax, -1056(%rbp)
movq -1056(%rbp), %rdi
movq -1016(%rbp), %rsi
movq -1048(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1064(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
movq -1064(%rbp), %rdx
call f31@PLT
movq %rax, -1072(%rbp)
jmp .Lf13_b19
.Lf13_b16:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1080(%rbp)
movabsq $1, %rax
movq %rax, -1088(%rbp)
movq -1080(%rbp), %rdi
movq -1088(%rbp), %rsi
call evn_member@PLT
movq %rax, -1096(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $0, %rax
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
movq -1096(%rbp), %rsi
movq -1104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1120(%rbp)
movabsq $1, %rax
movq %rax, -1128(%rbp)
movq -24(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1136(%rbp)
movq -1136(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_store@PLT
movq %rax, -1144(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1152(%rbp)
movabsq $0, %rax
movq %rax, -1160(%rbp)
movq -1152(%rbp), %rdi
movq -1160(%rbp), %rsi
call evn_member@PLT
movq %rax, -1168(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1176(%rbp)
movabsq $0, %rax
movq %rax, -1184(%rbp)
movq -1184(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1192(%rbp)
movabsq $0, %rax
movq %rax, -1200(%rbp)
movq -48(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1208(%rbp)
movq -1208(%rbp), %rdi
movq -1192(%rbp), %rsi
call evn_store@PLT
movq %rax, -1216(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1224(%rbp)
movabsq $8, %rax
movq %rax, -1232(%rbp)
movq -1232(%rbp), %rdi
call evn_none@PLT
movq %rax, -1240(%rbp)
movabsq $6, %rax
movq %rax, -1248(%rbp)
movq -1248(%rbp), %rdi
movq -1224(%rbp), %rsi
movq -1240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1264(%rbp)
cmpq $0, -1264(%rbp)
je .Lf13_b21
jmp .Lf13_b20
.Lf13_b15:
jmp .Lf13_b16
.Lf13_b14:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movq -872(%rbp), %rdi
call evn_get@PLT
movq %rax, -880(%rbp)
movabsq $7, %rax
movq %rax, -888(%rbp)
movq -880(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_member@PLT
movq %rax, -896(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_get@PLT
movq %rax, -912(%rbp)
movabsq $0, %rax
movq %rax, -920(%rbp)
movq -912(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_member@PLT
movq %rax, -928(%rbp)
movabsq $1, %rax
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
movq -896(%rbp), %rsi
movq -928(%rbp), %rdx
call evn_binary@PLT
movq %rax, -944(%rbp)
movabsq $9, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
movq -864(%rbp), %rsi
movq -944(%rbp), %rdx
call evn_binary@PLT
movq %rax, -960(%rbp)
movq -960(%rbp), %rdi
call evn_truth@PLT
movq %rax, -968(%rbp)
cmpq $0, -968(%rbp)
je .Lf13_b18
jmp .Lf13_b17
.Lf13_b13:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $12, %rax
movq %rax, -792(%rbp)
movq -784(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member@PLT
movq %rax, -800(%rbp)
movq -56(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_store@PLT
movq %rax, -808(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movabsq $8, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call evn_none@PLT
movq %rax, -832(%rbp)
movabsq $6, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
movq -816(%rbp), %rsi
movq -832(%rbp), %rdx
call evn_binary@PLT
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
call evn_truth@PLT
movq %rax, -856(%rbp)
cmpq $0, -856(%rbp)
je .Lf13_b15
jmp .Lf13_b14
.Lf13_b12:
jmp .Lf13_b13
.Lf13_b11:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movabsq $7, %rax
movq %rax, -720(%rbp)
movq -712(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_member@PLT
movq %rax, -728(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $0, %rax
movq %rax, -744(%rbp)
movq -736(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member@PLT
movq %rax, -752(%rbp)
movabsq $1, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
movq -728(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_binary@PLT
movq %rax, -768(%rbp)
movq -696(%rbp), %rdi
movq -704(%rbp), %rsi
movq -768(%rbp), %rdx
call f31@PLT
movq %rax, -776(%rbp)
jmp .Lf13_b13
.Lf13_b10:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $7, %rax
movq %rax, -616(%rbp)
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
call evn_member@PLT
movq %rax, -624(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $0, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_member@PLT
movq %rax, -648(%rbp)
movabsq $1, %rax
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
movq -624(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_binary@PLT
movq %rax, -664(%rbp)
movabsq $9, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
movq -600(%rbp), %rsi
movq -664(%rbp), %rdx
call evn_binary@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rdi
call evn_truth@PLT
movq %rax, -688(%rbp)
cmpq $0, -688(%rbp)
je .Lf13_b12
jmp .Lf13_b11
.Lf13_b9:
jmp .Lf13_b10
.Lf13_b8:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $3, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $2, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movabsq $1, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -504(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -552(%rbp)
movabsq $1, %rax
movq %rax, -560(%rbp)
movq -552(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_member@PLT
movq %rax, -568(%rbp)
movabsq $1, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
movq -544(%rbp), %rsi
movq -568(%rbp), %rdx
call evn_binary@PLT
movq %rax, -584(%rbp)
movq -472(%rbp), %rdi
movq -480(%rbp), %rsi
movq -584(%rbp), %rdx
call f31@PLT
movq %rax, -592(%rbp)
jmp .Lf13_b10
.Lf13_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $2, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -360(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $1, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -400(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movabsq $9, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -336(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_truth@PLT
movq %rax, -464(%rbp)
cmpq $0, -464(%rbp)
je .Lf13_b9
jmp .Lf13_b8
.Lf13_b6:
jmp .Lf13_b7
.Lf13_b5:
call f34@PLT
movq %rax, -328(%rbp)
jmp .Lf13_b7
.Lf13_b4:
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf13_b6
jmp .Lf13_b5
.Lf13_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $1024, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_int@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $1, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movabsq $1, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -256(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movabsq $9, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -240(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
movq %rax, -224(%rbp)
jmp .Lf13_b4
.Lf13_b2:
movq -168(%rbp), %rax
movq %rax, -224(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf13_b3
jmp .Lf13_b4
.Lf13_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $7, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -168(%rbp)
jmp .Lf13_b2
.Lf13_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1384(%rbp), %rsi
leaq .Lroots_f13(%rip), %rdx
movq $173, %rcx
call evn_bind_roots@PLT
movq -1376(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1384(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $4, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -48(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_store@PLT
movq %rax, -88(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call f32@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $0, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $6, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf13_b1
jmp .Lf13_b2
.size f13, .-f13
.text
.p2align 4
.type f14, @function
f14:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
movq %rdi, -312(%rbp)
movq %rsi, -320(%rbp)
leaq -304(%rbp), %rdi
movq $38, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf14_b0
.Lf14_b3:
movabsq $10, %rax
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_object@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $4, %rax
movq %rax, -152(%rbp)
movq -136(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $3, %rax
movq %rax, -176(%rbp)
movq -136(%rbp), %rdi
movq -176(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_init@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $2, %rax
movq %rax, -208(%rbp)
movq -136(%rbp), %rdi
movq -208(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_init@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -136(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movabsq $0, %rax
movq %rax, -272(%rbp)
movq -136(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $11, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -296(%rbp)
movq -8(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
leave
ret
.Lf14_b2:
jmp .Lf14_b3
.Lf14_b1:
call f34@PLT
movq %rax, -112(%rbp)
jmp .Lf14_b3
.Lf14_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -320(%rbp), %rsi
leaq .Lroots_f14(%rip), %rdx
movq $40, %rcx
call evn_bind_roots@PLT
movq -312(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -320(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call f32@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf14_b2
jmp .Lf14_b1
.size f14, .-f14
.text
.p2align 4
.type f15, @function
f15:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
movq %rdi, -488(%rbp)
movq %rsi, -496(%rbp)
leaq -480(%rbp), %rdi
movq $60, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf15_b0
.Lf15_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $1, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -288(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movabsq $1, %rax
movq %rax, -320(%rbp)
movq -24(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_store@PLT
movq %rax, -336(%rbp)
movabsq $12, %rax
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_object@PLT
movq %rax, -360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $2, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $2, %rax
movq %rax, -392(%rbp)
movq -360(%rbp), %rdi
movq -392(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_init@PLT
movq %rax, -400(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -360(%rbp), %rdi
movq -416(%rbp), %rsi
movq -408(%rbp), %rdx
call evn_init@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movabsq $0, %rax
movq %rax, -448(%rbp)
movq -360(%rbp), %rdi
movq -448(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_init@PLT
movq %rax, -456(%rbp)
movabsq $13, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -472(%rbp)
movq -8(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
leave
ret
.Lf15_b6:
jmp .Lf15_b7
.Lf15_b5:
call f34@PLT
movq %rax, -264(%rbp)
jmp .Lf15_b7
.Lf15_b4:
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -256(%rbp)
cmpq $0, -256(%rbp)
je .Lf15_b6
jmp .Lf15_b5
.Lf15_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movabsq $9, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -208(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -192(%rbp)
jmp .Lf15_b4
.Lf15_b2:
movq -136(%rbp), %rax
movq %rax, -192(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf15_b3
jmp .Lf15_b4
.Lf15_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $7, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -136(%rbp)
jmp .Lf15_b2
.Lf15_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -496(%rbp), %rsi
leaq .Lroots_f15(%rip), %rdx
movq $62, %rcx
call evn_bind_roots@PLT
movq -488(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -496(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $2, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call f32@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf15_b1
jmp .Lf15_b2
.size f15, .-f15
.text
.p2align 4
.type f16, @function
f16:
pushq %rbp
movq %rsp, %rbp
subq $1392, %rsp
movq %rdi, -1376(%rbp)
movq %rsi, -1384(%rbp)
leaq -1368(%rbp), %rdi
movq $171, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf16_b0
.Lf16_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1328(%rbp)
movabsq $2, %rax
movq %rax, -1336(%rbp)
movq -24(%rbp), %rdi
movq -1336(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1344(%rbp)
movq -1344(%rbp), %rdi
movq -1328(%rbp), %rsi
call evn_store@PLT
movq %rax, -1352(%rbp)
call evn_void@PLT
movq %rax, -1360(%rbp)
movq -8(%rbp), %rdi
movq -1360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1368(%rbp)
movq -1368(%rbp), %rax
leave
ret
.Lf16_b24:
jmp .Lf16_b25
.Lf16_b23:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1296(%rbp)
movabsq $3, %rax
movq %rax, -1304(%rbp)
movq -40(%rbp), %rdi
movq -1304(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
movq -1296(%rbp), %rsi
call evn_store@PLT
movq %rax, -1320(%rbp)
jmp .Lf16_b25
.Lf16_b22:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $6, %rax
movq %rax, -1176(%rbp)
movq -1168(%rbp), %rdi
movq -1176(%rbp), %rsi
call evn_member@PLT
movq %rax, -1184(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1192(%rbp)
movabsq $5, %rax
movq %rax, -1200(%rbp)
movq -1192(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_member@PLT
movq %rax, -1208(%rbp)
movabsq $0, %rax
movq %rax, -1216(%rbp)
movq -1216(%rbp), %rdi
movq -1184(%rbp), %rsi
movq -1208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1224(%rbp)
movq -72(%rbp), %rdi
movq -1224(%rbp), %rsi
call evn_store@PLT
movq %rax, -1232(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1240(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movabsq $3, %rax
movq %rax, -1256(%rbp)
movq -1248(%rbp), %rdi
movq -1256(%rbp), %rsi
call evn_member@PLT
movq %rax, -1264(%rbp)
movabsq $9, %rax
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rdi
movq -1240(%rbp), %rsi
movq -1264(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1280(%rbp)
movq -1280(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1288(%rbp)
cmpq $0, -1288(%rbp)
je .Lf16_b24
jmp .Lf16_b23
.Lf16_b21:
jmp .Lf16_b22
.Lf16_b20:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1120(%rbp)
movabsq $6, %rax
movq %rax, -1128(%rbp)
movq -1120(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_member@PLT
movq %rax, -1136(%rbp)
movabsq $4, %rax
movq %rax, -1144(%rbp)
movq -40(%rbp), %rdi
movq -1144(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1152(%rbp)
movq -1152(%rbp), %rdi
movq -1136(%rbp), %rsi
call evn_store@PLT
movq %rax, -1160(%rbp)
jmp .Lf16_b22
.Lf16_b19:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movabsq $6, %rax
movq %rax, -880(%rbp)
movq -872(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_member@PLT
movq %rax, -888(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $1, %rax
movq %rax, -904(%rbp)
movq -896(%rbp), %rdi
movq -904(%rbp), %rsi
call evn_member@PLT
movq %rax, -912(%rbp)
movabsq $1, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
movq -888(%rbp), %rsi
movq -912(%rbp), %rdx
call evn_binary@PLT
movq %rax, -928(%rbp)
movabsq $6, %rax
movq %rax, -936(%rbp)
movq -48(%rbp), %rdi
movq -936(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -944(%rbp)
movq -944(%rbp), %rdi
movq -928(%rbp), %rsi
call evn_store@PLT
movq %rax, -952(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movabsq $6, %rax
movq %rax, -968(%rbp)
movq -960(%rbp), %rdi
movq -968(%rbp), %rsi
call evn_member@PLT
movq %rax, -976(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -984(%rbp)
movabsq $1, %rax
movq %rax, -992(%rbp)
movq -984(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_member@PLT
movq %rax, -1000(%rbp)
movabsq $0, %rax
movq %rax, -1008(%rbp)
movq -1008(%rbp), %rdi
movq -976(%rbp), %rsi
movq -1000(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1016(%rbp)
movabsq $6, %rax
movq %rax, -1024(%rbp)
movq -40(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
movq -1016(%rbp), %rsi
call evn_store@PLT
movq %rax, -1040(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1048(%rbp)
movabsq $6, %rax
movq %rax, -1056(%rbp)
movq -1048(%rbp), %rdi
movq -1056(%rbp), %rsi
call evn_member@PLT
movq %rax, -1064(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movabsq $4, %rax
movq %rax, -1080(%rbp)
movq -1072(%rbp), %rdi
movq -1080(%rbp), %rsi
call evn_member@PLT
movq %rax, -1088(%rbp)
movabsq $9, %rax
movq %rax, -1096(%rbp)
movq -1096(%rbp), %rdi
movq -1064(%rbp), %rsi
movq -1088(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1104(%rbp)
movq -1104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1112(%rbp)
cmpq $0, -1112(%rbp)
je .Lf16_b21
jmp .Lf16_b20
.Lf16_b18:
jmp .Lf16_b19
.Lf16_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $1, %rax
movq %rax, -744(%rbp)
movq -736(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member@PLT
movq %rax, -752(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movabsq $9, %rax
movq %rax, -768(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_member@PLT
movq %rax, -776(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $6, %rax
movq %rax, -792(%rbp)
movq -784(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member@PLT
movq %rax, -800(%rbp)
movabsq $1, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
movq -776(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -816(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -824(%rbp)
movabsq $5, %rax
movq %rax, -832(%rbp)
movq -824(%rbp), %rdi
movq -832(%rbp), %rsi
call evn_member@PLT
movq %rax, -840(%rbp)
movabsq $1, %rax
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
movq -816(%rbp), %rsi
movq -840(%rbp), %rdx
call evn_binary@PLT
movq %rax, -856(%rbp)
movq -728(%rbp), %rdi
movq -752(%rbp), %rsi
movq -856(%rbp), %rdx
call f31@PLT
movq %rax, -864(%rbp)
jmp .Lf16_b19
.Lf16_b16:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $1, %rax
movq %rax, -584(%rbp)
movq -576(%rbp), %rdi
movq -584(%rbp), %rsi
call evn_member@PLT
movq %rax, -592(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $9, %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_member@PLT
movq %rax, -616(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $6, %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_member@PLT
movq %rax, -640(%rbp)
movabsq $1, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
movq -616(%rbp), %rsi
movq -640(%rbp), %rdx
call evn_binary@PLT
movq %rax, -656(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movabsq $5, %rax
movq %rax, -672(%rbp)
movq -664(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_member@PLT
movq %rax, -680(%rbp)
movabsq $1, %rax
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
movq -656(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_binary@PLT
movq %rax, -696(%rbp)
movabsq $9, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
movq -592(%rbp), %rsi
movq -696(%rbp), %rdx
call evn_binary@PLT
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
call evn_truth@PLT
movq %rax, -720(%rbp)
cmpq $0, -720(%rbp)
je .Lf16_b18
jmp .Lf16_b17
.Lf16_b15:
jmp .Lf16_b16
.Lf16_b14:
call f34@PLT
movq %rax, -568(%rbp)
jmp .Lf16_b16
.Lf16_b13:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $1, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_member@PLT
movq %rax, -512(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movabsq $6, %rax
movq %rax, -528(%rbp)
movq -520(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_member@PLT
movq %rax, -536(%rbp)
movabsq $9, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
movq -512(%rbp), %rsi
movq -536(%rbp), %rdx
call evn_binary@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_truth@PLT
movq %rax, -560(%rbp)
cmpq $0, -560(%rbp)
je .Lf16_b15
jmp .Lf16_b14
.Lf16_b12:
jmp .Lf16_b13
.Lf16_b11:
call f34@PLT
movq %rax, -488(%rbp)
jmp .Lf16_b13
.Lf16_b10:
movq -432(%rbp), %rdi
call evn_truth@PLT
movq %rax, -480(%rbp)
cmpq $0, -480(%rbp)
je .Lf16_b12
jmp .Lf16_b11
.Lf16_b9:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $6, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -448(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rax
movq %rax, -432(%rbp)
jmp .Lf16_b10
.Lf16_b8:
movq -376(%rbp), %rax
movq %rax, -432(%rbp)
movq -376(%rbp), %rdi
call evn_truth@PLT
movq %rax, -440(%rbp)
cmpq $0, -440(%rbp)
je .Lf16_b9
jmp .Lf16_b10
.Lf16_b7:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $8, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call evn_none@PLT
movq %rax, -408(%rbp)
movabsq $5, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
movq -392(%rbp), %rsi
movq -408(%rbp), %rdx
call evn_binary@PLT
movq %rax, -424(%rbp)
movq -424(%rbp), %rax
movq %rax, -376(%rbp)
jmp .Lf16_b8
.Lf16_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $12, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -56(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $12, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movq -64(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $8, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_none@PLT
movq %rax, -352(%rbp)
movabsq $5, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -336(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -384(%rbp)
cmpq $0, -384(%rbp)
je .Lf16_b7
jmp .Lf16_b8
.Lf16_b5:
jmp .Lf16_b6
.Lf16_b4:
call evn_void@PLT
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf16_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $2, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movq -48(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_store@PLT
movq %rax, -176(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call f32@PLT
movq %rax, -192(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call f32@PLT
movq %rax, -208(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $5, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -216(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf16_b5
jmp .Lf16_b4
.Lf16_b2:
jmp .Lf16_b3
.Lf16_b1:
call f34@PLT
movq %rax, -144(%rbp)
jmp .Lf16_b3
.Lf16_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1384(%rbp), %rsi
leaq .Lroots_f16(%rip), %rdx
movq $173, %rcx
call evn_bind_roots@PLT
movq -1376(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1384(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf16_b2
jmp .Lf16_b1
.size f16, .-f16
.text
.p2align 4
.type f17, @function
f17:
pushq %rbp
movq %rsp, %rbp
subq $784, %rsp
movq %rdi, -784(%rbp)
leaq -776(%rbp), %rdi
movq $97, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf17_b0
.Lf17_b17:
movabsq $1, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_int@PLT
movq %rax, -736(%rbp)
movabsq $0, %rax
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_store@PLT
movq %rax, -760(%rbp)
call evn_void@PLT
movq %rax, -768(%rbp)
movq -8(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rax
leave
ret
.Lf17_b16:
jmp .Lf17_b17
.Lf17_b15:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
call evn_get@PLT
movq %rax, -632(%rbp)
movabsq $6, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_member@PLT
movq %rax, -648(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $1, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movabsq $1, %rax
movq %rax, -680(%rbp)
movq -680(%rbp), %rdi
movq -648(%rbp), %rsi
movq -672(%rbp), %rdx
call evn_binary@PLT
movq %rax, -688(%rbp)
movq -40(%rbp), %rdi
call evn_get_ref@PLT
movq %rax, -696(%rbp)
movabsq $6, %rax
movq %rax, -704(%rbp)
movq -696(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
call evn_store@PLT
movq %rax, -720(%rbp)
jmp .Lf17_b17
.Lf17_b14:
jmp .Lf17_b11
.Lf17_b13:
jmp .Lf17_b14
.Lf17_b12:
call f34@PLT
movq %rax, -480(%rbp)
jmp .Lf17_b14
.Lf17_b11:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $6, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $1, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movabsq $1, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -504(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movabsq $6, %rax
movq %rax, -552(%rbp)
movq -32(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_store@PLT
movq %rax, -568(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $8, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_none@PLT
movq %rax, -592(%rbp)
movabsq $6, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf17_b16
jmp .Lf17_b15
.Lf17_b10:
jmp .Lf17_b11
.Lf17_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $1, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_get@PLT
movq %rax, -432(%rbp)
movabsq $6, %rax
movq %rax, -440(%rbp)
movq -432(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_member@PLT
movq %rax, -448(%rbp)
movabsq $9, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -416(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_truth@PLT
movq %rax, -472(%rbp)
cmpq $0, -472(%rbp)
je .Lf17_b13
jmp .Lf17_b12
.Lf17_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $8, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_none@PLT
movq %rax, -368(%rbp)
movabsq $6, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_truth@PLT
movq %rax, -392(%rbp)
cmpq $0, -392(%rbp)
je .Lf17_b10
jmp .Lf17_b9
.Lf17_b7:
jmp .Lf17_b8
.Lf17_b6:
call f34@PLT
movq %rax, -344(%rbp)
jmp .Lf17_b8
.Lf17_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $2, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -32(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $12, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -40(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $6, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $9, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -288(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf17_b7
jmp .Lf17_b6
.Lf17_b4:
jmp .Lf17_b5
.Lf17_b3:
call f34@PLT
movq %rax, -200(%rbp)
jmp .Lf17_b5
.Lf17_b2:
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf17_b4
jmp .Lf17_b3
.Lf17_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $10, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movabsq $3, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf17_b2
.Lf17_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -784(%rbp), %rsi
leaq .Lroots_f17(%rip), %rdx
movq $98, %rcx
call evn_bind_roots@PLT
movq -784(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $6, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf17_b1
jmp .Lf17_b2
.size f17, .-f17
.text
.p2align 4
.type f18, @function
f18:
pushq %rbp
movq %rsp, %rbp
subq $848, %rsp
movq %rdi, -848(%rbp)
leaq -840(%rbp), %rdi
movq $105, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf18_b0
.Lf18_b21:
movabsq $2, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $0, %rax
movq %rax, -808(%rbp)
movq -24(%rbp), %rdi
movq -808(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_store@PLT
movq %rax, -824(%rbp)
call evn_void@PLT
movq %rax, -832(%rbp)
movq -8(%rbp), %rdi
movq -832(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -840(%rbp)
movq -840(%rbp), %rax
leave
ret
.Lf18_b20:
jmp .Lf18_b21
.Lf18_b19:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
call evn_get@PLT
movq %rax, -752(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movabsq $1, %rax
movq %rax, -768(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_member@PLT
movq %rax, -776(%rbp)
movq -752(%rbp), %rdi
movq -776(%rbp), %rsi
call f19@PLT
movq %rax, -784(%rbp)
jmp .Lf18_b21
.Lf18_b18:
jmp .Lf18_b13
.Lf18_b17:
jmp .Lf18_b18
.Lf18_b16:
call f34@PLT
movq %rax, -648(%rbp)
jmp .Lf18_b18
.Lf18_b15:
movq -552(%rbp), %rdi
call evn_truth@PLT
movq %rax, -640(%rbp)
cmpq $0, -640(%rbp)
je .Lf18_b17
jmp .Lf18_b16
.Lf18_b14:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movabsq $1, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_member@PLT
movq %rax, -584(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
call evn_get@PLT
movq %rax, -600(%rbp)
movabsq $1, %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_member@PLT
movq %rax, -616(%rbp)
movabsq $9, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
movq -584(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_binary@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rax
movq %rax, -552(%rbp)
jmp .Lf18_b15
.Lf18_b13:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movabsq $1, %rax
movq %rax, -672(%rbp)
movq -664(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_member@PLT
movq %rax, -680(%rbp)
movq -656(%rbp), %rdi
movq -680(%rbp), %rsi
call f19@PLT
movq %rax, -688(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movabsq $8, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call evn_none@PLT
movq %rax, -712(%rbp)
movabsq $6, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
movq -696(%rbp), %rsi
movq -712(%rbp), %rdx
call evn_binary@PLT
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_truth@PLT
movq %rax, -736(%rbp)
cmpq $0, -736(%rbp)
je .Lf18_b20
jmp .Lf18_b19
.Lf18_b12:
jmp .Lf18_b13
.Lf18_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movabsq $1, %rax
movq %rax, -488(%rbp)
movq -480(%rbp), %rdi
movq -488(%rbp), %rsi
call evn_member@PLT
movq %rax, -496(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_get@PLT
movq %rax, -512(%rbp)
movabsq $5, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movabsq $9, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -496(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movq -544(%rbp), %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
call evn_truth@PLT
movq %rax, -560(%rbp)
cmpq $0, -560(%rbp)
je .Lf18_b14
jmp .Lf18_b15
.Lf18_b10:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $8, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_none@PLT
movq %rax, -448(%rbp)
movabsq $6, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_truth@PLT
movq %rax, -472(%rbp)
cmpq $0, -472(%rbp)
je .Lf18_b12
jmp .Lf18_b11
.Lf18_b9:
jmp .Lf18_b10
.Lf18_b8:
call f34@PLT
movq %rax, -424(%rbp)
jmp .Lf18_b10
.Lf18_b7:
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
cmpq $0, -416(%rbp)
je .Lf18_b9
jmp .Lf18_b8
.Lf18_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $1, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $1, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
movabsq $9, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -368(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_binary@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
movq %rax, -336(%rbp)
jmp .Lf18_b7
.Lf18_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $2, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -32(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $12, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -40(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $9, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -288(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf18_b6
jmp .Lf18_b7
.Lf18_b4:
jmp .Lf18_b5
.Lf18_b3:
call f34@PLT
movq %rax, -200(%rbp)
jmp .Lf18_b5
.Lf18_b2:
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf18_b4
jmp .Lf18_b3
.Lf18_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $10, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movabsq $3, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf18_b2
.Lf18_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -848(%rbp), %rsi
leaq .Lroots_f18(%rip), %rdx
movq $106, %rcx
call evn_bind_roots@PLT
movq -848(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $6, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf18_b1
jmp .Lf18_b2
.size f18, .-f18
.text
.p2align 4
.type f19, @function
f19:
pushq %rbp
movq %rsp, %rbp
subq $224, %rsp
movq %rdi, -208(%rbp)
movq %rsi, -216(%rbp)
leaq -200(%rbp), %rdi
movq $25, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf19_b0
.Lf19_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -216(%rbp), %rsi
leaq .Lroots_f19(%rip), %rdx
movq $27, %rcx
call evn_bind_roots@PLT
movq -208(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -216(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $5, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $1, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -64(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movabsq $5, %rax
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $1, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -136(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
call evn_void@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.size f19, .-f19
.text
.p2align 4
.type f20, @function
f20:
pushq %rbp
movq %rsp, %rbp
subq $912, %rsp
movq %rdi, -904(%rbp)
leaq -896(%rbp), %rdi
movq $112, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf20_b0
.Lf20_b19:
movabsq $1, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_int@PLT
movq %rax, -728(%rbp)
movabsq $0, %rax
movq %rax, -736(%rbp)
movq -24(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_store@PLT
movq %rax, -752(%rbp)
movabsq $12, %rax
movq %rax, -760(%rbp)
movabsq $3, %rax
movq %rax, -768(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_object@PLT
movq %rax, -776(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $2, %rax
movq %rax, -792(%rbp)
movq -776(%rbp), %rdi
movq -792(%rbp), %rsi
movq -784(%rbp), %rdx
call evn_init@PLT
movq %rax, -800(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movabsq $1, %rax
movq %rax, -816(%rbp)
movq -808(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_member@PLT
movq %rax, -824(%rbp)
movabsq $1, %rax
movq %rax, -832(%rbp)
movq -776(%rbp), %rdi
movq -832(%rbp), %rsi
movq -824(%rbp), %rdx
call evn_init@PLT
movq %rax, -840(%rbp)
movabsq $0, %rax
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
call evn_int@PLT
movq %rax, -856(%rbp)
movabsq $0, %rax
movq %rax, -864(%rbp)
movq -776(%rbp), %rdi
movq -864(%rbp), %rsi
movq -856(%rbp), %rdx
call evn_init@PLT
movq %rax, -872(%rbp)
movabsq $13, %rax
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -888(%rbp)
movq -8(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -896(%rbp)
movq -896(%rbp), %rax
leave
ret
.Lf20_b18:
jmp .Lf20_b19
.Lf20_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_get@PLT
movq %rax, -680(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $1, %rax
movq %rax, -696(%rbp)
movq -688(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_member@PLT
movq %rax, -704(%rbp)
movq -680(%rbp), %rdi
movq -704(%rbp), %rsi
call f21@PLT
movq %rax, -712(%rbp)
jmp .Lf20_b19
.Lf20_b16:
jmp .Lf20_b11
.Lf20_b15:
jmp .Lf20_b16
.Lf20_b14:
call f34@PLT
movq %rax, -576(%rbp)
jmp .Lf20_b16
.Lf20_b13:
movq -480(%rbp), %rdi
call evn_truth@PLT
movq %rax, -568(%rbp)
cmpq $0, -568(%rbp)
je .Lf20_b15
jmp .Lf20_b14
.Lf20_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $1, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_member@PLT
movq %rax, -512(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_get@PLT
movq %rax, -528(%rbp)
movabsq $1, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movabsq $9, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
movq -512(%rbp), %rsi
movq -544(%rbp), %rdx
call evn_binary@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rax
movq %rax, -480(%rbp)
jmp .Lf20_b13
.Lf20_b11:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -584(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $1, %rax
movq %rax, -600(%rbp)
movq -592(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_member@PLT
movq %rax, -608(%rbp)
movq -584(%rbp), %rdi
movq -608(%rbp), %rsi
call f21@PLT
movq %rax, -616(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $8, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call evn_none@PLT
movq %rax, -640(%rbp)
movabsq $6, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
movq -624(%rbp), %rsi
movq -640(%rbp), %rdx
call evn_binary@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_truth@PLT
movq %rax, -664(%rbp)
cmpq $0, -664(%rbp)
je .Lf20_b18
jmp .Lf20_b17
.Lf20_b10:
jmp .Lf20_b11
.Lf20_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_get@PLT
movq %rax, -440(%rbp)
movabsq $5, %rax
movq %rax, -448(%rbp)
movq -440(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member@PLT
movq %rax, -456(%rbp)
movabsq $9, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -424(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rax
movq %rax, -480(%rbp)
movq -472(%rbp), %rdi
call evn_truth@PLT
movq %rax, -488(%rbp)
cmpq $0, -488(%rbp)
je .Lf20_b12
jmp .Lf20_b13
.Lf20_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $8, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_none@PLT
movq %rax, -376(%rbp)
movabsq $6, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_truth@PLT
movq %rax, -400(%rbp)
cmpq $0, -400(%rbp)
je .Lf20_b10
jmp .Lf20_b9
.Lf20_b7:
jmp .Lf20_b8
.Lf20_b6:
call f34@PLT
movq %rax, -352(%rbp)
jmp .Lf20_b8
.Lf20_b5:
movq -264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf20_b7
jmp .Lf20_b6
.Lf20_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $1, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $1, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movabsq $9, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -296(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rax
movq %rax, -264(%rbp)
jmp .Lf20_b5
.Lf20_b3:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $12, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movq -40(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $1, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_member@PLT
movq %rax, -216(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $5, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movabsq $9, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -216(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf20_b4
jmp .Lf20_b5
.Lf20_b2:
jmp .Lf20_b3
.Lf20_b1:
call f34@PLT
movq %rax, -160(%rbp)
jmp .Lf20_b3
.Lf20_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -904(%rbp), %rsi
leaq .Lroots_f20(%rip), %rdx
movq $113, %rcx
call evn_bind_roots@PLT
movq -904(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $2, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -32(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_store@PLT
movq %rax, -72(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call f32@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_member@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $6, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf20_b2
jmp .Lf20_b1
.size f20, .-f20
.text
.p2align 4
.type f21, @function
f21:
pushq %rbp
movq %rsp, %rbp
subq $480, %rsp
movq %rdi, -472(%rbp)
movq %rsi, -480(%rbp)
leaq -464(%rbp), %rdi
movq $58, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf21_b0
.Lf21_b3:
call evn_void@PLT
movq %rax, -456(%rbp)
movq -8(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
leave
ret
.Lf21_b2:
jmp .Lf21_b3
.Lf21_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $6, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $4, %rax
movq %rax, -432(%rbp)
movq -24(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_store@PLT
movq %rax, -448(%rbp)
jmp .Lf21_b3
.Lf21_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -480(%rbp), %rsi
leaq .Lroots_f21(%rip), %rdx
movq $60, %rcx
call evn_bind_roots@PLT
movq -472(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -480(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $5, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $1, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -64(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movabsq $5, %rax
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $1, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -136(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movabsq $1, %rax
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $6, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
movq -208(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -232(%rbp)
movabsq $6, %rax
movq %rax, -240(%rbp)
movq -24(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $2, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $0, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -280(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movabsq $2, %rax
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $6, %rax
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_member@PLT
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $4, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_member@PLT
movq %rax, -376(%rbp)
movabsq $9, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -352(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_truth@PLT
movq %rax, -400(%rbp)
cmpq $0, -400(%rbp)
je .Lf21_b2
jmp .Lf21_b1
.size f21, .-f21
.text
.p2align 4
.type f22, @function
f22:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -512(%rbp)
movq %rsi, -520(%rbp)
leaq -504(%rbp), %rdi
movq $63, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf22_b0
.Lf22_b9:
movabsq $14, %rax
movq %rax, -384(%rbp)
movabsq $3, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_object@PLT
movq %rax, -400(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $2, %rax
movq %rax, -416(%rbp)
movq -400(%rbp), %rdi
movq -416(%rbp), %rsi
movq -408(%rbp), %rdx
call evn_init@PLT
movq %rax, -424(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $1, %rax
movq %rax, -440(%rbp)
movq -400(%rbp), %rdi
movq -440(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_init@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $0, %rax
movq %rax, -472(%rbp)
movq -400(%rbp), %rdi
movq -472(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_init@PLT
movq %rax, -480(%rbp)
movabsq $15, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -496(%rbp)
movq -8(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rax
leave
ret
.Lf22_b8:
jmp .Lf22_b9
.Lf22_b7:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_get@PLT
movq %rax, -360(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call f24@PLT
movq %rax, -376(%rbp)
jmp .Lf22_b9
.Lf22_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call f24@PLT
movq %rax, -296(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $8, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_none@PLT
movq %rax, -320(%rbp)
movabsq $6, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf22_b8
jmp .Lf22_b7
.Lf22_b5:
jmp .Lf22_b6
.Lf22_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_get@PLT
movq %rax, -256(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -240(%rbp), %rdi
movq -256(%rbp), %rsi
movq -264(%rbp), %rdx
call f23@PLT
movq %rax, -272(%rbp)
jmp .Lf22_b6
.Lf22_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
movq -144(%rbp), %rdx
call f23@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $12, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -48(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_store@PLT
movq %rax, -184(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $8, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_none@PLT
movq %rax, -208(%rbp)
movabsq $6, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf22_b5
jmp .Lf22_b4
.Lf22_b2:
jmp .Lf22_b3
.Lf22_b1:
call f34@PLT
movq %rax, -120(%rbp)
jmp .Lf22_b3
.Lf22_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -520(%rbp), %rsi
leaq .Lroots_f22(%rip), %rdx
movq $65, %rcx
call evn_bind_roots@PLT
movq -512(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -520(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call f32@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movabsq $0, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movabsq $7, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call evn_binary@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf22_b2
jmp .Lf22_b1
.size f22, .-f22
.text
.p2align 4
.type f23, @function
f23:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
movq %rdi, -472(%rbp)
movq %rsi, -480(%rbp)
movq %rdx, -488(%rbp)
leaq -464(%rbp), %rdi
movq $58, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf23_b0
.Lf23_b6:
call evn_void@PLT
movq %rax, -456(%rbp)
movq -8(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
leave
ret
.Lf23_b5:
jmp .Lf23_b6
.Lf23_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $8, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $2, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -360(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member@PLT
movq %rax, -424(%rbp)
movabsq $1, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -400(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
movq -440(%rbp), %rdx
call f31@PLT
movq %rax, -448(%rbp)
jmp .Lf23_b6
.Lf23_b3:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $2, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_int@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -280(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf23_b5
jmp .Lf23_b4
.Lf23_b2:
jmp .Lf23_b3
.Lf23_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $9, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $6, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -184(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $5, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_member@PLT
movq %rax, -248(%rbp)
movabsq $1, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -224(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -264(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
movq -264(%rbp), %rdx
call f31@PLT
movq %rax, -272(%rbp)
jmp .Lf23_b3
.Lf23_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -488(%rbp), %rsi
leaq .Lroots_f23(%rip), %rdx
movq $61, %rcx
call evn_bind_roots@PLT
movq -472(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -480(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -488(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call f25@PLT
movq %rax, -88(%rbp)
movq -64(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $1, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -104(%rbp), %rsi
movq -120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf23_b2
jmp .Lf23_b1
.size f23, .-f23
.text
.p2align 4
.type f24, @function
f24:
pushq %rbp
movq %rsp, %rbp
subq $384, %rsp
movq %rdi, -376(%rbp)
movq %rsi, -384(%rbp)
leaq -368(%rbp), %rdi
movq $46, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf24_b0
.Lf24_b3:
call evn_void@PLT
movq %rax, -360(%rbp)
movq -8(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
leave
ret
.Lf24_b2:
jmp .Lf24_b3
.Lf24_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $3, %rax
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
jmp .Lf24_b3
.Lf24_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -384(%rbp), %rsi
leaq .Lroots_f24(%rip), %rdx
movq $48, %rcx
call evn_bind_roots@PLT
movq -376(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -384(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $5, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -72(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movabsq $5, %rax
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -144(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movabsq $1, %rax
movq %rax, -176(%rbp)
movq -24(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_store@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $6, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_member@PLT
movq %rax, -216(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $5, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -216(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -48(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $3, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movabsq $9, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -272(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf24_b2
jmp .Lf24_b1
.size f24, .-f24
.text
.p2align 4
.type f25, @function
f25:
pushq %rbp
movq %rsp, %rbp
subq $400, %rsp
movq %rdi, -392(%rbp)
movq %rsi, -400(%rbp)
leaq -384(%rbp), %rdi
movq $48, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf25_b0
.Lf25_b6:
movabsq $0, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movq -8(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rax
leave
ret
.Lf25_b5:
jmp .Lf25_b6
.Lf25_b4:
movabsq $2, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movq -8(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rax
leave
ret
.Lf25_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $8, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $2, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -232(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_binary@PLT
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $1, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movabsq $1, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -272(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movabsq $9, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -208(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf25_b5
jmp .Lf25_b4
.Lf25_b2:
jmp .Lf25_b3
.Lf25_b1:
movabsq $1, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -8(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
leave
ret
.Lf25_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -400(%rbp), %rsi
leaq .Lroots_f25(%rip), %rdx
movq $50, %rcx
call evn_bind_roots@PLT
movq -392(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -400(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $9, %rax
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_member@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $6, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -72(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_binary@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $1, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -112(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movabsq $9, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -48(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf25_b2
jmp .Lf25_b1
.size f25, .-f25
.text
.p2align 4
.type f26, @function
f26:
pushq %rbp
movq %rsp, %rbp
subq $256, %rsp
movq %rdi, -240(%rbp)
movq %rsi, -248(%rbp)
leaq -232(%rbp), %rdi
movq $29, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf26_b0
.Lf26_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $2, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $67108864, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $268435456, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $268435456, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movq -152(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
movq -200(%rbp), %rcx
movq -216(%rbp), %r8
call f27@PLT
movq %rax, -224(%rbp)
movq -8(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
leave
ret
.Lf26_b2:
jmp .Lf26_b3
.Lf26_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $2, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $8388608, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movabsq $67108864, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $268435456, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
movq -112(%rbp), %rcx
movq -128(%rbp), %r8
call f27@PLT
movq %rax, -136(%rbp)
movq -8(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
leave
ret
.Lf26_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -248(%rbp), %rsi
leaq .Lroots_f26(%rip), %rdx
movq $31, %rcx
call evn_bind_roots@PLT
movq -240(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -248(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_truth@PLT
movq %rax, -56(%rbp)
cmpq $0, -56(%rbp)
je .Lf26_b2
jmp .Lf26_b1
.size f26, .-f26
.text
.p2align 4
.type f27, @function
f27:
pushq %rbp
movq %rsp, %rbp
subq $1008, %rsp
movq %rdi, -976(%rbp)
movq %rsi, -984(%rbp)
movq %rdx, -992(%rbp)
movq %rcx, -1000(%rbp)
movq %r8, -1008(%rbp)
leaq -968(%rbp), %rdi
movq $121, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf27_b0
.Lf27_b15:
movabsq $6, %rax
movq %rax, -536(%rbp)
movabsq $13, %rax
movq %rax, -544(%rbp)
movq -536(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_object@PLT
movq %rax, -552(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $8, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -576(%rbp)
movabsq $12, %rax
movq %rax, -584(%rbp)
movq -552(%rbp), %rdi
movq -584(%rbp), %rsi
movq -576(%rbp), %rdx
call evn_init@PLT
movq %rax, -592(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $11, %rax
movq %rax, -608(%rbp)
movq -552(%rbp), %rdi
movq -608(%rbp), %rsi
movq -600(%rbp), %rdx
call evn_init@PLT
movq %rax, -616(%rbp)
movabsq $0, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
call evn_int@PLT
movq %rax, -632(%rbp)
movabsq $10, %rax
movq %rax, -640(%rbp)
movq -552(%rbp), %rdi
movq -640(%rbp), %rsi
movq -632(%rbp), %rdx
call evn_init@PLT
movq %rax, -648(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $9, %rax
movq %rax, -664(%rbp)
movq -552(%rbp), %rdi
movq -664(%rbp), %rsi
movq -656(%rbp), %rdx
call evn_init@PLT
movq %rax, -672(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -680(%rbp)
movabsq $8, %rax
movq %rax, -688(%rbp)
movq -552(%rbp), %rdi
movq -688(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_init@PLT
movq %rax, -696(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -552(%rbp), %rdi
movq -712(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_init@PLT
movq %rax, -720(%rbp)
movabsq $0, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_int@PLT
movq %rax, -736(%rbp)
movabsq $6, %rax
movq %rax, -744(%rbp)
movq -552(%rbp), %rdi
movq -744(%rbp), %rsi
movq -736(%rbp), %rdx
call evn_init@PLT
movq %rax, -752(%rbp)
movabsq $0, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_int@PLT
movq %rax, -768(%rbp)
movabsq $5, %rax
movq %rax, -776(%rbp)
movq -552(%rbp), %rdi
movq -776(%rbp), %rsi
movq -768(%rbp), %rdx
call evn_init@PLT
movq %rax, -784(%rbp)
movabsq $0, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $4, %rax
movq %rax, -808(%rbp)
movq -552(%rbp), %rdi
movq -808(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_init@PLT
movq %rax, -816(%rbp)
movabsq $0, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call evn_int@PLT
movq %rax, -832(%rbp)
movabsq $3, %rax
movq %rax, -840(%rbp)
movq -552(%rbp), %rdi
movq -840(%rbp), %rsi
movq -832(%rbp), %rdx
call evn_init@PLT
movq %rax, -848(%rbp)
movabsq $0, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
call evn_int@PLT
movq %rax, -864(%rbp)
movabsq $2, %rax
movq %rax, -872(%rbp)
movq -552(%rbp), %rdi
movq -872(%rbp), %rsi
movq -864(%rbp), %rdx
call evn_init@PLT
movq %rax, -880(%rbp)
movabsq $0, %rax
movq %rax, -888(%rbp)
movq -888(%rbp), %rdi
call evn_int@PLT
movq %rax, -896(%rbp)
movabsq $1, %rax
movq %rax, -904(%rbp)
movq -552(%rbp), %rdi
movq -904(%rbp), %rsi
movq -896(%rbp), %rdx
call evn_init@PLT
movq %rax, -912(%rbp)
movabsq $0, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
call evn_int@PLT
movq %rax, -928(%rbp)
movabsq $0, %rax
movq %rax, -936(%rbp)
movq -552(%rbp), %rdi
movq -936(%rbp), %rsi
movq -928(%rbp), %rdx
call evn_init@PLT
movq %rax, -944(%rbp)
movabsq $7, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -960(%rbp)
movq -8(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -968(%rbp)
movq -968(%rbp), %rax
leave
ret
.Lf27_b14:
jmp .Lf27_b15
.Lf27_b13:
call f34@PLT
movq %rax, -528(%rbp)
jmp .Lf27_b15
.Lf27_b12:
movq -464(%rbp), %rdi
call evn_truth@PLT
movq %rax, -520(%rbp)
cmpq $0, -520(%rbp)
je .Lf27_b14
jmp .Lf27_b13
.Lf27_b11:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movabsq $0, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_int@PLT
movq %rax, -496(%rbp)
movabsq $7, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -480(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_binary@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rax
movq %rax, -464(%rbp)
jmp .Lf27_b12
.Lf27_b10:
movq -408(%rbp), %rax
movq %rax, -464(%rbp)
movq -408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -472(%rbp)
cmpq $0, -472(%rbp)
je .Lf27_b11
jmp .Lf27_b12
.Lf27_b9:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movabsq $7, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -424(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rax
movq %rax, -408(%rbp)
jmp .Lf27_b10
.Lf27_b8:
movq -352(%rbp), %rax
movq %rax, -408(%rbp)
movq -352(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
cmpq $0, -416(%rbp)
je .Lf27_b9
jmp .Lf27_b10
.Lf27_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $7, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -368(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rax
movq %rax, -352(%rbp)
jmp .Lf27_b8
.Lf27_b6:
movq -296(%rbp), %rax
movq %rax, -352(%rbp)
movq -296(%rbp), %rdi
call evn_truth@PLT
movq %rax, -360(%rbp)
cmpq $0, -360(%rbp)
je .Lf27_b7
jmp .Lf27_b8
.Lf27_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movabsq $2, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $9, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -312(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rax
movq %rax, -296(%rbp)
jmp .Lf27_b6
.Lf27_b4:
movq -240(%rbp), %rax
movq %rax, -296(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -304(%rbp)
cmpq $0, -304(%rbp)
je .Lf27_b5
jmp .Lf27_b6
.Lf27_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movabsq $7, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_binary@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
movq %rax, -240(%rbp)
jmp .Lf27_b4
.Lf27_b2:
movq -168(%rbp), %rax
movq %rax, -240(%rbp)
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf27_b3
jmp .Lf27_b4
.Lf27_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $11, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $6, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
movq -200(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
movq %rax, -168(%rbp)
jmp .Lf27_b2
.Lf27_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1008(%rbp), %rsi
leaq .Lroots_f27(%rip), %rdx
movq $126, %rcx
call evn_bind_roots@PLT
movq -976(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -984(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -992(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -1000(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -1008(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call f32@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $12, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $8, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_none@PLT
movq %rax, -144(%rbp)
movabsq $6, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf27_b1
jmp .Lf27_b2
.size f27, .-f27
.text
.p2align 4
.type f28, @function
f28:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
leaq -72(%rbp), %rdi
movq $9, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf28_b0
.Lf28_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f28(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movabsq $536870912, %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_int@PLT
movq %rax, -24(%rbp)
movabsq $2147483648, %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_int@PLT
movq %rax, -40(%rbp)
movabsq $268435456, %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_int@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
movq -40(%rbp), %rsi
movq -56(%rbp), %rdx
call f29@PLT
movq %rax, -64(%rbp)
movq -8(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -72(%rbp)
movq -72(%rbp), %rax
leave
ret
.size f28, .-f28
.text
.p2align 4
.type f29, @function
f29:
pushq %rbp
movq %rsp, %rbp
subq $688, %rsp
movq %rdi, -672(%rbp)
movq %rsi, -680(%rbp)
movq %rdx, -688(%rbp)
leaq -664(%rbp), %rdi
movq $83, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf29_b0
.Lf29_b7:
movabsq $6, %rax
movq %rax, -232(%rbp)
movabsq $13, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_object@PLT
movq %rax, -248(%rbp)
movabsq $8, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_none@PLT
movq %rax, -264(%rbp)
movabsq $12, %rax
movq %rax, -272(%rbp)
movq -248(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $0, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_int@PLT
movq %rax, -296(%rbp)
movabsq $11, %rax
movq %rax, -304(%rbp)
movq -248(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $10, %rax
movq %rax, -336(%rbp)
movq -248(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $9, %rax
movq %rax, -360(%rbp)
movq -248(%rbp), %rdi
movq -360(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_init@PLT
movq %rax, -368(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $8, %rax
movq %rax, -384(%rbp)
movq -248(%rbp), %rdi
movq -384(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_init@PLT
movq %rax, -392(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $7, %rax
movq %rax, -408(%rbp)
movq -248(%rbp), %rdi
movq -408(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_init@PLT
movq %rax, -416(%rbp)
movabsq $0, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $6, %rax
movq %rax, -440(%rbp)
movq -248(%rbp), %rdi
movq -440(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_init@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -248(%rbp), %rdi
movq -472(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_init@PLT
movq %rax, -480(%rbp)
movabsq $0, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_int@PLT
movq %rax, -496(%rbp)
movabsq $4, %rax
movq %rax, -504(%rbp)
movq -248(%rbp), %rdi
movq -504(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_init@PLT
movq %rax, -512(%rbp)
movabsq $0, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_int@PLT
movq %rax, -528(%rbp)
movabsq $3, %rax
movq %rax, -536(%rbp)
movq -248(%rbp), %rdi
movq -536(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_init@PLT
movq %rax, -544(%rbp)
movabsq $0, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $2, %rax
movq %rax, -568(%rbp)
movq -248(%rbp), %rdi
movq -568(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_init@PLT
movq %rax, -576(%rbp)
movabsq $0, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $1, %rax
movq %rax, -600(%rbp)
movq -248(%rbp), %rdi
movq -600(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_init@PLT
movq %rax, -608(%rbp)
movabsq $0, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_int@PLT
movq %rax, -624(%rbp)
movabsq $0, %rax
movq %rax, -632(%rbp)
movq -248(%rbp), %rdi
movq -632(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_init@PLT
movq %rax, -640(%rbp)
movabsq $7, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -656(%rbp)
movq -8(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -664(%rbp)
movq -664(%rbp), %rax
leave
ret
.Lf29_b6:
jmp .Lf29_b7
.Lf29_b5:
call f34@PLT
movq %rax, -224(%rbp)
jmp .Lf29_b7
.Lf29_b4:
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf29_b6
jmp .Lf29_b5
.Lf29_b3:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $0, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movabsq $7, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -176(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
movq %rax, -160(%rbp)
jmp .Lf29_b4
.Lf29_b2:
movq -104(%rbp), %rax
movq %rax, -160(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -168(%rbp)
cmpq $0, -168(%rbp)
je .Lf29_b3
jmp .Lf29_b4
.Lf29_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $7, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf29_b2
.Lf29_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -688(%rbp), %rsi
leaq .Lroots_f29(%rip), %rdx
movq $86, %rcx
call evn_bind_roots@PLT
movq -672(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -680(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -688(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf29_b1
jmp .Lf29_b2
.size f29, .-f29
.text
.p2align 4
.type f30, @function
f30:
pushq %rbp
movq %rsp, %rbp
subq $128, %rsp
movq %rdi, -112(%rbp)
movq %rsi, -120(%rbp)
movq %rdx, -128(%rbp)
leaq -104(%rbp), %rdi
movq $13, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf30_b0
.Lf30_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -128(%rbp), %rsi
leaq .Lroots_f30(%rip), %rdx
movq $16, %rcx
call evn_bind_roots@PLT
movq -112(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -120(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -128(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
movq -80(%rbp), %rdx
call f31@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
movq -8(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -104(%rbp)
movq -104(%rbp), %rax
leave
ret
.size f30, .-f30
.text
.p2align 4
.type f31, @function
f31:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -272(%rbp)
movq %rsi, -280(%rbp)
movq %rdx, -288(%rbp)
leaq -264(%rbp), %rdi
movq $33, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf31_b0
.Lf31_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f31(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -272(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -280(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -288(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $1, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $10, %rax
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movabsq $9, %rax
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_object@PLT
movq %rax, -120(%rbp)
leaq .Ldata_0(%rip), %rax
movq %rax, -128(%rbp)
movabsq $27, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_text@PLT
movq %rax, -144(%rbp)
movabsq $3, %rax
movq %rax, -152(%rbp)
movq -120(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
leaq .Ldata_1(%rip), %rax
movq %rax, -168(%rbp)
movabsq $14, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movabsq $2, %rax
movq %rax, -192(%rbp)
movq -120(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -120(%rbp), %rdi
movq -216(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_init@PLT
movq %rax, -224(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -120(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $3, %rax
movq %rax, -256(%rbp)
movq -120(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_fail@PLT
movq %rax, -264(%rbp)
ud2
.size f31, .-f31
.text
.p2align 4
.type f32, @function
f32:
pushq %rbp
movq %rsp, %rbp
subq $656, %rsp
movq %rdi, -648(%rbp)
leaq -640(%rbp), %rdi
movq $80, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf32_b0
.Lf32_b13:
call evn_void@PLT
movq %rax, -632(%rbp)
movq -8(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -640(%rbp)
movq -640(%rbp), %rax
leave
ret
.Lf32_b12:
jmp .Lf32_b13
.Lf32_b11:
call f34@PLT
movq %rax, -624(%rbp)
jmp .Lf32_b13
.Lf32_b10:
movq -544(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf32_b12
jmp .Lf32_b11
.Lf32_b9:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $10, %rax
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_member@PLT
movq %rax, -576(%rbp)
movabsq $0, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $6, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rax
movq %rax, -544(%rbp)
jmp .Lf32_b10
.Lf32_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $10, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movabsq $0, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_int@PLT
movq %rax, -520(%rbp)
movabsq $6, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
movq -504(%rbp), %rsi
movq -520(%rbp), %rdx
call evn_binary@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
movq %rax, -544(%rbp)
movq -536(%rbp), %rdi
call evn_truth@PLT
movq %rax, -552(%rbp)
cmpq $0, -552(%rbp)
je .Lf32_b9
jmp .Lf32_b10
.Lf32_b7:
jmp .Lf32_b8
.Lf32_b6:
movabsq $9, %rax
movq %rax, -304(%rbp)
movabsq $4, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_object@PLT
movq %rax, -320(%rbp)
leaq .Ldata_2(%rip), %rax
movq %rax, -328(%rbp)
movabsq $21, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_text@PLT
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -320(%rbp), %rdi
movq -352(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_init@PLT
movq %rax, -360(%rbp)
leaq .Ldata_3(%rip), %rax
movq %rax, -368(%rbp)
movabsq $9, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_text@PLT
movq %rax, -384(%rbp)
movabsq $2, %rax
movq %rax, -392(%rbp)
movq -320(%rbp), %rdi
movq -392(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_init@PLT
movq %rax, -400(%rbp)
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movabsq $1, %rax
movq %rax, -424(%rbp)
movq -320(%rbp), %rdi
movq -424(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_init@PLT
movq %rax, -432(%rbp)
movabsq $0, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -320(%rbp), %rdi
movq -456(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_init@PLT
movq %rax, -464(%rbp)
movabsq $3, %rax
movq %rax, -472(%rbp)
movq -320(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_fail@PLT
movq %rax, -480(%rbp)
ud2
.Lf32_b5:
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -296(%rbp)
cmpq $0, -296(%rbp)
je .Lf32_b7
jmp .Lf32_b6
.Lf32_b4:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $10, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movabsq $2, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movabsq $5, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_binary@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
movq %rax, -224(%rbp)
jmp .Lf32_b5
.Lf32_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $10, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movabsq $2, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $5, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf32_b4
jmp .Lf32_b5
.Lf32_b2:
jmp .Lf32_b3
.Lf32_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_get@PLT
movq %rax, -152(%rbp)
movq -32(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_store@PLT
movq %rax, -160(%rbp)
jmp .Lf32_b3
.Lf32_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -648(%rbp), %rsi
leaq .Lroots_f32(%rip), %rdx
movq $81, %rcx
call evn_bind_roots@PLT
movq -648(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -32(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_store@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $12, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -40(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_store@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $8, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_none@PLT
movq %rax, -112(%rbp)
movabsq $6, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf32_b2
jmp .Lf32_b1
.size f32, .-f32
.text
.p2align 4
.type f33, @function
f33:
pushq %rbp
movq %rsp, %rbp
subq $208, %rsp
movq %rdi, -200(%rbp)
leaq -192(%rbp), %rdi
movq $24, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf33_b0
.Lf33_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -200(%rbp), %rsi
leaq .Lroots_f33(%rip), %rdx
movq $25, %rcx
call evn_bind_roots@PLT
movq -200(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movabsq $9, %rax
movq %rax, -32(%rbp)
movabsq $4, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_object@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $3, %rax
movq %rax, -64(%rbp)
movq -48(%rbp), %rdi
movq -64(%rbp), %rsi
movq -56(%rbp), %rdx
call evn_init@PLT
movq %rax, -72(%rbp)
leaq .Ldata_4(%rip), %rax
movq %rax, -80(%rbp)
movabsq $13, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_text@PLT
movq %rax, -96(%rbp)
movabsq $2, %rax
movq %rax, -104(%rbp)
movq -48(%rbp), %rdi
movq -104(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_init@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -48(%rbp), %rdi
movq -136(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_init@PLT
movq %rax, -144(%rbp)
movabsq $0, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -48(%rbp), %rdi
movq -168(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_init@PLT
movq %rax, -176(%rbp)
movabsq $3, %rax
movq %rax, -184(%rbp)
movq -48(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_fail@PLT
movq %rax, -192(%rbp)
ud2
.size f33, .-f33
.text
.p2align 4
.type f34, @function
f34:
pushq %rbp
movq %rsp, %rbp
subq $192, %rsp
leaq -192(%rbp), %rdi
movq $24, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf34_b0
.Lf34_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -192(%rbp), %rsi
leaq .Lroots_f34(%rip), %rdx
movq $24, %rcx
call evn_bind_roots@PLT
movabsq $9, %rax
movq %rax, -16(%rbp)
movabsq $4, %rax
movq %rax, -24(%rbp)
movq -16(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_object@PLT
movq %rax, -32(%rbp)
leaq .Ldata_5(%rip), %rax
movq %rax, -40(%rbp)
movabsq $28, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_text@PLT
movq %rax, -56(%rbp)
movabsq $3, %rax
movq %rax, -64(%rbp)
movq -32(%rbp), %rdi
movq -64(%rbp), %rsi
movq -56(%rbp), %rdx
call evn_init@PLT
movq %rax, -72(%rbp)
leaq .Ldata_6(%rip), %rax
movq %rax, -80(%rbp)
movabsq $13, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_text@PLT
movq %rax, -96(%rbp)
movabsq $2, %rax
movq %rax, -104(%rbp)
movq -32(%rbp), %rdi
movq -104(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_init@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -32(%rbp), %rdi
movq -136(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_init@PLT
movq %rax, -144(%rbp)
movabsq $0, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -32(%rbp), %rdi
movq -168(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_init@PLT
movq %rax, -176(%rbp)
movabsq $3, %rax
movq %rax, -184(%rbp)
movq -32(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_fail@PLT
movq %rax, -192(%rbp)
ud2
.size f34, .-f34
.text
.p2align 4
.type f35, @function
f35:
pushq %rbp
movq %rsp, %rbp
subq $400, %rsp
movq %rdi, -392(%rbp)
leaq -384(%rbp), %rdi
movq $48, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf35_b0
.Lf35_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $0, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call f17@PLT
movq %rax, -368(%rbp)
call evn_void@PLT
movq %rax, -376(%rbp)
movq -8(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rax
leave
ret
.Lf35_b5:
jmp .Lf35_b6
.Lf35_b4:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call evn_get@PLT
movq %rax, -312(%rbp)
movabsq $6, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movq -312(%rbp), %rdi
movq -328(%rbp), %rsi
call f36@PLT
movq %rax, -336(%rbp)
jmp .Lf35_b6
.Lf35_b3:
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_bool@PLT
movq %rax, -112(%rbp)
movabsq $2, %rax
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $5, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -32(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -168(%rbp)
movabsq $23, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_none@PLT
movq %rax, -184(%rbp)
movabsq $5, %rax
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
movabsq $0, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $4, %rax
movq %rax, -232(%rbp)
movq -24(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $23, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_none@PLT
movq %rax, -272(%rbp)
movabsq $6, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_binary@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_truth@PLT
movq %rax, -296(%rbp)
cmpq $0, -296(%rbp)
je .Lf35_b5
jmp .Lf35_b4
.Lf35_b2:
jmp .Lf35_b3
.Lf35_b1:
leaq .Ldata_7(%rip), %rax
movq %rax, -72(%rbp)
movabsq $30, %rax
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_text@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call f33@PLT
movq %rax, -96(%rbp)
jmp .Lf35_b3
.Lf35_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -392(%rbp), %rsi
leaq .Lroots_f35(%rip), %rdx
movq $49, %rcx
call evn_bind_roots@PLT
movq -392(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $2, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_member@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_truth@PLT
movq %rax, -64(%rbp)
cmpq $0, -64(%rbp)
je .Lf35_b2
jmp .Lf35_b1
.size f35, .-f35
.text
.p2align 4
.type f36, @function
f36:
pushq %rbp
movq %rsp, %rbp
subq $848, %rsp
movq %rdi, -840(%rbp)
movq %rsi, -848(%rbp)
leaq -832(%rbp), %rdi
movq $104, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf36_b0
.Lf36_b18:
call evn_void@PLT
movq %rax, -824(%rbp)
movq -8(%rbp), %rdi
movq -824(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -832(%rbp)
movq -832(%rbp), %rax
leave
ret
.Lf36_b17:
jmp .Lf36_b18
.Lf36_b16:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
call evn_get@PLT
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
call f17@PLT
movq %rax, -816(%rbp)
jmp .Lf36_b18
.Lf36_b15:
jmp .Lf36_b12
.Lf36_b14:
jmp .Lf36_b15
.Lf36_b13:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_get@PLT
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
call f17@PLT
movq %rax, -672(%rbp)
jmp .Lf36_b15
.Lf36_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -680(%rbp)
movabsq $0, %rax
movq %rax, -688(%rbp)
movq -680(%rbp), %rdi
movq -688(%rbp), %rsi
call evn_member@PLT
movq %rax, -696(%rbp)
movq -80(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_store@PLT
movq %rax, -704(%rbp)
movabsq $18, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
call evn_none@PLT
movq %rax, -720(%rbp)
movabsq $0, %rax
movq %rax, -728(%rbp)
movq -24(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_store@PLT
movq %rax, -744(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -752(%rbp)
movabsq $18, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_none@PLT
movq %rax, -768(%rbp)
movabsq $6, %rax
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
movq -752(%rbp), %rsi
movq -768(%rbp), %rdx
call evn_binary@PLT
movq %rax, -784(%rbp)
movq -784(%rbp), %rdi
call evn_truth@PLT
movq %rax, -792(%rbp)
cmpq $0, -792(%rbp)
je .Lf36_b17
jmp .Lf36_b16
.Lf36_b11:
jmp .Lf36_b12
.Lf36_b10:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_get@PLT
movq %rax, -528(%rbp)
movabsq $0, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movq -72(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_store@PLT
movq %rax, -552(%rbp)
movabsq $18, %rax
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
call evn_none@PLT
movq %rax, -568(%rbp)
movq -64(%rbp), %rdi
call evn_get_ref@PLT
movq %rax, -576(%rbp)
movabsq $0, %rax
movq %rax, -584(%rbp)
movq -576(%rbp), %rdi
movq -584(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_store@PLT
movq %rax, -600(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $18, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_none@PLT
movq %rax, -624(%rbp)
movabsq $6, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
movq -608(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_binary@PLT
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_truth@PLT
movq %rax, -648(%rbp)
cmpq $0, -648(%rbp)
je .Lf36_b14
jmp .Lf36_b13
.Lf36_b9:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $1, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -48(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_store@PLT
movq %rax, -392(%rbp)
jmp .Lf36_b4
.Lf36_b8:
jmp .Lf36_b9
.Lf36_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_get@PLT
movq %rax, -296(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $1, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $1, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -296(%rbp), %rdi
movq -336(%rbp), %rsi
call f36@PLT
movq %rax, -344(%rbp)
jmp .Lf36_b9
.Lf36_b6:
jmp .Lf36_b3
.Lf36_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call f43@PLT
movq %rax, -224(%rbp)
movq -56(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $23, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_none@PLT
movq %rax, -256(%rbp)
movabsq $6, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -240(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_binary@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_truth@PLT
movq %rax, -280(%rbp)
cmpq $0, -280(%rbp)
je .Lf36_b8
jmp .Lf36_b7
.Lf36_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $16, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $7, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf36_b6
jmp .Lf36_b5
.Lf36_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $1, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movq -64(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_store@PLT
movq %rax, -424(%rbp)
movabsq $21, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_none@PLT
movq %rax, -440(%rbp)
movabsq $1, %rax
movq %rax, -448(%rbp)
movq -24(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_store@PLT
movq %rax, -464(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movabsq $21, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_none@PLT
movq %rax, -488(%rbp)
movabsq $6, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_truth@PLT
movq %rax, -512(%rbp)
cmpq $0, -512(%rbp)
je .Lf36_b11
jmp .Lf36_b10
.Lf36_b2:
jmp .Lf36_b3
.Lf36_b1:
jmp .Lf36_b4
.Lf36_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -848(%rbp), %rsi
leaq .Lroots_f36(%rip), %rdx
movq $106, %rcx
call evn_bind_roots@PLT
movq -840(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -848(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -48(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $9, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf36_b2
jmp .Lf36_b1
.size f36, .-f36
.text
.p2align 4
.type f37, @function
f37:
pushq %rbp
movq %rsp, %rbp
subq $192, %rsp
movq %rdi, -184(%rbp)
leaq -176(%rbp), %rdi
movq $22, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf37_b0
.Lf37_b3:
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_bool@PLT
movq %rax, -136(%rbp)
movabsq $1, %rax
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_store@PLT
movq %rax, -160(%rbp)
call evn_void@PLT
movq %rax, -168(%rbp)
movq -8(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rax
leave
ret
.Lf37_b2:
jmp .Lf37_b3
.Lf37_b1:
leaq .Ldata_8(%rip), %rax
movq %rax, -96(%rbp)
movabsq $21, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_text@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call f33@PLT
movq %rax, -120(%rbp)
jmp .Lf37_b3
.Lf37_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -184(%rbp), %rsi
leaq .Lroots_f37(%rip), %rdx
movq $23, %rcx
call evn_bind_roots@PLT
movq -184(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $6, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call f9@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $2, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf37_b2
jmp .Lf37_b1
.size f37, .-f37
.text
.p2align 4
.type f38, @function
f38:
pushq %rbp
movq %rsp, %rbp
subq $544, %rsp
movq %rdi, -520(%rbp)
movq %rsi, -528(%rbp)
movq %rdx, -536(%rbp)
leaq -512(%rbp), %rdi
movq $64, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf38_b0
.Lf38_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $4, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_member@PLT
movq %rax, -304(%rbp)
movq -64(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $1, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_bool@PLT
movq %rax, -352(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
movq -336(%rbp), %rdx
movq -352(%rbp), %rcx
call f41@PLT
movq %rax, -360(%rbp)
movq -72(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_store@PLT
movq %rax, -368(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $16, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $4, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -376(%rbp), %rdi
movq -416(%rbp), %rsi
movq -424(%rbp), %rdx
call f44@PLT
movq %rax, -432(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movabsq $1, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $0, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -440(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movabsq $4, %rax
movq %rax, -480(%rbp)
movq -24(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_store@PLT
movq %rax, -496(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movq -8(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rax
leave
ret
.Lf38_b2:
jmp .Lf38_b3
.Lf38_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $6, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movabsq $1, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_int@PLT
movq %rax, -256(%rbp)
movabsq $0, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movq -240(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
call f30@PLT
movq %rax, -280(%rbp)
jmp .Lf38_b3
.Lf38_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -536(%rbp), %rsi
leaq .Lroots_f38(%rip), %rdx
movq $67, %rcx
call evn_bind_roots@PLT
movq -520(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -528(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -536(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_bool@PLT
movq %rax, -104(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call f51@PLT
movq %rax, -112(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movq -120(%rbp), %rdi
movq -136(%rbp), %rsi
call f11@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $4, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $3, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $10, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -168(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf38_b2
jmp .Lf38_b1
.size f38, .-f38
.text
.p2align 4
.type f39, @function
f39:
pushq %rbp
movq %rsp, %rbp
subq $464, %rsp
movq %rdi, -440(%rbp)
movq %rsi, -448(%rbp)
movq %rdx, -456(%rbp)
movq %rcx, -464(%rbp)
leaq -432(%rbp), %rdi
movq $54, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf39_b0
.Lf39_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movq -272(%rbp), %rdi
movq -288(%rbp), %rsi
call f11@PLT
movq %rax, -296(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movabsq $0, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_bool@PLT
movq %rax, -336(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
movq -320(%rbp), %rdx
movq -336(%rbp), %rcx
call f41@PLT
movq %rax, -344(%rbp)
movq -80(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $16, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $4, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -368(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movq -360(%rbp), %rdi
movq -400(%rbp), %rsi
movq -408(%rbp), %rdx
call f44@PLT
movq %rax, -416(%rbp)
call evn_void@PLT
movq %rax, -424(%rbp)
movq -8(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rax
leave
ret
.Lf39_b4:
jmp .Lf39_b5
.Lf39_b3:
leaq .Ldata_9(%rip), %rax
movq %rax, -240(%rbp)
movabsq $27, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_text@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call f33@PLT
movq %rax, -264(%rbp)
jmp .Lf39_b5
.Lf39_b2:
movq -168(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf39_b4
jmp .Lf39_b3
.Lf39_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $4, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movabsq $10, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -184(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rax
movq %rax, -168(%rbp)
jmp .Lf39_b2
.Lf39_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -464(%rbp), %rsi
leaq .Lroots_f39(%rip), %rdx
movq $58, %rcx
call evn_bind_roots@PLT
movq -440(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -448(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -456(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -464(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_bool@PLT
movq %rax, -112(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call f51@PLT
movq %rax, -120(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $0, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $7, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -176(%rbp)
cmpq $0, -176(%rbp)
je .Lf39_b1
jmp .Lf39_b2
.size f39, .-f39
.text
.p2align 4
.type f40, @function
f40:
pushq %rbp
movq %rsp, %rbp
subq $432, %rsp
movq %rdi, -408(%rbp)
movq %rsi, -416(%rbp)
movq %rdx, -424(%rbp)
leaq -400(%rbp), %rdi
movq $50, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf40_b0
.Lf40_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movq -256(%rbp), %rdi
movq -272(%rbp), %rsi
call f11@PLT
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $0, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_bool@PLT
movq %rax, -320(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
movq -304(%rbp), %rdx
movq -320(%rbp), %rcx
call f41@PLT
movq %rax, -328(%rbp)
movq -64(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_store@PLT
movq %rax, -336(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $16, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movabsq $4, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -344(%rbp), %rdi
movq -384(%rbp), %rsi
call f45@PLT
movq %rax, -392(%rbp)
movq -8(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rax
leave
ret
.Lf40_b4:
jmp .Lf40_b5
.Lf40_b3:
leaq .Ldata_10(%rip), %rax
movq %rax, -224(%rbp)
movabsq $27, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_text@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call f33@PLT
movq %rax, -248(%rbp)
jmp .Lf40_b5
.Lf40_b2:
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf40_b4
jmp .Lf40_b3
.Lf40_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $4, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movabsq $10, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -168(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
movq %rax, -152(%rbp)
jmp .Lf40_b2
.Lf40_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -424(%rbp), %rsi
leaq .Lroots_f40(%rip), %rdx
movq $53, %rcx
call evn_bind_roots@PLT
movq -408(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -416(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -424(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_bool@PLT
movq %rax, -96(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call f51@PLT
movq %rax, -104(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $0, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $7, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf40_b1
jmp .Lf40_b2
.size f40, .-f40
.text
.p2align 4
.type f41, @function
f41:
pushq %rbp
movq %rsp, %rbp
subq $1088, %rsp
movq %rdi, -1056(%rbp)
movq %rsi, -1064(%rbp)
movq %rdx, -1072(%rbp)
movq %rcx, -1080(%rbp)
leaq -1048(%rbp), %rdi
movq $131, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf41_b0
.Lf41_b18:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1016(%rbp)
movabsq $1, %rax
movq %rax, -1024(%rbp)
movq -1016(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_member@PLT
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
call f46@PLT
movq %rax, -1040(%rbp)
movq -8(%rbp), %rdi
movq -1040(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1048(%rbp)
movq -1048(%rbp), %rax
leave
ret
.Lf41_b17:
jmp .Lf41_b18
.Lf41_b16:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -936(%rbp)
movabsq $6, %rax
movq %rax, -944(%rbp)
movq -936(%rbp), %rdi
movq -944(%rbp), %rsi
call evn_member@PLT
movq %rax, -952(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movq -952(%rbp), %rdi
movq -960(%rbp), %rsi
call f48@PLT
movq %rax, -968(%rbp)
movabsq $21, %rax
movq %rax, -976(%rbp)
movq -976(%rbp), %rdi
movq -968(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -984(%rbp)
movabsq $1, %rax
movq %rax, -992(%rbp)
movq -80(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_store@PLT
movq %rax, -1008(%rbp)
jmp .Lf41_b18
.Lf41_b15:
movq -856(%rbp), %rdi
call evn_truth@PLT
movq %rax, -928(%rbp)
cmpq $0, -928(%rbp)
je .Lf41_b17
jmp .Lf41_b16
.Lf41_b14:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movabsq $1, %rax
movq %rax, -880(%rbp)
movq -872(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_member@PLT
movq %rax, -888(%rbp)
movabsq $21, %rax
movq %rax, -896(%rbp)
movq -896(%rbp), %rdi
call evn_none@PLT
movq %rax, -904(%rbp)
movabsq $5, %rax
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
movq -888(%rbp), %rsi
movq -904(%rbp), %rdx
call evn_binary@PLT
movq %rax, -920(%rbp)
movq -920(%rbp), %rax
movq %rax, -856(%rbp)
jmp .Lf41_b15
.Lf41_b13:
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
call f47@PLT
movq %rax, -784(%rbp)
movq -80(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_store@PLT
movq %rax, -792(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -800(%rbp)
movabsq $16, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
call evn_int@PLT
movq %rax, -816(%rbp)
movabsq $3, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
movq -800(%rbp), %rsi
movq -816(%rbp), %rdx
call evn_binary@PLT
movq %rax, -832(%rbp)
movq -88(%rbp), %rdi
movq -832(%rbp), %rsi
call evn_store@PLT
movq %rax, -840(%rbp)
jmp .Lf41_b6
.Lf41_b12:
jmp .Lf41_b13
.Lf41_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movabsq $6, %rax
movq %rax, -672(%rbp)
movq -664(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_member@PLT
movq %rax, -680(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movq -680(%rbp), %rdi
movq -688(%rbp), %rsi
call f49@PLT
movq %rax, -696(%rbp)
movq -120(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_store@PLT
movq %rax, -704(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movq -712(%rbp), %rdi
movq -720(%rbp), %rsi
movq -728(%rbp), %rdx
call f42@PLT
movq %rax, -736(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movabsq $23, %rax
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -760(%rbp)
movq -112(%rbp), %rdi
movq -760(%rbp), %rsi
call evn_store@PLT
movq %rax, -768(%rbp)
jmp .Lf41_b13
.Lf41_b10:
movq -632(%rbp), %rdi
call evn_truth@PLT
movq %rax, -656(%rbp)
cmpq $0, -656(%rbp)
je .Lf41_b12
jmp .Lf41_b11
.Lf41_b9:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
movq %rax, -632(%rbp)
jmp .Lf41_b10
.Lf41_b8:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movq -848(%rbp), %rax
movq %rax, -856(%rbp)
movq -848(%rbp), %rdi
call evn_truth@PLT
movq %rax, -864(%rbp)
cmpq $0, -864(%rbp)
je .Lf41_b15
jmp .Lf41_b14
.Lf41_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $1, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_int@PLT
movq %rax, -472(%rbp)
movq -456(%rbp), %rdi
movq -472(%rbp), %rsi
call f11@PLT
movq %rax, -480(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $3, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -488(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_binary@PLT
movq %rax, -512(%rbp)
movabsq $16, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_int@PLT
movq %rax, -528(%rbp)
movabsq $4, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -512(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movq -104(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_store@PLT
movq %rax, -552(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call f43@PLT
movq %rax, -576(%rbp)
movq -112(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_store@PLT
movq %rax, -584(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $23, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
call evn_none@PLT
movq %rax, -608(%rbp)
movabsq $5, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
movq -592(%rbp), %rsi
movq -608(%rbp), %rdx
call evn_binary@PLT
movq %rax, -624(%rbp)
movq -624(%rbp), %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
call evn_truth@PLT
movq %rax, -640(%rbp)
cmpq $0, -640(%rbp)
je .Lf41_b10
jmp .Lf41_b9
.Lf41_b6:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movabsq $10, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -408(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -448(%rbp)
cmpq $0, -448(%rbp)
je .Lf41_b8
jmp .Lf41_b7
.Lf41_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call f47@PLT
movq %rax, -320(%rbp)
movq -80(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movabsq $1048576, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movq -88(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $16, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movabsq $3, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -96(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_store@PLT
movq %rax, -400(%rbp)
jmp .Lf41_b6
.Lf41_b4:
jmp .Lf41_b5
.Lf41_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $6, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call f49@PLT
movq %rax, -248(%rbp)
movabsq $23, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -264(%rbp)
movabsq $5, %rax
movq %rax, -272(%rbp)
movq -24(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_store@PLT
movq %rax, -288(%rbp)
jmp .Lf41_b5
.Lf41_b2:
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -208(%rbp)
cmpq $0, -208(%rbp)
je .Lf41_b4
jmp .Lf41_b3
.Lf41_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $5, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movabsq $23, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_none@PLT
movq %rax, -184(%rbp)
movabsq $5, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
movq %rax, -136(%rbp)
jmp .Lf41_b2
.Lf41_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1080(%rbp), %rsi
leaq .Lroots_f41(%rip), %rdx
movq $135, %rcx
call evn_bind_roots@PLT
movq -1056(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1064(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1072(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -1080(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
call evn_void@PLT
movq %rax, -120(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -144(%rbp)
cmpq $0, -144(%rbp)
je .Lf41_b2
jmp .Lf41_b1
.size f41, .-f41
.text
.p2align 4
.type f42, @function
f42:
pushq %rbp
movq %rsp, %rbp
subq $1840, %rsp
movq %rdi, -1824(%rbp)
movq %rsi, -1832(%rbp)
movq %rdx, -1840(%rbp)
leaq -1816(%rbp), %rdi
movq $227, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf42_b0
.Lf42_b44:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1744(%rbp)
movabsq $23, %rax
movq %rax, -1752(%rbp)
movq -1752(%rbp), %rdi
movq -1744(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1760(%rbp)
movabsq $2, %rax
movq %rax, -1768(%rbp)
movq -24(%rbp), %rdi
movq -1768(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1776(%rbp)
movq -1776(%rbp), %rdi
movq -1760(%rbp), %rsi
call evn_store@PLT
movq %rax, -1784(%rbp)
call evn_void@PLT
movq %rax, -1792(%rbp)
movq -8(%rbp), %rdi
movq -1792(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1800(%rbp)
movq -1800(%rbp), %rax
leave
ret
.Lf42_b43:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1680(%rbp)
movabsq $23, %rax
movq %rax, -1688(%rbp)
movq -1688(%rbp), %rdi
movq -1680(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1696(%rbp)
movabsq $3, %rax
movq %rax, -1704(%rbp)
movq -24(%rbp), %rdi
movq -1704(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1712(%rbp)
movq -1712(%rbp), %rdi
movq -1696(%rbp), %rsi
call evn_store@PLT
movq %rax, -1720(%rbp)
call evn_void@PLT
movq %rax, -1728(%rbp)
movq -8(%rbp), %rdi
movq -1728(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1736(%rbp)
movq -1736(%rbp), %rax
leave
ret
.Lf42_b41:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1568(%rbp)
movabsq $23, %rax
movq %rax, -1576(%rbp)
movq -1576(%rbp), %rdi
movq -1568(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1584(%rbp)
movabsq $4, %rax
movq %rax, -1592(%rbp)
movq -24(%rbp), %rdi
movq -1592(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1600(%rbp)
movq -1600(%rbp), %rdi
movq -1584(%rbp), %rsi
call evn_store@PLT
movq %rax, -1608(%rbp)
call evn_void@PLT
movq %rax, -1616(%rbp)
movq -8(%rbp), %rdi
movq -1616(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1624(%rbp)
movq -1624(%rbp), %rax
leave
ret
.Lf42_b40:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1504(%rbp)
movabsq $23, %rax
movq %rax, -1512(%rbp)
movq -1512(%rbp), %rdi
movq -1504(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1520(%rbp)
movabsq $5, %rax
movq %rax, -1528(%rbp)
movq -24(%rbp), %rdi
movq -1528(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1536(%rbp)
movq -1536(%rbp), %rdi
movq -1520(%rbp), %rsi
call evn_store@PLT
movq %rax, -1544(%rbp)
call evn_void@PLT
movq %rax, -1552(%rbp)
movq -8(%rbp), %rdi
movq -1552(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1560(%rbp)
movq -1560(%rbp), %rax
leave
ret
.Lf42_b38:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1632(%rbp)
movabsq $15, %rax
movq %rax, -1640(%rbp)
movq -1640(%rbp), %rdi
call evn_int@PLT
movq %rax, -1648(%rbp)
movabsq $7, %rax
movq %rax, -1656(%rbp)
movq -1656(%rbp), %rdi
movq -1632(%rbp), %rsi
movq -1648(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1672(%rbp)
cmpq $0, -1672(%rbp)
je .Lf42_b44
jmp .Lf42_b43
.Lf42_b37:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1456(%rbp)
movabsq $13, %rax
movq %rax, -1464(%rbp)
movq -1464(%rbp), %rdi
call evn_int@PLT
movq %rax, -1472(%rbp)
movabsq $7, %rax
movq %rax, -1480(%rbp)
movq -1480(%rbp), %rdi
movq -1456(%rbp), %rsi
movq -1472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1488(%rbp)
movq -1488(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1496(%rbp)
cmpq $0, -1496(%rbp)
je .Lf42_b41
jmp .Lf42_b40
.Lf42_b35:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1344(%rbp)
movabsq $23, %rax
movq %rax, -1352(%rbp)
movq -1352(%rbp), %rdi
movq -1344(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1360(%rbp)
movabsq $6, %rax
movq %rax, -1368(%rbp)
movq -24(%rbp), %rdi
movq -1368(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1376(%rbp)
movq -1376(%rbp), %rdi
movq -1360(%rbp), %rsi
call evn_store@PLT
movq %rax, -1384(%rbp)
call evn_void@PLT
movq %rax, -1392(%rbp)
movq -8(%rbp), %rdi
movq -1392(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1400(%rbp)
movq -1400(%rbp), %rax
leave
ret
.Lf42_b34:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1280(%rbp)
movabsq $23, %rax
movq %rax, -1288(%rbp)
movq -1288(%rbp), %rdi
movq -1280(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1296(%rbp)
movabsq $7, %rax
movq %rax, -1304(%rbp)
movq -24(%rbp), %rdi
movq -1304(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
movq -1296(%rbp), %rsi
call evn_store@PLT
movq %rax, -1320(%rbp)
call evn_void@PLT
movq %rax, -1328(%rbp)
movq -8(%rbp), %rdi
movq -1328(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1336(%rbp)
movq -1336(%rbp), %rax
leave
ret
.Lf42_b32:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $23, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
movq -1168(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1184(%rbp)
movabsq $8, %rax
movq %rax, -1192(%rbp)
movq -24(%rbp), %rdi
movq -1192(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
movq -1184(%rbp), %rsi
call evn_store@PLT
movq %rax, -1208(%rbp)
call evn_void@PLT
movq %rax, -1216(%rbp)
movq -8(%rbp), %rdi
movq -1216(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1224(%rbp)
movq -1224(%rbp), %rax
leave
ret
.Lf42_b31:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $23, %rax
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
movq -1104(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1120(%rbp)
movabsq $9, %rax
movq %rax, -1128(%rbp)
movq -24(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1136(%rbp)
movq -1136(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_store@PLT
movq %rax, -1144(%rbp)
call evn_void@PLT
movq %rax, -1152(%rbp)
movq -8(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rax
leave
ret
.Lf42_b29:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1232(%rbp)
movabsq $11, %rax
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rdi
call evn_int@PLT
movq %rax, -1248(%rbp)
movabsq $7, %rax
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
movq -1232(%rbp), %rsi
movq -1248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1264(%rbp)
movq -1264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1272(%rbp)
cmpq $0, -1272(%rbp)
je .Lf42_b35
jmp .Lf42_b34
.Lf42_b28:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movabsq $9, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_int@PLT
movq %rax, -1072(%rbp)
movabsq $7, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1072(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf42_b32
jmp .Lf42_b31
.Lf42_b26:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1408(%rbp)
movabsq $14, %rax
movq %rax, -1416(%rbp)
movq -1416(%rbp), %rdi
call evn_int@PLT
movq %rax, -1424(%rbp)
movabsq $7, %rax
movq %rax, -1432(%rbp)
movq -1432(%rbp), %rdi
movq -1408(%rbp), %rsi
movq -1424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1440(%rbp)
movq -1440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1448(%rbp)
cmpq $0, -1448(%rbp)
je .Lf42_b38
jmp .Lf42_b37
.Lf42_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1008(%rbp)
movabsq $10, %rax
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rdi
call evn_int@PLT
movq %rax, -1024(%rbp)
movabsq $7, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1024(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1048(%rbp)
cmpq $0, -1048(%rbp)
je .Lf42_b29
jmp .Lf42_b28
.Lf42_b23:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $23, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
movq -896(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -912(%rbp)
movabsq $10, %rax
movq %rax, -920(%rbp)
movq -24(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
movq -912(%rbp), %rsi
call evn_store@PLT
movq %rax, -936(%rbp)
call evn_void@PLT
movq %rax, -944(%rbp)
movq -8(%rbp), %rdi
movq -944(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -952(%rbp)
movq -952(%rbp), %rax
leave
ret
.Lf42_b22:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movabsq $23, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
movq -832(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -848(%rbp)
movabsq $11, %rax
movq %rax, -856(%rbp)
movq -24(%rbp), %rdi
movq -856(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -864(%rbp)
movq -864(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_store@PLT
movq %rax, -872(%rbp)
call evn_void@PLT
movq %rax, -880(%rbp)
movq -8(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rax
leave
ret
.Lf42_b20:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movabsq $23, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -736(%rbp)
movabsq $12, %rax
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_store@PLT
movq %rax, -760(%rbp)
call evn_void@PLT
movq %rax, -768(%rbp)
movq -8(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rax
leave
ret
.Lf42_b19:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $23, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -672(%rbp)
movabsq $13, %rax
movq %rax, -680(%rbp)
movq -24(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_store@PLT
movq %rax, -696(%rbp)
call evn_void@PLT
movq %rax, -704(%rbp)
movq -8(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -712(%rbp)
movq -712(%rbp), %rax
leave
ret
.Lf42_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $7, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $7, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
movq -784(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_truth@PLT
movq %rax, -824(%rbp)
cmpq $0, -824(%rbp)
je .Lf42_b23
jmp .Lf42_b22
.Lf42_b16:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $5, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_int@PLT
movq %rax, -624(%rbp)
movabsq $7, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
movq -608(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_binary@PLT
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_truth@PLT
movq %rax, -648(%rbp)
cmpq $0, -648(%rbp)
je .Lf42_b20
jmp .Lf42_b19
.Lf42_b14:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $23, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -512(%rbp)
movabsq $14, %rax
movq %rax, -520(%rbp)
movq -24(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_store@PLT
movq %rax, -536(%rbp)
call evn_void@PLT
movq %rax, -544(%rbp)
movq -8(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rax
leave
ret
.Lf42_b13:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $23, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -448(%rbp)
movabsq $15, %rax
movq %rax, -456(%rbp)
movq -24(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -472(%rbp)
call evn_void@PLT
movq %rax, -480(%rbp)
movq -8(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
leave
ret
.Lf42_b11:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movabsq $23, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -336(%rbp)
movabsq $16, %rax
movq %rax, -344(%rbp)
movq -24(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_store@PLT
movq %rax, -360(%rbp)
call evn_void@PLT
movq %rax, -368(%rbp)
movq -8(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
leave
ret
.Lf42_b10:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $23, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -272(%rbp)
movabsq $17, %rax
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
call evn_void@PLT
movq %rax, -304(%rbp)
movq -8(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
leave
ret
.Lf42_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $3, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $7, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_truth@PLT
movq %rax, -424(%rbp)
cmpq $0, -424(%rbp)
je .Lf42_b14
jmp .Lf42_b13
.Lf42_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $7, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf42_b11
jmp .Lf42_b10
.Lf42_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $6, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
call evn_int@PLT
movq %rax, -576(%rbp)
movabsq $7, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
movq -560(%rbp), %rsi
movq -576(%rbp), %rdx
call evn_binary@PLT
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
call evn_truth@PLT
movq %rax, -600(%rbp)
cmpq $0, -600(%rbp)
je .Lf42_b17
jmp .Lf42_b16
.Lf42_b4:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $2, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $7, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf42_b8
jmp .Lf42_b7
.Lf42_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movabsq $12, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
call evn_int@PLT
movq %rax, -976(%rbp)
movabsq $7, %rax
movq %rax, -984(%rbp)
movq -984(%rbp), %rdi
movq -960(%rbp), %rsi
movq -976(%rbp), %rdx
call evn_binary@PLT
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1000(%rbp)
cmpq $0, -1000(%rbp)
je .Lf42_b26
jmp .Lf42_b25
.Lf42_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $4, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $7, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf42_b5
jmp .Lf42_b4
.Lf42_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1840(%rbp), %rsi
leaq .Lroots_f42(%rip), %rdx
movq $230, %rcx
call evn_bind_roots@PLT
movq -1824(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1832(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1840(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $8, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf42_b2
jmp .Lf42_b1
.size f42, .-f42
.text
.p2align 4
.type f43, @function
f43:
pushq %rbp
movq %rsp, %rbp
subq $1312, %rsp
movq %rdi, -1296(%rbp)
movq %rsi, -1304(%rbp)
leaq -1288(%rbp), %rdi
movq $161, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf43_b0
.Lf43_b44:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movabsq $2, %rax
movq %rax, -1256(%rbp)
movq -1248(%rbp), %rdi
movq -1256(%rbp), %rsi
call evn_member@PLT
movq %rax, -1264(%rbp)
movq -8(%rbp), %rdi
movq -1264(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rax
leave
ret
.Lf43_b43:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movabsq $3, %rax
movq %rax, -1224(%rbp)
movq -1216(%rbp), %rdi
movq -1224(%rbp), %rsi
call evn_member@PLT
movq %rax, -1232(%rbp)
movq -8(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rax
leave
ret
.Lf43_b41:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1136(%rbp)
movabsq $4, %rax
movq %rax, -1144(%rbp)
movq -1136(%rbp), %rdi
movq -1144(%rbp), %rsi
call evn_member@PLT
movq %rax, -1152(%rbp)
movq -8(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rax
leave
ret
.Lf43_b40:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $5, %rax
movq %rax, -1112(%rbp)
movq -1104(%rbp), %rdi
movq -1112(%rbp), %rsi
call evn_member@PLT
movq %rax, -1120(%rbp)
movq -8(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1128(%rbp)
movq -1128(%rbp), %rax
leave
ret
.Lf43_b38:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $15, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
call evn_int@PLT
movq %rax, -1184(%rbp)
movabsq $7, %rax
movq %rax, -1192(%rbp)
movq -1192(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1208(%rbp)
cmpq $0, -1208(%rbp)
je .Lf43_b44
jmp .Lf43_b43
.Lf43_b37:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movabsq $13, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_int@PLT
movq %rax, -1072(%rbp)
movabsq $7, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1072(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf43_b41
jmp .Lf43_b40
.Lf43_b35:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movabsq $6, %rax
movq %rax, -984(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_member@PLT
movq %rax, -992(%rbp)
movq -8(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rax
leave
ret
.Lf43_b34:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $7, %rax
movq %rax, -952(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_member@PLT
movq %rax, -960(%rbp)
movq -8(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -968(%rbp)
movq -968(%rbp), %rax
leave
ret
.Lf43_b32:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movabsq $8, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_member@PLT
movq %rax, -880(%rbp)
movq -8(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rax
leave
ret
.Lf43_b31:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movabsq $9, %rax
movq %rax, -840(%rbp)
movq -832(%rbp), %rdi
movq -840(%rbp), %rsi
call evn_member@PLT
movq %rax, -848(%rbp)
movq -8(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -856(%rbp)
movq -856(%rbp), %rax
leave
ret
.Lf43_b29:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $11, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_int@PLT
movq %rax, -912(%rbp)
movabsq $7, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
movq -896(%rbp), %rsi
movq -912(%rbp), %rdx
call evn_binary@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
call evn_truth@PLT
movq %rax, -936(%rbp)
cmpq $0, -936(%rbp)
je .Lf43_b35
jmp .Lf43_b34
.Lf43_b28:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $9, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $7, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
movq -784(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_truth@PLT
movq %rax, -824(%rbp)
cmpq $0, -824(%rbp)
je .Lf43_b32
jmp .Lf43_b31
.Lf43_b26:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1008(%rbp)
movabsq $14, %rax
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rdi
call evn_int@PLT
movq %rax, -1024(%rbp)
movabsq $7, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1024(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1048(%rbp)
cmpq $0, -1048(%rbp)
je .Lf43_b38
jmp .Lf43_b37
.Lf43_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $10, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
call evn_int@PLT
movq %rax, -752(%rbp)
movabsq $7, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
movq -736(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_binary@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
call evn_truth@PLT
movq %rax, -776(%rbp)
cmpq $0, -776(%rbp)
je .Lf43_b29
jmp .Lf43_b28
.Lf43_b23:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $10, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movq -8(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
leave
ret
.Lf43_b22:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $11, %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_member@PLT
movq %rax, -640(%rbp)
movq -8(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
leave
ret
.Lf43_b20:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $12, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member@PLT
movq %rax, -560(%rbp)
movq -8(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -568(%rbp)
movq -568(%rbp), %rax
leave
ret
.Lf43_b19:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $13, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movq -8(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
leave
ret
.Lf43_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $7, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $7, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf43_b23
jmp .Lf43_b22
.Lf43_b16:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_int@PLT
movq %rax, -480(%rbp)
movabsq $7, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -464(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -504(%rbp)
cmpq $0, -504(%rbp)
je .Lf43_b20
jmp .Lf43_b19
.Lf43_b14:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $14, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movq -8(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
leave
ret
.Lf43_b13:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $15, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -8(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
leave
ret
.Lf43_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $16, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf43_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $17, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf43_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $3, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $7, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf43_b14
jmp .Lf43_b13
.Lf43_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $1, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movabsq $7, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf43_b11
jmp .Lf43_b10
.Lf43_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $6, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $7, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -416(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_truth@PLT
movq %rax, -456(%rbp)
cmpq $0, -456(%rbp)
je .Lf43_b17
jmp .Lf43_b16
.Lf43_b4:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $2, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $7, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_truth@PLT
movq %rax, -184(%rbp)
cmpq $0, -184(%rbp)
je .Lf43_b8
jmp .Lf43_b7
.Lf43_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $12, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_binary@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_truth@PLT
movq %rax, -728(%rbp)
cmpq $0, -728(%rbp)
je .Lf43_b26
jmp .Lf43_b25
.Lf43_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $4, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $7, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf43_b5
jmp .Lf43_b4
.Lf43_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1304(%rbp), %rsi
leaq .Lroots_f43(%rip), %rdx
movq $163, %rcx
call evn_bind_roots@PLT
movq -1296(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1304(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $8, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $7, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf43_b2
jmp .Lf43_b1
.size f43, .-f43
.text
.p2align 4
.type f44, @function
f44:
pushq %rbp
movq %rsp, %rbp
subq $1584, %rsp
movq %rdi, -1568(%rbp)
movq %rsi, -1576(%rbp)
movq %rdx, -1584(%rbp)
leaq -1560(%rbp), %rdi
movq $195, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf44_b0
.Lf44_b44:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1504(%rbp)
movabsq $1, %rax
movq %rax, -1512(%rbp)
movq -24(%rbp), %rdi
movq -1512(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1520(%rbp)
movq -1520(%rbp), %rdi
movq -1504(%rbp), %rsi
call evn_store@PLT
movq %rax, -1528(%rbp)
call evn_void@PLT
movq %rax, -1536(%rbp)
movq -8(%rbp), %rdi
movq -1536(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1544(%rbp)
movq -1544(%rbp), %rax
leave
ret
.Lf44_b43:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1456(%rbp)
movabsq $2, %rax
movq %rax, -1464(%rbp)
movq -24(%rbp), %rdi
movq -1464(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1472(%rbp)
movq -1472(%rbp), %rdi
movq -1456(%rbp), %rsi
call evn_store@PLT
movq %rax, -1480(%rbp)
call evn_void@PLT
movq %rax, -1488(%rbp)
movq -8(%rbp), %rdi
movq -1488(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1496(%rbp)
movq -1496(%rbp), %rax
leave
ret
.Lf44_b41:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1360(%rbp)
movabsq $3, %rax
movq %rax, -1368(%rbp)
movq -24(%rbp), %rdi
movq -1368(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1376(%rbp)
movq -1376(%rbp), %rdi
movq -1360(%rbp), %rsi
call evn_store@PLT
movq %rax, -1384(%rbp)
call evn_void@PLT
movq %rax, -1392(%rbp)
movq -8(%rbp), %rdi
movq -1392(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1400(%rbp)
movq -1400(%rbp), %rax
leave
ret
.Lf44_b40:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1312(%rbp)
movabsq $4, %rax
movq %rax, -1320(%rbp)
movq -24(%rbp), %rdi
movq -1320(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1328(%rbp)
movq -1328(%rbp), %rdi
movq -1312(%rbp), %rsi
call evn_store@PLT
movq %rax, -1336(%rbp)
call evn_void@PLT
movq %rax, -1344(%rbp)
movq -8(%rbp), %rdi
movq -1344(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1352(%rbp)
movq -1352(%rbp), %rax
leave
ret
.Lf44_b38:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1408(%rbp)
movabsq $15, %rax
movq %rax, -1416(%rbp)
movq -1416(%rbp), %rdi
call evn_int@PLT
movq %rax, -1424(%rbp)
movabsq $7, %rax
movq %rax, -1432(%rbp)
movq -1432(%rbp), %rdi
movq -1408(%rbp), %rsi
movq -1424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1440(%rbp)
movq -1440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1448(%rbp)
cmpq $0, -1448(%rbp)
je .Lf44_b44
jmp .Lf44_b43
.Lf44_b37:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1264(%rbp)
movabsq $13, %rax
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rdi
call evn_int@PLT
movq %rax, -1280(%rbp)
movabsq $7, %rax
movq %rax, -1288(%rbp)
movq -1288(%rbp), %rdi
movq -1264(%rbp), %rsi
movq -1280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1296(%rbp)
movq -1296(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1304(%rbp)
cmpq $0, -1304(%rbp)
je .Lf44_b41
jmp .Lf44_b40
.Lf44_b35:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $5, %rax
movq %rax, -1176(%rbp)
movq -24(%rbp), %rdi
movq -1176(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1184(%rbp)
movq -1184(%rbp), %rdi
movq -1168(%rbp), %rsi
call evn_store@PLT
movq %rax, -1192(%rbp)
call evn_void@PLT
movq %rax, -1200(%rbp)
movq -8(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1208(%rbp)
movq -1208(%rbp), %rax
leave
ret
.Lf44_b34:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1120(%rbp)
movabsq $6, %rax
movq %rax, -1128(%rbp)
movq -24(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1136(%rbp)
movq -1136(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_store@PLT
movq %rax, -1144(%rbp)
call evn_void@PLT
movq %rax, -1152(%rbp)
movq -8(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rax
leave
ret
.Lf44_b32:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movabsq $7, %rax
movq %rax, -1032(%rbp)
movq -24(%rbp), %rdi
movq -1032(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_store@PLT
movq %rax, -1048(%rbp)
call evn_void@PLT
movq %rax, -1056(%rbp)
movq -8(%rbp), %rdi
movq -1056(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rax
leave
ret
.Lf44_b31:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movabsq $8, %rax
movq %rax, -984(%rbp)
movq -24(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
movq -976(%rbp), %rsi
call evn_store@PLT
movq %rax, -1000(%rbp)
call evn_void@PLT
movq %rax, -1008(%rbp)
movq -8(%rbp), %rdi
movq -1008(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rax
leave
ret
.Lf44_b29:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movabsq $11, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
call evn_int@PLT
movq %rax, -1088(%rbp)
movabsq $7, %rax
movq %rax, -1096(%rbp)
movq -1096(%rbp), %rdi
movq -1072(%rbp), %rsi
movq -1088(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1104(%rbp)
movq -1104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1112(%rbp)
cmpq $0, -1112(%rbp)
je .Lf44_b35
jmp .Lf44_b34
.Lf44_b28:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -928(%rbp)
movabsq $9, %rax
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
call evn_int@PLT
movq %rax, -944(%rbp)
movabsq $7, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
movq -928(%rbp), %rsi
movq -944(%rbp), %rdx
call evn_binary@PLT
movq %rax, -960(%rbp)
movq -960(%rbp), %rdi
call evn_truth@PLT
movq %rax, -968(%rbp)
cmpq $0, -968(%rbp)
je .Lf44_b32
jmp .Lf44_b31
.Lf44_b26:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movabsq $14, %rax
movq %rax, -1224(%rbp)
movq -1224(%rbp), %rdi
call evn_int@PLT
movq %rax, -1232(%rbp)
movabsq $7, %rax
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rdi
movq -1216(%rbp), %rsi
movq -1232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1248(%rbp)
movq -1248(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1256(%rbp)
cmpq $0, -1256(%rbp)
je .Lf44_b38
jmp .Lf44_b37
.Lf44_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -880(%rbp)
movabsq $10, %rax
movq %rax, -888(%rbp)
movq -888(%rbp), %rdi
call evn_int@PLT
movq %rax, -896(%rbp)
movabsq $7, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
movq -880(%rbp), %rsi
movq -896(%rbp), %rdx
call evn_binary@PLT
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
call evn_truth@PLT
movq %rax, -920(%rbp)
cmpq $0, -920(%rbp)
je .Lf44_b29
jmp .Lf44_b28
.Lf44_b23:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $9, %rax
movq %rax, -792(%rbp)
movq -24(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_store@PLT
movq %rax, -808(%rbp)
call evn_void@PLT
movq %rax, -816(%rbp)
movq -8(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -824(%rbp)
movq -824(%rbp), %rax
leave
ret
.Lf44_b22:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $10, %rax
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_store@PLT
movq %rax, -760(%rbp)
call evn_void@PLT
movq %rax, -768(%rbp)
movq -8(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rax
leave
ret
.Lf44_b20:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -640(%rbp)
movabsq $11, %rax
movq %rax, -648(%rbp)
movq -24(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_store@PLT
movq %rax, -664(%rbp)
call evn_void@PLT
movq %rax, -672(%rbp)
movq -8(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
leave
ret
.Lf44_b19:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $12, %rax
movq %rax, -600(%rbp)
movq -24(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
movq -592(%rbp), %rsi
call evn_store@PLT
movq %rax, -616(%rbp)
call evn_void@PLT
movq %rax, -624(%rbp)
movq -8(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rax
leave
ret
.Lf44_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $7, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_binary@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_truth@PLT
movq %rax, -728(%rbp)
cmpq $0, -728(%rbp)
je .Lf44_b23
jmp .Lf44_b22
.Lf44_b16:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $5, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $7, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -544(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_truth@PLT
movq %rax, -584(%rbp)
cmpq $0, -584(%rbp)
je .Lf44_b20
jmp .Lf44_b19
.Lf44_b14:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movabsq $13, %rax
movq %rax, -456(%rbp)
movq -24(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -472(%rbp)
call evn_void@PLT
movq %rax, -480(%rbp)
movq -8(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
leave
ret
.Lf44_b13:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $14, %rax
movq %rax, -408(%rbp)
movq -24(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_store@PLT
movq %rax, -424(%rbp)
call evn_void@PLT
movq %rax, -432(%rbp)
movq -8(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rax
leave
ret
.Lf44_b11:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $15, %rax
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
call evn_void@PLT
movq %rax, -336(%rbp)
movq -8(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rax
leave
ret
.Lf44_b10:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $16, %rax
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -280(%rbp)
call evn_void@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf44_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $3, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movabsq $7, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_truth@PLT
movq %rax, -392(%rbp)
cmpq $0, -392(%rbp)
je .Lf44_b14
jmp .Lf44_b13
.Lf44_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $7, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf44_b11
jmp .Lf44_b10
.Lf44_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $6, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_int@PLT
movq %rax, -512(%rbp)
movabsq $7, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
movq -496(%rbp), %rsi
movq -512(%rbp), %rdx
call evn_binary@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call evn_truth@PLT
movq %rax, -536(%rbp)
cmpq $0, -536(%rbp)
je .Lf44_b17
jmp .Lf44_b16
.Lf44_b4:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $2, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $7, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
movq -160(%rbp), %rsi
movq -176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf44_b8
jmp .Lf44_b7
.Lf44_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movabsq $12, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
call evn_int@PLT
movq %rax, -848(%rbp)
movabsq $7, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
movq -832(%rbp), %rsi
movq -848(%rbp), %rdx
call evn_binary@PLT
movq %rax, -864(%rbp)
movq -864(%rbp), %rdi
call evn_truth@PLT
movq %rax, -872(%rbp)
cmpq $0, -872(%rbp)
je .Lf44_b26
jmp .Lf44_b25
.Lf44_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $4, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $7, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf44_b5
jmp .Lf44_b4
.Lf44_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1584(%rbp), %rsi
leaq .Lroots_f44(%rip), %rdx
movq $198, %rcx
call evn_bind_roots@PLT
movq -1568(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1576(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1584(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $8, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -104(%rbp)
cmpq $0, -104(%rbp)
je .Lf44_b2
jmp .Lf44_b1
.size f44, .-f44
.text
.p2align 4
.type f45, @function
f45:
pushq %rbp
movq %rsp, %rbp
subq $1312, %rsp
movq %rdi, -1296(%rbp)
movq %rsi, -1304(%rbp)
leaq -1288(%rbp), %rdi
movq $161, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf45_b0
.Lf45_b44:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movabsq $1, %rax
movq %rax, -1256(%rbp)
movq -1248(%rbp), %rdi
movq -1256(%rbp), %rsi
call evn_member@PLT
movq %rax, -1264(%rbp)
movq -8(%rbp), %rdi
movq -1264(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rax
leave
ret
.Lf45_b43:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movabsq $2, %rax
movq %rax, -1224(%rbp)
movq -1216(%rbp), %rdi
movq -1224(%rbp), %rsi
call evn_member@PLT
movq %rax, -1232(%rbp)
movq -8(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rax
leave
ret
.Lf45_b41:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1136(%rbp)
movabsq $3, %rax
movq %rax, -1144(%rbp)
movq -1136(%rbp), %rdi
movq -1144(%rbp), %rsi
call evn_member@PLT
movq %rax, -1152(%rbp)
movq -8(%rbp), %rdi
movq -1152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rax
leave
ret
.Lf45_b40:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $4, %rax
movq %rax, -1112(%rbp)
movq -1104(%rbp), %rdi
movq -1112(%rbp), %rsi
call evn_member@PLT
movq %rax, -1120(%rbp)
movq -8(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1128(%rbp)
movq -1128(%rbp), %rax
leave
ret
.Lf45_b38:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1168(%rbp)
movabsq $15, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
call evn_int@PLT
movq %rax, -1184(%rbp)
movabsq $7, %rax
movq %rax, -1192(%rbp)
movq -1192(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1208(%rbp)
cmpq $0, -1208(%rbp)
je .Lf45_b44
jmp .Lf45_b43
.Lf45_b37:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movabsq $13, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_int@PLT
movq %rax, -1072(%rbp)
movabsq $7, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1072(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf45_b41
jmp .Lf45_b40
.Lf45_b35:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movabsq $5, %rax
movq %rax, -984(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_member@PLT
movq %rax, -992(%rbp)
movq -8(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rax
leave
ret
.Lf45_b34:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $6, %rax
movq %rax, -952(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_member@PLT
movq %rax, -960(%rbp)
movq -8(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -968(%rbp)
movq -968(%rbp), %rax
leave
ret
.Lf45_b32:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movabsq $7, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_member@PLT
movq %rax, -880(%rbp)
movq -8(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rax
leave
ret
.Lf45_b31:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movabsq $8, %rax
movq %rax, -840(%rbp)
movq -832(%rbp), %rdi
movq -840(%rbp), %rsi
call evn_member@PLT
movq %rax, -848(%rbp)
movq -8(%rbp), %rdi
movq -848(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -856(%rbp)
movq -856(%rbp), %rax
leave
ret
.Lf45_b29:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $11, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_int@PLT
movq %rax, -912(%rbp)
movabsq $7, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
movq -896(%rbp), %rsi
movq -912(%rbp), %rdx
call evn_binary@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
call evn_truth@PLT
movq %rax, -936(%rbp)
cmpq $0, -936(%rbp)
je .Lf45_b35
jmp .Lf45_b34
.Lf45_b28:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $9, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $7, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
movq -784(%rbp), %rsi
movq -800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_truth@PLT
movq %rax, -824(%rbp)
cmpq $0, -824(%rbp)
je .Lf45_b32
jmp .Lf45_b31
.Lf45_b26:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1008(%rbp)
movabsq $14, %rax
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rdi
call evn_int@PLT
movq %rax, -1024(%rbp)
movabsq $7, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1024(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1048(%rbp)
cmpq $0, -1048(%rbp)
je .Lf45_b38
jmp .Lf45_b37
.Lf45_b25:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $10, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
call evn_int@PLT
movq %rax, -752(%rbp)
movabsq $7, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
movq -736(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_binary@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
call evn_truth@PLT
movq %rax, -776(%rbp)
cmpq $0, -776(%rbp)
je .Lf45_b29
jmp .Lf45_b28
.Lf45_b23:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $9, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movq -8(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
leave
ret
.Lf45_b22:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $10, %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_member@PLT
movq %rax, -640(%rbp)
movq -8(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
leave
ret
.Lf45_b20:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $11, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member@PLT
movq %rax, -560(%rbp)
movq -8(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -568(%rbp)
movq -568(%rbp), %rax
leave
ret
.Lf45_b19:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $12, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movq -8(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
leave
ret
.Lf45_b17:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $7, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $7, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf45_b23
jmp .Lf45_b22
.Lf45_b16:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_int@PLT
movq %rax, -480(%rbp)
movabsq $7, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -464(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -504(%rbp)
cmpq $0, -504(%rbp)
je .Lf45_b20
jmp .Lf45_b19
.Lf45_b14:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $13, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movq -8(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
leave
ret
.Lf45_b13:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $14, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -8(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
leave
ret
.Lf45_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $15, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -8(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
leave
ret
.Lf45_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $16, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -8(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rax
leave
ret
.Lf45_b8:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $3, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $7, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf45_b14
jmp .Lf45_b13
.Lf45_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $1, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movabsq $7, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf45_b11
jmp .Lf45_b10
.Lf45_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $6, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $7, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -416(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_truth@PLT
movq %rax, -456(%rbp)
cmpq $0, -456(%rbp)
je .Lf45_b17
jmp .Lf45_b16
.Lf45_b4:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $2, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $7, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_truth@PLT
movq %rax, -184(%rbp)
cmpq $0, -184(%rbp)
je .Lf45_b8
jmp .Lf45_b7
.Lf45_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movabsq $12, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movabsq $7, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_binary@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_truth@PLT
movq %rax, -728(%rbp)
cmpq $0, -728(%rbp)
je .Lf45_b26
jmp .Lf45_b25
.Lf45_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $4, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $7, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf45_b5
jmp .Lf45_b4
.Lf45_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1304(%rbp), %rsi
leaq .Lroots_f45(%rip), %rdx
movq $163, %rcx
call evn_bind_roots@PLT
movq -1296(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1304(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $8, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $7, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
movq -48(%rbp), %rsi
movq -64(%rbp), %rdx
call evn_binary@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf45_b2
jmp .Lf45_b1
.size f45, .-f45
.text
.p2align 4
.type f46, @function
f46:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -288(%rbp)
leaq -280(%rbp), %rdi
movq $35, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf46_b0
.Lf46_b3:
movabsq $9, %rax
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_object@PLT
movq %rax, -120(%rbp)
leaq .Ldata_11(%rip), %rax
movq %rax, -128(%rbp)
movabsq $21, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_text@PLT
movq %rax, -144(%rbp)
movabsq $3, %rax
movq %rax, -152(%rbp)
movq -120(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
leaq .Ldata_12(%rip), %rax
movq %rax, -168(%rbp)
movabsq $13, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movabsq $2, %rax
movq %rax, -192(%rbp)
movq -120(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -120(%rbp), %rdi
movq -224(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_init@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -120(%rbp), %rdi
movq -256(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_init@PLT
movq %rax, -264(%rbp)
movabsq $3, %rax
movq %rax, -272(%rbp)
movq -120(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_fail@PLT
movq %rax, -280(%rbp)
ud2
.Lf46_b2:
jmp .Lf46_b3
.Lf46_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_get@PLT
movq %rax, -88(%rbp)
movq -8(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
leave
ret
.Lf46_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f46(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $21, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_none@PLT
movq %rax, -48(%rbp)
movabsq $6, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -72(%rbp)
cmpq $0, -72(%rbp)
je .Lf46_b2
jmp .Lf46_b1
.size f46, .-f46
.text
.p2align 4
.type f47, @function
f47:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -288(%rbp)
leaq -280(%rbp), %rdi
movq $35, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf47_b0
.Lf47_b3:
movabsq $9, %rax
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_object@PLT
movq %rax, -120(%rbp)
leaq .Ldata_13(%rip), %rax
movq %rax, -128(%rbp)
movabsq $22, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_text@PLT
movq %rax, -144(%rbp)
movabsq $3, %rax
movq %rax, -152(%rbp)
movq -120(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
leaq .Ldata_14(%rip), %rax
movq %rax, -168(%rbp)
movabsq $13, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movabsq $2, %rax
movq %rax, -192(%rbp)
movq -120(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -120(%rbp), %rdi
movq -224(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_init@PLT
movq %rax, -232(%rbp)
movabsq $0, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -120(%rbp), %rdi
movq -256(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_init@PLT
movq %rax, -264(%rbp)
movabsq $3, %rax
movq %rax, -272(%rbp)
movq -120(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_fail@PLT
movq %rax, -280(%rbp)
ud2
.Lf47_b2:
jmp .Lf47_b3
.Lf47_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_get@PLT
movq %rax, -88(%rbp)
movq -8(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
leave
ret
.Lf47_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f47(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $23, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_none@PLT
movq %rax, -48(%rbp)
movabsq $6, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -72(%rbp)
cmpq $0, -72(%rbp)
je .Lf47_b2
jmp .Lf47_b1
.size f47, .-f47
.text
.p2align 4
.type f48, @function
f48:
pushq %rbp
movq %rsp, %rbp
subq $816, %rsp
movq %rdi, -800(%rbp)
movq %rsi, -808(%rbp)
leaq -792(%rbp), %rdi
movq $99, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf48_b0
.Lf48_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -808(%rbp), %rsi
leaq .Lroots_f48(%rip), %rdx
movq $101, %rcx
call evn_bind_roots@PLT
movq -800(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -808(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $17, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
call f11@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $768, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movq -96(%rbp), %rdi
movq -112(%rbp), %rsi
call f22@PLT
movq %rax, -120(%rbp)
movq -48(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movabsq $19, %rax
movq %rax, -136(%rbp)
movabsq $17, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_object@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $16, %rax
movq %rax, -176(%rbp)
movq -152(%rbp), %rdi
movq -176(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_init@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $15, %rax
movq %rax, -208(%rbp)
movq -152(%rbp), %rdi
movq -208(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_init@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $14, %rax
movq %rax, -240(%rbp)
movq -152(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movabsq $13, %rax
movq %rax, -272(%rbp)
movq -152(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $0, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_int@PLT
movq %rax, -296(%rbp)
movabsq $12, %rax
movq %rax, -304(%rbp)
movq -152(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $11, %rax
movq %rax, -336(%rbp)
movq -152(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movabsq $0, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_int@PLT
movq %rax, -360(%rbp)
movabsq $10, %rax
movq %rax, -368(%rbp)
movq -152(%rbp), %rdi
movq -368(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_init@PLT
movq %rax, -376(%rbp)
movabsq $0, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_int@PLT
movq %rax, -392(%rbp)
movabsq $9, %rax
movq %rax, -400(%rbp)
movq -152(%rbp), %rdi
movq -400(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_init@PLT
movq %rax, -408(%rbp)
movabsq $0, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movabsq $8, %rax
movq %rax, -432(%rbp)
movq -152(%rbp), %rdi
movq -432(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_init@PLT
movq %rax, -440(%rbp)
movabsq $0, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $7, %rax
movq %rax, -464(%rbp)
movq -152(%rbp), %rdi
movq -464(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_init@PLT
movq %rax, -472(%rbp)
movabsq $0, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $6, %rax
movq %rax, -496(%rbp)
movq -152(%rbp), %rdi
movq -496(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_init@PLT
movq %rax, -504(%rbp)
movabsq $0, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_int@PLT
movq %rax, -520(%rbp)
movabsq $5, %rax
movq %rax, -528(%rbp)
movq -152(%rbp), %rdi
movq -528(%rbp), %rsi
movq -520(%rbp), %rdx
call evn_init@PLT
movq %rax, -536(%rbp)
movabsq $0, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call evn_int@PLT
movq %rax, -552(%rbp)
movabsq $4, %rax
movq %rax, -560(%rbp)
movq -152(%rbp), %rdi
movq -560(%rbp), %rsi
movq -552(%rbp), %rdx
call evn_init@PLT
movq %rax, -568(%rbp)
movabsq $0, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_int@PLT
movq %rax, -584(%rbp)
movabsq $3, %rax
movq %rax, -592(%rbp)
movq -152(%rbp), %rdi
movq -592(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_init@PLT
movq %rax, -600(%rbp)
movabsq $0, %rax
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_int@PLT
movq %rax, -616(%rbp)
movabsq $2, %rax
movq %rax, -624(%rbp)
movq -152(%rbp), %rdi
movq -624(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_init@PLT
movq %rax, -632(%rbp)
movabsq $0, %rax
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_int@PLT
movq %rax, -648(%rbp)
movabsq $1, %rax
movq %rax, -656(%rbp)
movq -152(%rbp), %rdi
movq -656(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_init@PLT
movq %rax, -664(%rbp)
movabsq $18, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_none@PLT
movq %rax, -680(%rbp)
movabsq $0, %rax
movq %rax, -688(%rbp)
movq -152(%rbp), %rdi
movq -688(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_init@PLT
movq %rax, -696(%rbp)
movabsq $20, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -712(%rbp)
movq -56(%rbp), %rdi
movq -712(%rbp), %rsi
call evn_store@PLT
movq %rax, -720(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call f20@PLT
movq %rax, -736(%rbp)
movabsq $18, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -752(%rbp)
movabsq $0, %rax
movq %rax, -760(%rbp)
movq -56(%rbp), %rdi
movq -760(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
movq -752(%rbp), %rsi
call evn_store@PLT
movq %rax, -776(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movq -8(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -792(%rbp)
movq -792(%rbp), %rax
leave
ret
.size f48, .-f48
.text
.p2align 4
.type f49, @function
f49:
pushq %rbp
movq %rsp, %rbp
subq $848, %rsp
movq %rdi, -832(%rbp)
movq %rsi, -840(%rbp)
leaq -824(%rbp), %rdi
movq $103, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf49_b0
.Lf49_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -840(%rbp), %rsi
leaq .Lroots_f49(%rip), %rdx
movq $105, %rcx
call evn_bind_roots@PLT
movq -832(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -840(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $18, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
call f11@PLT
movq %rax, -88(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $800, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movq -96(%rbp), %rdi
movq -112(%rbp), %rsi
call f22@PLT
movq %rax, -120(%rbp)
movq -48(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movabsq $17, %rax
movq %rax, -136(%rbp)
movabsq $18, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_object@PLT
movq %rax, -152(%rbp)
movabsq $23, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_none@PLT
movq %rax, -168(%rbp)
movabsq $17, %rax
movq %rax, -176(%rbp)
movq -152(%rbp), %rdi
movq -176(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_init@PLT
movq %rax, -184(%rbp)
movabsq $23, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_none@PLT
movq %rax, -200(%rbp)
movabsq $16, %rax
movq %rax, -208(%rbp)
movq -152(%rbp), %rdi
movq -208(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_init@PLT
movq %rax, -216(%rbp)
movabsq $23, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_none@PLT
movq %rax, -232(%rbp)
movabsq $15, %rax
movq %rax, -240(%rbp)
movq -152(%rbp), %rdi
movq -240(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_init@PLT
movq %rax, -248(%rbp)
movabsq $23, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_none@PLT
movq %rax, -264(%rbp)
movabsq $14, %rax
movq %rax, -272(%rbp)
movq -152(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $23, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_none@PLT
movq %rax, -296(%rbp)
movabsq $13, %rax
movq %rax, -304(%rbp)
movq -152(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $23, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_none@PLT
movq %rax, -328(%rbp)
movabsq $12, %rax
movq %rax, -336(%rbp)
movq -152(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movabsq $23, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_none@PLT
movq %rax, -360(%rbp)
movabsq $11, %rax
movq %rax, -368(%rbp)
movq -152(%rbp), %rdi
movq -368(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_init@PLT
movq %rax, -376(%rbp)
movabsq $23, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_none@PLT
movq %rax, -392(%rbp)
movabsq $10, %rax
movq %rax, -400(%rbp)
movq -152(%rbp), %rdi
movq -400(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_init@PLT
movq %rax, -408(%rbp)
movabsq $23, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_none@PLT
movq %rax, -424(%rbp)
movabsq $9, %rax
movq %rax, -432(%rbp)
movq -152(%rbp), %rdi
movq -432(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_init@PLT
movq %rax, -440(%rbp)
movabsq $23, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_none@PLT
movq %rax, -456(%rbp)
movabsq $8, %rax
movq %rax, -464(%rbp)
movq -152(%rbp), %rdi
movq -464(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_init@PLT
movq %rax, -472(%rbp)
movabsq $23, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_none@PLT
movq %rax, -488(%rbp)
movabsq $7, %rax
movq %rax, -496(%rbp)
movq -152(%rbp), %rdi
movq -496(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_init@PLT
movq %rax, -504(%rbp)
movabsq $23, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_none@PLT
movq %rax, -520(%rbp)
movabsq $6, %rax
movq %rax, -528(%rbp)
movq -152(%rbp), %rdi
movq -528(%rbp), %rsi
movq -520(%rbp), %rdx
call evn_init@PLT
movq %rax, -536(%rbp)
movabsq $23, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call evn_none@PLT
movq %rax, -552(%rbp)
movabsq $5, %rax
movq %rax, -560(%rbp)
movq -152(%rbp), %rdi
movq -560(%rbp), %rsi
movq -552(%rbp), %rdx
call evn_init@PLT
movq %rax, -568(%rbp)
movabsq $23, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_none@PLT
movq %rax, -584(%rbp)
movabsq $4, %rax
movq %rax, -592(%rbp)
movq -152(%rbp), %rdi
movq -592(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_init@PLT
movq %rax, -600(%rbp)
movabsq $23, %rax
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_none@PLT
movq %rax, -616(%rbp)
movabsq $3, %rax
movq %rax, -624(%rbp)
movq -152(%rbp), %rdi
movq -624(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_init@PLT
movq %rax, -632(%rbp)
movabsq $23, %rax
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
call evn_none@PLT
movq %rax, -648(%rbp)
movabsq $2, %rax
movq %rax, -656(%rbp)
movq -152(%rbp), %rdi
movq -656(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_init@PLT
movq %rax, -664(%rbp)
movabsq $21, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_none@PLT
movq %rax, -680(%rbp)
movabsq $1, %rax
movq %rax, -688(%rbp)
movq -152(%rbp), %rdi
movq -688(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_init@PLT
movq %rax, -696(%rbp)
movabsq $18, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call evn_none@PLT
movq %rax, -712(%rbp)
movabsq $0, %rax
movq %rax, -720(%rbp)
movq -152(%rbp), %rdi
movq -720(%rbp), %rsi
movq -712(%rbp), %rdx
call evn_init@PLT
movq %rax, -728(%rbp)
movabsq $22, %rax
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -744(%rbp)
movq -56(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_store@PLT
movq %rax, -752(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call f20@PLT
movq %rax, -768(%rbp)
movabsq $18, %rax
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -784(%rbp)
movabsq $0, %rax
movq %rax, -792(%rbp)
movq -56(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_store@PLT
movq %rax, -808(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movq -8(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -824(%rbp)
movq -824(%rbp), %rax
leave
ret
.size f49, .-f49
.text
.p2align 4
.type f50, @function
f50:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -512(%rbp)
movq %rsi, -520(%rbp)
leaq -504(%rbp), %rdi
movq $63, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf50_b0
.Lf50_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $512, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movq -200(%rbp), %rdi
movq -216(%rbp), %rsi
call f22@PLT
movq %rax, -224(%rbp)
movq -48(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movabsq $16, %rax
movq %rax, -240(%rbp)
movabsq $7, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_object@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $6, %rax
movq %rax, -272(%rbp)
movq -256(%rbp), %rdi
movq -272(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_init@PLT
movq %rax, -280(%rbp)
movabsq $23, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_none@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -256(%rbp), %rdi
movq -304(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_init@PLT
movq %rax, -312(%rbp)
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $4, %rax
movq %rax, -336(%rbp)
movq -256(%rbp), %rdi
movq -336(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_init@PLT
movq %rax, -344(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $3, %rax
movq %rax, -360(%rbp)
movq -256(%rbp), %rdi
movq -360(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_init@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_bool@PLT
movq %rax, -384(%rbp)
movabsq $2, %rax
movq %rax, -392(%rbp)
movq -256(%rbp), %rdi
movq -392(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_init@PLT
movq %rax, -400(%rbp)
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_bool@PLT
movq %rax, -416(%rbp)
movabsq $1, %rax
movq %rax, -424(%rbp)
movq -256(%rbp), %rdi
movq -424(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_init@PLT
movq %rax, -432(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call f20@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -256(%rbp), %rdi
movq -456(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_init@PLT
movq %rax, -464(%rbp)
movabsq $24, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -480(%rbp)
movq -56(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_store@PLT
movq %rax, -488(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movq -8(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rax
leave
ret
.Lf50_b4:
jmp .Lf50_b5
.Lf50_b3:
leaq .Ldata_15(%rip), %rax
movq %rax, -168(%rbp)
movabsq $22, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call f33@PLT
movq %rax, -192(%rbp)
jmp .Lf50_b5
.Lf50_b2:
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf50_b4
jmp .Lf50_b3
.Lf50_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $33554432, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $9, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf50_b2
.Lf50_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -520(%rbp), %rsi
leaq .Lroots_f50(%rip), %rdx
movq $65, %rcx
call evn_bind_roots@PLT
movq -512(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -520(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf50_b1
jmp .Lf50_b2
.size f50, .-f50
.text
.p2align 4
.type f51, @function
f51:
pushq %rbp
movq %rsp, %rbp
subq $688, %rsp
movq %rdi, -664(%rbp)
movq %rsi, -672(%rbp)
movq %rdx, -680(%rbp)
leaq -656(%rbp), %rdi
movq $82, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf51_b0
.Lf51_b19:
jmp .Lf51_b14
.Lf51_b18:
jmp .Lf51_b19
.Lf51_b17:
leaq .Ldata_16(%rip), %rax
movq %rax, -616(%rbp)
movabsq $22, %rax
movq %rax, -624(%rbp)
movq -616(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_text@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call f33@PLT
movq %rax, -640(%rbp)
jmp .Lf51_b19
.Lf51_b16:
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -608(%rbp)
cmpq $0, -608(%rbp)
je .Lf51_b18
jmp .Lf51_b17
.Lf51_b15:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $6, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_member@PLT
movq %rax, -528(%rbp)
movabsq $12, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -552(%rbp)
movabsq $4, %rax
movq %rax, -560(%rbp)
movq -552(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_member@PLT
movq %rax, -568(%rbp)
movabsq $12, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_member@PLT
movq %rax, -584(%rbp)
movabsq $6, %rax
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -544(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_binary@PLT
movq %rax, -600(%rbp)
movq -600(%rbp), %rax
movq %rax, -496(%rbp)
jmp .Lf51_b16
.Lf51_b14:
jmp .Lf51_b6
.Lf51_b13:
jmp .Lf51_b14
.Lf51_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $6, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member@PLT
movq %rax, -440(%rbp)
movabsq $11, %rax
movq %rax, -448(%rbp)
movq -440(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member@PLT
movq %rax, -456(%rbp)
movabsq $1, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_int@PLT
movq %rax, -472(%rbp)
movabsq $6, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
movq -456(%rbp), %rsi
movq -472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
call evn_truth@PLT
movq %rax, -504(%rbp)
cmpq $0, -504(%rbp)
je .Lf51_b15
jmp .Lf51_b16
.Lf51_b11:
jmp .Lf51_b6
.Lf51_b10:
jmp .Lf51_b11
.Lf51_b9:
leaq .Ldata_17(%rip), %rax
movq %rax, -320(%rbp)
movabsq $35, %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_text@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call f33@PLT
movq %rax, -344(%rbp)
jmp .Lf51_b11
.Lf51_b8:
movq -232(%rbp), %rdi
call evn_truth@PLT
movq %rax, -312(%rbp)
cmpq $0, -312(%rbp)
je .Lf51_b10
jmp .Lf51_b9
.Lf51_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movabsq $6, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_member@PLT
movq %rax, -264(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $4, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movabsq $6, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -264(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -232(%rbp)
jmp .Lf51_b8
.Lf51_b6:
call evn_void@PLT
movq %rax, -648(%rbp)
movq -8(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rax
leave
ret
.Lf51_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $6, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $4, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
movabsq $6, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -368(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_binary@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
cmpq $0, -416(%rbp)
je .Lf51_b13
jmp .Lf51_b12
.Lf51_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $1, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -240(%rbp)
cmpq $0, -240(%rbp)
je .Lf51_b7
jmp .Lf51_b8
.Lf51_b3:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf51_b5
jmp .Lf51_b4
.Lf51_b2:
jmp .Lf51_b3
.Lf51_b1:
leaq .Ldata_18(%rip), %rax
movq %rax, -160(%rbp)
movabsq $21, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_text@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call f33@PLT
movq %rax, -184(%rbp)
jmp .Lf51_b3
.Lf51_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -680(%rbp), %rsi
leaq .Lroots_f51(%rip), %rdx
movq $85, %rcx
call evn_bind_roots@PLT
movq -664(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -672(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -680(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $6, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call f9@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $4, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_member@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call f9@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $2, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf51_b2
jmp .Lf51_b1
.size f51, .-f51
.text
.p2align 4
.type f52, @function
f52:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
movq %rdi, -496(%rbp)
leaq -488(%rbp), %rdi
movq $61, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf52_b0
.Lf52_b6:
call evn_void@PLT
movq %rax, -480(%rbp)
movq -8(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
leave
ret
.Lf52_b5:
jmp .Lf52_b6
.Lf52_b4:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_get@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call f17@PLT
movq %rax, -472(%rbp)
jmp .Lf52_b6
.Lf52_b3:
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_bool@PLT
movq %rax, -112(%rbp)
movabsq $7, %rax
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $5, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call f35@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $4, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call f35@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $3, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call f35@PLT
movq %rax, -232(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $2, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call f35@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $1, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call f35@PLT
movq %rax, -296(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $0, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call f35@PLT
movq %rax, -328(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $6, %rax
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_member@PLT
movq %rax, -352(%rbp)
movq -32(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_store@PLT
movq %rax, -360(%rbp)
movabsq $18, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_none@PLT
movq %rax, -376(%rbp)
movabsq $6, %rax
movq %rax, -384(%rbp)
movq -24(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_store@PLT
movq %rax, -400(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $18, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_none@PLT
movq %rax, -424(%rbp)
movabsq $6, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -408(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -448(%rbp)
cmpq $0, -448(%rbp)
je .Lf52_b5
jmp .Lf52_b4
.Lf52_b2:
jmp .Lf52_b3
.Lf52_b1:
leaq .Ldata_19(%rip), %rax
movq %rax, -72(%rbp)
movabsq $28, %rax
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_text@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call f33@PLT
movq %rax, -96(%rbp)
jmp .Lf52_b3
.Lf52_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -496(%rbp), %rsi
leaq .Lroots_f52(%rip), %rdx
movq $62, %rcx
call evn_bind_roots@PLT
movq -496(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $7, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_member@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_truth@PLT
movq %rax, -64(%rbp)
cmpq $0, -64(%rbp)
je .Lf52_b2
jmp .Lf52_b1
.size f52, .-f52
.text
.p2align 4
.type f53, @function
f53:
pushq %rbp
movq %rsp, %rbp
subq $384, %rsp
movq %rdi, -376(%rbp)
leaq -368(%rbp), %rdi
movq $46, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf53_b0
.Lf53_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $5, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call f37@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $4, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call f37@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $3, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call f37@PLT
movq %rax, -216(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $2, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call f37@PLT
movq %rax, -248(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call f37@PLT
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $0, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_member@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call f37@PLT
movq %rax, -312(%rbp)
movabsq $1, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_bool@PLT
movq %rax, -328(%rbp)
movabsq $8, %rax
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
call evn_void@PLT
movq %rax, -360(%rbp)
movq -8(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rax
leave
ret
.Lf53_b2:
jmp .Lf53_b3
.Lf53_b1:
leaq .Ldata_20(%rip), %rax
movq %rax, -96(%rbp)
movabsq $19, %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_text@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call f33@PLT
movq %rax, -120(%rbp)
jmp .Lf53_b3
.Lf53_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -376(%rbp), %rsi
leaq .Lroots_f53(%rip), %rdx
movq $47, %rcx
call evn_bind_roots@PLT
movq -376(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $9, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call f9@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $7, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_truth@PLT
movq %rax, -88(%rbp)
cmpq $0, -88(%rbp)
je .Lf53_b2
jmp .Lf53_b1
.size f53, .-f53
.text
.p2align 4
.type f54, @function
f54:
pushq %rbp
movq %rsp, %rbp
subq $416, %rsp
movq %rdi, -408(%rbp)
movq %rsi, -416(%rbp)
leaq -400(%rbp), %rdi
movq $50, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf54_b0
.Lf54_b9:
call evn_void@PLT
movq %rax, -392(%rbp)
movq -8(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rax
leave
ret
.Lf54_b8:
jmp .Lf54_b9
.Lf54_b7:
leaq .Ldata_21(%rip), %rax
movq %rax, -360(%rbp)
movabsq $28, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_text@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call f33@PLT
movq %rax, -384(%rbp)
jmp .Lf54_b9
.Lf54_b6:
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -352(%rbp)
cmpq $0, -352(%rbp)
je .Lf54_b8
jmp .Lf54_b7
.Lf54_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $0, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movabsq $4, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movabsq $7, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call evn_int@PLT
movq %rax, -312(%rbp)
movabsq $3, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -296(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movabsq $9, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -256(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rax
movq %rax, -224(%rbp)
jmp .Lf54_b6
.Lf54_b4:
movq -152(%rbp), %rax
movq %rax, -224(%rbp)
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf54_b5
jmp .Lf54_b6
.Lf54_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $0, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movabsq $1, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $7, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -152(%rbp)
jmp .Lf54_b4
.Lf54_b2:
movq -72(%rbp), %rax
movq %rax, -152(%rbp)
movq -72(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf54_b3
jmp .Lf54_b4
.Lf54_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $10, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $6, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -104(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
movq %rax, -72(%rbp)
jmp .Lf54_b2
.Lf54_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -416(%rbp), %rsi
leaq .Lroots_f54(%rip), %rdx
movq $52, %rcx
call evn_bind_roots@PLT
movq -408(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -416(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $7, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -80(%rbp)
cmpq $0, -80(%rbp)
je .Lf54_b1
jmp .Lf54_b2
.size f54, .-f54
.text
.p2align 4
.type f55, @function
f55:
pushq %rbp
movq %rsp, %rbp
subq $1728, %rsp
movq %rdi, -1672(%rbp)
movq %rsi, -1680(%rbp)
movq %rdx, -1688(%rbp)
movq %rcx, -1696(%rbp)
movq %r8, -1704(%rbp)
movq %r9, -1712(%rbp)
movq 16(%rbp), %rax
movq %rax, -1720(%rbp)
movq 24(%rbp), %rax
movq %rax, -1728(%rbp)
leaq -1664(%rbp), %rdi
movq $208, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf55_b0
.Lf55_b22:
movabsq $29, %rax
movq %rax, -1048(%rbp)
movabsq $2, %rax
movq %rax, -1056(%rbp)
movq -1048(%rbp), %rdi
movq -1056(%rbp), %rsi
call evn_object@PLT
movq %rax, -1064(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movabsq $10, %rax
movq %rax, -1080(%rbp)
movq -1072(%rbp), %rdi
movq -1080(%rbp), %rsi
call evn_member@PLT
movq %rax, -1088(%rbp)
movabsq $1, %rax
movq %rax, -1096(%rbp)
movq -1064(%rbp), %rdi
movq -1096(%rbp), %rsi
movq -1088(%rbp), %rdx
call evn_init@PLT
movq %rax, -1104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1112(%rbp)
movabsq $0, %rax
movq %rax, -1120(%rbp)
movq -1112(%rbp), %rdi
movq -1120(%rbp), %rsi
call evn_member@PLT
movq %rax, -1128(%rbp)
movabsq $4, %rax
movq %rax, -1136(%rbp)
movq -1128(%rbp), %rdi
movq -1136(%rbp), %rsi
call evn_member@PLT
movq %rax, -1144(%rbp)
movabsq $7, %rax
movq %rax, -1152(%rbp)
movq -1152(%rbp), %rdi
call evn_int@PLT
movq %rax, -1160(%rbp)
movabsq $3, %rax
movq %rax, -1168(%rbp)
movq -1168(%rbp), %rdi
movq -1144(%rbp), %rsi
movq -1160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1176(%rbp)
movabsq $1, %rax
movq %rax, -1184(%rbp)
movq -1184(%rbp), %rdi
call evn_int@PLT
movq %rax, -1192(%rbp)
movabsq $0, %rax
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
movq -1176(%rbp), %rsi
movq -1192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1208(%rbp)
movabsq $0, %rax
movq %rax, -1216(%rbp)
movq -1064(%rbp), %rdi
movq -1216(%rbp), %rsi
movq -1208(%rbp), %rdx
call evn_init@PLT
movq %rax, -1224(%rbp)
movq -152(%rbp), %rdi
movq -1064(%rbp), %rsi
call evn_store@PLT
movq %rax, -1232(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1240(%rbp)
movabsq $0, %rax
movq %rax, -1248(%rbp)
movq -1240(%rbp), %rdi
movq -1248(%rbp), %rsi
call evn_member@PLT
movq %rax, -1256(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1264(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1272(%rbp)
movabsq $0, %rax
movq %rax, -1280(%rbp)
movq -1272(%rbp), %rdi
movq -1280(%rbp), %rsi
call evn_member@PLT
movq %rax, -1288(%rbp)
movq -1256(%rbp), %rdi
movq -1264(%rbp), %rsi
movq -1288(%rbp), %rdx
call f38@PLT
movq %rax, -1296(%rbp)
movq -160(%rbp), %rdi
movq -1296(%rbp), %rsi
call evn_store@PLT
movq %rax, -1304(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1312(%rbp)
movabsq $0, %rax
movq %rax, -1320(%rbp)
movq -1312(%rbp), %rdi
movq -1320(%rbp), %rsi
call evn_member@PLT
movq %rax, -1328(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1336(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1344(%rbp)
movq -1328(%rbp), %rdi
movq -1336(%rbp), %rsi
movq -1344(%rbp), %rdx
call f38@PLT
movq %rax, -1352(%rbp)
movq -160(%rbp), %rdi
movq -1352(%rbp), %rsi
call evn_store@PLT
movq %rax, -1360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1368(%rbp)
movabsq $0, %rax
movq %rax, -1376(%rbp)
movq -1368(%rbp), %rdi
movq -1376(%rbp), %rsi
call evn_member@PLT
movq %rax, -1384(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1392(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1400(%rbp)
movq -1384(%rbp), %rdi
movq -1392(%rbp), %rsi
movq -1400(%rbp), %rdx
call f38@PLT
movq %rax, -1408(%rbp)
movq -160(%rbp), %rdi
movq -1408(%rbp), %rsi
call evn_store@PLT
movq %rax, -1416(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1424(%rbp)
movabsq $0, %rax
movq %rax, -1432(%rbp)
movq -1424(%rbp), %rdi
movq -1432(%rbp), %rsi
call evn_member@PLT
movq %rax, -1440(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1448(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1456(%rbp)
movq -1440(%rbp), %rdi
movq -1448(%rbp), %rsi
movq -1456(%rbp), %rdx
call f38@PLT
movq %rax, -1464(%rbp)
movq -160(%rbp), %rdi
movq -1464(%rbp), %rsi
call evn_store@PLT
movq %rax, -1472(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1480(%rbp)
movabsq $0, %rax
movq %rax, -1488(%rbp)
movq -1480(%rbp), %rdi
movq -1488(%rbp), %rsi
call evn_member@PLT
movq %rax, -1496(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1504(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1512(%rbp)
movq -1496(%rbp), %rdi
movq -1504(%rbp), %rsi
movq -1512(%rbp), %rdx
call f38@PLT
movq %rax, -1520(%rbp)
movq -160(%rbp), %rdi
movq -1520(%rbp), %rsi
call evn_store@PLT
movq %rax, -1528(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1536(%rbp)
movabsq $0, %rax
movq %rax, -1544(%rbp)
movq -1536(%rbp), %rdi
movq -1544(%rbp), %rsi
call evn_member@PLT
movq %rax, -1552(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1560(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1568(%rbp)
movq -1552(%rbp), %rdi
movq -1560(%rbp), %rsi
movq -1568(%rbp), %rdx
call f38@PLT
movq %rax, -1576(%rbp)
movq -160(%rbp), %rdi
movq -1576(%rbp), %rsi
call evn_store@PLT
movq %rax, -1584(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1592(%rbp)
movabsq $0, %rax
movq %rax, -1600(%rbp)
movq -1592(%rbp), %rdi
movq -1600(%rbp), %rsi
call evn_member@PLT
movq %rax, -1608(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1616(%rbp)
movabsq $0, %rax
movq %rax, -1624(%rbp)
movq -1624(%rbp), %rdi
call evn_int@PLT
movq %rax, -1632(%rbp)
movq -1608(%rbp), %rdi
movq -1616(%rbp), %rsi
movq -1632(%rbp), %rdx
call f38@PLT
movq %rax, -1640(%rbp)
movq -160(%rbp), %rdi
movq -1640(%rbp), %rsi
call evn_store@PLT
movq %rax, -1648(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1656(%rbp)
movq -8(%rbp), %rdi
movq -1656(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rax
leave
ret
.Lf55_b21:
jmp .Lf55_b22
.Lf55_b20:
leaq .Ldata_22(%rip), %rax
movq %rax, -1016(%rbp)
movabsq $23, %rax
movq %rax, -1024(%rbp)
movq -1016(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_text@PLT
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
call f33@PLT
movq %rax, -1040(%rbp)
jmp .Lf55_b22
.Lf55_b19:
movq -952(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1008(%rbp)
cmpq $0, -1008(%rbp)
je .Lf55_b21
jmp .Lf55_b20
.Lf55_b18:
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -968(%rbp)
movabsq $1, %rax
movq %rax, -976(%rbp)
movq -976(%rbp), %rdi
call evn_int@PLT
movq %rax, -984(%rbp)
movabsq $7, %rax
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
movq -968(%rbp), %rsi
movq -984(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rax
movq %rax, -952(%rbp)
jmp .Lf55_b19
.Lf55_b17:
movq -896(%rbp), %rax
movq %rax, -952(%rbp)
movq -896(%rbp), %rdi
call evn_truth@PLT
movq %rax, -960(%rbp)
cmpq $0, -960(%rbp)
je .Lf55_b18
jmp .Lf55_b19
.Lf55_b16:
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -912(%rbp)
movabsq $1, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
call evn_int@PLT
movq %rax, -928(%rbp)
movabsq $7, %rax
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
movq -912(%rbp), %rsi
movq -928(%rbp), %rdx
call evn_binary@PLT
movq %rax, -944(%rbp)
movq -944(%rbp), %rax
movq %rax, -896(%rbp)
jmp .Lf55_b17
.Lf55_b15:
movq -848(%rbp), %rax
movq %rax, -896(%rbp)
movq -848(%rbp), %rdi
call evn_truth@PLT
movq %rax, -904(%rbp)
cmpq $0, -904(%rbp)
je .Lf55_b16
jmp .Lf55_b17
.Lf55_b14:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movabsq $9, %rax
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
movq -864(%rbp), %rsi
movq -872(%rbp), %rdx
call evn_binary@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rax
movq %rax, -848(%rbp)
jmp .Lf55_b15
.Lf55_b13:
movq -800(%rbp), %rax
movq %rax, -848(%rbp)
movq -800(%rbp), %rdi
call evn_truth@PLT
movq %rax, -856(%rbp)
cmpq $0, -856(%rbp)
je .Lf55_b14
jmp .Lf55_b15
.Lf55_b12:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -824(%rbp)
movabsq $7, %rax
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
movq -816(%rbp), %rsi
movq -824(%rbp), %rdx
call evn_binary@PLT
movq %rax, -840(%rbp)
movq -840(%rbp), %rax
movq %rax, -800(%rbp)
jmp .Lf55_b13
.Lf55_b11:
movq -752(%rbp), %rax
movq %rax, -800(%rbp)
movq -752(%rbp), %rdi
call evn_truth@PLT
movq %rax, -808(%rbp)
cmpq $0, -808(%rbp)
je .Lf55_b12
jmp .Lf55_b13
.Lf55_b10:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -768(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -776(%rbp)
movabsq $9, %rax
movq %rax, -784(%rbp)
movq -784(%rbp), %rdi
movq -768(%rbp), %rsi
movq -776(%rbp), %rdx
call evn_binary@PLT
movq %rax, -792(%rbp)
movq -792(%rbp), %rax
movq %rax, -752(%rbp)
jmp .Lf55_b11
.Lf55_b9:
movq -704(%rbp), %rax
movq %rax, -752(%rbp)
movq -704(%rbp), %rdi
call evn_truth@PLT
movq %rax, -760(%rbp)
cmpq $0, -760(%rbp)
je .Lf55_b10
jmp .Lf55_b11
.Lf55_b8:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movabsq $7, %rax
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
movq -720(%rbp), %rsi
movq -728(%rbp), %rdx
call evn_binary@PLT
movq %rax, -744(%rbp)
movq -744(%rbp), %rax
movq %rax, -704(%rbp)
jmp .Lf55_b9
.Lf55_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $2, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_member@PLT
movq %rax, -512(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $0, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movabsq $1, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $1, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -544(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movabsq $4, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $2, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movabsq $3, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_int@PLT
movq %rax, -624(%rbp)
movabsq $0, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
movq -608(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_binary@PLT
movq %rax, -640(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
movq -640(%rbp), %rdx
call f40@PLT
movq %rax, -648(%rbp)
movq -144(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_store@PLT
movq %rax, -656(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movabsq $0, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_int@PLT
movq %rax, -680(%rbp)
movabsq $7, %rax
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
movq -664(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_binary@PLT
movq %rax, -696(%rbp)
movq -696(%rbp), %rax
movq %rax, -704(%rbp)
movq -696(%rbp), %rdi
call evn_truth@PLT
movq %rax, -712(%rbp)
cmpq $0, -712(%rbp)
je .Lf55_b8
jmp .Lf55_b9
.Lf55_b6:
jmp .Lf55_b7
.Lf55_b5:
leaq .Ldata_23(%rip), %rax
movq %rax, -464(%rbp)
movabsq $31, %rax
movq %rax, -472(%rbp)
movq -464(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_text@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call f33@PLT
movq %rax, -488(%rbp)
jmp .Lf55_b7
.Lf55_b4:
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -456(%rbp)
cmpq $0, -456(%rbp)
je .Lf55_b6
jmp .Lf55_b5
.Lf55_b3:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $0, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $2, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $4, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movabsq $4, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movabsq $3, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -400(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_binary@PLT
movq %rax, -432(%rbp)
movabsq $9, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -360(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rax
movq %rax, -328(%rbp)
jmp .Lf55_b4
.Lf55_b2:
movq -256(%rbp), %rax
movq %rax, -328(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf55_b3
jmp .Lf55_b4
.Lf55_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movabsq $1, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movabsq $7, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -288(%rbp), %rsi
movq -304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rax
movq %rax, -256(%rbp)
jmp .Lf55_b2
.Lf55_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1728(%rbp), %rsi
leaq .Lroots_f55(%rip), %rdx
movq $216, %rcx
call evn_bind_roots@PLT
movq -1672(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1680(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1688(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -1696(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -1704(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -1712(%rbp), %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -1720(%rbp), %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -1728(%rbp), %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
call evn_void@PLT
movq %rax, -144(%rbp)
call evn_void@PLT
movq %rax, -152(%rbp)
call evn_void@PLT
movq %rax, -160(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call f68@PLT
movq %rax, -184(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $1, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_member@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $10, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movabsq $6, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -208(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf55_b1
jmp .Lf55_b2
.size f55, .-f55
.text
.p2align 4
.type f56, @function
f56:
pushq %rbp
movq %rsp, %rbp
subq $2336, %rsp
movq %rdi, -2304(%rbp)
movq %rsi, -2312(%rbp)
movq %rdx, -2320(%rbp)
movq %rcx, -2328(%rbp)
movq %r8, -2336(%rbp)
leaq -2296(%rbp), %rdi
movq $287, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf56_b0
.Lf56_b30:
movabsq $30, %rax
movq %rax, -1592(%rbp)
movabsq $2, %rax
movq %rax, -1600(%rbp)
movq -1592(%rbp), %rdi
movq -1600(%rbp), %rsi
call evn_object@PLT
movq %rax, -1608(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1616(%rbp)
movabsq $10, %rax
movq %rax, -1624(%rbp)
movq -1616(%rbp), %rdi
movq -1624(%rbp), %rsi
call evn_member@PLT
movq %rax, -1632(%rbp)
movabsq $1, %rax
movq %rax, -1640(%rbp)
movq -1608(%rbp), %rdi
movq -1640(%rbp), %rsi
movq -1632(%rbp), %rdx
call evn_init@PLT
movq %rax, -1648(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1656(%rbp)
movabsq $1, %rax
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rdi
call evn_int@PLT
movq %rax, -1672(%rbp)
movabsq $0, %rax
movq %rax, -1680(%rbp)
movq -1680(%rbp), %rdi
movq -1656(%rbp), %rsi
movq -1672(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1688(%rbp)
movabsq $0, %rax
movq %rax, -1696(%rbp)
movq -1608(%rbp), %rdi
movq -1696(%rbp), %rsi
movq -1688(%rbp), %rdx
call evn_init@PLT
movq %rax, -1704(%rbp)
movq -8(%rbp), %rdi
movq -1608(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1712(%rbp)
movq -1712(%rbp), %rax
leave
ret
.Lf56_b29:
jmp .Lf56_b30
.Lf56_b28:
leaq .Ldata_24(%rip), %rax
movq %rax, -1560(%rbp)
movabsq $27, %rax
movq %rax, -1568(%rbp)
movq -1560(%rbp), %rdi
movq -1568(%rbp), %rsi
call evn_text@PLT
movq %rax, -1576(%rbp)
movq -1576(%rbp), %rdi
call f33@PLT
movq %rax, -1584(%rbp)
jmp .Lf56_b30
.Lf56_b27:
movq -1432(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1552(%rbp)
cmpq $0, -1552(%rbp)
je .Lf56_b29
jmp .Lf56_b28
.Lf56_b26:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1448(%rbp)
movabsq $2, %rax
movq %rax, -1456(%rbp)
movq -1448(%rbp), %rdi
movq -1456(%rbp), %rsi
call evn_member@PLT
movq %rax, -1464(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1472(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1480(%rbp)
movabsq $3, %rax
movq %rax, -1488(%rbp)
movq -1488(%rbp), %rdi
call evn_int@PLT
movq %rax, -1496(%rbp)
movabsq $0, %rax
movq %rax, -1504(%rbp)
movq -1504(%rbp), %rdi
movq -1480(%rbp), %rsi
movq -1496(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1512(%rbp)
movq -1464(%rbp), %rdi
movq -1472(%rbp), %rsi
movq -1512(%rbp), %rdx
call f40@PLT
movq %rax, -1520(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1528(%rbp)
movabsq $6, %rax
movq %rax, -1536(%rbp)
movq -1536(%rbp), %rdi
movq -1520(%rbp), %rsi
movq -1528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1544(%rbp)
movq -1544(%rbp), %rax
movq %rax, -1432(%rbp)
jmp .Lf56_b27
.Lf56_b25:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1720(%rbp)
movabsq $1, %rax
movq %rax, -1728(%rbp)
movq -1728(%rbp), %rdi
call evn_int@PLT
movq %rax, -1736(%rbp)
movabsq $0, %rax
movq %rax, -1744(%rbp)
movq -1744(%rbp), %rdi
movq -1720(%rbp), %rsi
movq -1736(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1752(%rbp)
movq -96(%rbp), %rdi
movq -1752(%rbp), %rsi
call evn_store@PLT
movq %rax, -1760(%rbp)
jmp .Lf56_b20
.Lf56_b24:
jmp .Lf56_b25
.Lf56_b23:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1272(%rbp)
movabsq $2, %rax
movq %rax, -1280(%rbp)
movq -1272(%rbp), %rdi
movq -1280(%rbp), %rsi
call evn_member@PLT
movq %rax, -1288(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1296(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1304(%rbp)
movabsq $2, %rax
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
call evn_int@PLT
movq %rax, -1320(%rbp)
movabsq $0, %rax
movq %rax, -1328(%rbp)
movq -1328(%rbp), %rdi
movq -1304(%rbp), %rsi
movq -1320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1336(%rbp)
movq -1288(%rbp), %rdi
movq -1296(%rbp), %rsi
movq -1336(%rbp), %rdx
call f40@PLT
movq %rax, -1344(%rbp)
movq -136(%rbp), %rdi
movq -1344(%rbp), %rsi
call evn_store@PLT
movq %rax, -1352(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1360(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1368(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1376(%rbp)
movabsq $64, %rax
movq %rax, -1384(%rbp)
movq -1384(%rbp), %rdi
call evn_int@PLT
movq %rax, -1392(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1400(%rbp)
movq -1360(%rbp), %rdi
movq -1368(%rbp), %rsi
movq -1376(%rbp), %rdx
movq -1392(%rbp), %rcx
movq -1400(%rbp), %r8
call f57@PLT
movq %rax, -1408(%rbp)
movabsq $1, %rax
movq %rax, -1416(%rbp)
movq -1416(%rbp), %rdi
movq -1408(%rbp), %rsi
call evn_unary@PLT
movq %rax, -1424(%rbp)
movq -1424(%rbp), %rax
movq %rax, -1432(%rbp)
movq -1424(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1440(%rbp)
cmpq $0, -1440(%rbp)
je .Lf56_b26
jmp .Lf56_b27
.Lf56_b22:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1768(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1776(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1784(%rbp)
movq -1768(%rbp), %rdi
movq -1776(%rbp), %rsi
movq -1784(%rbp), %rdx
call f58@PLT
movq %rax, -1792(%rbp)
movq -144(%rbp), %rdi
movq -1792(%rbp), %rsi
call evn_store@PLT
movq %rax, -1800(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1808(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1816(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1824(%rbp)
movq -1808(%rbp), %rdi
movq -1816(%rbp), %rsi
movq -1824(%rbp), %rdx
call f58@PLT
movq %rax, -1832(%rbp)
movq -152(%rbp), %rdi
movq -1832(%rbp), %rsi
call evn_store@PLT
movq %rax, -1840(%rbp)
movabsq $30, %rax
movq %rax, -1848(%rbp)
movabsq $2, %rax
movq %rax, -1856(%rbp)
movq -1848(%rbp), %rdi
movq -1856(%rbp), %rsi
call evn_object@PLT
movq %rax, -1864(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1872(%rbp)
movabsq $10, %rax
movq %rax, -1880(%rbp)
movq -1872(%rbp), %rdi
movq -1880(%rbp), %rsi
call evn_member@PLT
movq %rax, -1888(%rbp)
movabsq $1, %rax
movq %rax, -1896(%rbp)
movq -1864(%rbp), %rdi
movq -1896(%rbp), %rsi
movq -1888(%rbp), %rdx
call evn_init@PLT
movq %rax, -1904(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1912(%rbp)
movabsq $2, %rax
movq %rax, -1920(%rbp)
movq -1912(%rbp), %rdi
movq -1920(%rbp), %rsi
call evn_member@PLT
movq %rax, -1928(%rbp)
movabsq $4, %rax
movq %rax, -1936(%rbp)
movq -1928(%rbp), %rdi
movq -1936(%rbp), %rsi
call evn_member@PLT
movq %rax, -1944(%rbp)
movabsq $4, %rax
movq %rax, -1952(%rbp)
movq -1952(%rbp), %rdi
call evn_int@PLT
movq %rax, -1960(%rbp)
movabsq $3, %rax
movq %rax, -1968(%rbp)
movq -1968(%rbp), %rdi
movq -1944(%rbp), %rsi
movq -1960(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1976(%rbp)
movabsq $1, %rax
movq %rax, -1984(%rbp)
movq -1984(%rbp), %rdi
call evn_int@PLT
movq %rax, -1992(%rbp)
movabsq $0, %rax
movq %rax, -2000(%rbp)
movq -2000(%rbp), %rdi
movq -1976(%rbp), %rsi
movq -1992(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2008(%rbp)
movabsq $0, %rax
movq %rax, -2016(%rbp)
movq -1864(%rbp), %rdi
movq -2016(%rbp), %rsi
movq -2008(%rbp), %rdx
call evn_init@PLT
movq %rax, -2024(%rbp)
movq -160(%rbp), %rdi
movq -1864(%rbp), %rsi
call evn_store@PLT
movq %rax, -2032(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2040(%rbp)
movabsq $2, %rax
movq %rax, -2048(%rbp)
movq -2040(%rbp), %rdi
movq -2048(%rbp), %rsi
call evn_member@PLT
movq %rax, -2056(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2064(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2072(%rbp)
movq -2056(%rbp), %rdi
movq -2064(%rbp), %rsi
movq -2072(%rbp), %rdx
call f38@PLT
movq %rax, -2080(%rbp)
movq -168(%rbp), %rdi
movq -2080(%rbp), %rsi
call evn_store@PLT
movq %rax, -2088(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2096(%rbp)
movabsq $2, %rax
movq %rax, -2104(%rbp)
movq -2096(%rbp), %rdi
movq -2104(%rbp), %rsi
call evn_member@PLT
movq %rax, -2112(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2120(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2128(%rbp)
movabsq $42, %rax
movq %rax, -2136(%rbp)
movq -2136(%rbp), %rdi
movq -2128(%rbp), %rsi
call evn_view@PLT
movq %rax, -2144(%rbp)
movq -2144(%rbp), %rdi
call evn_count@PLT
movq %rax, -2152(%rbp)
movq -2112(%rbp), %rdi
movq -2120(%rbp), %rsi
movq -2152(%rbp), %rdx
call f38@PLT
movq %rax, -2160(%rbp)
movq -168(%rbp), %rdi
movq -2160(%rbp), %rsi
call evn_store@PLT
movq %rax, -2168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2176(%rbp)
movabsq $2, %rax
movq %rax, -2184(%rbp)
movq -2176(%rbp), %rdi
movq -2184(%rbp), %rsi
call evn_member@PLT
movq %rax, -2192(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2200(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2208(%rbp)
movq -2192(%rbp), %rdi
movq -2200(%rbp), %rsi
movq -2208(%rbp), %rdx
call f38@PLT
movq %rax, -2216(%rbp)
movq -168(%rbp), %rdi
movq -2216(%rbp), %rsi
call evn_store@PLT
movq %rax, -2224(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2232(%rbp)
movabsq $2, %rax
movq %rax, -2240(%rbp)
movq -2232(%rbp), %rdi
movq -2240(%rbp), %rsi
call evn_member@PLT
movq %rax, -2248(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2256(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2264(%rbp)
movq -2248(%rbp), %rdi
movq -2256(%rbp), %rsi
movq -2264(%rbp), %rdx
call f38@PLT
movq %rax, -2272(%rbp)
movq -168(%rbp), %rdi
movq -2272(%rbp), %rsi
call evn_store@PLT
movq %rax, -2280(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2288(%rbp)
movq -8(%rbp), %rdi
movq -2288(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -2296(%rbp)
movq -2296(%rbp), %rax
leave
ret
.Lf56_b21:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movabsq $4, %rax
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
call evn_int@PLT
movq %rax, -1040(%rbp)
movabsq $2, %rax
movq %rax, -1048(%rbp)
movq -1048(%rbp), %rdi
movq -1024(%rbp), %rsi
movq -1040(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1056(%rbp)
movq -112(%rbp), %rdi
movq -1056(%rbp), %rsi
call evn_store@PLT
movq %rax, -1064(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movabsq $2, %rax
movq %rax, -1080(%rbp)
movq -1072(%rbp), %rdi
movq -1080(%rbp), %rsi
call evn_member@PLT
movq %rax, -1088(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1096(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movq -1088(%rbp), %rdi
movq -1096(%rbp), %rsi
movq -1104(%rbp), %rdx
call f40@PLT
movq %rax, -1112(%rbp)
movq -120(%rbp), %rdi
movq -1112(%rbp), %rsi
call evn_store@PLT
movq %rax, -1120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1128(%rbp)
movabsq $2, %rax
movq %rax, -1136(%rbp)
movq -1128(%rbp), %rdi
movq -1136(%rbp), %rsi
call evn_member@PLT
movq %rax, -1144(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1152(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1160(%rbp)
movabsq $1, %rax
movq %rax, -1168(%rbp)
movq -1168(%rbp), %rdi
call evn_int@PLT
movq %rax, -1176(%rbp)
movabsq $0, %rax
movq %rax, -1184(%rbp)
movq -1184(%rbp), %rdi
movq -1160(%rbp), %rsi
movq -1176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1192(%rbp)
movq -1144(%rbp), %rdi
movq -1152(%rbp), %rsi
movq -1192(%rbp), %rdx
call f40@PLT
movq %rax, -1200(%rbp)
movq -128(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_store@PLT
movq %rax, -1208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1224(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1232(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1240(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movq -1216(%rbp), %rdi
movq -1224(%rbp), %rsi
movq -1232(%rbp), %rdx
movq -1240(%rbp), %rcx
movq -1248(%rbp), %r8
call f57@PLT
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1264(%rbp)
cmpq $0, -1264(%rbp)
je .Lf56_b24
jmp .Lf56_b23
.Lf56_b20:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -920(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -928(%rbp)
movabsq $2, %rax
movq %rax, -936(%rbp)
movq -928(%rbp), %rdi
movq -936(%rbp), %rsi
call evn_member@PLT
movq %rax, -944(%rbp)
movabsq $4, %rax
movq %rax, -952(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_member@PLT
movq %rax, -960(%rbp)
movabsq $4, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
call evn_int@PLT
movq %rax, -976(%rbp)
movabsq $3, %rax
movq %rax, -984(%rbp)
movq -984(%rbp), %rdi
movq -960(%rbp), %rsi
movq -976(%rbp), %rdx
call evn_binary@PLT
movq %rax, -992(%rbp)
movabsq $7, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
movq -920(%rbp), %rsi
movq -992(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1008(%rbp)
movq -1008(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1016(%rbp)
cmpq $0, -1016(%rbp)
je .Lf56_b22
jmp .Lf56_b21
.Lf56_b19:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movabsq $1, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
call evn_int@PLT
movq %rax, -864(%rbp)
movabsq $0, %rax
movq %rax, -872(%rbp)
movq -872(%rbp), %rdi
movq -848(%rbp), %rsi
movq -864(%rbp), %rdx
call evn_binary@PLT
movq %rax, -880(%rbp)
movq -96(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_store@PLT
movq %rax, -888(%rbp)
jmp .Lf56_b8
.Lf56_b18:
jmp .Lf56_b19
.Lf56_b17:
leaq .Ldata_25(%rip), %rax
movq %rax, -816(%rbp)
movabsq $43, %rax
movq %rax, -824(%rbp)
movq -816(%rbp), %rdi
movq -824(%rbp), %rsi
call evn_text@PLT
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
call f33@PLT
movq %rax, -840(%rbp)
jmp .Lf56_b19
.Lf56_b16:
movabsq $1, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_unary@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rax
movq %rax, -680(%rbp)
jmp .Lf56_b14
.Lf56_b15:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -752(%rbp)
movabsq $102, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_int@PLT
movq %rax, -768(%rbp)
movabsq $8, %rax
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
movq -752(%rbp), %rsi
movq -768(%rbp), %rdx
call evn_binary@PLT
movq %rax, -784(%rbp)
movq -784(%rbp), %rax
movq %rax, -736(%rbp)
jmp .Lf56_b16
.Lf56_b14:
movq -680(%rbp), %rdi
call evn_truth@PLT
movq %rax, -808(%rbp)
cmpq $0, -808(%rbp)
je .Lf56_b18
jmp .Lf56_b17
.Lf56_b13:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movabsq $97, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call evn_int@PLT
movq %rax, -712(%rbp)
movabsq $10, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
movq -696(%rbp), %rsi
movq -712(%rbp), %rdx
call evn_binary@PLT
movq %rax, -728(%rbp)
movq -728(%rbp), %rax
movq %rax, -736(%rbp)
movq -728(%rbp), %rdi
call evn_truth@PLT
movq %rax, -744(%rbp)
cmpq $0, -744(%rbp)
je .Lf56_b16
jmp .Lf56_b15
.Lf56_b12:
movabsq $1, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_unary@PLT
movq %rax, -672(%rbp)
movq -672(%rbp), %rax
movq %rax, -680(%rbp)
movq -672(%rbp), %rdi
call evn_truth@PLT
movq %rax, -688(%rbp)
cmpq $0, -688(%rbp)
je .Lf56_b14
jmp .Lf56_b13
.Lf56_b11:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $57, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call evn_int@PLT
movq %rax, -640(%rbp)
movabsq $8, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
movq -624(%rbp), %rsi
movq -640(%rbp), %rdx
call evn_binary@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rax
movq %rax, -608(%rbp)
jmp .Lf56_b12
.Lf56_b10:
movabsq $0, %rax
movq %rax, -896(%rbp)
movq -896(%rbp), %rdi
call evn_int@PLT
movq %rax, -904(%rbp)
movq -96(%rbp), %rdi
movq -904(%rbp), %rsi
call evn_store@PLT
movq %rax, -912(%rbp)
jmp .Lf56_b20
.Lf56_b9:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $42, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_view@PLT
movq %rax, -528(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
call evn_truth@PLT
movq %rax, -544(%rbp)
movq -528(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_index@PLT
movq %rax, -552(%rbp)
movq -104(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_store@PLT
movq %rax, -560(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movabsq $48, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_int@PLT
movq %rax, -584(%rbp)
movabsq $10, %rax
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -568(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_binary@PLT
movq %rax, -600(%rbp)
movq -600(%rbp), %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf56_b12
jmp .Lf56_b11
.Lf56_b8:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $64, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_int@PLT
movq %rax, -480(%rbp)
movabsq $7, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -464(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -504(%rbp)
cmpq $0, -504(%rbp)
je .Lf56_b10
jmp .Lf56_b9
.Lf56_b7:
movabsq $0, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movq -96(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -456(%rbp)
jmp .Lf56_b8
.Lf56_b6:
jmp .Lf56_b7
.Lf56_b5:
leaq .Ldata_26(%rip), %rax
movq %rax, -408(%rbp)
movabsq $27, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_text@PLT
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call f33@PLT
movq %rax, -432(%rbp)
jmp .Lf56_b7
.Lf56_b4:
movq -344(%rbp), %rdi
call evn_truth@PLT
movq %rax, -400(%rbp)
cmpq $0, -400(%rbp)
je .Lf56_b6
jmp .Lf56_b5
.Lf56_b3:
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $0, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movabsq $7, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rax
movq %rax, -344(%rbp)
jmp .Lf56_b4
.Lf56_b2:
movq -264(%rbp), %rax
movq %rax, -344(%rbp)
movq -264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -352(%rbp)
cmpq $0, -352(%rbp)
je .Lf56_b3
jmp .Lf56_b4
.Lf56_b1:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $42, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_view@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_count@PLT
movq %rax, -304(%rbp)
movabsq $64, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $6, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rax
movq %rax, -264(%rbp)
jmp .Lf56_b2
.Lf56_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -2336(%rbp), %rsi
leaq .Lroots_f56(%rip), %rdx
movq $292, %rcx
call evn_bind_roots@PLT
movq -2304(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -2312(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -2320(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -2328(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -2336(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
call evn_void@PLT
movq %rax, -120(%rbp)
call evn_void@PLT
movq %rax, -128(%rbp)
call evn_void@PLT
movq %rax, -136(%rbp)
call evn_void@PLT
movq %rax, -144(%rbp)
call evn_void@PLT
movq %rax, -152(%rbp)
call evn_void@PLT
movq %rax, -160(%rbp)
call evn_void@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call f68@PLT
movq %rax, -192(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $42, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_view@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_count@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movabsq $5, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -224(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf56_b1
jmp .Lf56_b2
.size f56, .-f56
.text
.p2align 4
.type f57, @function
f57:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -496(%rbp)
movq %rsi, -504(%rbp)
movq %rdx, -512(%rbp)
movq %rcx, -520(%rbp)
movq %r8, -528(%rbp)
leaq -488(%rbp), %rdi
movq $61, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf57_b0
.Lf57_b9:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $1, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movabsq $0, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
movq -424(%rbp), %rsi
movq -440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -456(%rbp)
movq -96(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_store@PLT
movq %rax, -464(%rbp)
jmp .Lf57_b4
.Lf57_b8:
jmp .Lf57_b9
.Lf57_b7:
movabsq $0, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call evn_bool@PLT
movq %rax, -408(%rbp)
movq -8(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -416(%rbp)
movq -416(%rbp), %rax
leave
ret
.Lf57_b6:
movabsq $1, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_bool@PLT
movq %rax, -480(%rbp)
movq -8(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
leave
ret
.Lf57_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member@PLT
movq %rax, -272(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $0, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -288(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
movq -312(%rbp), %rdx
call f40@PLT
movq %rax, -320(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $42, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_view@PLT
movq %rax, -344(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_truth@PLT
movq %rax, -360(%rbp)
movq -344(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_index@PLT
movq %rax, -368(%rbp)
movabsq $6, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -320(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_truth@PLT
movq %rax, -392(%rbp)
cmpq $0, -392(%rbp)
je .Lf57_b8
jmp .Lf57_b7
.Lf57_b4:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $7, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
movq -216(%rbp), %rsi
movq -224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_truth@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf57_b6
jmp .Lf57_b5
.Lf57_b3:
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movq -96(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
jmp .Lf57_b4
.Lf57_b2:
jmp .Lf57_b3
.Lf57_b1:
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_bool@PLT
movq %rax, -176(%rbp)
movq -8(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
leave
ret
.Lf57_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -528(%rbp), %rsi
leaq .Lroots_f57(%rip), %rdx
movq $66, %rcx
call evn_bind_roots@PLT
movq -496(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -504(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -512(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -520(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -528(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $42, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_view@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_count@PLT
movq %rax, -136(%rbp)
movabsq $6, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -104(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf57_b2
jmp .Lf57_b1
.size f57, .-f57
.text
.p2align 4
.type f58, @function
f58:
pushq %rbp
movq %rsp, %rbp
subq $400, %rsp
movq %rdi, -384(%rbp)
movq %rsi, -392(%rbp)
movq %rdx, -400(%rbp)
leaq -376(%rbp), %rdi
movq $47, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf58_b0
.Lf58_b3:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movq -8(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
leave
ret
.Lf58_b2:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $1, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $42, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_view@PLT
movq %rax, -272(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_truth@PLT
movq %rax, -288(%rbp)
movq -272(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_index@PLT
movq %rax, -296(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
movq -296(%rbp), %rdx
call f38@PLT
movq %rax, -304(%rbp)
movq -80(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_store@PLT
movq %rax, -312(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movabsq $1, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_int@PLT
movq %rax, -336(%rbp)
movabsq $0, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
movq -320(%rbp), %rsi
movq -336(%rbp), %rdx
call evn_binary@PLT
movq %rax, -352(%rbp)
movq -72(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_store@PLT
movq %rax, -360(%rbp)
jmp .Lf58_b1
.Lf58_b1:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $42, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_view@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_count@PLT
movq %rax, -192(%rbp)
movabsq $7, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -160(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf58_b3
jmp .Lf58_b2
.Lf58_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -400(%rbp), %rsi
leaq .Lroots_f58(%rip), %rdx
movq $50, %rcx
call evn_bind_roots@PLT
movq -384(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -392(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -400(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movq -64(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movabsq $0, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movq -72(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_store@PLT
movq %rax, -152(%rbp)
jmp .Lf58_b1
.size f58, .-f58
.text
.p2align 4
.type f59, @function
f59:
pushq %rbp
movq %rsp, %rbp
subq $2512, %rsp
movq %rdi, -2488(%rbp)
movq %rsi, -2496(%rbp)
movq %rdx, -2504(%rbp)
movq %rcx, -2512(%rbp)
leaq -2480(%rbp), %rdi
movq $310, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf59_b0
.Lf59_b22:
movabsq $33, %rax
movq %rax, -1800(%rbp)
movabsq $2, %rax
movq %rax, -1808(%rbp)
movq -1800(%rbp), %rdi
movq -1808(%rbp), %rsi
call evn_object@PLT
movq %rax, -1816(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1824(%rbp)
movabsq $10, %rax
movq %rax, -1832(%rbp)
movq -1824(%rbp), %rdi
movq -1832(%rbp), %rsi
call evn_member@PLT
movq %rax, -1840(%rbp)
movabsq $1, %rax
movq %rax, -1848(%rbp)
movq -1816(%rbp), %rdi
movq -1848(%rbp), %rsi
movq -1840(%rbp), %rdx
call evn_init@PLT
movq %rax, -1856(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1864(%rbp)
movabsq $5, %rax
movq %rax, -1872(%rbp)
movq -1864(%rbp), %rdi
movq -1872(%rbp), %rsi
call evn_member@PLT
movq %rax, -1880(%rbp)
movabsq $4, %rax
movq %rax, -1888(%rbp)
movq -1880(%rbp), %rdi
movq -1888(%rbp), %rsi
call evn_member@PLT
movq %rax, -1896(%rbp)
movabsq $6, %rax
movq %rax, -1904(%rbp)
movq -1904(%rbp), %rdi
call evn_int@PLT
movq %rax, -1912(%rbp)
movabsq $3, %rax
movq %rax, -1920(%rbp)
movq -1920(%rbp), %rdi
movq -1896(%rbp), %rsi
movq -1912(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1928(%rbp)
movabsq $1, %rax
movq %rax, -1936(%rbp)
movq -1936(%rbp), %rdi
call evn_int@PLT
movq %rax, -1944(%rbp)
movabsq $0, %rax
movq %rax, -1952(%rbp)
movq -1952(%rbp), %rdi
movq -1928(%rbp), %rsi
movq -1944(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1960(%rbp)
movabsq $0, %rax
movq %rax, -1968(%rbp)
movq -1816(%rbp), %rdi
movq -1968(%rbp), %rsi
movq -1960(%rbp), %rdx
call evn_init@PLT
movq %rax, -1976(%rbp)
movq -192(%rbp), %rdi
movq -1816(%rbp), %rsi
call evn_store@PLT
movq %rax, -1984(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1992(%rbp)
movabsq $3, %rax
movq %rax, -2000(%rbp)
movq -1992(%rbp), %rdi
movq -2000(%rbp), %rsi
call evn_member@PLT
movq %rax, -2008(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2016(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2024(%rbp)
movq -2008(%rbp), %rdi
movq -2016(%rbp), %rsi
movq -2024(%rbp), %rdx
call f40@PLT
movq %rax, -2032(%rbp)
movq -200(%rbp), %rdi
movq -2032(%rbp), %rsi
call evn_store@PLT
movq %rax, -2040(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2048(%rbp)
movabsq $5, %rax
movq %rax, -2056(%rbp)
movq -2048(%rbp), %rdi
movq -2056(%rbp), %rsi
call evn_member@PLT
movq %rax, -2064(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2072(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2080(%rbp)
movq -2064(%rbp), %rdi
movq -2072(%rbp), %rsi
movq -2080(%rbp), %rdx
call f38@PLT
movq %rax, -2088(%rbp)
movq -208(%rbp), %rdi
movq -2088(%rbp), %rsi
call evn_store@PLT
movq %rax, -2096(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2104(%rbp)
movabsq $5, %rax
movq %rax, -2112(%rbp)
movq -2104(%rbp), %rdi
movq -2112(%rbp), %rsi
call evn_member@PLT
movq %rax, -2120(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2128(%rbp)
movq -200(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2136(%rbp)
movq -2120(%rbp), %rdi
movq -2128(%rbp), %rsi
movq -2136(%rbp), %rdx
call f38@PLT
movq %rax, -2144(%rbp)
movq -208(%rbp), %rdi
movq -2144(%rbp), %rsi
call evn_store@PLT
movq %rax, -2152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2160(%rbp)
movabsq $5, %rax
movq %rax, -2168(%rbp)
movq -2160(%rbp), %rdi
movq -2168(%rbp), %rsi
call evn_member@PLT
movq %rax, -2176(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2184(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2192(%rbp)
movq -2176(%rbp), %rdi
movq -2184(%rbp), %rsi
movq -2192(%rbp), %rdx
call f38@PLT
movq %rax, -2200(%rbp)
movq -208(%rbp), %rdi
movq -2200(%rbp), %rsi
call evn_store@PLT
movq %rax, -2208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2216(%rbp)
movabsq $5, %rax
movq %rax, -2224(%rbp)
movq -2216(%rbp), %rdi
movq -2224(%rbp), %rsi
call evn_member@PLT
movq %rax, -2232(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2240(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2248(%rbp)
movq -2248(%rbp), %rdi
call evn_count@PLT
movq %rax, -2256(%rbp)
movq -2232(%rbp), %rdi
movq -2240(%rbp), %rsi
movq -2256(%rbp), %rdx
call f38@PLT
movq %rax, -2264(%rbp)
movq -208(%rbp), %rdi
movq -2264(%rbp), %rsi
call evn_store@PLT
movq %rax, -2272(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2280(%rbp)
movabsq $5, %rax
movq %rax, -2288(%rbp)
movq -2280(%rbp), %rdi
movq -2288(%rbp), %rsi
call evn_member@PLT
movq %rax, -2296(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2304(%rbp)
movq -168(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2312(%rbp)
movq -2296(%rbp), %rdi
movq -2304(%rbp), %rsi
movq -2312(%rbp), %rdx
call f38@PLT
movq %rax, -2320(%rbp)
movq -208(%rbp), %rdi
movq -2320(%rbp), %rsi
call evn_store@PLT
movq %rax, -2328(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2336(%rbp)
movabsq $5, %rax
movq %rax, -2344(%rbp)
movq -2336(%rbp), %rdi
movq -2344(%rbp), %rsi
call evn_member@PLT
movq %rax, -2352(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2360(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2368(%rbp)
movq -2368(%rbp), %rdi
call evn_count@PLT
movq %rax, -2376(%rbp)
movq -2352(%rbp), %rdi
movq -2360(%rbp), %rsi
movq -2376(%rbp), %rdx
call f38@PLT
movq %rax, -2384(%rbp)
movq -208(%rbp), %rdi
movq -2384(%rbp), %rsi
call evn_store@PLT
movq %rax, -2392(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2400(%rbp)
movabsq $3, %rax
movq %rax, -2408(%rbp)
movq -2400(%rbp), %rdi
movq -2408(%rbp), %rsi
call evn_member@PLT
movq %rax, -2416(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2424(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2432(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2440(%rbp)
movabsq $0, %rax
movq %rax, -2448(%rbp)
movq -2440(%rbp), %rdi
movq -2448(%rbp), %rsi
call evn_member@PLT
movq %rax, -2456(%rbp)
movq -2416(%rbp), %rdi
movq -2424(%rbp), %rsi
movq -2432(%rbp), %rdx
movq -2456(%rbp), %rcx
call f39@PLT
movq %rax, -2464(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2472(%rbp)
movq -8(%rbp), %rdi
movq -2472(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -2480(%rbp)
movq -2480(%rbp), %rax
leave
ret
.Lf59_b21:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1624(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1632(%rbp)
movq -1632(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1640(%rbp)
movq -1624(%rbp), %rdi
movq -1640(%rbp), %rsi
call evn_index@PLT
movq %rax, -1648(%rbp)
movq -176(%rbp), %rdi
movq -1648(%rbp), %rsi
call evn_store@PLT
movq %rax, -1656(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rdi
call f69@PLT
movq %rax, -1672(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1680(%rbp)
movabsq $4, %rax
movq %rax, -1688(%rbp)
movq -1680(%rbp), %rdi
movq -1688(%rbp), %rsi
call evn_member@PLT
movq %rax, -1696(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1704(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1712(%rbp)
movabsq $0, %rax
movq %rax, -1720(%rbp)
movq -1712(%rbp), %rdi
movq -1720(%rbp), %rsi
call evn_member@PLT
movq %rax, -1728(%rbp)
movq -1696(%rbp), %rdi
movq -1704(%rbp), %rsi
movq -1728(%rbp), %rdx
call f38@PLT
movq %rax, -1736(%rbp)
movq -184(%rbp), %rdi
movq -1736(%rbp), %rsi
call evn_store@PLT
movq %rax, -1744(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1752(%rbp)
movabsq $1, %rax
movq %rax, -1760(%rbp)
movq -1760(%rbp), %rdi
call evn_int@PLT
movq %rax, -1768(%rbp)
movabsq $0, %rax
movq %rax, -1776(%rbp)
movq -1776(%rbp), %rdi
movq -1752(%rbp), %rsi
movq -1768(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1784(%rbp)
movq -144(%rbp), %rdi
movq -1784(%rbp), %rsi
call evn_store@PLT
movq %rax, -1792(%rbp)
jmp .Lf59_b20
.Lf59_b20:
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1576(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1584(%rbp)
movq -1584(%rbp), %rdi
call evn_count@PLT
movq %rax, -1592(%rbp)
movabsq $7, %rax
movq %rax, -1600(%rbp)
movq -1600(%rbp), %rdi
movq -1576(%rbp), %rsi
movq -1592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1608(%rbp)
movq -1608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1616(%rbp)
cmpq $0, -1616(%rbp)
je .Lf59_b22
jmp .Lf59_b21
.Lf59_b19:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1504(%rbp)
movabsq $4, %rax
movq %rax, -1512(%rbp)
movq -1504(%rbp), %rdi
movq -1512(%rbp), %rsi
call evn_member@PLT
movq %rax, -1520(%rbp)
movabsq $4, %rax
movq %rax, -1528(%rbp)
movq -1520(%rbp), %rdi
movq -1528(%rbp), %rsi
call evn_member@PLT
movq %rax, -1536(%rbp)
movq -168(%rbp), %rdi
movq -1536(%rbp), %rsi
call evn_store@PLT
movq %rax, -1544(%rbp)
movabsq $0, %rax
movq %rax, -1552(%rbp)
movq -1552(%rbp), %rdi
call evn_int@PLT
movq %rax, -1560(%rbp)
movq -144(%rbp), %rdi
movq -1560(%rbp), %rsi
call evn_store@PLT
movq %rax, -1568(%rbp)
jmp .Lf59_b20
.Lf59_b18:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1328(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1336(%rbp)
movq -1336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1344(%rbp)
movq -1328(%rbp), %rdi
movq -1344(%rbp), %rsi
call evn_index@PLT
movq %rax, -1352(%rbp)
movq -152(%rbp), %rdi
movq -1352(%rbp), %rsi
call evn_store@PLT
movq %rax, -1360(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1368(%rbp)
movq -1368(%rbp), %rdi
call f69@PLT
movq %rax, -1376(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1384(%rbp)
movabsq $4, %rax
movq %rax, -1392(%rbp)
movq -1384(%rbp), %rdi
movq -1392(%rbp), %rsi
call evn_member@PLT
movq %rax, -1400(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1408(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1416(%rbp)
movabsq $0, %rax
movq %rax, -1424(%rbp)
movq -1416(%rbp), %rdi
movq -1424(%rbp), %rsi
call evn_member@PLT
movq %rax, -1432(%rbp)
movq -1400(%rbp), %rdi
movq -1408(%rbp), %rsi
movq -1432(%rbp), %rdx
call f38@PLT
movq %rax, -1440(%rbp)
movq -160(%rbp), %rdi
movq -1440(%rbp), %rsi
call evn_store@PLT
movq %rax, -1448(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1456(%rbp)
movabsq $1, %rax
movq %rax, -1464(%rbp)
movq -1464(%rbp), %rdi
call evn_int@PLT
movq %rax, -1472(%rbp)
movabsq $0, %rax
movq %rax, -1480(%rbp)
movq -1480(%rbp), %rdi
movq -1456(%rbp), %rsi
movq -1472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1488(%rbp)
movq -144(%rbp), %rdi
movq -1488(%rbp), %rsi
call evn_store@PLT
movq %rax, -1496(%rbp)
jmp .Lf59_b17
.Lf59_b17:
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1280(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1288(%rbp)
movq -1288(%rbp), %rdi
call evn_count@PLT
movq %rax, -1296(%rbp)
movabsq $7, %rax
movq %rax, -1304(%rbp)
movq -1304(%rbp), %rdi
movq -1280(%rbp), %rsi
movq -1296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1320(%rbp)
cmpq $0, -1320(%rbp)
je .Lf59_b19
jmp .Lf59_b18
.Lf59_b16:
jmp .Lf59_b11
.Lf59_b15:
jmp .Lf59_b16
.Lf59_b14:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movq -8(%rbp), %rdi
movq -1104(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rax
leave
ret
.Lf59_b13:
movq -1040(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf59_b15
jmp .Lf59_b14
.Lf59_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1064(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1080(%rbp)
movq -1056(%rbp), %rdi
movq -1064(%rbp), %rsi
movq -1072(%rbp), %rdx
movq -1080(%rbp), %rcx
call f60@PLT
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rax
movq %rax, -1040(%rbp)
jmp .Lf59_b13
.Lf59_b11:
jmp .Lf59_b6
.Lf59_b10:
jmp .Lf59_b11
.Lf59_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -824(%rbp)
movabsq $5, %rax
movq %rax, -832(%rbp)
movq -824(%rbp), %rdi
movq -832(%rbp), %rsi
call evn_member@PLT
movq %rax, -840(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -856(%rbp)
movabsq $2, %rax
movq %rax, -864(%rbp)
movq -864(%rbp), %rdi
call evn_int@PLT
movq %rax, -872(%rbp)
movabsq $0, %rax
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
movq -856(%rbp), %rsi
movq -872(%rbp), %rdx
call evn_binary@PLT
movq %rax, -888(%rbp)
movq -840(%rbp), %rdi
movq -848(%rbp), %rsi
movq -888(%rbp), %rdx
call f40@PLT
movq %rax, -896(%rbp)
movq -120(%rbp), %rdi
movq -896(%rbp), %rsi
call evn_store@PLT
movq %rax, -904(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -912(%rbp)
movabsq $5, %rax
movq %rax, -920(%rbp)
movq -912(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_member@PLT
movq %rax, -928(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -936(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $4, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
call evn_int@PLT
movq %rax, -960(%rbp)
movabsq $0, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
movq -944(%rbp), %rsi
movq -960(%rbp), %rdx
call evn_binary@PLT
movq %rax, -976(%rbp)
movq -928(%rbp), %rdi
movq -936(%rbp), %rsi
movq -976(%rbp), %rdx
call f40@PLT
movq %rax, -984(%rbp)
movq -128(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_store@PLT
movq %rax, -992(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1000(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1008(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1016(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movq -1000(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1016(%rbp), %rdx
movq -1024(%rbp), %rcx
call f60@PLT
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rax
movq %rax, -1040(%rbp)
movq -1032(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1048(%rbp)
cmpq $0, -1048(%rbp)
je .Lf59_b13
jmp .Lf59_b12
.Lf59_b8:
movq -736(%rbp), %rdi
call evn_truth@PLT
movq %rax, -816(%rbp)
cmpq $0, -816(%rbp)
je .Lf59_b10
jmp .Lf59_b9
.Lf59_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -752(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -768(%rbp)
movq -752(%rbp), %rdi
movq -760(%rbp), %rsi
movq -768(%rbp), %rdx
call f64@PLT
movq %rax, -776(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movq -784(%rbp), %rdi
call evn_count@PLT
movq %rax, -792(%rbp)
movabsq $5, %rax
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
movq -776(%rbp), %rsi
movq -792(%rbp), %rdx
call evn_binary@PLT
movq %rax, -808(%rbp)
movq -808(%rbp), %rax
movq %rax, -736(%rbp)
jmp .Lf59_b8
.Lf59_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1120(%rbp)
movabsq $5, %rax
movq %rax, -1128(%rbp)
movq -1120(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_member@PLT
movq %rax, -1136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1144(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1152(%rbp)
movabsq $1, %rax
movq %rax, -1160(%rbp)
movq -1160(%rbp), %rdi
call evn_int@PLT
movq %rax, -1168(%rbp)
movabsq $0, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
movq -1152(%rbp), %rsi
movq -1168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1184(%rbp)
movq -1136(%rbp), %rdi
movq -1144(%rbp), %rsi
movq -1184(%rbp), %rdx
call f40@PLT
movq %rax, -1192(%rbp)
movq -96(%rbp), %rdi
movq -1192(%rbp), %rsi
call evn_store@PLT
movq %rax, -1200(%rbp)
jmp .Lf59_b1
.Lf59_b5:
jmp .Lf59_b6
.Lf59_b4:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -672(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -680(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movq -672(%rbp), %rdi
movq -680(%rbp), %rsi
movq -688(%rbp), %rdx
call f65@PLT
movq %rax, -696(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call evn_count@PLT
movq %rax, -712(%rbp)
movabsq $5, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
movq -696(%rbp), %rsi
movq -712(%rbp), %rdx
call evn_binary@PLT
movq %rax, -728(%rbp)
movq -728(%rbp), %rax
movq %rax, -736(%rbp)
movq -728(%rbp), %rdi
call evn_truth@PLT
movq %rax, -744(%rbp)
cmpq $0, -744(%rbp)
je .Lf59_b8
jmp .Lf59_b7
.Lf59_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1208(%rbp)
movabsq $4, %rax
movq %rax, -1216(%rbp)
movq -1208(%rbp), %rdi
movq -1216(%rbp), %rsi
call evn_member@PLT
movq %rax, -1224(%rbp)
movabsq $4, %rax
movq %rax, -1232(%rbp)
movq -1224(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_member@PLT
movq %rax, -1240(%rbp)
movq -136(%rbp), %rdi
movq -1240(%rbp), %rsi
call evn_store@PLT
movq %rax, -1248(%rbp)
movabsq $0, %rax
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
call evn_int@PLT
movq %rax, -1264(%rbp)
movq -144(%rbp), %rdi
movq -1264(%rbp), %rsi
call evn_store@PLT
movq %rax, -1272(%rbp)
jmp .Lf59_b17
.Lf59_b2:
movabsq $33, %rax
movq %rax, -464(%rbp)
movabsq $2, %rax
movq %rax, -472(%rbp)
movq -464(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_object@PLT
movq %rax, -480(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $10, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movabsq $1, %rax
movq %rax, -512(%rbp)
movq -480(%rbp), %rdi
movq -512(%rbp), %rsi
movq -504(%rbp), %rdx
call evn_init@PLT
movq %rax, -520(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $0, %rax
movq %rax, -536(%rbp)
movq -480(%rbp), %rdi
movq -536(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_init@PLT
movq %rax, -544(%rbp)
movq -104(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_store@PLT
movq %rax, -552(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call f66@PLT
movq %rax, -576(%rbp)
movq -112(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_store@PLT
movq %rax, -584(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $5, %rax
movq %rax, -600(%rbp)
movq -592(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_member@PLT
movq %rax, -608(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
movq -624(%rbp), %rdx
call f40@PLT
movq %rax, -632(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -640(%rbp)
movabsq $5, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
movq -632(%rbp), %rsi
movq -640(%rbp), %rdx
call evn_binary@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_truth@PLT
movq %rax, -664(%rbp)
cmpq $0, -664(%rbp)
je .Lf59_b5
jmp .Lf59_b4
.Lf59_b1:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $0, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $6, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -416(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_truth@PLT
movq %rax, -456(%rbp)
cmpq $0, -456(%rbp)
je .Lf59_b3
jmp .Lf59_b2
.Lf59_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -2512(%rbp), %rsi
leaq .Lroots_f59(%rip), %rdx
movq $314, %rcx
call evn_bind_roots@PLT
movq -2488(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -2496(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -2504(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -2512(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
call evn_void@PLT
movq %rax, -120(%rbp)
call evn_void@PLT
movq %rax, -128(%rbp)
call evn_void@PLT
movq %rax, -136(%rbp)
call evn_void@PLT
movq %rax, -144(%rbp)
call evn_void@PLT
movq %rax, -152(%rbp)
call evn_void@PLT
movq %rax, -160(%rbp)
call evn_void@PLT
movq %rax, -168(%rbp)
call evn_void@PLT
movq %rax, -176(%rbp)
call evn_void@PLT
movq %rax, -184(%rbp)
call evn_void@PLT
movq %rax, -192(%rbp)
call evn_void@PLT
movq %rax, -200(%rbp)
call evn_void@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call f68@PLT
movq %rax, -232(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $17, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_int@PLT
movq %rax, -280(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
movq -280(%rbp), %rdx
call f61@PLT
movq %rax, -288(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
movq -288(%rbp), %rdx
call f61@PLT
movq %rax, -296(%rbp)
movq -80(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_store@PLT
movq %rax, -304(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movabsq $64, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $4, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -312(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movq -88(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $3, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_member@PLT
movq %rax, -376(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
movq -392(%rbp), %rdx
call f40@PLT
movq %rax, -400(%rbp)
movq -96(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_store@PLT
movq %rax, -408(%rbp)
jmp .Lf59_b1
.size f59, .-f59
.text
.p2align 4
.type f60, @function
f60:
pushq %rbp
movq %rsp, %rbp
subq $464, %rsp
movq %rdi, -440(%rbp)
movq %rsi, -448(%rbp)
movq %rdx, -456(%rbp)
movq %rcx, -464(%rbp)
leaq -432(%rbp), %rdi
movq $54, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf60_b0
.Lf60_b6:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $1, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $0, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -368(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -80(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_store@PLT
movq %rax, -408(%rbp)
jmp .Lf60_b1
.Lf60_b5:
jmp .Lf60_b6
.Lf60_b4:
movabsq $0, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_bool@PLT
movq %rax, -352(%rbp)
movq -8(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rax
leave
ret
.Lf60_b3:
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_bool@PLT
movq %rax, -424(%rbp)
movq -8(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rax
leave
ret
.Lf60_b2:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_truth@PLT
movq %rax, -184(%rbp)
movq -168(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_index@PLT
movq %rax, -192(%rbp)
movq -88(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_store@PLT
movq %rax, -200(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call f69@PLT
movq %rax, -216(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $4, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $0, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
movq -256(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_binary@PLT
movq %rax, -280(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
movq -280(%rbp), %rdx
call f40@PLT
movq %rax, -288(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $0, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $6, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -288(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf60_b5
jmp .Lf60_b4
.Lf60_b1:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_count@PLT
movq %rax, -136(%rbp)
movabsq $7, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf60_b3
jmp .Lf60_b2
.Lf60_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -464(%rbp), %rsi
leaq .Lroots_f60(%rip), %rdx
movq $58, %rcx
call evn_bind_roots@PLT
movq -440(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -448(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -456(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -464(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
movabsq $0, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movq -80(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
jmp .Lf60_b1
.size f60, .-f60
.text
.p2align 4
.type f61, @function
f61:
pushq %rbp
movq %rsp, %rbp
subq $560, %rsp
movq %rdi, -544(%rbp)
movq %rsi, -552(%rbp)
movq %rdx, -560(%rbp)
leaq -536(%rbp), %rdi
movq $67, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf61_b0
.Lf61_b3:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $131, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movabsq $2, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_count@PLT
movq %rax, -480(%rbp)
movabsq $0, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -464(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -496(%rbp)
movabsq $2147483629, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call evn_int@PLT
movq %rax, -512(%rbp)
movabsq $4, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
movq -496(%rbp), %rsi
movq -512(%rbp), %rdx
call evn_binary@PLT
movq %rax, -528(%rbp)
movq -8(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
leave
ret
.Lf61_b2:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $1, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -176(%rbp), %rdi
movq -192(%rbp), %rsi
call f11@PLT
movq %rax, -200(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_truth@PLT
movq %rax, -224(%rbp)
movq -208(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_index@PLT
movq %rax, -232(%rbp)
movq -80(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -240(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call f69@PLT
movq %rax, -256(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $131, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_int@PLT
movq %rax, -280(%rbp)
movabsq $2, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
movq -264(%rbp), %rsi
movq -280(%rbp), %rdx
call evn_binary@PLT
movq %rax, -296(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $0, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movabsq $0, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -296(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movabsq $2147483629, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movabsq $4, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -336(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -64(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_store@PLT
movq %rax, -376(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -72(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_store@PLT
movq %rax, -424(%rbp)
jmp .Lf61_b1
.Lf61_b1:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_count@PLT
movq %rax, -144(%rbp)
movabsq $7, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_binary@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_truth@PLT
movq %rax, -168(%rbp)
cmpq $0, -168(%rbp)
je .Lf61_b3
jmp .Lf61_b2
.Lf61_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -560(%rbp), %rsi
leaq .Lroots_f61(%rip), %rdx
movq $70, %rcx
call evn_bind_roots@PLT
movq -544(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -552(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -560(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -64(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movq -72(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -120(%rbp)
jmp .Lf61_b1
.size f61, .-f61
.text
.p2align 4
.type f62, @function
f62:
pushq %rbp
movq %rsp, %rbp
subq $512, %rsp
movq %rdi, -480(%rbp)
movq %rsi, -488(%rbp)
movq %rdx, -496(%rbp)
movq %rcx, -504(%rbp)
leaq -472(%rbp), %rdi
movq $59, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf62_b0
.Lf62_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $5, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $4, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movabsq $0, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -336(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
movq -368(%rbp), %rdx
call f40@PLT
movq %rax, -376(%rbp)
movq -96(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_store@PLT
movq %rax, -384(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $4, %rax
movq %rax, -400(%rbp)
movq -392(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_member@PLT
movq %rax, -408(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $0, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -424(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
movq -448(%rbp), %rdx
call f40@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call f73@PLT
movq %rax, -464(%rbp)
movq -8(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rax
leave
ret
.Lf62_b4:
jmp .Lf62_b5
.Lf62_b3:
leaq .Ldata_27(%rip), %rax
movq %rax, -272(%rbp)
movabsq $29, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_text@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call f33@PLT
movq %rax, -296(%rbp)
jmp .Lf62_b5
.Lf62_b2:
movq -216(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf62_b4
jmp .Lf62_b3
.Lf62_b1:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $10, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -232(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rax
movq %rax, -216(%rbp)
jmp .Lf62_b2
.Lf62_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -504(%rbp), %rsi
leaq .Lroots_f62(%rip), %rdx
movq $63, %rcx
call evn_bind_roots@PLT
movq -480(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -488(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -496(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -504(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call f66@PLT
movq %rax, -120(%rbp)
movq -80(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
movq -152(%rbp), %rdx
call f64@PLT
movq %rax, -160(%rbp)
movq -88(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -168(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $0, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movabsq $7, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -176(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -224(%rbp)
cmpq $0, -224(%rbp)
je .Lf62_b1
jmp .Lf62_b2
.size f62, .-f62
.text
.p2align 4
.type f63, @function
f63:
pushq %rbp
movq %rsp, %rbp
subq $512, %rsp
movq %rdi, -480(%rbp)
movq %rsi, -488(%rbp)
movq %rdx, -496(%rbp)
movq %rcx, -504(%rbp)
leaq -472(%rbp), %rdi
movq $59, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf63_b0
.Lf63_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $5, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $2, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
call evn_int@PLT
movq %rax, -352(%rbp)
movabsq $0, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -336(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
movq -368(%rbp), %rdx
call f40@PLT
movq %rax, -376(%rbp)
movq -96(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_store@PLT
movq %rax, -384(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $4, %rax
movq %rax, -400(%rbp)
movq -392(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_member@PLT
movq %rax, -408(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $0, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -424(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
movq -448(%rbp), %rdx
call f40@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call f73@PLT
movq %rax, -464(%rbp)
movq -8(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rax
leave
ret
.Lf63_b4:
jmp .Lf63_b5
.Lf63_b3:
leaq .Ldata_28(%rip), %rax
movq %rax, -272(%rbp)
movabsq $32, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_text@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call f33@PLT
movq %rax, -296(%rbp)
jmp .Lf63_b5
.Lf63_b2:
movq -216(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf63_b4
jmp .Lf63_b3
.Lf63_b1:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $10, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -232(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rax
movq %rax, -216(%rbp)
jmp .Lf63_b2
.Lf63_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -504(%rbp), %rsi
leaq .Lroots_f63(%rip), %rdx
movq $63, %rcx
call evn_bind_roots@PLT
movq -480(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -488(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -496(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -504(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call f66@PLT
movq %rax, -120(%rbp)
movq -80(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
movq -152(%rbp), %rdx
call f65@PLT
movq %rax, -160(%rbp)
movq -88(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -168(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $0, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movabsq $7, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
movq -176(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_binary@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -224(%rbp)
cmpq $0, -224(%rbp)
je .Lf63_b1
jmp .Lf63_b2
.size f63, .-f63
.text
.p2align 4
.type f64, @function
f64:
pushq %rbp
movq %rsp, %rbp
subq $208, %rsp
movq %rdi, -192(%rbp)
movq %rsi, -200(%rbp)
movq %rdx, -208(%rbp)
leaq -184(%rbp), %rdi
movq $23, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf64_b0
.Lf64_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -208(%rbp), %rsi
leaq .Lroots_f64(%rip), %rdx
movq $26, %rcx
call evn_bind_roots@PLT
movq -192(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -200(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -208(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call f66@PLT
movq %rax, -88(%rbp)
movq -64(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $5, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $5, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -136(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
movq -168(%rbp), %rdx
call f40@PLT
movq %rax, -176(%rbp)
movq -8(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
leave
ret
.size f64, .-f64
.text
.p2align 4
.type f65, @function
f65:
pushq %rbp
movq %rsp, %rbp
subq $208, %rsp
movq %rdi, -192(%rbp)
movq %rsi, -200(%rbp)
movq %rdx, -208(%rbp)
leaq -184(%rbp), %rdi
movq $23, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf65_b0
.Lf65_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -208(%rbp), %rsi
leaq .Lroots_f65(%rip), %rdx
movq $26, %rcx
call evn_bind_roots@PLT
movq -192(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -200(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -208(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call f66@PLT
movq %rax, -88(%rbp)
movq -64(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $5, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $3, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -136(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
movq -168(%rbp), %rdx
call f40@PLT
movq %rax, -176(%rbp)
movq -8(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
leave
ret
.size f65, .-f65
.text
.p2align 4
.type f66, @function
f66:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
movq %rdi, -488(%rbp)
movq %rsi, -496(%rbp)
leaq -480(%rbp), %rdi
movq $60, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf66_b0
.Lf66_b9:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $0, %rax
movq %rax, -400(%rbp)
movq -392(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_member@PLT
movq %rax, -408(%rbp)
movabsq $1, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movabsq $1, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -408(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movabsq $6, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $2, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -440(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movq -8(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
leave
ret
.Lf66_b8:
jmp .Lf66_b9
.Lf66_b7:
leaq .Ldata_29(%rip), %rax
movq %rax, -360(%rbp)
movabsq $34, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_text@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call f33@PLT
movq %rax, -384(%rbp)
jmp .Lf66_b9
.Lf66_b6:
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -352(%rbp)
cmpq $0, -352(%rbp)
je .Lf66_b8
jmp .Lf66_b7
.Lf66_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $5, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
movabsq $4, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movabsq $6, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call evn_int@PLT
movq %rax, -312(%rbp)
movabsq $3, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -296(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movabsq $9, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -256(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rax
movq %rax, -224(%rbp)
jmp .Lf66_b6
.Lf66_b4:
movq -152(%rbp), %rax
movq %rax, -224(%rbp)
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf66_b5
jmp .Lf66_b6
.Lf66_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $0, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movabsq $1, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $7, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -152(%rbp)
jmp .Lf66_b4
.Lf66_b2:
movq -72(%rbp), %rax
movq %rax, -152(%rbp)
movq -72(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf66_b3
jmp .Lf66_b4
.Lf66_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $10, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $6, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -104(%rbp), %rsi
movq -128(%rbp), %rdx
call evn_binary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
movq %rax, -72(%rbp)
jmp .Lf66_b2
.Lf66_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -496(%rbp), %rsi
leaq .Lroots_f66(%rip), %rdx
movq $62, %rcx
call evn_bind_roots@PLT
movq -488(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -496(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $7, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -80(%rbp)
cmpq $0, -80(%rbp)
je .Lf66_b1
jmp .Lf66_b2
.size f66, .-f66
.text
.p2align 4
.type f67, @function
f67:
pushq %rbp
movq %rsp, %rbp
subq $1328, %rsp
movq %rdi, -1320(%rbp)
movq %rsi, -1328(%rbp)
leaq -1312(%rbp), %rdi
movq $164, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf67_b0
.Lf67_b12:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movq -1248(%rbp), %rdi
call f20@PLT
movq %rax, -1256(%rbp)
movabsq $18, %rax
movq %rax, -1264(%rbp)
movq -1264(%rbp), %rdi
movq -1256(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1272(%rbp)
movabsq $6, %rax
movq %rax, -1280(%rbp)
movq -64(%rbp), %rdi
movq -1280(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1288(%rbp)
movq -1288(%rbp), %rdi
movq -1272(%rbp), %rsi
call evn_store@PLT
movq %rax, -1296(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1304(%rbp)
movq -8(%rbp), %rdi
movq -1304(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rax
leave
ret
.Lf67_b11:
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1136(%rbp)
movabsq $3, %rax
movq %rax, -1144(%rbp)
movq -1136(%rbp), %rdi
movq -1144(%rbp), %rsi
call evn_member@PLT
movq %rax, -1152(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1160(%rbp)
movabsq $0, %rax
movq %rax, -1168(%rbp)
movq -1168(%rbp), %rdi
call evn_int@PLT
movq %rax, -1176(%rbp)
movq -1152(%rbp), %rdi
movq -1160(%rbp), %rsi
movq -1176(%rbp), %rdx
call f38@PLT
movq %rax, -1184(%rbp)
movq -80(%rbp), %rdi
movq -1184(%rbp), %rsi
call evn_store@PLT
movq %rax, -1192(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1200(%rbp)
movabsq $1, %rax
movq %rax, -1208(%rbp)
movq -1208(%rbp), %rdi
call evn_int@PLT
movq %rax, -1216(%rbp)
movabsq $0, %rax
movq %rax, -1224(%rbp)
movq -1224(%rbp), %rdi
movq -1200(%rbp), %rsi
movq -1216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1232(%rbp)
movq -72(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_store@PLT
movq %rax, -1240(%rbp)
jmp .Lf67_b10
.Lf67_b10:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1088(%rbp)
movabsq $64, %rax
movq %rax, -1096(%rbp)
movq -1096(%rbp), %rdi
call evn_int@PLT
movq %rax, -1104(%rbp)
movabsq $7, %rax
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
movq -1088(%rbp), %rsi
movq -1104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1120(%rbp)
movq -1120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1128(%rbp)
cmpq $0, -1128(%rbp)
je .Lf67_b12
jmp .Lf67_b11
.Lf67_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $16384, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call evn_int@PLT
movq %rax, -408(%rbp)
movq -392(%rbp), %rdi
movq -408(%rbp), %rsi
call f22@PLT
movq %rax, -416(%rbp)
movq -48(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_store@PLT
movq %rax, -424(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call f18@PLT
movq %rax, -440(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movabsq $1024, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movq -448(%rbp), %rdi
movq -464(%rbp), %rsi
call f13@PLT
movq %rax, -472(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movabsq $768, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_int@PLT
movq %rax, -496(%rbp)
movq -480(%rbp), %rdi
movq -496(%rbp), %rsi
call f22@PLT
movq %rax, -504(%rbp)
movq -56(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_store@PLT
movq %rax, -512(%rbp)
movabsq $25, %rax
movq %rax, -520(%rbp)
movabsq $11, %rax
movq %rax, -528(%rbp)
movq -520(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_object@PLT
movq %rax, -536(%rbp)
movabsq $26, %rax
movq %rax, -544(%rbp)
movabsq $1, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_object@PLT
movq %rax, -560(%rbp)
movabsq $0, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
call evn_int@PLT
movq %rax, -576(%rbp)
movabsq $0, %rax
movq %rax, -584(%rbp)
movq -560(%rbp), %rdi
movq -584(%rbp), %rsi
movq -576(%rbp), %rdx
call evn_init@PLT
movq %rax, -592(%rbp)
movabsq $27, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -608(%rbp)
movabsq $10, %rax
movq %rax, -616(%rbp)
movq -536(%rbp), %rdi
movq -616(%rbp), %rsi
movq -608(%rbp), %rdx
call evn_init@PLT
movq %rax, -624(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $9, %rax
movq %rax, -640(%rbp)
movq -536(%rbp), %rdi
movq -640(%rbp), %rsi
movq -632(%rbp), %rdx
call evn_init@PLT
movq %rax, -648(%rbp)
movabsq $0, %rax
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_bool@PLT
movq %rax, -664(%rbp)
movabsq $8, %rax
movq %rax, -672(%rbp)
movq -536(%rbp), %rdi
movq -672(%rbp), %rsi
movq -664(%rbp), %rdx
call evn_init@PLT
movq %rax, -680(%rbp)
movabsq $0, %rax
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
call evn_bool@PLT
movq %rax, -696(%rbp)
movabsq $7, %rax
movq %rax, -704(%rbp)
movq -536(%rbp), %rdi
movq -704(%rbp), %rsi
movq -696(%rbp), %rdx
call evn_init@PLT
movq %rax, -712(%rbp)
movabsq $18, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_none@PLT
movq %rax, -728(%rbp)
movabsq $6, %rax
movq %rax, -736(%rbp)
movq -536(%rbp), %rdi
movq -736(%rbp), %rsi
movq -728(%rbp), %rdx
call evn_init@PLT
movq %rax, -744(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -752(%rbp)
movabsq $6291456, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_int@PLT
movq %rax, -768(%rbp)
movq -752(%rbp), %rdi
movq -768(%rbp), %rsi
call f50@PLT
movq %rax, -776(%rbp)
movabsq $5, %rax
movq %rax, -784(%rbp)
movq -536(%rbp), %rdi
movq -784(%rbp), %rsi
movq -776(%rbp), %rdx
call evn_init@PLT
movq %rax, -792(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -800(%rbp)
movabsq $8388608, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
call evn_int@PLT
movq %rax, -816(%rbp)
movq -800(%rbp), %rdi
movq -816(%rbp), %rsi
call f50@PLT
movq %rax, -824(%rbp)
movabsq $4, %rax
movq %rax, -832(%rbp)
movq -536(%rbp), %rdi
movq -832(%rbp), %rsi
movq -824(%rbp), %rdx
call evn_init@PLT
movq %rax, -840(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movabsq $64, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
call evn_int@PLT
movq %rax, -864(%rbp)
movq -848(%rbp), %rdi
movq -864(%rbp), %rsi
call f50@PLT
movq %rax, -872(%rbp)
movabsq $3, %rax
movq %rax, -880(%rbp)
movq -536(%rbp), %rdi
movq -880(%rbp), %rsi
movq -872(%rbp), %rdx
call evn_init@PLT
movq %rax, -888(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $524288, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_int@PLT
movq %rax, -912(%rbp)
movq -896(%rbp), %rdi
movq -912(%rbp), %rsi
call f50@PLT
movq %rax, -920(%rbp)
movabsq $2, %rax
movq %rax, -928(%rbp)
movq -536(%rbp), %rdi
movq -928(%rbp), %rsi
movq -920(%rbp), %rdx
call evn_init@PLT
movq %rax, -936(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $8388608, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
call evn_int@PLT
movq %rax, -960(%rbp)
movq -944(%rbp), %rdi
movq -960(%rbp), %rsi
call f50@PLT
movq %rax, -968(%rbp)
movabsq $1, %rax
movq %rax, -976(%rbp)
movq -536(%rbp), %rdi
movq -976(%rbp), %rsi
movq -968(%rbp), %rdx
call evn_init@PLT
movq %rax, -984(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -992(%rbp)
movabsq $7340032, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
call evn_int@PLT
movq %rax, -1008(%rbp)
movq -992(%rbp), %rdi
movq -1008(%rbp), %rsi
call f50@PLT
movq %rax, -1016(%rbp)
movabsq $0, %rax
movq %rax, -1024(%rbp)
movq -536(%rbp), %rdi
movq -1024(%rbp), %rsi
movq -1016(%rbp), %rdx
call evn_init@PLT
movq %rax, -1032(%rbp)
movabsq $28, %rax
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1048(%rbp)
movq -64(%rbp), %rdi
movq -1048(%rbp), %rsi
call evn_store@PLT
movq %rax, -1056(%rbp)
movabsq $0, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_int@PLT
movq %rax, -1072(%rbp)
movq -72(%rbp), %rdi
movq -1072(%rbp), %rsi
call evn_store@PLT
movq %rax, -1080(%rbp)
jmp .Lf67_b10
.Lf67_b8:
jmp .Lf67_b9
.Lf67_b7:
leaq .Ldata_30(%rip), %rax
movq %rax, -360(%rbp)
movabsq $38, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_text@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call f33@PLT
movq %rax, -384(%rbp)
jmp .Lf67_b9
.Lf67_b6:
movq -280(%rbp), %rdi
call evn_truth@PLT
movq %rax, -352(%rbp)
cmpq $0, -352(%rbp)
je .Lf67_b8
jmp .Lf67_b7
.Lf67_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $1, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $6, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -312(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movq -344(%rbp), %rax
movq %rax, -280(%rbp)
jmp .Lf67_b6
.Lf67_b4:
movq -208(%rbp), %rax
movq %rax, -280(%rbp)
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -288(%rbp)
cmpq $0, -288(%rbp)
je .Lf67_b5
jmp .Lf67_b6
.Lf67_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $2, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movabsq $0, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_int@PLT
movq %rax, -256(%rbp)
movabsq $6, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -240(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_binary@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rax
movq %rax, -208(%rbp)
jmp .Lf67_b4
.Lf67_b2:
movq -144(%rbp), %rax
movq %rax, -208(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf67_b3
jmp .Lf67_b4
.Lf67_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $4, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $6, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -176(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
movq %rax, -144(%rbp)
jmp .Lf67_b2
.Lf67_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1328(%rbp), %rsi
leaq .Lroots_f67(%rip), %rdx
movq $166, %rcx
call evn_bind_roots@PLT
movq -1320(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1328(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $11, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movabsq $1, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_int@PLT
movq %rax, -120(%rbp)
movabsq $6, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
movq -104(%rbp), %rsi
movq -120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf67_b1
jmp .Lf67_b2
.size f67, .-f67
.text
.p2align 4
.type f68, @function
f68:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -280(%rbp)
movq %rsi, -288(%rbp)
leaq -272(%rbp), %rdi
movq $34, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf68_b0
.Lf68_b7:
call evn_void@PLT
movq %rax, -264(%rbp)
movq -8(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rax
leave
ret
.Lf68_b6:
jmp .Lf68_b7
.Lf68_b5:
leaq .Ldata_31(%rip), %rax
movq %rax, -232(%rbp)
movabsq $33, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_text@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call f33@PLT
movq %rax, -256(%rbp)
jmp .Lf68_b7
.Lf68_b4:
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -224(%rbp)
cmpq $0, -224(%rbp)
je .Lf68_b6
jmp .Lf68_b5
.Lf68_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $4, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $9, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movabsq $6, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -176(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -144(%rbp)
jmp .Lf68_b4
.Lf68_b2:
movq -104(%rbp), %rax
movq %rax, -144(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -152(%rbp)
cmpq $0, -152(%rbp)
je .Lf68_b3
jmp .Lf68_b4
.Lf68_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $8, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf68_b2
.Lf68_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -288(%rbp), %rsi
leaq .Lroots_f68(%rip), %rdx
movq $36, %rcx
call evn_bind_roots@PLT
movq -280(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -288(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $9, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call f9@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movabsq $7, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_member@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf68_b1
jmp .Lf68_b2
.size f68, .-f68
.text
.p2align 4
.type f69, @function
f69:
pushq %rbp
movq %rsp, %rbp
subq $96, %rsp
movq %rdi, -96(%rbp)
leaq -88(%rbp), %rdi
movq $11, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf69_b0
.Lf69_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -96(%rbp), %rsi
leaq .Lroots_f69(%rip), %rdx
movq $12, %rcx
call evn_bind_roots@PLT
movq -96(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $0, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_member@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call f73@PLT
movq %rax, -64(%rbp)
movq -32(%rbp), %rdi
movq -64(%rbp), %rsi
call evn_store@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -8(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rax
leave
ret
.size f69, .-f69
.text
.p2align 4
.type f70, @function
f70:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
leaq -72(%rbp), %rdi
movq $9, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf70_b0
.Lf70_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f70(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movabsq $31, %rax
movq %rax, -16(%rbp)
movabsq $1, %rax
movq %rax, -24(%rbp)
movq -16(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_object@PLT
movq %rax, -32(%rbp)
movabsq $3, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -32(%rbp), %rdi
movq -56(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_init@PLT
movq %rax, -64(%rbp)
movq -8(%rbp), %rdi
movq -32(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -72(%rbp)
movq -72(%rbp), %rax
leave
ret
.size f70, .-f70
.text
.p2align 4
.type f71, @function
f71:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
leaq -72(%rbp), %rdi
movq $9, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf71_b0
.Lf71_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f71(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movabsq $31, %rax
movq %rax, -16(%rbp)
movabsq $1, %rax
movq %rax, -24(%rbp)
movq -16(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_object@PLT
movq %rax, -32(%rbp)
movabsq $2, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -32(%rbp), %rdi
movq -56(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_init@PLT
movq %rax, -64(%rbp)
movq -8(%rbp), %rdi
movq -32(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -72(%rbp)
movq -72(%rbp), %rax
leave
ret
.size f71, .-f71
.text
.p2align 4
.type f72, @function
f72:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
leaq -72(%rbp), %rdi
movq $9, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf72_b0
.Lf72_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f72(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movabsq $31, %rax
movq %rax, -16(%rbp)
movabsq $1, %rax
movq %rax, -24(%rbp)
movq -16(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_object@PLT
movq %rax, -32(%rbp)
movabsq $1, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $0, %rax
movq %rax, -56(%rbp)
movq -32(%rbp), %rdi
movq -56(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_init@PLT
movq %rax, -64(%rbp)
movq -8(%rbp), %rdi
movq -32(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -72(%rbp)
movq -72(%rbp), %rax
leave
ret
.size f72, .-f72
.text
.p2align 4
.type f73, @function
f73:
pushq %rbp
movq %rsp, %rbp
subq $224, %rsp
movq %rdi, -224(%rbp)
leaq -216(%rbp), %rdi
movq $27, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf73_b0
.Lf73_b5:
movabsq $31, %rax
movq %rax, -168(%rbp)
movabsq $1, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_object@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $0, %rax
movq %rax, -200(%rbp)
movq -184(%rbp), %rdi
movq -200(%rbp), %rsi
movq -192(%rbp), %rdx
call evn_init@PLT
movq %rax, -208(%rbp)
movq -8(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
leave
ret
.Lf73_b4:
jmp .Lf73_b5
.Lf73_b3:
leaq .Ldata_32(%rip), %rax
movq %rax, -136(%rbp)
movabsq $20, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_text@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call f33@PLT
movq %rax, -160(%rbp)
jmp .Lf73_b5
.Lf73_b2:
movq -72(%rbp), %rdi
call evn_truth@PLT
movq %rax, -128(%rbp)
cmpq $0, -128(%rbp)
je .Lf73_b4
jmp .Lf73_b3
.Lf73_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $3, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movabsq $9, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rax
movq %rax, -72(%rbp)
jmp .Lf73_b2
.Lf73_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -224(%rbp), %rsi
leaq .Lroots_f73(%rip), %rdx
movq $28, %rcx
call evn_bind_roots@PLT
movq -224(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $1, %rax
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call evn_int@PLT
movq %rax, -48(%rbp)
movabsq $7, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -32(%rbp), %rsi
movq -48(%rbp), %rdx
call evn_binary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -80(%rbp)
cmpq $0, -80(%rbp)
je .Lf73_b1
jmp .Lf73_b2
.size f73, .-f73
.text
.p2align 4
.type f74, @function
f74:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -528(%rbp)
leaq -520(%rbp), %rdi
movq $65, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf74_b0
.Lf74_b6:
call evn_void@PLT
movq %rax, -512(%rbp)
movq -8(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rax
leave
ret
.Lf74_b5:
jmp .Lf74_b6
.Lf74_b4:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_get@PLT
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call f17@PLT
movq %rax, -504(%rbp)
jmp .Lf74_b6
.Lf74_b3:
movabsq $2, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $8, %rax
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_store@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $5, %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_member@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call f35@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $4, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call f35@PLT
movq %rax, -232(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $3, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_member@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call f35@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $2, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call f35@PLT
movq %rax, -296(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $1, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call f35@PLT
movq %rax, -328(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movabsq $0, %rax
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_member@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call f35@PLT
movq %rax, -360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $6, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movq -32(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_store@PLT
movq %rax, -392(%rbp)
movabsq $18, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call evn_none@PLT
movq %rax, -408(%rbp)
movabsq $6, %rax
movq %rax, -416(%rbp)
movq -24(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_store@PLT
movq %rax, -432(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movabsq $18, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_none@PLT
movq %rax, -456(%rbp)
movabsq $6, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -440(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_truth@PLT
movq %rax, -480(%rbp)
cmpq $0, -480(%rbp)
je .Lf74_b5
jmp .Lf74_b4
.Lf74_b2:
jmp .Lf74_b3
.Lf74_b1:
leaq .Ldata_33(%rip), %rax
movq %rax, -104(%rbp)
movabsq $28, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_text@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call f33@PLT
movq %rax, -128(%rbp)
jmp .Lf74_b3
.Lf74_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -528(%rbp), %rsi
leaq .Lroots_f74(%rip), %rdx
movq $66, %rcx
call evn_bind_roots@PLT
movq -528(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movabsq $8, %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_member@PLT
movq %rax, -56(%rbp)
movabsq $2, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $5, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
movq -56(%rbp), %rsi
movq -72(%rbp), %rdx
call evn_binary@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_truth@PLT
movq %rax, -96(%rbp)
cmpq $0, -96(%rbp)
je .Lf74_b2
jmp .Lf74_b1
.size f74, .-f74
.text
.p2align 4
.type f75, @function
f75:
pushq %rbp
movq %rsp, %rbp
subq $1520, %rsp
movq %rdi, -1520(%rbp)
leaq -1512(%rbp), %rdi
movq $189, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf75_b0
.Lf75_b18:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1224(%rbp)
movabsq $1, %rax
movq %rax, -1232(%rbp)
movq -1232(%rbp), %rdi
call evn_int@PLT
movq %rax, -1240(%rbp)
movabsq $0, %rax
movq %rax, -1248(%rbp)
movq -1248(%rbp), %rdi
movq -1224(%rbp), %rsi
movq -1240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1256(%rbp)
movq -48(%rbp), %rdi
movq -1256(%rbp), %rsi
call evn_store@PLT
movq %rax, -1264(%rbp)
jmp .Lf75_b13
.Lf75_b17:
jmp .Lf75_b18
.Lf75_b16:
leaq .Ldata_34(%rip), %rax
movq %rax, -1192(%rbp)
movabsq $22, %rax
movq %rax, -1200(%rbp)
movq -1192(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_text@PLT
movq %rax, -1208(%rbp)
movq -1208(%rbp), %rdi
call f33@PLT
movq %rax, -1216(%rbp)
jmp .Lf75_b18
.Lf75_b15:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1272(%rbp)
movabsq $5, %rax
movq %rax, -1280(%rbp)
movq -1272(%rbp), %rdi
movq -1280(%rbp), %rsi
call evn_member@PLT
movq %rax, -1288(%rbp)
movq -1288(%rbp), %rdi
call f37@PLT
movq %rax, -1296(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1304(%rbp)
movabsq $4, %rax
movq %rax, -1312(%rbp)
movq -1304(%rbp), %rdi
movq -1312(%rbp), %rsi
call evn_member@PLT
movq %rax, -1320(%rbp)
movq -1320(%rbp), %rdi
call f37@PLT
movq %rax, -1328(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1336(%rbp)
movabsq $3, %rax
movq %rax, -1344(%rbp)
movq -1336(%rbp), %rdi
movq -1344(%rbp), %rsi
call evn_member@PLT
movq %rax, -1352(%rbp)
movq -1352(%rbp), %rdi
call f37@PLT
movq %rax, -1360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1368(%rbp)
movabsq $2, %rax
movq %rax, -1376(%rbp)
movq -1368(%rbp), %rdi
movq -1376(%rbp), %rsi
call evn_member@PLT
movq %rax, -1384(%rbp)
movq -1384(%rbp), %rdi
call f37@PLT
movq %rax, -1392(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1400(%rbp)
movabsq $1, %rax
movq %rax, -1408(%rbp)
movq -1400(%rbp), %rdi
movq -1408(%rbp), %rsi
call evn_member@PLT
movq %rax, -1416(%rbp)
movq -1416(%rbp), %rdi
call f37@PLT
movq %rax, -1424(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1432(%rbp)
movabsq $0, %rax
movq %rax, -1440(%rbp)
movq -1432(%rbp), %rdi
movq -1440(%rbp), %rsi
call evn_member@PLT
movq %rax, -1448(%rbp)
movq -1448(%rbp), %rdi
call f37@PLT
movq %rax, -1456(%rbp)
movabsq $1, %rax
movq %rax, -1464(%rbp)
movq -1464(%rbp), %rdi
call evn_int@PLT
movq %rax, -1472(%rbp)
movabsq $8, %rax
movq %rax, -1480(%rbp)
movq -24(%rbp), %rdi
movq -1480(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1488(%rbp)
movq -1488(%rbp), %rdi
movq -1472(%rbp), %rsi
call evn_store@PLT
movq %rax, -1496(%rbp)
call evn_void@PLT
movq %rax, -1504(%rbp)
movq -8(%rbp), %rdi
movq -1504(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1512(%rbp)
movq -1512(%rbp), %rax
leave
ret
.Lf75_b14:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movabsq $5, %rax
movq %rax, -1032(%rbp)
movq -1024(%rbp), %rdi
movq -1032(%rbp), %rsi
call evn_member@PLT
movq %rax, -1040(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1048(%rbp)
movabsq $9, %rax
movq %rax, -1056(%rbp)
movq -1048(%rbp), %rdi
movq -1056(%rbp), %rsi
call evn_member@PLT
movq %rax, -1064(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movabsq $5, %rax
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
call evn_int@PLT
movq %rax, -1088(%rbp)
movabsq $2, %rax
movq %rax, -1096(%rbp)
movq -1096(%rbp), %rdi
movq -1072(%rbp), %rsi
movq -1088(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1104(%rbp)
movabsq $4, %rax
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
call evn_int@PLT
movq %rax, -1120(%rbp)
movabsq $0, %rax
movq %rax, -1128(%rbp)
movq -1128(%rbp), %rdi
movq -1104(%rbp), %rsi
movq -1120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1136(%rbp)
movq -1040(%rbp), %rdi
movq -1064(%rbp), %rsi
movq -1136(%rbp), %rdx
call f40@PLT
movq %rax, -1144(%rbp)
movabsq $0, %rax
movq %rax, -1152(%rbp)
movq -1152(%rbp), %rdi
call evn_int@PLT
movq %rax, -1160(%rbp)
movabsq $5, %rax
movq %rax, -1168(%rbp)
movq -1168(%rbp), %rdi
movq -1144(%rbp), %rsi
movq -1160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1184(%rbp)
cmpq $0, -1184(%rbp)
je .Lf75_b17
jmp .Lf75_b16
.Lf75_b13:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -920(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -928(%rbp)
movabsq $5, %rax
movq %rax, -936(%rbp)
movq -928(%rbp), %rdi
movq -936(%rbp), %rsi
call evn_member@PLT
movq %rax, -944(%rbp)
movabsq $4, %rax
movq %rax, -952(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_member@PLT
movq %rax, -960(%rbp)
movabsq $5, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
call evn_int@PLT
movq %rax, -976(%rbp)
movabsq $3, %rax
movq %rax, -984(%rbp)
movq -984(%rbp), %rdi
movq -960(%rbp), %rsi
movq -976(%rbp), %rdx
call evn_binary@PLT
movq %rax, -992(%rbp)
movabsq $7, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
movq -920(%rbp), %rsi
movq -992(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1008(%rbp)
movq -1008(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1016(%rbp)
cmpq $0, -1016(%rbp)
je .Lf75_b15
jmp .Lf75_b14
.Lf75_b12:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movabsq $1, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
call evn_int@PLT
movq %rax, -864(%rbp)
movabsq $0, %rax
movq %rax, -872(%rbp)
movq -872(%rbp), %rdi
movq -848(%rbp), %rsi
movq -864(%rbp), %rdx
call evn_binary@PLT
movq %rax, -880(%rbp)
movq -48(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_store@PLT
movq %rax, -888(%rbp)
jmp .Lf75_b7
.Lf75_b11:
jmp .Lf75_b12
.Lf75_b10:
leaq .Ldata_35(%rip), %rax
movq %rax, -816(%rbp)
movabsq $23, %rax
movq %rax, -824(%rbp)
movq -816(%rbp), %rdi
movq -824(%rbp), %rsi
call evn_text@PLT
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
call f33@PLT
movq %rax, -840(%rbp)
jmp .Lf75_b12
.Lf75_b9:
movabsq $0, %rax
movq %rax, -896(%rbp)
movq -896(%rbp), %rdi
call evn_int@PLT
movq %rax, -904(%rbp)
movq -48(%rbp), %rdi
movq -904(%rbp), %rsi
call evn_store@PLT
movq %rax, -912(%rbp)
jmp .Lf75_b13
.Lf75_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
movq -616(%rbp), %rdx
call f91@PLT
movq %rax, -624(%rbp)
movq -592(%rbp), %rdi
movq -624(%rbp), %rsi
call f93@PLT
movq %rax, -632(%rbp)
movq -56(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_store@PLT
movq %rax, -640(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -648(%rbp)
movabsq $12, %rax
movq %rax, -656(%rbp)
movq -648(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_member@PLT
movq %rax, -664(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -672(%rbp)
movabsq $9, %rax
movq %rax, -680(%rbp)
movq -672(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_member@PLT
movq %rax, -688(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movabsq $11, %rax
movq %rax, -704(%rbp)
movq -696(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_member@PLT
movq %rax, -712(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movq -664(%rbp), %rdi
movq -688(%rbp), %rsi
movq -712(%rbp), %rdx
movq -720(%rbp), %rcx
call f63@PLT
movq %rax, -728(%rbp)
movq -64(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_store@PLT
movq %rax, -736(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movabsq $0, %rax
movq %rax, -752(%rbp)
movq -744(%rbp), %rdi
movq -752(%rbp), %rsi
call evn_member@PLT
movq %rax, -760(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -768(%rbp)
movabsq $0, %rax
movq %rax, -776(%rbp)
movq -768(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_member@PLT
movq %rax, -784(%rbp)
movabsq $6, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
movq -760(%rbp), %rsi
movq -784(%rbp), %rdx
call evn_binary@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
call evn_truth@PLT
movq %rax, -808(%rbp)
cmpq $0, -808(%rbp)
je .Lf75_b11
jmp .Lf75_b10
.Lf75_b7:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -552(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $7, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -552(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call evn_truth@PLT
movq %rax, -584(%rbp)
cmpq $0, -584(%rbp)
je .Lf75_b9
jmp .Lf75_b8
.Lf75_b6:
movabsq $0, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call evn_int@PLT
movq %rax, -536(%rbp)
movq -48(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_store@PLT
movq %rax, -544(%rbp)
jmp .Lf75_b7
.Lf75_b5:
jmp .Lf75_b6
.Lf75_b4:
leaq .Ldata_36(%rip), %rax
movq %rax, -496(%rbp)
movabsq $28, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_text@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call f33@PLT
movq %rax, -520(%rbp)
jmp .Lf75_b6
.Lf75_b3:
movabsq $37, %rax
movq %rax, -200(%rbp)
movabsq $2, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_object@PLT
movq %rax, -216(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $13, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_member@PLT
movq %rax, -240(%rbp)
movabsq $1, %rax
movq %rax, -248(%rbp)
movq -216(%rbp), %rdi
movq -248(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_init@PLT
movq %rax, -256(%rbp)
movabsq $1, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -216(%rbp), %rdi
movq -280(%rbp), %rsi
movq -272(%rbp), %rdx
call evn_init@PLT
movq %rax, -288(%rbp)
movq -32(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $12, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $9, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member@PLT
movq %rax, -344(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $11, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -320(%rbp), %rdi
movq -344(%rbp), %rsi
movq -368(%rbp), %rdx
call f65@PLT
movq %rax, -376(%rbp)
movq -40(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_store@PLT
movq %rax, -384(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $5, %rax
movq %rax, -400(%rbp)
movq -392(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_member@PLT
movq %rax, -408(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $9, %rax
movq %rax, -424(%rbp)
movq -416(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_member@PLT
movq %rax, -432(%rbp)
movabsq $1, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movq -408(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
call f40@PLT
movq %rax, -456(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $6, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
movq -456(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_binary@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_truth@PLT
movq %rax, -488(%rbp)
cmpq $0, -488(%rbp)
je .Lf75_b5
jmp .Lf75_b4
.Lf75_b2:
jmp .Lf75_b3
.Lf75_b1:
leaq .Ldata_37(%rip), %rax
movq %rax, -168(%rbp)
movabsq $25, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_text@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call f33@PLT
movq %rax, -192(%rbp)
jmp .Lf75_b3
.Lf75_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1520(%rbp), %rsi
leaq .Lroots_f75(%rip), %rdx
movq $190, %rcx
call evn_bind_roots@PLT
movq -1520(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call f98@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $5, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movabsq $4, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $5, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
movq -120(%rbp), %rsi
movq -136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf75_b2
jmp .Lf75_b1
.size f75, .-f75
.text
.p2align 4
.type f76, @function
f76:
pushq %rbp
movq %rsp, %rbp
subq $896, %rsp
movq %rdi, -872(%rbp)
movq %rsi, -880(%rbp)
movq %rdx, -888(%rbp)
leaq -864(%rbp), %rdi
movq $108, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf76_b0
.Lf76_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $1, %rax
movq %rax, -600(%rbp)
movq -592(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_member@PLT
movq %rax, -608(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movabsq $9, %rax
movq %rax, -624(%rbp)
movq -616(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_member@PLT
movq %rax, -632(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -640(%rbp)
movabsq $1, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
call evn_int@PLT
movq %rax, -656(%rbp)
movabsq $0, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
movq -640(%rbp), %rsi
movq -656(%rbp), %rdx
call evn_binary@PLT
movq %rax, -672(%rbp)
movq -608(%rbp), %rdi
movq -632(%rbp), %rsi
movq -672(%rbp), %rdx
call f40@PLT
movq %rax, -680(%rbp)
movq -80(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_store@PLT
movq %rax, -688(%rbp)
movabsq $36, %rax
movq %rax, -696(%rbp)
movabsq $2, %rax
movq %rax, -704(%rbp)
movq -696(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_object@PLT
movq %rax, -712(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movabsq $13, %rax
movq %rax, -728(%rbp)
movq -720(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_member@PLT
movq %rax, -736(%rbp)
movabsq $1, %rax
movq %rax, -744(%rbp)
movq -712(%rbp), %rdi
movq -744(%rbp), %rsi
movq -736(%rbp), %rdx
call evn_init@PLT
movq %rax, -752(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movabsq $0, %rax
movq %rax, -768(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_member@PLT
movq %rax, -776(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $9, %rax
movq %rax, -792(%rbp)
movq -784(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_member@PLT
movq %rax, -800(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movabsq $0, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
movq -808(%rbp), %rsi
movq -816(%rbp), %rdx
call evn_binary@PLT
movq %rax, -832(%rbp)
movq -776(%rbp), %rdi
movq -800(%rbp), %rsi
movq -832(%rbp), %rdx
call f40@PLT
movq %rax, -840(%rbp)
movabsq $0, %rax
movq %rax, -848(%rbp)
movq -712(%rbp), %rdi
movq -848(%rbp), %rsi
movq -840(%rbp), %rdx
call evn_init@PLT
movq %rax, -856(%rbp)
movq -8(%rbp), %rdi
movq -712(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -864(%rbp)
movq -864(%rbp), %rax
leave
ret
.Lf76_b9:
jmp .Lf76_b10
.Lf76_b8:
leaq .Ldata_38(%rip), %rax
movq %rax, -560(%rbp)
movabsq $36, %rax
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_text@PLT
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
call f33@PLT
movq %rax, -584(%rbp)
jmp .Lf76_b10
.Lf76_b7:
movq -504(%rbp), %rdi
call evn_truth@PLT
movq %rax, -552(%rbp)
cmpq $0, -552(%rbp)
je .Lf76_b9
jmp .Lf76_b8
.Lf76_b6:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $10, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -520(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movq -544(%rbp), %rax
movq %rax, -504(%rbp)
jmp .Lf76_b7
.Lf76_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $1, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_int@PLT
movq %rax, -296(%rbp)
movabsq $1, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
movq -280(%rbp), %rsi
movq -296(%rbp), %rdx
call evn_binary@PLT
movq %rax, -312(%rbp)
movabsq $3, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $2, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
movq -312(%rbp), %rsi
movq -328(%rbp), %rdx
call evn_binary@PLT
movq %rax, -344(%rbp)
movq -64(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $1, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_member@PLT
movq %rax, -376(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $9, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movabsq $2, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
call evn_int@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
movq -408(%rbp), %rsi
movq -424(%rbp), %rdx
call evn_binary@PLT
movq %rax, -440(%rbp)
movq -376(%rbp), %rdi
movq -400(%rbp), %rsi
movq -440(%rbp), %rdx
call f40@PLT
movq %rax, -448(%rbp)
movq -72(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -456(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $0, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
call evn_int@PLT
movq %rax, -480(%rbp)
movabsq $7, %rax
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
movq -464(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -496(%rbp)
movq -496(%rbp), %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
call evn_truth@PLT
movq %rax, -512(%rbp)
cmpq $0, -512(%rbp)
je .Lf76_b6
jmp .Lf76_b7
.Lf76_b4:
jmp .Lf76_b5
.Lf76_b3:
leaq .Ldata_39(%rip), %rax
movq %rax, -248(%rbp)
movabsq $16, %rax
movq %rax, -256(%rbp)
movq -248(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_text@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call f33@PLT
movq %rax, -272(%rbp)
jmp .Lf76_b5
.Lf76_b2:
movq -128(%rbp), %rdi
call evn_truth@PLT
movq %rax, -240(%rbp)
cmpq $0, -240(%rbp)
je .Lf76_b4
jmp .Lf76_b3
.Lf76_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $1, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movabsq $4, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movabsq $3, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $3, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movabsq $9, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
movq -144(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rax
movq %rax, -128(%rbp)
jmp .Lf76_b2
.Lf76_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -888(%rbp), %rsi
leaq .Lroots_f76(%rip), %rdx
movq $111, %rcx
call evn_bind_roots@PLT
movq -872(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -880(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -888(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $1, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movabsq $7, %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -136(%rbp)
cmpq $0, -136(%rbp)
je .Lf76_b1
jmp .Lf76_b2
.size f76, .-f76
.text
.p2align 4
.type f77, @function
f77:
pushq %rbp
movq %rsp, %rbp
subq $832, %rsp
movq %rdi, -808(%rbp)
movq %rsi, -816(%rbp)
movq %rdx, -824(%rbp)
movq %rcx, -832(%rbp)
leaq -800(%rbp), %rdi
movq $100, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf77_b0
.Lf77_b9:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -648(%rbp)
movabsq $1, %rax
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_int@PLT
movq %rax, -664(%rbp)
movabsq $0, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
movq -648(%rbp), %rsi
movq -664(%rbp), %rdx
call evn_binary@PLT
movq %rax, -680(%rbp)
movq -96(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_store@PLT
movq %rax, -688(%rbp)
jmp .Lf77_b4
.Lf77_b8:
jmp .Lf77_b9
.Lf77_b7:
leaq .Ldata_40(%rip), %rax
movq %rax, -616(%rbp)
movabsq $24, %rax
movq %rax, -624(%rbp)
movq -616(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_text@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call f33@PLT
movq %rax, -640(%rbp)
jmp .Lf77_b9
.Lf77_b6:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movabsq $8, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
call evn_int@PLT
movq %rax, -720(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $0, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
call evn_int@PLT
movq %rax, -752(%rbp)
movabsq $0, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_int@PLT
movq %rax, -768(%rbp)
movq -696(%rbp), %rdi
movq -704(%rbp), %rsi
movq -720(%rbp), %rdx
movq -728(%rbp), %rcx
movq -736(%rbp), %r8
movq -752(%rbp), %r9
subq $8, %rsp
pushq -768(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -776(%rbp)
movq -120(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_store@PLT
movq %rax, -784(%rbp)
call evn_void@PLT
movq %rax, -792(%rbp)
movq -8(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -800(%rbp)
movq -800(%rbp), %rax
leave
ret
.Lf77_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
movq -400(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_index@PLT
movq %rax, -424(%rbp)
movq -392(%rbp), %rdi
movq -424(%rbp), %rsi
call f93@PLT
movq %rax, -432(%rbp)
movq -104(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_store@PLT
movq %rax, -440(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movabsq $12, %rax
movq %rax, -456(%rbp)
movq -448(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member@PLT
movq %rax, -464(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movabsq $9, %rax
movq %rax, -480(%rbp)
movq -472(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_member@PLT
movq %rax, -488(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $11, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_member@PLT
movq %rax, -512(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -464(%rbp), %rdi
movq -488(%rbp), %rsi
movq -512(%rbp), %rdx
movq -520(%rbp), %rcx
call f62@PLT
movq %rax, -528(%rbp)
movq -112(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_store@PLT
movq %rax, -536(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $0, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member@PLT
movq %rax, -560(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -568(%rbp)
movabsq $0, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_member@PLT
movq %rax, -584(%rbp)
movabsq $6, %rax
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -560(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_binary@PLT
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
call evn_truth@PLT
movq %rax, -608(%rbp)
cmpq $0, -608(%rbp)
je .Lf77_b8
jmp .Lf77_b7
.Lf77_b4:
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $7, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
movq -352(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_binary@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_truth@PLT
movq %rax, -384(%rbp)
cmpq $0, -384(%rbp)
je .Lf77_b6
jmp .Lf77_b5
.Lf77_b3:
movabsq $0, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call evn_int@PLT
movq %rax, -336(%rbp)
movq -96(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_store@PLT
movq %rax, -344(%rbp)
jmp .Lf77_b4
.Lf77_b2:
jmp .Lf77_b3
.Lf77_b1:
leaq .Ldata_41(%rip), %rax
movq %rax, -296(%rbp)
movabsq $25, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_text@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call f33@PLT
movq %rax, -320(%rbp)
jmp .Lf77_b3
.Lf77_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -832(%rbp), %rsi
leaq .Lroots_f77(%rip), %rdx
movq $104, %rcx
call evn_bind_roots@PLT
movq -808(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -816(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -824(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -832(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
call evn_void@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call f90@PLT
movq %rax, -144(%rbp)
movq -80(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_store@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $12, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $9, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $11, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movq -176(%rbp), %rdi
movq -200(%rbp), %rsi
movq -224(%rbp), %rdx
call f64@PLT
movq %rax, -232(%rbp)
movq -88(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -240(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_count@PLT
movq %rax, -256(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $6, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
movq -256(%rbp), %rsi
movq -264(%rbp), %rdx
call evn_binary@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_truth@PLT
movq %rax, -288(%rbp)
cmpq $0, -288(%rbp)
je .Lf77_b2
jmp .Lf77_b1
.size f77, .-f77
.text
.p2align 4
.type f78, @function
f78:
pushq %rbp
movq %rsp, %rbp
subq $720, %rsp
movq %rdi, -664(%rbp)
movq %rsi, -672(%rbp)
movq %rdx, -680(%rbp)
movq %rcx, -688(%rbp)
movq %r8, -696(%rbp)
movq %r9, -704(%rbp)
movq 16(%rbp), %rax
movq %rax, -712(%rbp)
movq 24(%rbp), %rax
movq %rax, -720(%rbp)
leaq -656(%rbp), %rdi
movq $82, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf78_b0
.Lf78_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
movq -400(%rbp), %rdx
call f89@PLT
movq %rax, -408(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movq -416(%rbp), %rdi
movq -424(%rbp), %rsi
movq -432(%rbp), %rdx
call f89@PLT
movq %rax, -440(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movq -448(%rbp), %rdi
movq -456(%rbp), %rsi
movq -464(%rbp), %rdx
call f88@PLT
movq %rax, -472(%rbp)
movq -160(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_store@PLT
movq %rax, -480(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
movq -504(%rbp), %rdx
call f88@PLT
movq %rax, -512(%rbp)
movq -168(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_store@PLT
movq %rax, -520(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -536(%rbp)
movabsq $7, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call evn_int@PLT
movq %rax, -552(%rbp)
movabsq $38, %rax
movq %rax, -560(%rbp)
movabsq $1, %rax
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_object@PLT
movq %rax, -576(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -584(%rbp)
movabsq $0, %rax
movq %rax, -592(%rbp)
movq -576(%rbp), %rdi
movq -592(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_init@PLT
movq %rax, -600(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movq -168(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
movq -552(%rbp), %rdx
movq -576(%rbp), %rcx
movq -608(%rbp), %r8
movq -616(%rbp), %r9
subq $8, %rsp
pushq -624(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -632(%rbp)
movq -176(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_store@PLT
movq %rax, -640(%rbp)
call evn_void@PLT
movq %rax, -648(%rbp)
movq -8(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rax
leave
ret
.Lf78_b2:
jmp .Lf78_b3
.Lf78_b1:
leaq .Ldata_42(%rip), %rax
movq %rax, -352(%rbp)
movabsq $24, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_text@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call f33@PLT
movq %rax, -376(%rbp)
jmp .Lf78_b3
.Lf78_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -720(%rbp), %rsi
leaq .Lroots_f78(%rip), %rdx
movq $90, %rcx
call evn_bind_roots@PLT
movq -664(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -672(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -680(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -688(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -696(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -704(%rbp), %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -712(%rbp), %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -720(%rbp), %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
call evn_void@PLT
movq %rax, -144(%rbp)
call evn_void@PLT
movq %rax, -152(%rbp)
call evn_void@PLT
movq %rax, -160(%rbp)
call evn_void@PLT
movq %rax, -168(%rbp)
call evn_void@PLT
movq %rax, -176(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call f90@PLT
movq %rax, -200(%rbp)
movq -144(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $12, %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_member@PLT
movq %rax, -232(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call f54@PLT
movq %rax, -248(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call f93@PLT
movq %rax, -272(%rbp)
movq -152(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_store@PLT
movq %rax, -280(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $0, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_member@PLT
movq %rax, -304(%rbp)
movabsq $1, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $6, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf78_b2
jmp .Lf78_b1
.size f78, .-f78
.text
.p2align 4
.type f79, @function
f79:
pushq %rbp
movq %rsp, %rbp
subq $416, %rsp
movq %rdi, -384(%rbp)
movq %rsi, -392(%rbp)
movq %rdx, -400(%rbp)
movq %rcx, -408(%rbp)
movq %r8, -416(%rbp)
leaq -376(%rbp), %rdi
movq $47, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf79_b0
.Lf79_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -416(%rbp), %rsi
leaq .Lroots_f79(%rip), %rdx
movq $52, %rcx
call evn_bind_roots@PLT
movq -384(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -392(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -400(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -408(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -416(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call f90@PLT
movq %rax, -136(%rbp)
movq -96(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_store@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $12, %rax
movq %rax, -160(%rbp)
movq -152(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_member@PLT
movq %rax, -168(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call f54@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
movq -208(%rbp), %rdx
call f89@PLT
movq %rax, -216(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
movq -240(%rbp), %rdx
call f88@PLT
movq %rax, -248(%rbp)
movq -104(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_store@PLT
movq %rax, -256(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $6, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movabsq $38, %rax
movq %rax, -296(%rbp)
movabsq $0, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_object@PLT
movq %rax, -312(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -320(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $0, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
movq -288(%rbp), %rdx
movq -312(%rbp), %rcx
movq -320(%rbp), %r8
movq -328(%rbp), %r9
subq $8, %rsp
pushq -344(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -352(%rbp)
movq -112(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_store@PLT
movq %rax, -360(%rbp)
call evn_void@PLT
movq %rax, -368(%rbp)
movq -8(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
leave
ret
.size f79, .-f79
.text
.p2align 4
.type f80, @function
f80:
pushq %rbp
movq %rsp, %rbp
subq $288, %rsp
movq %rdi, -248(%rbp)
movq %rsi, -256(%rbp)
movq %rdx, -264(%rbp)
movq %rcx, -272(%rbp)
movq %r8, -280(%rbp)
leaq -240(%rbp), %rdi
movq $30, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf80_b0
.Lf80_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -280(%rbp), %rsi
leaq .Lroots_f80(%rip), %rdx
movq $35, %rcx
call evn_bind_roots@PLT
movq -248(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -256(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -264(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -272(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -280(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $5, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $38, %rax
movq %rax, -136(%rbp)
movabsq $1, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_object@PLT
movq %rax, -152(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -152(%rbp), %rdi
movq -168(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_init@PLT
movq %rax, -176(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movabsq $0, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
movq -152(%rbp), %rcx
movq -184(%rbp), %r8
movq -192(%rbp), %r9
subq $8, %rsp
pushq -208(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -216(%rbp)
movq -96(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_store@PLT
movq %rax, -224(%rbp)
call evn_void@PLT
movq %rax, -232(%rbp)
movq -8(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rax
leave
ret
.size f80, .-f80
.text
.p2align 4
.type f81, @function
f81:
pushq %rbp
movq %rsp, %rbp
subq $272, %rsp
movq %rdi, -248(%rbp)
movq %rsi, -256(%rbp)
movq %rdx, -264(%rbp)
movq %rcx, -272(%rbp)
leaq -240(%rbp), %rdi
movq $30, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf81_b0
.Lf81_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -272(%rbp), %rsi
leaq .Lroots_f81(%rip), %rdx
movq $34, %rcx
call evn_bind_roots@PLT
movq -248(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -256(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -264(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -272(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $4, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $38, %rax
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_object@PLT
movq %rax, -136(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $0, %rax
movq %rax, -152(%rbp)
movq -136(%rbp), %rdi
movq -152(%rbp), %rsi
movq -144(%rbp), %rdx
call evn_init@PLT
movq %rax, -160(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $0, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
movq -136(%rbp), %rcx
movq -168(%rbp), %r8
movq -184(%rbp), %r9
subq $8, %rsp
pushq -200(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -208(%rbp)
movabsq $0, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movq -80(%rbp), %rdi
movq -208(%rbp), %rsi
movq -224(%rbp), %rdx
call f86@PLT
movq %rax, -232(%rbp)
movq -8(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rax
leave
ret
.size f81, .-f81
.text
.p2align 4
.type f82, @function
f82:
pushq %rbp
movq %rsp, %rbp
subq $448, %rsp
movq %rdi, -408(%rbp)
movq %rsi, -416(%rbp)
movq %rdx, -424(%rbp)
movq %rcx, -432(%rbp)
movq %r8, -440(%rbp)
leaq -400(%rbp), %rdi
movq $50, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf82_b0
.Lf82_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -440(%rbp), %rsi
leaq .Lroots_f82(%rip), %rdx
movq $55, %rcx
call evn_bind_roots@PLT
movq -408(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -416(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -424(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -432(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -440(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $3, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $38, %rax
movq %rax, -136(%rbp)
movabsq $2, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_object@PLT
movq %rax, -152(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -152(%rbp), %rdi
movq -168(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_init@PLT
movq %rax, -176(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $1, %rax
movq %rax, -192(%rbp)
movq -152(%rbp), %rdi
movq -192(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_init@PLT
movq %rax, -200(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $0, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
movq -152(%rbp), %rcx
movq -208(%rbp), %r8
movq -224(%rbp), %r9
subq $8, %rsp
pushq -240(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -248(%rbp)
movq -96(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_store@PLT
movq %rax, -256(%rbp)
movabsq $39, %rax
movq %rax, -264(%rbp)
movabsq $2, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_object@PLT
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $0, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call evn_int@PLT
movq %rax, -312(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
movq -312(%rbp), %rdx
call f86@PLT
movq %rax, -320(%rbp)
movabsq $1, %rax
movq %rax, -328(%rbp)
movq -280(%rbp), %rdi
movq -328(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_init@PLT
movq %rax, -336(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $1, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
movq -368(%rbp), %rdx
call f86@PLT
movq %rax, -376(%rbp)
movabsq $0, %rax
movq %rax, -384(%rbp)
movq -280(%rbp), %rdi
movq -384(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_init@PLT
movq %rax, -392(%rbp)
movq -8(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rax
leave
ret
.size f82, .-f82
.text
.p2align 4
.type f83, @function
f83:
pushq %rbp
movq %rsp, %rbp
subq $240, %rsp
movq %rdi, -216(%rbp)
movq %rsi, -224(%rbp)
movq %rdx, -232(%rbp)
movq %rcx, -240(%rbp)
leaq -208(%rbp), %rdi
movq $26, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf83_b0
.Lf83_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -240(%rbp), %rsi
leaq .Lroots_f83(%rip), %rdx
movq $30, %rcx
call evn_bind_roots@PLT
movq -216(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -224(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -232(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -240(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $9, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $38, %rax
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_object@PLT
movq %rax, -136(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
movq -136(%rbp), %rcx
movq -144(%rbp), %r8
movq -152(%rbp), %r9
subq $8, %rsp
pushq -168(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -176(%rbp)
movabsq $0, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -80(%rbp), %rdi
movq -176(%rbp), %rsi
movq -192(%rbp), %rdx
call f86@PLT
movq %rax, -200(%rbp)
movq -8(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
leave
ret
.size f83, .-f83
.text
.p2align 4
.type f84, @function
f84:
pushq %rbp
movq %rsp, %rbp
subq $320, %rsp
movq %rdi, -288(%rbp)
movq %rsi, -296(%rbp)
movq %rdx, -304(%rbp)
movq %rcx, -312(%rbp)
leaq -280(%rbp), %rdi
movq $35, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf84_b0
.Lf84_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $2, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $38, %rax
movq %rax, -192(%rbp)
movabsq $0, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_object@PLT
movq %rax, -208(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
movq -208(%rbp), %rcx
movq -216(%rbp), %r8
movq -224(%rbp), %r9
subq $8, %rsp
pushq -240(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movq -152(%rbp), %rdi
movq -248(%rbp), %rsi
movq -264(%rbp), %rdx
call f86@PLT
movq %rax, -272(%rbp)
movq -8(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rax
leave
ret
.Lf84_b2:
jmp .Lf84_b3
.Lf84_b1:
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movq -80(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_store@PLT
movq %rax, -144(%rbp)
jmp .Lf84_b3
.Lf84_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -312(%rbp), %rsi
leaq .Lroots_f84(%rip), %rdx
movq $39, %rcx
call evn_bind_roots@PLT
movq -288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -296(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -304(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -312(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -80(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_truth@PLT
movq %rax, -120(%rbp)
cmpq $0, -120(%rbp)
je .Lf84_b2
jmp .Lf84_b1
.size f84, .-f84
.text
.p2align 4
.type f85, @function
f85:
pushq %rbp
movq %rsp, %rbp
subq $240, %rsp
movq %rdi, -216(%rbp)
movq %rsi, -224(%rbp)
movq %rdx, -232(%rbp)
movq %rcx, -240(%rbp)
leaq -208(%rbp), %rdi
movq $26, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf85_b0
.Lf85_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -240(%rbp), %rsi
leaq .Lroots_f85(%rip), %rdx
movq $30, %rcx
call evn_bind_roots@PLT
movq -216(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -224(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -232(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -240(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $38, %rax
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_object@PLT
movq %rax, -136(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $0, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
movq -136(%rbp), %rcx
movq -144(%rbp), %r8
movq -152(%rbp), %r9
subq $8, %rsp
pushq -168(%rbp)
call f87@PLT
addq $16, %rsp
movq %rax, -176(%rbp)
movabsq $0, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -80(%rbp), %rdi
movq -176(%rbp), %rsi
movq -192(%rbp), %rdx
call f86@PLT
movq %rax, -200(%rbp)
movq -8(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
leave
ret
.size f85, .-f85
.text
.p2align 4
.type f86, @function
f86:
pushq %rbp
movq %rsp, %rbp
subq $592, %rsp
movq %rdi, -576(%rbp)
movq %rsi, -584(%rbp)
movq %rdx, -592(%rbp)
leaq -568(%rbp), %rdi
movq $71, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf86_b0
.Lf86_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $3, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $9, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $4, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movabsq $0, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -400(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_binary@PLT
movq %rax, -432(%rbp)
movq -368(%rbp), %rdi
movq -392(%rbp), %rsi
movq -432(%rbp), %rdx
call f40@PLT
movq %rax, -440(%rbp)
movq -80(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_store@PLT
movq %rax, -448(%rbp)
movabsq $36, %rax
movq %rax, -456(%rbp)
movabsq $2, %rax
movq %rax, -464(%rbp)
movq -456(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_object@PLT
movq %rax, -472(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movabsq $13, %rax
movq %rax, -488(%rbp)
movq -480(%rbp), %rdi
movq -488(%rbp), %rsi
call evn_member@PLT
movq %rax, -496(%rbp)
movabsq $1, %rax
movq %rax, -504(%rbp)
movq -472(%rbp), %rdi
movq -504(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_init@PLT
movq %rax, -512(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $0, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -520(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movabsq $0, %rax
movq %rax, -552(%rbp)
movq -472(%rbp), %rdi
movq -552(%rbp), %rsi
movq -544(%rbp), %rdx
call evn_init@PLT
movq %rax, -560(%rbp)
movq -8(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -568(%rbp)
movq -568(%rbp), %rax
leave
ret
.Lf86_b4:
jmp .Lf86_b5
.Lf86_b3:
leaq .Ldata_43(%rip), %rax
movq %rax, -320(%rbp)
movabsq $41, %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_text@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call f33@PLT
movq %rax, -344(%rbp)
jmp .Lf86_b5
.Lf86_b2:
movq -264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -312(%rbp)
cmpq $0, -312(%rbp)
je .Lf86_b4
jmp .Lf86_b3
.Lf86_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $10, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -280(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -264(%rbp)
jmp .Lf86_b2
.Lf86_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -592(%rbp), %rsi
leaq .Lroots_f86(%rip), %rdx
movq $74, %rcx
call evn_bind_roots@PLT
movq -576(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -584(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -592(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call f95@PLT
movq %rax, -104(%rbp)
movq -64(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $3, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $9, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $5, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -136(%rbp), %rdi
movq -160(%rbp), %rsi
movq -200(%rbp), %rdx
call f40@PLT
movq %rax, -208(%rbp)
movq -72(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_store@PLT
movq %rax, -216(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movabsq $7, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -224(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf86_b1
jmp .Lf86_b2
.size f86, .-f86
.text
.p2align 4
.type f87, @function
f87:
pushq %rbp
movq %rsp, %rbp
subq $4336, %rsp
movq %rdi, -4288(%rbp)
movq %rsi, -4296(%rbp)
movq %rdx, -4304(%rbp)
movq %rcx, -4312(%rbp)
movq %r8, -4320(%rbp)
movq %r9, -4328(%rbp)
movq 16(%rbp), %rax
movq %rax, -4336(%rbp)
leaq -4280(%rbp), %rdi
movq $535, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf87_b0
.Lf87_b51:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4072(%rbp)
movabsq $5, %rax
movq %rax, -4080(%rbp)
movq -4072(%rbp), %rdi
movq -4080(%rbp), %rsi
call evn_member@PLT
movq %rax, -4088(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4096(%rbp)
movabsq $9, %rax
movq %rax, -4104(%rbp)
movq -4096(%rbp), %rdi
movq -4104(%rbp), %rsi
call evn_member@PLT
movq %rax, -4112(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4120(%rbp)
movabsq $3, %rax
movq %rax, -4128(%rbp)
movq -4128(%rbp), %rdi
call evn_int@PLT
movq %rax, -4136(%rbp)
movabsq $0, %rax
movq %rax, -4144(%rbp)
movq -4144(%rbp), %rdi
movq -4120(%rbp), %rsi
movq -4136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -4152(%rbp)
movq -184(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4160(%rbp)
movabsq $0, %rax
movq %rax, -4168(%rbp)
movq -4160(%rbp), %rdi
movq -4168(%rbp), %rsi
call evn_member@PLT
movq %rax, -4176(%rbp)
movq -4088(%rbp), %rdi
movq -4112(%rbp), %rsi
movq -4152(%rbp), %rdx
movq -4176(%rbp), %rcx
call f39@PLT
movq %rax, -4184(%rbp)
jmp .Lf87_b48
.Lf87_b50:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3888(%rbp)
movabsq $3, %rax
movq %rax, -3896(%rbp)
movq -3888(%rbp), %rdi
movq -3896(%rbp), %rsi
call evn_member@PLT
movq %rax, -3904(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3912(%rbp)
movabsq $9, %rax
movq %rax, -3920(%rbp)
movq -3912(%rbp), %rdi
movq -3920(%rbp), %rsi
call evn_member@PLT
movq %rax, -3928(%rbp)
movq -216(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3936(%rbp)
movabsq $1, %rax
movq %rax, -3944(%rbp)
movq -3944(%rbp), %rdi
call evn_int@PLT
movq %rax, -3952(%rbp)
movabsq $1, %rax
movq %rax, -3960(%rbp)
movq -3960(%rbp), %rdi
movq -3936(%rbp), %rsi
movq -3952(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3968(%rbp)
movabsq $10, %rax
movq %rax, -3976(%rbp)
movq -3976(%rbp), %rdi
call evn_int@PLT
movq %rax, -3984(%rbp)
movabsq $2, %rax
movq %rax, -3992(%rbp)
movq -3992(%rbp), %rdi
movq -3968(%rbp), %rsi
movq -3984(%rbp), %rdx
call evn_binary@PLT
movq %rax, -4000(%rbp)
movabsq $9, %rax
movq %rax, -4008(%rbp)
movq -4008(%rbp), %rdi
call evn_int@PLT
movq %rax, -4016(%rbp)
movabsq $0, %rax
movq %rax, -4024(%rbp)
movq -4024(%rbp), %rdi
movq -4000(%rbp), %rsi
movq -4016(%rbp), %rdx
call evn_binary@PLT
movq %rax, -4032(%rbp)
movq -184(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4040(%rbp)
movabsq $0, %rax
movq %rax, -4048(%rbp)
movq -4040(%rbp), %rdi
movq -4048(%rbp), %rsi
call evn_member@PLT
movq %rax, -4056(%rbp)
movq -3904(%rbp), %rdi
movq -3928(%rbp), %rsi
movq -4032(%rbp), %rdx
movq -4056(%rbp), %rcx
call f39@PLT
movq %rax, -4064(%rbp)
jmp .Lf87_b51
.Lf87_b49:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3768(%rbp)
movabsq $5, %rax
movq %rax, -3776(%rbp)
movq -3768(%rbp), %rdi
movq -3776(%rbp), %rsi
call evn_member@PLT
movq %rax, -3784(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3792(%rbp)
movabsq $9, %rax
movq %rax, -3800(%rbp)
movq -3792(%rbp), %rdi
movq -3800(%rbp), %rsi
call evn_member@PLT
movq %rax, -3808(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3816(%rbp)
movabsq $2, %rax
movq %rax, -3824(%rbp)
movq -3824(%rbp), %rdi
call evn_int@PLT
movq %rax, -3832(%rbp)
movabsq $0, %rax
movq %rax, -3840(%rbp)
movq -3840(%rbp), %rdi
movq -3816(%rbp), %rsi
movq -3832(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3848(%rbp)
movq -184(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3856(%rbp)
movabsq $0, %rax
movq %rax, -3864(%rbp)
movq -3856(%rbp), %rdi
movq -3864(%rbp), %rsi
call evn_member@PLT
movq %rax, -3872(%rbp)
movq -3784(%rbp), %rdi
movq -3808(%rbp), %rsi
movq -3848(%rbp), %rdx
movq -3872(%rbp), %rcx
call f39@PLT
movq %rax, -3880(%rbp)
jmp .Lf87_b51
.Lf87_b48:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4192(%rbp)
movabsq $7, %rax
movq %rax, -4200(%rbp)
movq -4192(%rbp), %rdi
movq -4200(%rbp), %rsi
call evn_member@PLT
movq %rax, -4208(%rbp)
movabsq $1, %rax
movq %rax, -4216(%rbp)
movq -4216(%rbp), %rdi
call evn_int@PLT
movq %rax, -4224(%rbp)
movabsq $0, %rax
movq %rax, -4232(%rbp)
movq -4232(%rbp), %rdi
movq -4208(%rbp), %rsi
movq -4224(%rbp), %rdx
call evn_binary@PLT
movq %rax, -4240(%rbp)
movabsq $7, %rax
movq %rax, -4248(%rbp)
movq -24(%rbp), %rdi
movq -4248(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -4256(%rbp)
movq -4256(%rbp), %rdi
movq -4240(%rbp), %rsi
call evn_store@PLT
movq %rax, -4264(%rbp)
movq -184(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4272(%rbp)
movq -8(%rbp), %rdi
movq -4272(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -4280(%rbp)
movq -4280(%rbp), %rax
leave
ret
.Lf87_b47:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3616(%rbp)
movabsq $5, %rax
movq %rax, -3624(%rbp)
movq -3616(%rbp), %rdi
movq -3624(%rbp), %rsi
call evn_member@PLT
movq %rax, -3632(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3640(%rbp)
movabsq $9, %rax
movq %rax, -3648(%rbp)
movq -3640(%rbp), %rdi
movq -3648(%rbp), %rsi
call evn_member@PLT
movq %rax, -3656(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3664(%rbp)
movabsq $3, %rax
movq %rax, -3672(%rbp)
movq -3672(%rbp), %rdi
call evn_int@PLT
movq %rax, -3680(%rbp)
movabsq $0, %rax
movq %rax, -3688(%rbp)
movq -3688(%rbp), %rdi
movq -3664(%rbp), %rsi
movq -3680(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3696(%rbp)
movq -3632(%rbp), %rdi
movq -3656(%rbp), %rsi
movq -3696(%rbp), %rdx
call f40@PLT
movq %rax, -3704(%rbp)
movq -216(%rbp), %rdi
movq -3704(%rbp), %rsi
call evn_store@PLT
movq %rax, -3712(%rbp)
movq -216(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3720(%rbp)
movabsq $0, %rax
movq %rax, -3728(%rbp)
movq -3728(%rbp), %rdi
call evn_int@PLT
movq %rax, -3736(%rbp)
movabsq $5, %rax
movq %rax, -3744(%rbp)
movq -3744(%rbp), %rdi
movq -3720(%rbp), %rsi
movq -3736(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3752(%rbp)
movq -3752(%rbp), %rdi
call evn_truth@PLT
movq %rax, -3760(%rbp)
cmpq $0, -3760(%rbp)
je .Lf87_b50
jmp .Lf87_b49
.Lf87_b46:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3496(%rbp)
movabsq $5, %rax
movq %rax, -3504(%rbp)
movq -3496(%rbp), %rdi
movq -3504(%rbp), %rsi
call evn_member@PLT
movq %rax, -3512(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3520(%rbp)
movabsq $9, %rax
movq %rax, -3528(%rbp)
movq -3520(%rbp), %rdi
movq -3528(%rbp), %rsi
call evn_member@PLT
movq %rax, -3536(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3544(%rbp)
movabsq $4, %rax
movq %rax, -3552(%rbp)
movq -3552(%rbp), %rdi
call evn_int@PLT
movq %rax, -3560(%rbp)
movabsq $0, %rax
movq %rax, -3568(%rbp)
movq -3568(%rbp), %rdi
movq -3544(%rbp), %rsi
movq -3560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3576(%rbp)
movq -184(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3584(%rbp)
movabsq $0, %rax
movq %rax, -3592(%rbp)
movq -3584(%rbp), %rdi
movq -3592(%rbp), %rsi
call evn_member@PLT
movq %rax, -3600(%rbp)
movq -3512(%rbp), %rdi
movq -3536(%rbp), %rsi
movq -3576(%rbp), %rdx
movq -3600(%rbp), %rcx
call f39@PLT
movq %rax, -3608(%rbp)
jmp .Lf87_b48
.Lf87_b45:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2696(%rbp)
movabsq $3, %rax
movq %rax, -2704(%rbp)
movq -2696(%rbp), %rdi
movq -2704(%rbp), %rsi
call evn_member@PLT
movq %rax, -2712(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2720(%rbp)
movabsq $9, %rax
movq %rax, -2728(%rbp)
movq -2720(%rbp), %rdi
movq -2728(%rbp), %rsi
call evn_member@PLT
movq %rax, -2736(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2744(%rbp)
movq -2712(%rbp), %rdi
movq -2736(%rbp), %rsi
movq -2744(%rbp), %rdx
call f38@PLT
movq %rax, -2752(%rbp)
movq -208(%rbp), %rdi
movq -2752(%rbp), %rsi
call evn_store@PLT
movq %rax, -2760(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2768(%rbp)
movabsq $3, %rax
movq %rax, -2776(%rbp)
movq -2768(%rbp), %rdi
movq -2776(%rbp), %rsi
call evn_member@PLT
movq %rax, -2784(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2792(%rbp)
movabsq $9, %rax
movq %rax, -2800(%rbp)
movq -2792(%rbp), %rdi
movq -2800(%rbp), %rsi
call evn_member@PLT
movq %rax, -2808(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2816(%rbp)
movabsq $0, %rax
movq %rax, -2824(%rbp)
movq -2816(%rbp), %rdi
movq -2824(%rbp), %rsi
call evn_member@PLT
movq %rax, -2832(%rbp)
movq -2784(%rbp), %rdi
movq -2808(%rbp), %rsi
movq -2832(%rbp), %rdx
call f38@PLT
movq %rax, -2840(%rbp)
movq -208(%rbp), %rdi
movq -2840(%rbp), %rsi
call evn_store@PLT
movq %rax, -2848(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2856(%rbp)
movabsq $3, %rax
movq %rax, -2864(%rbp)
movq -2856(%rbp), %rdi
movq -2864(%rbp), %rsi
call evn_member@PLT
movq %rax, -2872(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2880(%rbp)
movabsq $9, %rax
movq %rax, -2888(%rbp)
movq -2880(%rbp), %rdi
movq -2888(%rbp), %rsi
call evn_member@PLT
movq %rax, -2896(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2904(%rbp)
movq -2872(%rbp), %rdi
movq -2896(%rbp), %rsi
movq -2904(%rbp), %rdx
call f38@PLT
movq %rax, -2912(%rbp)
movq -208(%rbp), %rdi
movq -2912(%rbp), %rsi
call evn_store@PLT
movq %rax, -2920(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2928(%rbp)
movabsq $3, %rax
movq %rax, -2936(%rbp)
movq -2928(%rbp), %rdi
movq -2936(%rbp), %rsi
call evn_member@PLT
movq %rax, -2944(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2952(%rbp)
movabsq $9, %rax
movq %rax, -2960(%rbp)
movq -2952(%rbp), %rdi
movq -2960(%rbp), %rsi
call evn_member@PLT
movq %rax, -2968(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2976(%rbp)
movq -2976(%rbp), %rdi
call evn_count@PLT
movq %rax, -2984(%rbp)
movq -2944(%rbp), %rdi
movq -2968(%rbp), %rsi
movq -2984(%rbp), %rdx
call f38@PLT
movq %rax, -2992(%rbp)
movq -208(%rbp), %rdi
movq -2992(%rbp), %rsi
call evn_store@PLT
movq %rax, -3000(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3008(%rbp)
movabsq $3, %rax
movq %rax, -3016(%rbp)
movq -3008(%rbp), %rdi
movq -3016(%rbp), %rsi
call evn_member@PLT
movq %rax, -3024(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3032(%rbp)
movabsq $9, %rax
movq %rax, -3040(%rbp)
movq -3032(%rbp), %rdi
movq -3040(%rbp), %rsi
call evn_member@PLT
movq %rax, -3048(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3056(%rbp)
movq -3024(%rbp), %rdi
movq -3048(%rbp), %rsi
movq -3056(%rbp), %rdx
call f38@PLT
movq %rax, -3064(%rbp)
movq -208(%rbp), %rdi
movq -3064(%rbp), %rsi
call evn_store@PLT
movq %rax, -3072(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3080(%rbp)
movabsq $3, %rax
movq %rax, -3088(%rbp)
movq -3080(%rbp), %rdi
movq -3088(%rbp), %rsi
call evn_member@PLT
movq %rax, -3096(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3104(%rbp)
movabsq $9, %rax
movq %rax, -3112(%rbp)
movq -3104(%rbp), %rdi
movq -3112(%rbp), %rsi
call evn_member@PLT
movq %rax, -3120(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3128(%rbp)
movq -3128(%rbp), %rdi
call f2@PLT
movq %rax, -3136(%rbp)
movq -3096(%rbp), %rdi
movq -3120(%rbp), %rsi
movq -3136(%rbp), %rdx
call f38@PLT
movq %rax, -3144(%rbp)
movq -208(%rbp), %rdi
movq -3144(%rbp), %rsi
call evn_store@PLT
movq %rax, -3152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3160(%rbp)
movabsq $3, %rax
movq %rax, -3168(%rbp)
movq -3160(%rbp), %rdi
movq -3168(%rbp), %rsi
call evn_member@PLT
movq %rax, -3176(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3184(%rbp)
movabsq $9, %rax
movq %rax, -3192(%rbp)
movq -3184(%rbp), %rdi
movq -3192(%rbp), %rsi
call evn_member@PLT
movq %rax, -3200(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3208(%rbp)
movabsq $0, %rax
movq %rax, -3216(%rbp)
movq -3208(%rbp), %rdi
movq -3216(%rbp), %rsi
call evn_member@PLT
movq %rax, -3224(%rbp)
movq -3176(%rbp), %rdi
movq -3200(%rbp), %rsi
movq -3224(%rbp), %rdx
call f38@PLT
movq %rax, -3232(%rbp)
movq -208(%rbp), %rdi
movq -3232(%rbp), %rsi
call evn_store@PLT
movq %rax, -3240(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3248(%rbp)
movabsq $3, %rax
movq %rax, -3256(%rbp)
movq -3248(%rbp), %rdi
movq -3256(%rbp), %rsi
call evn_member@PLT
movq %rax, -3264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3272(%rbp)
movabsq $9, %rax
movq %rax, -3280(%rbp)
movq -3272(%rbp), %rdi
movq -3280(%rbp), %rsi
call evn_member@PLT
movq %rax, -3288(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3296(%rbp)
movq -3264(%rbp), %rdi
movq -3288(%rbp), %rsi
movq -3296(%rbp), %rdx
call f38@PLT
movq %rax, -3304(%rbp)
movq -208(%rbp), %rdi
movq -3304(%rbp), %rsi
call evn_store@PLT
movq %rax, -3312(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3320(%rbp)
movabsq $3, %rax
movq %rax, -3328(%rbp)
movq -3320(%rbp), %rdi
movq -3328(%rbp), %rsi
call evn_member@PLT
movq %rax, -3336(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3344(%rbp)
movabsq $9, %rax
movq %rax, -3352(%rbp)
movq -3344(%rbp), %rdi
movq -3352(%rbp), %rsi
call evn_member@PLT
movq %rax, -3360(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3368(%rbp)
movq -3336(%rbp), %rdi
movq -3360(%rbp), %rsi
movq -3368(%rbp), %rdx
call f38@PLT
movq %rax, -3376(%rbp)
movq -208(%rbp), %rdi
movq -3376(%rbp), %rsi
call evn_store@PLT
movq %rax, -3384(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3392(%rbp)
movabsq $3, %rax
movq %rax, -3400(%rbp)
movq -3392(%rbp), %rdi
movq -3400(%rbp), %rsi
call evn_member@PLT
movq %rax, -3408(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3416(%rbp)
movabsq $9, %rax
movq %rax, -3424(%rbp)
movq -3416(%rbp), %rdi
movq -3424(%rbp), %rsi
call evn_member@PLT
movq %rax, -3432(%rbp)
movabsq $0, %rax
movq %rax, -3440(%rbp)
movq -3440(%rbp), %rdi
call evn_int@PLT
movq %rax, -3448(%rbp)
movq -3408(%rbp), %rdi
movq -3432(%rbp), %rsi
movq -3448(%rbp), %rdx
call f38@PLT
movq %rax, -3456(%rbp)
movq -208(%rbp), %rdi
movq -3456(%rbp), %rsi
call evn_store@PLT
movq %rax, -3464(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3472(%rbp)
movq -3472(%rbp), %rdi
call f4@PLT
movq %rax, -3480(%rbp)
movq -3480(%rbp), %rdi
call evn_truth@PLT
movq %rax, -3488(%rbp)
cmpq $0, -3488(%rbp)
je .Lf87_b47
jmp .Lf87_b46
.Lf87_b44:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2320(%rbp)
movabsq $4, %rax
movq %rax, -2328(%rbp)
movq -2320(%rbp), %rdi
movq -2328(%rbp), %rsi
call evn_member@PLT
movq %rax, -2336(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2344(%rbp)
movabsq $9, %rax
movq %rax, -2352(%rbp)
movq -2344(%rbp), %rdi
movq -2352(%rbp), %rsi
call evn_member@PLT
movq %rax, -2360(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2368(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2376(%rbp)
movq -2368(%rbp), %rdi
movq -2376(%rbp), %rsi
call f0@PLT
movq %rax, -2384(%rbp)
movq -2336(%rbp), %rdi
movq -2360(%rbp), %rsi
movq -2384(%rbp), %rdx
call f38@PLT
movq %rax, -2392(%rbp)
movq -200(%rbp), %rdi
movq -2392(%rbp), %rsi
call evn_store@PLT
movq %rax, -2400(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2408(%rbp)
movabsq $4, %rax
movq %rax, -2416(%rbp)
movq -2408(%rbp), %rdi
movq -2416(%rbp), %rsi
call evn_member@PLT
movq %rax, -2424(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2432(%rbp)
movabsq $9, %rax
movq %rax, -2440(%rbp)
movq -2432(%rbp), %rdi
movq -2440(%rbp), %rsi
call evn_member@PLT
movq %rax, -2448(%rbp)
movabsq $1, %rax
movq %rax, -2456(%rbp)
movq -2456(%rbp), %rdi
call evn_int@PLT
movq %rax, -2464(%rbp)
movq -2424(%rbp), %rdi
movq -2448(%rbp), %rsi
movq -2464(%rbp), %rdx
call f38@PLT
movq %rax, -2472(%rbp)
movq -200(%rbp), %rdi
movq -2472(%rbp), %rsi
call evn_store@PLT
movq %rax, -2480(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2488(%rbp)
movabsq $4, %rax
movq %rax, -2496(%rbp)
movq -2488(%rbp), %rdi
movq -2496(%rbp), %rsi
call evn_member@PLT
movq %rax, -2504(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2512(%rbp)
movabsq $9, %rax
movq %rax, -2520(%rbp)
movq -2512(%rbp), %rdi
movq -2520(%rbp), %rsi
call evn_member@PLT
movq %rax, -2528(%rbp)
movq -184(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2536(%rbp)
movabsq $0, %rax
movq %rax, -2544(%rbp)
movq -2536(%rbp), %rdi
movq -2544(%rbp), %rsi
call evn_member@PLT
movq %rax, -2552(%rbp)
movq -2504(%rbp), %rdi
movq -2528(%rbp), %rsi
movq -2552(%rbp), %rdx
call f38@PLT
movq %rax, -2560(%rbp)
movq -200(%rbp), %rdi
movq -2560(%rbp), %rsi
call evn_store@PLT
movq %rax, -2568(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2576(%rbp)
movabsq $4, %rax
movq %rax, -2584(%rbp)
movq -2576(%rbp), %rdi
movq -2584(%rbp), %rsi
call evn_member@PLT
movq %rax, -2592(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2600(%rbp)
movabsq $9, %rax
movq %rax, -2608(%rbp)
movq -2600(%rbp), %rdi
movq -2608(%rbp), %rsi
call evn_member@PLT
movq %rax, -2616(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2624(%rbp)
movq -2592(%rbp), %rdi
movq -2616(%rbp), %rsi
movq -2624(%rbp), %rdx
call f38@PLT
movq %rax, -2632(%rbp)
movq -200(%rbp), %rdi
movq -2632(%rbp), %rsi
call evn_store@PLT
movq %rax, -2640(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2648(%rbp)
movabsq $1, %rax
movq %rax, -2656(%rbp)
movq -2656(%rbp), %rdi
call evn_int@PLT
movq %rax, -2664(%rbp)
movabsq $0, %rax
movq %rax, -2672(%rbp)
movq -2672(%rbp), %rdi
movq -2648(%rbp), %rsi
movq -2664(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2680(%rbp)
movq -144(%rbp), %rdi
movq -2680(%rbp), %rsi
call evn_store@PLT
movq %rax, -2688(%rbp)
jmp .Lf87_b43
.Lf87_b43:
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2272(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2280(%rbp)
movq -2280(%rbp), %rdi
call f2@PLT
movq %rax, -2288(%rbp)
movabsq $7, %rax
movq %rax, -2296(%rbp)
movq -2296(%rbp), %rdi
movq -2272(%rbp), %rsi
movq -2288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2304(%rbp)
movq -2304(%rbp), %rdi
call evn_truth@PLT
movq %rax, -2312(%rbp)
cmpq $0, -2312(%rbp)
je .Lf87_b45
jmp .Lf87_b44
.Lf87_b42:
movabsq $0, %rax
movq %rax, -2248(%rbp)
movq -2248(%rbp), %rdi
call evn_int@PLT
movq %rax, -2256(%rbp)
movq -144(%rbp), %rdi
movq -2256(%rbp), %rsi
call evn_store@PLT
movq %rax, -2264(%rbp)
jmp .Lf87_b43
.Lf87_b41:
jmp .Lf87_b42
.Lf87_b40:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2136(%rbp)
movabsq $4, %rax
movq %rax, -2144(%rbp)
movq -2136(%rbp), %rdi
movq -2144(%rbp), %rsi
call evn_member@PLT
movq %rax, -2152(%rbp)
movabsq $4, %rax
movq %rax, -2160(%rbp)
movq -2152(%rbp), %rdi
movq -2160(%rbp), %rsi
call evn_member@PLT
movq %rax, -2168(%rbp)
movabsq $4, %rax
movq %rax, -2176(%rbp)
movq -2176(%rbp), %rdi
call evn_int@PLT
movq %rax, -2184(%rbp)
movabsq $3, %rax
movq %rax, -2192(%rbp)
movq -2192(%rbp), %rdi
movq -2168(%rbp), %rsi
movq -2184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2200(%rbp)
movabsq $1, %rax
movq %rax, -2208(%rbp)
movq -2208(%rbp), %rdi
call evn_int@PLT
movq %rax, -2216(%rbp)
movabsq $0, %rax
movq %rax, -2224(%rbp)
movq -2224(%rbp), %rdi
movq -2200(%rbp), %rsi
movq -2216(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2232(%rbp)
movq -192(%rbp), %rdi
movq -2232(%rbp), %rsi
call evn_store@PLT
movq %rax, -2240(%rbp)
jmp .Lf87_b42
.Lf87_b39:
movabsq $40, %rax
movq %rax, -1864(%rbp)
movabsq $2, %rax
movq %rax, -1872(%rbp)
movq -1864(%rbp), %rdi
movq -1872(%rbp), %rsi
call evn_object@PLT
movq %rax, -1880(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1888(%rbp)
movabsq $13, %rax
movq %rax, -1896(%rbp)
movq -1888(%rbp), %rdi
movq -1896(%rbp), %rsi
call evn_member@PLT
movq %rax, -1904(%rbp)
movabsq $1, %rax
movq %rax, -1912(%rbp)
movq -1880(%rbp), %rdi
movq -1912(%rbp), %rsi
movq -1904(%rbp), %rdx
call evn_init@PLT
movq %rax, -1920(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1928(%rbp)
movabsq $3, %rax
movq %rax, -1936(%rbp)
movq -1928(%rbp), %rdi
movq -1936(%rbp), %rsi
call evn_member@PLT
movq %rax, -1944(%rbp)
movabsq $4, %rax
movq %rax, -1952(%rbp)
movq -1944(%rbp), %rdi
movq -1952(%rbp), %rsi
call evn_member@PLT
movq %rax, -1960(%rbp)
movabsq $10, %rax
movq %rax, -1968(%rbp)
movq -1968(%rbp), %rdi
call evn_int@PLT
movq %rax, -1976(%rbp)
movabsq $3, %rax
movq %rax, -1984(%rbp)
movq -1984(%rbp), %rdi
movq -1960(%rbp), %rsi
movq -1976(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1992(%rbp)
movabsq $1, %rax
movq %rax, -2000(%rbp)
movq -2000(%rbp), %rdi
call evn_int@PLT
movq %rax, -2008(%rbp)
movabsq $0, %rax
movq %rax, -2016(%rbp)
movq -2016(%rbp), %rdi
movq -1992(%rbp), %rsi
movq -2008(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2024(%rbp)
movabsq $0, %rax
movq %rax, -2032(%rbp)
movq -1880(%rbp), %rdi
movq -2032(%rbp), %rsi
movq -2024(%rbp), %rdx
call evn_init@PLT
movq %rax, -2040(%rbp)
movq -184(%rbp), %rdi
movq -1880(%rbp), %rsi
call evn_store@PLT
movq %rax, -2048(%rbp)
movabsq $0, %rax
movq %rax, -2056(%rbp)
movq -2056(%rbp), %rdi
call evn_int@PLT
movq %rax, -2064(%rbp)
movq -192(%rbp), %rdi
movq -2064(%rbp), %rsi
call evn_store@PLT
movq %rax, -2072(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2080(%rbp)
movq -2080(%rbp), %rdi
call f2@PLT
movq %rax, -2088(%rbp)
movabsq $0, %rax
movq %rax, -2096(%rbp)
movq -2096(%rbp), %rdi
call evn_int@PLT
movq %rax, -2104(%rbp)
movabsq $9, %rax
movq %rax, -2112(%rbp)
movq -2112(%rbp), %rdi
movq -2088(%rbp), %rsi
movq -2104(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2120(%rbp)
movq -2120(%rbp), %rdi
call evn_truth@PLT
movq %rax, -2128(%rbp)
cmpq $0, -2128(%rbp)
je .Lf87_b41
jmp .Lf87_b40
.Lf87_b38:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1688(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1696(%rbp)
movq -1696(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1704(%rbp)
movq -1688(%rbp), %rdi
movq -1704(%rbp), %rsi
call evn_index@PLT
movq %rax, -1712(%rbp)
movq -168(%rbp), %rdi
movq -1712(%rbp), %rsi
call evn_store@PLT
movq %rax, -1720(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1728(%rbp)
movabsq $2, %rax
movq %rax, -1736(%rbp)
movq -1728(%rbp), %rdi
movq -1736(%rbp), %rsi
call evn_member@PLT
movq %rax, -1744(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1752(%rbp)
movabsq $9, %rax
movq %rax, -1760(%rbp)
movq -1752(%rbp), %rdi
movq -1760(%rbp), %rsi
call evn_member@PLT
movq %rax, -1768(%rbp)
movq -168(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1776(%rbp)
movabsq $0, %rax
movq %rax, -1784(%rbp)
movq -1776(%rbp), %rdi
movq -1784(%rbp), %rsi
call evn_member@PLT
movq %rax, -1792(%rbp)
movq -1744(%rbp), %rdi
movq -1768(%rbp), %rsi
movq -1792(%rbp), %rdx
call f38@PLT
movq %rax, -1800(%rbp)
movq -176(%rbp), %rdi
movq -1800(%rbp), %rsi
call evn_store@PLT
movq %rax, -1808(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1816(%rbp)
movabsq $1, %rax
movq %rax, -1824(%rbp)
movq -1824(%rbp), %rdi
call evn_int@PLT
movq %rax, -1832(%rbp)
movabsq $0, %rax
movq %rax, -1840(%rbp)
movq -1840(%rbp), %rdi
movq -1816(%rbp), %rsi
movq -1832(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1848(%rbp)
movq -144(%rbp), %rdi
movq -1848(%rbp), %rsi
call evn_store@PLT
movq %rax, -1856(%rbp)
jmp .Lf87_b37
.Lf87_b37:
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1640(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1648(%rbp)
movq -1648(%rbp), %rdi
call evn_count@PLT
movq %rax, -1656(%rbp)
movabsq $7, %rax
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rdi
movq -1640(%rbp), %rsi
movq -1656(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1672(%rbp)
movq -1672(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1680(%rbp)
cmpq $0, -1680(%rbp)
je .Lf87_b39
jmp .Lf87_b38
.Lf87_b36:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1568(%rbp)
movabsq $2, %rax
movq %rax, -1576(%rbp)
movq -1568(%rbp), %rdi
movq -1576(%rbp), %rsi
call evn_member@PLT
movq %rax, -1584(%rbp)
movabsq $4, %rax
movq %rax, -1592(%rbp)
movq -1584(%rbp), %rdi
movq -1592(%rbp), %rsi
call evn_member@PLT
movq %rax, -1600(%rbp)
movq -160(%rbp), %rdi
movq -1600(%rbp), %rsi
call evn_store@PLT
movq %rax, -1608(%rbp)
movabsq $0, %rax
movq %rax, -1616(%rbp)
movq -1616(%rbp), %rdi
call evn_int@PLT
movq %rax, -1624(%rbp)
movq -144(%rbp), %rdi
movq -1624(%rbp), %rsi
call evn_store@PLT
movq %rax, -1632(%rbp)
jmp .Lf87_b37
.Lf87_b35:
jmp .Lf87_b36
.Lf87_b34:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1504(%rbp)
movabsq $10, %rax
movq %rax, -1512(%rbp)
movq -1504(%rbp), %rdi
movq -1512(%rbp), %rsi
call evn_member@PLT
movq %rax, -1520(%rbp)
movabsq $1, %rax
movq %rax, -1528(%rbp)
movq -1528(%rbp), %rdi
call evn_int@PLT
movq %rax, -1536(%rbp)
movabsq $0, %rax
movq %rax, -1544(%rbp)
movq -1544(%rbp), %rdi
call evn_int@PLT
movq %rax, -1552(%rbp)
movq -1520(%rbp), %rdi
movq -1536(%rbp), %rsi
movq -1552(%rbp), %rdx
call f30@PLT
movq %rax, -1560(%rbp)
jmp .Lf87_b36
.Lf87_b33:
movq -1344(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1496(%rbp)
cmpq $0, -1496(%rbp)
je .Lf87_b35
jmp .Lf87_b34
.Lf87_b32:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1360(%rbp)
movq -1360(%rbp), %rdi
call f2@PLT
movq %rax, -1368(%rbp)
movabsq $1048576, %rax
movq %rax, -1376(%rbp)
movq -1376(%rbp), %rdi
call evn_int@PLT
movq %rax, -1384(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1392(%rbp)
movabsq $4, %rax
movq %rax, -1400(%rbp)
movq -1392(%rbp), %rdi
movq -1400(%rbp), %rsi
call evn_member@PLT
movq %rax, -1408(%rbp)
movabsq $4, %rax
movq %rax, -1416(%rbp)
movq -1408(%rbp), %rdi
movq -1416(%rbp), %rsi
call evn_member@PLT
movq %rax, -1424(%rbp)
movabsq $4, %rax
movq %rax, -1432(%rbp)
movq -1432(%rbp), %rdi
call evn_int@PLT
movq %rax, -1440(%rbp)
movabsq $3, %rax
movq %rax, -1448(%rbp)
movq -1448(%rbp), %rdi
movq -1424(%rbp), %rsi
movq -1440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1456(%rbp)
movabsq $1, %rax
movq %rax, -1464(%rbp)
movq -1464(%rbp), %rdi
movq -1384(%rbp), %rsi
movq -1456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1472(%rbp)
movabsq $9, %rax
movq %rax, -1480(%rbp)
movq -1480(%rbp), %rdi
movq -1368(%rbp), %rsi
movq -1472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1488(%rbp)
movq -1488(%rbp), %rax
movq %rax, -1344(%rbp)
jmp .Lf87_b33
.Lf87_b31:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1240(%rbp)
movabsq $3, %rax
movq %rax, -1248(%rbp)
movq -1240(%rbp), %rdi
movq -1248(%rbp), %rsi
call evn_member@PLT
movq %rax, -1256(%rbp)
movabsq $4, %rax
movq %rax, -1264(%rbp)
movq -1256(%rbp), %rdi
movq -1264(%rbp), %rsi
call evn_member@PLT
movq %rax, -1272(%rbp)
movabsq $10, %rax
movq %rax, -1280(%rbp)
movq -1280(%rbp), %rdi
call evn_int@PLT
movq %rax, -1288(%rbp)
movabsq $3, %rax
movq %rax, -1296(%rbp)
movq -1296(%rbp), %rdi
movq -1272(%rbp), %rsi
movq -1288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1304(%rbp)
movabsq $1048576, %rax
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
call evn_int@PLT
movq %rax, -1320(%rbp)
movabsq $10, %rax
movq %rax, -1328(%rbp)
movq -1328(%rbp), %rdi
movq -1304(%rbp), %rsi
movq -1320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1336(%rbp)
movq -1336(%rbp), %rax
movq %rax, -1344(%rbp)
movq -1336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1352(%rbp)
cmpq $0, -1352(%rbp)
je .Lf87_b32
jmp .Lf87_b33
.Lf87_b30:
jmp .Lf87_b31
.Lf87_b29:
leaq .Ldata_44(%rip), %rax
movq %rax, -1208(%rbp)
movabsq $21, %rax
movq %rax, -1216(%rbp)
movq -1208(%rbp), %rdi
movq -1216(%rbp), %rsi
call evn_text@PLT
movq %rax, -1224(%rbp)
movq -1224(%rbp), %rdi
call f33@PLT
movq %rax, -1232(%rbp)
jmp .Lf87_b31
.Lf87_b28:
movq -1144(%rbp), %rax
movq %rax, -1088(%rbp)
jmp .Lf87_b26
.Lf87_b27:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1160(%rbp)
movabsq $4, %rax
movq %rax, -1168(%rbp)
movq -1168(%rbp), %rdi
call evn_int@PLT
movq %rax, -1176(%rbp)
movabsq $9, %rax
movq %rax, -1184(%rbp)
movq -1184(%rbp), %rdi
movq -1160(%rbp), %rsi
movq -1176(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1192(%rbp)
movq -1192(%rbp), %rax
movq %rax, -1144(%rbp)
jmp .Lf87_b28
.Lf87_b26:
movq -1088(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1200(%rbp)
cmpq $0, -1200(%rbp)
je .Lf87_b30
jmp .Lf87_b29
.Lf87_b25:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $1, %rax
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
call evn_int@PLT
movq %rax, -1120(%rbp)
movabsq $7, %rax
movq %rax, -1128(%rbp)
movq -1128(%rbp), %rdi
movq -1104(%rbp), %rsi
movq -1120(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1136(%rbp)
movq -1136(%rbp), %rax
movq %rax, -1144(%rbp)
movq -1136(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1152(%rbp)
cmpq $0, -1152(%rbp)
je .Lf87_b27
jmp .Lf87_b28
.Lf87_b24:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1048(%rbp)
movabsq $5, %rax
movq %rax, -1056(%rbp)
movq -1056(%rbp), %rdi
call evn_int@PLT
movq %rax, -1064(%rbp)
movabsq $5, %rax
movq %rax, -1072(%rbp)
movq -1072(%rbp), %rdi
movq -1048(%rbp), %rsi
movq -1064(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rax
movq %rax, -1088(%rbp)
movq -1080(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf87_b26
jmp .Lf87_b25
.Lf87_b23:
jmp .Lf87_b24
.Lf87_b22:
leaq .Ldata_45(%rip), %rax
movq %rax, -1016(%rbp)
movabsq $30, %rax
movq %rax, -1024(%rbp)
movq -1016(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_text@PLT
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
call f33@PLT
movq %rax, -1040(%rbp)
jmp .Lf87_b24
.Lf87_b21:
movq -952(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1008(%rbp)
cmpq $0, -1008(%rbp)
je .Lf87_b23
jmp .Lf87_b22
.Lf87_b20:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -968(%rbp)
movabsq $1, %rax
movq %rax, -976(%rbp)
movq -976(%rbp), %rdi
call evn_int@PLT
movq %rax, -984(%rbp)
movabsq $6, %rax
movq %rax, -992(%rbp)
movq -992(%rbp), %rdi
movq -968(%rbp), %rsi
movq -984(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rax
movq %rax, -952(%rbp)
jmp .Lf87_b21
.Lf87_b19:
movq -896(%rbp), %rax
movq %rax, -952(%rbp)
movq -896(%rbp), %rdi
call evn_truth@PLT
movq %rax, -960(%rbp)
cmpq $0, -960(%rbp)
je .Lf87_b21
jmp .Lf87_b20
.Lf87_b18:
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -912(%rbp)
movabsq $0, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
call evn_int@PLT
movq %rax, -928(%rbp)
movabsq $6, %rax
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
movq -912(%rbp), %rsi
movq -928(%rbp), %rdx
call evn_binary@PLT
movq %rax, -944(%rbp)
movq -944(%rbp), %rax
movq %rax, -896(%rbp)
jmp .Lf87_b19
.Lf87_b17:
jmp .Lf87_b14
.Lf87_b16:
jmp .Lf87_b17
.Lf87_b15:
leaq .Ldata_46(%rip), %rax
movq %rax, -776(%rbp)
movabsq $25, %rax
movq %rax, -784(%rbp)
movq -776(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_text@PLT
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call f33@PLT
movq %rax, -800(%rbp)
jmp .Lf87_b17
.Lf87_b14:
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movabsq $1, %rax
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_int@PLT
movq %rax, -824(%rbp)
movabsq $0, %rax
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
movq -808(%rbp), %rsi
movq -824(%rbp), %rdx
call evn_binary@PLT
movq %rax, -840(%rbp)
movq -144(%rbp), %rdi
movq -840(%rbp), %rsi
call evn_store@PLT
movq %rax, -848(%rbp)
jmp .Lf87_b9
.Lf87_b13:
jmp .Lf87_b14
.Lf87_b12:
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movabsq $0, %rax
movq %rax, -712(%rbp)
movq -704(%rbp), %rdi
movq -712(%rbp), %rsi
call evn_member@PLT
movq %rax, -720(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movq -728(%rbp), %rdi
movq -736(%rbp), %rsi
call f1@PLT
movq %rax, -744(%rbp)
movabsq $6, %rax
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
movq -720(%rbp), %rsi
movq -744(%rbp), %rdx
call evn_binary@PLT
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_truth@PLT
movq %rax, -768(%rbp)
cmpq $0, -768(%rbp)
je .Lf87_b16
jmp .Lf87_b15
.Lf87_b11:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -856(%rbp)
movabsq $2, %rax
movq %rax, -864(%rbp)
movq -864(%rbp), %rdi
call evn_int@PLT
movq %rax, -872(%rbp)
movabsq $5, %rax
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
movq -856(%rbp), %rsi
movq -872(%rbp), %rdx
call evn_binary@PLT
movq %rax, -888(%rbp)
movq -888(%rbp), %rax
movq %rax, -896(%rbp)
movq -888(%rbp), %rdi
call evn_truth@PLT
movq %rax, -904(%rbp)
cmpq $0, -904(%rbp)
je .Lf87_b19
jmp .Lf87_b18
.Lf87_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_truth@PLT
movq %rax, -624(%rbp)
movq -608(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_index@PLT
movq %rax, -632(%rbp)
movq -600(%rbp), %rdi
movq -632(%rbp), %rsi
call f93@PLT
movq %rax, -640(%rbp)
movq -152(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_store@PLT
movq %rax, -648(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $8, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
call evn_int@PLT
movq %rax, -672(%rbp)
movabsq $6, %rax
movq %rax, -680(%rbp)
movq -680(%rbp), %rdi
movq -656(%rbp), %rsi
movq -672(%rbp), %rdx
call evn_binary@PLT
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
call evn_truth@PLT
movq %rax, -696(%rbp)
cmpq $0, -696(%rbp)
je .Lf87_b13
jmp .Lf87_b12
.Lf87_b9:
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -552(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
call evn_count@PLT
movq %rax, -568(%rbp)
movabsq $7, %rax
movq %rax, -576(%rbp)
movq -576(%rbp), %rdi
movq -552(%rbp), %rsi
movq -568(%rbp), %rdx
call evn_binary@PLT
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_truth@PLT
movq %rax, -592(%rbp)
cmpq $0, -592(%rbp)
je .Lf87_b11
jmp .Lf87_b10
.Lf87_b8:
movabsq $0, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call evn_int@PLT
movq %rax, -536(%rbp)
movq -144(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_store@PLT
movq %rax, -544(%rbp)
jmp .Lf87_b9
.Lf87_b7:
jmp .Lf87_b8
.Lf87_b6:
leaq .Ldata_47(%rip), %rax
movq %rax, -496(%rbp)
movabsq $30, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_text@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call f33@PLT
movq %rax, -520(%rbp)
jmp .Lf87_b8
.Lf87_b5:
movq -432(%rbp), %rdi
call evn_truth@PLT
movq %rax, -488(%rbp)
cmpq $0, -488(%rbp)
je .Lf87_b7
jmp .Lf87_b6
.Lf87_b4:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_count@PLT
movq %rax, -456(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movabsq $6, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
movq -456(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_binary@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
movq %rax, -432(%rbp)
jmp .Lf87_b5
.Lf87_b3:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call f3@PLT
movq %rax, -376(%rbp)
movq -136(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_store@PLT
movq %rax, -384(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movabsq $0, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call evn_int@PLT
movq %rax, -408(%rbp)
movabsq $10, %rax
movq %rax, -416(%rbp)
movq -416(%rbp), %rdi
movq -392(%rbp), %rsi
movq -408(%rbp), %rdx
call evn_binary@PLT
movq %rax, -424(%rbp)
movq -424(%rbp), %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
call evn_truth@PLT
movq %rax, -440(%rbp)
cmpq $0, -440(%rbp)
je .Lf87_b5
jmp .Lf87_b4
.Lf87_b2:
jmp .Lf87_b3
.Lf87_b1:
leaq .Ldata_48(%rip), %rax
movq %rax, -336(%rbp)
movabsq $25, %rax
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_text@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call f33@PLT
movq %rax, -360(%rbp)
jmp .Lf87_b3
.Lf87_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -4336(%rbp), %rsi
leaq .Lroots_f87(%rip), %rdx
movq $542, %rcx
call evn_bind_roots@PLT
movq -4288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -4296(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -4304(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -4312(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -4320(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -4328(%rbp), %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -4336(%rbp), %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
call evn_void@PLT
movq %rax, -128(%rbp)
call evn_void@PLT
movq %rax, -136(%rbp)
call evn_void@PLT
movq %rax, -144(%rbp)
call evn_void@PLT
movq %rax, -152(%rbp)
call evn_void@PLT
movq %rax, -160(%rbp)
call evn_void@PLT
movq %rax, -168(%rbp)
call evn_void@PLT
movq %rax, -176(%rbp)
call evn_void@PLT
movq %rax, -184(%rbp)
call evn_void@PLT
movq %rax, -192(%rbp)
call evn_void@PLT
movq %rax, -200(%rbp)
call evn_void@PLT
movq %rax, -208(%rbp)
call evn_void@PLT
movq %rax, -216(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call f90@PLT
movq %rax, -240(%rbp)
movq -128(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $12, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member@PLT
movq %rax, -272(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call f54@PLT
movq %rax, -288(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call f5@PLT
movq %rax, -304(%rbp)
movabsq $1, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_unary@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_truth@PLT
movq %rax, -328(%rbp)
cmpq $0, -328(%rbp)
je .Lf87_b2
jmp .Lf87_b1
.size f87, .-f87
.text
.p2align 4
.type f88, @function
f88:
pushq %rbp
movq %rsp, %rbp
subq $1136, %rsp
movq %rdi, -1112(%rbp)
movq %rsi, -1120(%rbp)
movq %rdx, -1128(%rbp)
leaq -1104(%rbp), %rdi
movq $138, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf88_b0
.Lf88_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movabsq $1, %rax
movq %rax, -752(%rbp)
movq -744(%rbp), %rdi
movq -752(%rbp), %rsi
call evn_member@PLT
movq %rax, -760(%rbp)
movabsq $4, %rax
movq %rax, -768(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
call evn_member@PLT
movq %rax, -776(%rbp)
movabsq $3, %rax
movq %rax, -784(%rbp)
movq -784(%rbp), %rdi
call evn_int@PLT
movq %rax, -792(%rbp)
movabsq $3, %rax
movq %rax, -800(%rbp)
movq -800(%rbp), %rdi
movq -776(%rbp), %rsi
movq -792(%rbp), %rdx
call evn_binary@PLT
movq %rax, -808(%rbp)
movabsq $1, %rax
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call evn_int@PLT
movq %rax, -824(%rbp)
movabsq $0, %rax
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
movq -808(%rbp), %rsi
movq -824(%rbp), %rdx
call evn_binary@PLT
movq %rax, -840(%rbp)
movq -104(%rbp), %rdi
movq -840(%rbp), %rsi
call evn_store@PLT
movq %rax, -848(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -856(%rbp)
movabsq $1, %rax
movq %rax, -864(%rbp)
movq -856(%rbp), %rdi
movq -864(%rbp), %rsi
call evn_member@PLT
movq %rax, -872(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -880(%rbp)
movabsq $9, %rax
movq %rax, -888(%rbp)
movq -880(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_member@PLT
movq %rax, -896(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movabsq $0, %rax
movq %rax, -912(%rbp)
movq -904(%rbp), %rdi
movq -912(%rbp), %rsi
call evn_member@PLT
movq %rax, -920(%rbp)
movq -872(%rbp), %rdi
movq -896(%rbp), %rsi
movq -920(%rbp), %rdx
call f38@PLT
movq %rax, -928(%rbp)
movq -112(%rbp), %rdi
movq -928(%rbp), %rsi
call evn_store@PLT
movq %rax, -936(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $1, %rax
movq %rax, -952(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_member@PLT
movq %rax, -960(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -968(%rbp)
movabsq $9, %rax
movq %rax, -976(%rbp)
movq -968(%rbp), %rdi
movq -976(%rbp), %rsi
call evn_member@PLT
movq %rax, -984(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -992(%rbp)
movq -960(%rbp), %rdi
movq -984(%rbp), %rsi
movq -992(%rbp), %rdx
call f38@PLT
movq %rax, -1000(%rbp)
movq -112(%rbp), %rdi
movq -1000(%rbp), %rsi
call evn_store@PLT
movq %rax, -1008(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1016(%rbp)
movabsq $1, %rax
movq %rax, -1024(%rbp)
movq -1016(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_member@PLT
movq %rax, -1032(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1040(%rbp)
movabsq $9, %rax
movq %rax, -1048(%rbp)
movq -1040(%rbp), %rdi
movq -1048(%rbp), %rsi
call evn_member@PLT
movq %rax, -1056(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_count@PLT
movq %rax, -1072(%rbp)
movq -1032(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1072(%rbp), %rdx
call f38@PLT
movq %rax, -1080(%rbp)
movq -112(%rbp), %rdi
movq -1080(%rbp), %rsi
call evn_store@PLT
movq %rax, -1088(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1096(%rbp)
movq -8(%rbp), %rdi
movq -1096(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1104(%rbp)
movq -1104(%rbp), %rax
leave
ret
.Lf88_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -536(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call evn_truth@PLT
movq %rax, -552(%rbp)
movq -536(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_index@PLT
movq %rax, -560(%rbp)
movq -80(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_store@PLT
movq %rax, -568(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -584(%rbp)
movq -576(%rbp), %rdi
movq -584(%rbp), %rsi
call f93@PLT
movq %rax, -592(%rbp)
movq -88(%rbp), %rdi
movq -592(%rbp), %rsi
call evn_store@PLT
movq %rax, -600(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movabsq $0, %rax
movq %rax, -616(%rbp)
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
call evn_member@PLT
movq %rax, -624(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $9, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_member@PLT
movq %rax, -648(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $0, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movq -624(%rbp), %rdi
movq -648(%rbp), %rsi
movq -672(%rbp), %rdx
call f38@PLT
movq %rax, -680(%rbp)
movq -96(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_store@PLT
movq %rax, -688(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movabsq $1, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call evn_int@PLT
movq %rax, -712(%rbp)
movabsq $0, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
movq -696(%rbp), %rsi
movq -712(%rbp), %rdx
call evn_binary@PLT
movq %rax, -728(%rbp)
movq -72(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_store@PLT
movq %rax, -736(%rbp)
jmp .Lf88_b6
.Lf88_b6:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
call evn_count@PLT
movq %rax, -504(%rbp)
movabsq $7, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
movq -488(%rbp), %rsi
movq -504(%rbp), %rdx
call evn_binary@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_truth@PLT
movq %rax, -528(%rbp)
cmpq $0, -528(%rbp)
je .Lf88_b8
jmp .Lf88_b7
.Lf88_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $0, %rax
movq %rax, -424(%rbp)
movq -416(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_member@PLT
movq %rax, -432(%rbp)
movabsq $4, %rax
movq %rax, -440(%rbp)
movq -432(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_member@PLT
movq %rax, -448(%rbp)
movq -64(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -456(%rbp)
movabsq $0, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_int@PLT
movq %rax, -472(%rbp)
movq -72(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_store@PLT
movq %rax, -480(%rbp)
jmp .Lf88_b6
.Lf88_b4:
jmp .Lf88_b5
.Lf88_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $10, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movabsq $1, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $0, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movq -368(%rbp), %rdi
movq -384(%rbp), %rsi
movq -400(%rbp), %rdx
call f30@PLT
movq %rax, -408(%rbp)
jmp .Lf88_b5
.Lf88_b2:
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf88_b4
jmp .Lf88_b3
.Lf88_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_count@PLT
movq %rax, -248(%rbp)
movabsq $4194304, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movabsq $4, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_member@PLT
movq %rax, -304(%rbp)
movabsq $1, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -264(%rbp), %rsi
movq -304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -320(%rbp)
movabsq $9, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -248(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rax
movq %rax, -224(%rbp)
jmp .Lf88_b2
.Lf88_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1128(%rbp), %rsi
leaq .Lroots_f88(%rip), %rdx
movq $141, %rcx
call evn_bind_roots@PLT
movq -1112(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1120(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1128(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $4, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movabsq $3, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $3, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movabsq $262144, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $10, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rax
movq %rax, -224(%rbp)
movq -216(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf88_b1
jmp .Lf88_b2
.size f88, .-f88
.text
.p2align 4
.type f89, @function
f89:
pushq %rbp
movq %rsp, %rbp
subq $688, %rsp
movq %rdi, -664(%rbp)
movq %rsi, -672(%rbp)
movq %rdx, -680(%rbp)
leaq -656(%rbp), %rdi
movq $82, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf89_b0
.Lf89_b9:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $1, %rax
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_int@PLT
movq %rax, -616(%rbp)
movabsq $0, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
movq -600(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_binary@PLT
movq %rax, -632(%rbp)
movq -80(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_store@PLT
movq %rax, -640(%rbp)
jmp .Lf89_b4
.Lf89_b8:
jmp .Lf89_b9
.Lf89_b7:
leaq .Ldata_49(%rip), %rax
movq %rax, -568(%rbp)
movabsq $22, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_text@PLT
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call f33@PLT
movq %rax, -592(%rbp)
jmp .Lf89_b9
.Lf89_b6:
call evn_void@PLT
movq %rax, -648(%rbp)
movq -8(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rax
leave
ret
.Lf89_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -392(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call evn_truth@PLT
movq %rax, -408(%rbp)
movq -392(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_index@PLT
movq %rax, -416(%rbp)
movq -384(%rbp), %rdi
movq -416(%rbp), %rsi
call f93@PLT
movq %rax, -424(%rbp)
movq -88(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_store@PLT
movq %rax, -432(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movq -448(%rbp), %rdi
movq -456(%rbp), %rsi
movq -464(%rbp), %rdx
call f91@PLT
movq %rax, -472(%rbp)
movq -440(%rbp), %rdi
movq -472(%rbp), %rsi
call f93@PLT
movq %rax, -480(%rbp)
movq -96(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_store@PLT
movq %rax, -488(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $0, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_member@PLT
movq %rax, -512(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movabsq $0, %rax
movq %rax, -528(%rbp)
movq -520(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_member@PLT
movq %rax, -536(%rbp)
movabsq $6, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
movq -512(%rbp), %rsi
movq -536(%rbp), %rdx
call evn_binary@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_truth@PLT
movq %rax, -560(%rbp)
cmpq $0, -560(%rbp)
je .Lf89_b8
jmp .Lf89_b7
.Lf89_b4:
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $7, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
movq -344(%rbp), %rsi
movq -352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -376(%rbp)
cmpq $0, -376(%rbp)
je .Lf89_b6
jmp .Lf89_b5
.Lf89_b3:
movabsq $0, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movq -80(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_store@PLT
movq %rax, -336(%rbp)
jmp .Lf89_b4
.Lf89_b2:
jmp .Lf89_b3
.Lf89_b1:
leaq .Ldata_50(%rip), %rax
movq %rax, -288(%rbp)
movabsq $23, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_text@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call f33@PLT
movq %rax, -312(%rbp)
jmp .Lf89_b3
.Lf89_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -680(%rbp), %rsi
leaq .Lroots_f89(%rip), %rdx
movq $85, %rcx
call evn_bind_roots@PLT
movq -664(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -672(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -680(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call f97@PLT
movq %rax, -120(%rbp)
movq -64(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $5, %rax
movq %rax, -144(%rbp)
movq -136(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_member@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movabsq $9, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_member@PLT
movq %rax, -176(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $1, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -184(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -152(%rbp), %rdi
movq -176(%rbp), %rsi
movq -216(%rbp), %rdx
call f40@PLT
movq %rax, -224(%rbp)
movq -72(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_count@PLT
movq %rax, -256(%rbp)
movabsq $6, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -240(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_binary@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_truth@PLT
movq %rax, -280(%rbp)
cmpq $0, -280(%rbp)
je .Lf89_b2
jmp .Lf89_b1
.size f89, .-f89
.text
.p2align 4
.type f90, @function
f90:
pushq %rbp
movq %rsp, %rbp
subq $304, %rsp
movq %rdi, -288(%rbp)
movq %rsi, -296(%rbp)
leaq -280(%rbp), %rdi
movq $35, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf90_b0
.Lf90_b3:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movq -8(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rax
leave
ret
.Lf90_b2:
jmp .Lf90_b3
.Lf90_b1:
leaq .Ldata_51(%rip), %rax
movq %rax, -240(%rbp)
movabsq $28, %rax
movq %rax, -248(%rbp)
movq -240(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_text@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call f33@PLT
movq %rax, -264(%rbp)
jmp .Lf90_b3
.Lf90_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -296(%rbp), %rsi
leaq .Lroots_f90(%rip), %rdx
movq $37, %rcx
call evn_bind_roots@PLT
movq -288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -296(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call f98@PLT
movq %rax, -64(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -80(%rbp)
movq -72(%rbp), %rdi
movq -80(%rbp), %rsi
call f97@PLT
movq %rax, -88(%rbp)
movq -48(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_store@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $5, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $9, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_member@PLT
movq %rax, -144(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $4, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $0, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
call evn_binary@PLT
movq %rax, -184(%rbp)
movq -120(%rbp), %rdi
movq -144(%rbp), %rsi
movq -184(%rbp), %rdx
call f40@PLT
movq %rax, -192(%rbp)
movabsq $0, %rax
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call evn_int@PLT
movq %rax, -208(%rbp)
movabsq $6, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
movq -192(%rbp), %rsi
movq -208(%rbp), %rdx
call evn_binary@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_truth@PLT
movq %rax, -232(%rbp)
cmpq $0, -232(%rbp)
je .Lf90_b2
jmp .Lf90_b1
.size f90, .-f90
.text
.p2align 4
.type f91, @function
f91:
pushq %rbp
movq %rsp, %rbp
subq $560, %rsp
movq %rdi, -544(%rbp)
movq %rsi, -552(%rbp)
movq %rdx, -560(%rbp)
leaq -536(%rbp), %rdi
movq $67, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf91_b0
.Lf91_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $5, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $9, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movq -368(%rbp), %rdi
movq -392(%rbp), %rsi
movq -400(%rbp), %rdx
call f40@PLT
movq %rax, -408(%rbp)
movq -80(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_store@PLT
movq %rax, -416(%rbp)
movabsq $36, %rax
movq %rax, -424(%rbp)
movabsq $2, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_object@PLT
movq %rax, -440(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movabsq $13, %rax
movq %rax, -456(%rbp)
movq -448(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member@PLT
movq %rax, -464(%rbp)
movabsq $1, %rax
movq %rax, -472(%rbp)
movq -440(%rbp), %rdi
movq -472(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_init@PLT
movq %rax, -480(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movabsq $0, %rax
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
movq -488(%rbp), %rsi
movq -496(%rbp), %rdx
call evn_binary@PLT
movq %rax, -512(%rbp)
movabsq $0, %rax
movq %rax, -520(%rbp)
movq -440(%rbp), %rdi
movq -520(%rbp), %rsi
movq -512(%rbp), %rdx
call evn_init@PLT
movq %rax, -528(%rbp)
movq -8(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
leave
ret
.Lf91_b4:
jmp .Lf91_b5
.Lf91_b3:
leaq .Ldata_52(%rip), %rax
movq %rax, -320(%rbp)
movabsq $38, %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_text@PLT
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call f33@PLT
movq %rax, -344(%rbp)
jmp .Lf91_b5
.Lf91_b2:
movq -264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -312(%rbp)
cmpq $0, -312(%rbp)
je .Lf91_b4
jmp .Lf91_b3
.Lf91_b1:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $10, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -280(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -264(%rbp)
jmp .Lf91_b2
.Lf91_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -560(%rbp), %rsi
leaq .Lroots_f91(%rip), %rdx
movq $70, %rcx
call evn_bind_roots@PLT
movq -544(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -552(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -560(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call f97@PLT
movq %rax, -104(%rbp)
movq -64(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $5, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $9, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $1, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $0, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -136(%rbp), %rdi
movq -160(%rbp), %rsi
movq -200(%rbp), %rdx
call f40@PLT
movq %rax, -208(%rbp)
movq -72(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_store@PLT
movq %rax, -216(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $0, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movabsq $7, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -224(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf91_b1
jmp .Lf91_b2
.size f91, .-f91
.text
.p2align 4
.type f92, @function
f92:
pushq %rbp
movq %rsp, %rbp
subq $1968, %rsp
movq %rdi, -1952(%rbp)
movq %rsi, -1960(%rbp)
leaq -1944(%rbp), %rdi
movq $243, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf92_b0
.Lf92_b14:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1856(%rbp)
movabsq $7, %rax
movq %rax, -1864(%rbp)
movq -1856(%rbp), %rdi
movq -1864(%rbp), %rsi
call evn_member@PLT
movq %rax, -1872(%rbp)
movabsq $1, %rax
movq %rax, -1880(%rbp)
movq -1880(%rbp), %rdi
call evn_int@PLT
movq %rax, -1888(%rbp)
movabsq $0, %rax
movq %rax, -1896(%rbp)
movq -1896(%rbp), %rdi
movq -1872(%rbp), %rsi
movq -1888(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1904(%rbp)
movabsq $7, %rax
movq %rax, -1912(%rbp)
movq -24(%rbp), %rdi
movq -1912(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1920(%rbp)
movq -1920(%rbp), %rdi
movq -1904(%rbp), %rsi
call evn_store@PLT
movq %rax, -1928(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1936(%rbp)
movq -8(%rbp), %rdi
movq -1936(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1944(%rbp)
movq -1944(%rbp), %rax
leave
ret
.Lf92_b13:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1440(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1448(%rbp)
movq -1448(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1456(%rbp)
movq -1440(%rbp), %rdi
movq -1456(%rbp), %rsi
call evn_index@PLT
movq %rax, -1464(%rbp)
movq -80(%rbp), %rdi
movq -1464(%rbp), %rsi
call evn_store@PLT
movq %rax, -1472(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1480(%rbp)
movabsq $4, %rax
movq %rax, -1488(%rbp)
movq -1480(%rbp), %rdi
movq -1488(%rbp), %rsi
call evn_member@PLT
movq %rax, -1496(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1504(%rbp)
movabsq $9, %rax
movq %rax, -1512(%rbp)
movq -1504(%rbp), %rdi
movq -1512(%rbp), %rsi
call evn_member@PLT
movq %rax, -1520(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1528(%rbp)
movabsq $0, %rax
movq %rax, -1536(%rbp)
movq -1528(%rbp), %rdi
movq -1536(%rbp), %rsi
call evn_member@PLT
movq %rax, -1544(%rbp)
movq -1496(%rbp), %rdi
movq -1520(%rbp), %rsi
movq -1544(%rbp), %rdx
call f38@PLT
movq %rax, -1552(%rbp)
movq -72(%rbp), %rdi
movq -1552(%rbp), %rsi
call evn_store@PLT
movq %rax, -1560(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1568(%rbp)
movabsq $4, %rax
movq %rax, -1576(%rbp)
movq -1568(%rbp), %rdi
movq -1576(%rbp), %rsi
call evn_member@PLT
movq %rax, -1584(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1592(%rbp)
movabsq $9, %rax
movq %rax, -1600(%rbp)
movq -1592(%rbp), %rdi
movq -1600(%rbp), %rsi
call evn_member@PLT
movq %rax, -1608(%rbp)
movabsq $0, %rax
movq %rax, -1616(%rbp)
movq -1616(%rbp), %rdi
call evn_int@PLT
movq %rax, -1624(%rbp)
movq -1584(%rbp), %rdi
movq -1608(%rbp), %rsi
movq -1624(%rbp), %rdx
call f38@PLT
movq %rax, -1632(%rbp)
movq -72(%rbp), %rdi
movq -1632(%rbp), %rsi
call evn_store@PLT
movq %rax, -1640(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1648(%rbp)
movabsq $4, %rax
movq %rax, -1656(%rbp)
movq -1648(%rbp), %rdi
movq -1656(%rbp), %rsi
call evn_member@PLT
movq %rax, -1664(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1672(%rbp)
movabsq $9, %rax
movq %rax, -1680(%rbp)
movq -1672(%rbp), %rdi
movq -1680(%rbp), %rsi
call evn_member@PLT
movq %rax, -1688(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1696(%rbp)
movabsq $0, %rax
movq %rax, -1704(%rbp)
movq -1696(%rbp), %rdi
movq -1704(%rbp), %rsi
call evn_member@PLT
movq %rax, -1712(%rbp)
movq -1664(%rbp), %rdi
movq -1688(%rbp), %rsi
movq -1712(%rbp), %rdx
call f38@PLT
movq %rax, -1720(%rbp)
movq -72(%rbp), %rdi
movq -1720(%rbp), %rsi
call evn_store@PLT
movq %rax, -1728(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1736(%rbp)
movabsq $4, %rax
movq %rax, -1744(%rbp)
movq -1736(%rbp), %rdi
movq -1744(%rbp), %rsi
call evn_member@PLT
movq %rax, -1752(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1760(%rbp)
movabsq $9, %rax
movq %rax, -1768(%rbp)
movq -1760(%rbp), %rdi
movq -1768(%rbp), %rsi
call evn_member@PLT
movq %rax, -1776(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1784(%rbp)
movq -1752(%rbp), %rdi
movq -1776(%rbp), %rsi
movq -1784(%rbp), %rdx
call f38@PLT
movq %rax, -1792(%rbp)
movq -72(%rbp), %rdi
movq -1792(%rbp), %rsi
call evn_store@PLT
movq %rax, -1800(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1808(%rbp)
movabsq $1, %rax
movq %rax, -1816(%rbp)
movq -1816(%rbp), %rdi
call evn_int@PLT
movq %rax, -1824(%rbp)
movabsq $0, %rax
movq %rax, -1832(%rbp)
movq -1832(%rbp), %rdi
movq -1808(%rbp), %rsi
movq -1824(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1840(%rbp)
movq -48(%rbp), %rdi
movq -1840(%rbp), %rsi
call evn_store@PLT
movq %rax, -1848(%rbp)
jmp .Lf92_b12
.Lf92_b12:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1392(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1400(%rbp)
movq -1400(%rbp), %rdi
call evn_count@PLT
movq %rax, -1408(%rbp)
movabsq $7, %rax
movq %rax, -1416(%rbp)
movq -1416(%rbp), %rdi
movq -1392(%rbp), %rsi
movq -1408(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1424(%rbp)
movq -1424(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1432(%rbp)
cmpq $0, -1432(%rbp)
je .Lf92_b14
jmp .Lf92_b13
.Lf92_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movabsq $5, %rax
movq %rax, -984(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_member@PLT
movq %rax, -992(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1000(%rbp)
movabsq $9, %rax
movq %rax, -1008(%rbp)
movq -1000(%rbp), %rdi
movq -1008(%rbp), %rsi
call evn_member@PLT
movq %rax, -1016(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1024(%rbp)
movq -992(%rbp), %rdi
movq -1016(%rbp), %rsi
movq -1024(%rbp), %rdx
call f38@PLT
movq %rax, -1032(%rbp)
movq -72(%rbp), %rdi
movq -1032(%rbp), %rsi
call evn_store@PLT
movq %rax, -1040(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1048(%rbp)
movabsq $5, %rax
movq %rax, -1056(%rbp)
movq -1048(%rbp), %rdi
movq -1056(%rbp), %rsi
call evn_member@PLT
movq %rax, -1064(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movabsq $9, %rax
movq %rax, -1080(%rbp)
movq -1072(%rbp), %rdi
movq -1080(%rbp), %rsi
call evn_member@PLT
movq %rax, -1088(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1096(%rbp)
movq -1096(%rbp), %rdi
call evn_count@PLT
movq %rax, -1104(%rbp)
movq -1064(%rbp), %rdi
movq -1088(%rbp), %rsi
movq -1104(%rbp), %rdx
call f38@PLT
movq %rax, -1112(%rbp)
movq -72(%rbp), %rdi
movq -1112(%rbp), %rsi
call evn_store@PLT
movq %rax, -1120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1128(%rbp)
movabsq $5, %rax
movq %rax, -1136(%rbp)
movq -1128(%rbp), %rdi
movq -1136(%rbp), %rsi
call evn_member@PLT
movq %rax, -1144(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1152(%rbp)
movabsq $9, %rax
movq %rax, -1160(%rbp)
movq -1152(%rbp), %rdi
movq -1160(%rbp), %rsi
call evn_member@PLT
movq %rax, -1168(%rbp)
movabsq $0, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
call evn_int@PLT
movq %rax, -1184(%rbp)
movq -1144(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1184(%rbp), %rdx
call f38@PLT
movq %rax, -1192(%rbp)
movq -72(%rbp), %rdi
movq -1192(%rbp), %rsi
call evn_store@PLT
movq %rax, -1200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1208(%rbp)
movabsq $5, %rax
movq %rax, -1216(%rbp)
movq -1208(%rbp), %rdi
movq -1216(%rbp), %rsi
call evn_member@PLT
movq %rax, -1224(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1232(%rbp)
movabsq $9, %rax
movq %rax, -1240(%rbp)
movq -1232(%rbp), %rdi
movq -1240(%rbp), %rsi
call evn_member@PLT
movq %rax, -1248(%rbp)
movabsq $0, %rax
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
call evn_int@PLT
movq %rax, -1264(%rbp)
movq -1224(%rbp), %rdi
movq -1248(%rbp), %rsi
movq -1264(%rbp), %rdx
call f38@PLT
movq %rax, -1272(%rbp)
movq -72(%rbp), %rdi
movq -1272(%rbp), %rsi
call evn_store@PLT
movq %rax, -1280(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1288(%rbp)
movabsq $5, %rax
movq %rax, -1296(%rbp)
movq -1288(%rbp), %rdi
movq -1296(%rbp), %rsi
call evn_member@PLT
movq %rax, -1304(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1312(%rbp)
movabsq $9, %rax
movq %rax, -1320(%rbp)
movq -1312(%rbp), %rdi
movq -1320(%rbp), %rsi
call evn_member@PLT
movq %rax, -1328(%rbp)
movabsq $0, %rax
movq %rax, -1336(%rbp)
movq -1336(%rbp), %rdi
call evn_int@PLT
movq %rax, -1344(%rbp)
movq -1304(%rbp), %rdi
movq -1328(%rbp), %rsi
movq -1344(%rbp), %rdx
call f38@PLT
movq %rax, -1352(%rbp)
movq -72(%rbp), %rdi
movq -1352(%rbp), %rsi
call evn_store@PLT
movq %rax, -1360(%rbp)
movabsq $0, %rax
movq %rax, -1368(%rbp)
movq -1368(%rbp), %rdi
call evn_int@PLT
movq %rax, -1376(%rbp)
movq -48(%rbp), %rdi
movq -1376(%rbp), %rsi
call evn_store@PLT
movq %rax, -1384(%rbp)
jmp .Lf92_b12
.Lf92_b10:
jmp .Lf92_b11
.Lf92_b9:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movabsq $4, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_member@PLT
movq %rax, -880(%rbp)
movabsq $4, %rax
movq %rax, -888(%rbp)
movq -880(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_member@PLT
movq %rax, -896(%rbp)
movabsq $4, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_int@PLT
movq %rax, -912(%rbp)
movabsq $3, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
movq -896(%rbp), %rsi
movq -912(%rbp), %rdx
call evn_binary@PLT
movq %rax, -928(%rbp)
movabsq $1, %rax
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
call evn_int@PLT
movq %rax, -944(%rbp)
movabsq $0, %rax
movq %rax, -952(%rbp)
movq -952(%rbp), %rdi
movq -928(%rbp), %rsi
movq -944(%rbp), %rdx
call evn_binary@PLT
movq %rax, -960(%rbp)
movq -64(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_store@PLT
movq %rax, -968(%rbp)
jmp .Lf92_b11
.Lf92_b8:
movabsq $37, %rax
movq %rax, -592(%rbp)
movabsq $2, %rax
movq %rax, -600(%rbp)
movq -592(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_object@PLT
movq %rax, -608(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movabsq $13, %rax
movq %rax, -624(%rbp)
movq -616(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_member@PLT
movq %rax, -632(%rbp)
movabsq $1, %rax
movq %rax, -640(%rbp)
movq -608(%rbp), %rdi
movq -640(%rbp), %rsi
movq -632(%rbp), %rdx
call evn_init@PLT
movq %rax, -648(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $5, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_member@PLT
movq %rax, -672(%rbp)
movabsq $4, %rax
movq %rax, -680(%rbp)
movq -672(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_member@PLT
movq %rax, -688(%rbp)
movabsq $5, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movabsq $3, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_binary@PLT
movq %rax, -720(%rbp)
movabsq $1, %rax
movq %rax, -728(%rbp)
movq -728(%rbp), %rdi
call evn_int@PLT
movq %rax, -736(%rbp)
movabsq $0, %rax
movq %rax, -744(%rbp)
movq -744(%rbp), %rdi
movq -720(%rbp), %rsi
movq -736(%rbp), %rdx
call evn_binary@PLT
movq %rax, -752(%rbp)
movabsq $0, %rax
movq %rax, -760(%rbp)
movq -608(%rbp), %rdi
movq -760(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_init@PLT
movq %rax, -768(%rbp)
movq -56(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_store@PLT
movq %rax, -776(%rbp)
movabsq $0, %rax
movq %rax, -784(%rbp)
movq -784(%rbp), %rdi
call evn_int@PLT
movq %rax, -792(%rbp)
movq -64(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_store@PLT
movq %rax, -800(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
call evn_count@PLT
movq %rax, -816(%rbp)
movabsq $0, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call evn_int@PLT
movq %rax, -832(%rbp)
movabsq $9, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
movq -816(%rbp), %rsi
movq -832(%rbp), %rdx
call evn_binary@PLT
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
call evn_truth@PLT
movq %rax, -856(%rbp)
cmpq $0, -856(%rbp)
je .Lf92_b10
jmp .Lf92_b9
.Lf92_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_truth@PLT
movq %rax, -520(%rbp)
movq -504(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_index@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call f69@PLT
movq %rax, -536(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $1, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $0, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -544(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movq -48(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_store@PLT
movq %rax, -584(%rbp)
jmp .Lf92_b6
.Lf92_b6:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_count@PLT
movq %rax, -472(%rbp)
movabsq $7, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
movq -456(%rbp), %rsi
movq -472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rdi
call evn_truth@PLT
movq %rax, -496(%rbp)
cmpq $0, -496(%rbp)
je .Lf92_b8
jmp .Lf92_b7
.Lf92_b5:
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -432(%rbp), %rdi
call evn_int@PLT
movq %rax, -440(%rbp)
movq -48(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_store@PLT
movq %rax, -448(%rbp)
jmp .Lf92_b6
.Lf92_b4:
jmp .Lf92_b5
.Lf92_b3:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $10, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movq -384(%rbp), %rdi
movq -400(%rbp), %rsi
movq -416(%rbp), %rdx
call f30@PLT
movq %rax, -424(%rbp)
jmp .Lf92_b5
.Lf92_b2:
movq -208(%rbp), %rdi
call evn_truth@PLT
movq %rax, -360(%rbp)
cmpq $0, -360(%rbp)
je .Lf92_b4
jmp .Lf92_b3
.Lf92_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_count@PLT
movq %rax, -232(%rbp)
movabsq $1048576, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $4, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member@PLT
movq %rax, -272(%rbp)
movabsq $4, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movabsq $4, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movabsq $3, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -288(%rbp), %rsi
movq -304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -320(%rbp)
movabsq $1, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -248(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movabsq $9, %rax
movq %rax, -344(%rbp)
movq -344(%rbp), %rdi
movq -232(%rbp), %rsi
movq -336(%rbp), %rdx
call evn_binary@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rax
movq %rax, -208(%rbp)
jmp .Lf92_b2
.Lf92_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1960(%rbp), %rsi
leaq .Lroots_f92(%rip), %rdx
movq $245, %rcx
call evn_bind_roots@PLT
movq -1952(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1960(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call f98@PLT
movq %rax, -96(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $5, %rax
movq %rax, -112(%rbp)
movq -104(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_member@PLT
movq %rax, -120(%rbp)
movabsq $4, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movabsq $5, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $3, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
movq -136(%rbp), %rsi
movq -152(%rbp), %rdx
call evn_binary@PLT
movq %rax, -168(%rbp)
movabsq $65536, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $10, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
call evn_truth@PLT
movq %rax, -216(%rbp)
cmpq $0, -216(%rbp)
je .Lf92_b1
jmp .Lf92_b2
.size f92, .-f92
.text
.p2align 4
.type f93, @function
f93:
pushq %rbp
movq %rsp, %rbp
subq $176, %rsp
movq %rdi, -168(%rbp)
movq %rsi, -176(%rbp)
leaq -160(%rbp), %rdi
movq $20, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf93_b0
.Lf93_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -176(%rbp), %rsi
leaq .Lroots_f93(%rip), %rdx
movq $22, %rcx
call evn_bind_roots@PLT
movq -168(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -176(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movq -56(%rbp), %rdi
movq -64(%rbp), %rsi
call f96@PLT
movq %rax, -72(%rbp)
movq -48(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_store@PLT
movq %rax, -80(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movabsq $4, %rax
movq %rax, -96(%rbp)
movq -88(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_member@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $9, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -104(%rbp), %rdi
movq -128(%rbp), %rsi
movq -136(%rbp), %rdx
call f40@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call f73@PLT
movq %rax, -152(%rbp)
movq -8(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rax
leave
ret
.size f93, .-f93
.text
.p2align 4
.type f94, @function
f94:
pushq %rbp
movq %rsp, %rbp
subq $1312, %rsp
movq %rdi, -1288(%rbp)
movq %rsi, -1296(%rbp)
movq %rdx, -1304(%rbp)
movq %rcx, -1312(%rbp)
leaq -1280(%rbp), %rdi
movq $160, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf94_b0
.Lf94_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -464(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -472(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movq -464(%rbp), %rdi
movq -472(%rbp), %rsi
movq -480(%rbp), %rdx
call f64@PLT
movq %rax, -488(%rbp)
movq -80(%rbp), %rdi
movq -488(%rbp), %rsi
call evn_store@PLT
movq %rax, -496(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movabsq $8192, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_int@PLT
movq %rax, -520(%rbp)
movq -504(%rbp), %rdi
movq -520(%rbp), %rsi
call f22@PLT
movq %rax, -528(%rbp)
movq -88(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_store@PLT
movq %rax, -536(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call f18@PLT
movq %rax, -552(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $1024, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
call evn_int@PLT
movq %rax, -576(%rbp)
movq -560(%rbp), %rdi
movq -576(%rbp), %rsi
call f22@PLT
movq %rax, -584(%rbp)
movq -96(%rbp), %rdi
movq -584(%rbp), %rsi
call evn_store@PLT
movq %rax, -592(%rbp)
movabsq $34, %rax
movq %rax, -600(%rbp)
movabsq $14, %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_object@PLT
movq %rax, -616(%rbp)
movabsq $26, %rax
movq %rax, -624(%rbp)
movabsq $1, %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_object@PLT
movq %rax, -640(%rbp)
movabsq $0, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
call evn_int@PLT
movq %rax, -656(%rbp)
movabsq $0, %rax
movq %rax, -664(%rbp)
movq -640(%rbp), %rdi
movq -664(%rbp), %rsi
movq -656(%rbp), %rdx
call evn_init@PLT
movq %rax, -672(%rbp)
movabsq $27, %rax
movq %rax, -680(%rbp)
movq -680(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -688(%rbp)
movabsq $13, %rax
movq %rax, -696(%rbp)
movq -616(%rbp), %rdi
movq -696(%rbp), %rsi
movq -688(%rbp), %rdx
call evn_init@PLT
movq %rax, -704(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movabsq $12, %rax
movq %rax, -720(%rbp)
movq -616(%rbp), %rdi
movq -720(%rbp), %rsi
movq -712(%rbp), %rdx
call evn_init@PLT
movq %rax, -728(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $11, %rax
movq %rax, -744(%rbp)
movq -616(%rbp), %rdi
movq -744(%rbp), %rsi
movq -736(%rbp), %rdx
call evn_init@PLT
movq %rax, -752(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movabsq $10, %rax
movq %rax, -768(%rbp)
movq -616(%rbp), %rdi
movq -768(%rbp), %rsi
movq -760(%rbp), %rdx
call evn_init@PLT
movq %rax, -776(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $9, %rax
movq %rax, -792(%rbp)
movq -616(%rbp), %rdi
movq -792(%rbp), %rsi
movq -784(%rbp), %rdx
call evn_init@PLT
movq %rax, -800(%rbp)
movabsq $0, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
call evn_int@PLT
movq %rax, -816(%rbp)
movabsq $8, %rax
movq %rax, -824(%rbp)
movq -616(%rbp), %rdi
movq -824(%rbp), %rsi
movq -816(%rbp), %rdx
call evn_init@PLT
movq %rax, -832(%rbp)
movabsq $0, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
call evn_int@PLT
movq %rax, -848(%rbp)
movabsq $7, %rax
movq %rax, -856(%rbp)
movq -616(%rbp), %rdi
movq -856(%rbp), %rsi
movq -848(%rbp), %rdx
call evn_init@PLT
movq %rax, -864(%rbp)
movabsq $18, %rax
movq %rax, -872(%rbp)
movq -872(%rbp), %rdi
call evn_none@PLT
movq %rax, -880(%rbp)
movabsq $6, %rax
movq %rax, -888(%rbp)
movq -616(%rbp), %rdi
movq -888(%rbp), %rsi
movq -880(%rbp), %rdx
call evn_init@PLT
movq %rax, -896(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movabsq $327680, %rax
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
call evn_int@PLT
movq %rax, -920(%rbp)
movq -904(%rbp), %rdi
movq -920(%rbp), %rsi
call f50@PLT
movq %rax, -928(%rbp)
movabsq $5, %rax
movq %rax, -936(%rbp)
movq -616(%rbp), %rdi
movq -936(%rbp), %rsi
movq -928(%rbp), %rdx
call evn_init@PLT
movq %rax, -944(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -952(%rbp)
movabsq $4194304, %rax
movq %rax, -960(%rbp)
movq -960(%rbp), %rdi
call evn_int@PLT
movq %rax, -968(%rbp)
movq -952(%rbp), %rdi
movq -968(%rbp), %rsi
call f50@PLT
movq %rax, -976(%rbp)
movabsq $4, %rax
movq %rax, -984(%rbp)
movq -616(%rbp), %rdi
movq -984(%rbp), %rsi
movq -976(%rbp), %rdx
call evn_init@PLT
movq %rax, -992(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1000(%rbp)
movabsq $10485760, %rax
movq %rax, -1008(%rbp)
movq -1008(%rbp), %rdi
call evn_int@PLT
movq %rax, -1016(%rbp)
movq -1000(%rbp), %rdi
movq -1016(%rbp), %rsi
call f50@PLT
movq %rax, -1024(%rbp)
movabsq $3, %rax
movq %rax, -1032(%rbp)
movq -616(%rbp), %rdi
movq -1032(%rbp), %rsi
movq -1024(%rbp), %rdx
call evn_init@PLT
movq %rax, -1040(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1048(%rbp)
movabsq $16777216, %rax
movq %rax, -1056(%rbp)
movq -1056(%rbp), %rdi
call evn_int@PLT
movq %rax, -1064(%rbp)
movq -1048(%rbp), %rdi
movq -1064(%rbp), %rsi
call f50@PLT
movq %rax, -1072(%rbp)
movabsq $2, %rax
movq %rax, -1080(%rbp)
movq -616(%rbp), %rdi
movq -1080(%rbp), %rsi
movq -1072(%rbp), %rdx
call evn_init@PLT
movq %rax, -1088(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1096(%rbp)
movabsq $786432, %rax
movq %rax, -1104(%rbp)
movq -1104(%rbp), %rdi
call evn_int@PLT
movq %rax, -1112(%rbp)
movq -1096(%rbp), %rdi
movq -1112(%rbp), %rsi
call f50@PLT
movq %rax, -1120(%rbp)
movabsq $1, %rax
movq %rax, -1128(%rbp)
movq -616(%rbp), %rdi
movq -1128(%rbp), %rsi
movq -1120(%rbp), %rdx
call evn_init@PLT
movq %rax, -1136(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1144(%rbp)
movabsq $4194304, %rax
movq %rax, -1152(%rbp)
movq -1152(%rbp), %rdi
call evn_int@PLT
movq %rax, -1160(%rbp)
movq -1144(%rbp), %rdi
movq -1160(%rbp), %rsi
call f50@PLT
movq %rax, -1168(%rbp)
movabsq $0, %rax
movq %rax, -1176(%rbp)
movq -616(%rbp), %rdi
movq -1176(%rbp), %rsi
movq -1168(%rbp), %rdx
call evn_init@PLT
movq %rax, -1184(%rbp)
movabsq $35, %rax
movq %rax, -1192(%rbp)
movq -1192(%rbp), %rdi
movq -616(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1200(%rbp)
movq -104(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_store@PLT
movq %rax, -1208(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1216(%rbp)
movq -1216(%rbp), %rdi
call f20@PLT
movq %rax, -1224(%rbp)
movabsq $18, %rax
movq %rax, -1232(%rbp)
movq -1232(%rbp), %rdi
movq -1224(%rbp), %rsi
call evn_wrap@PLT
movq %rax, -1240(%rbp)
movabsq $6, %rax
movq %rax, -1248(%rbp)
movq -104(%rbp), %rdi
movq -1248(%rbp), %rsi
call evn_member_ref@PLT
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
movq -1240(%rbp), %rsi
call evn_store@PLT
movq %rax, -1264(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1272(%rbp)
movq -8(%rbp), %rdi
movq -1272(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1280(%rbp)
movq -1280(%rbp), %rax
leave
ret
.Lf94_b10:
jmp .Lf94_b11
.Lf94_b9:
leaq .Ldata_53(%rip), %rax
movq %rax, -432(%rbp)
movabsq $58, %rax
movq %rax, -440(%rbp)
movq -432(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_text@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call f33@PLT
movq %rax, -456(%rbp)
jmp .Lf94_b11
.Lf94_b8:
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -424(%rbp)
cmpq $0, -424(%rbp)
je .Lf94_b10
jmp .Lf94_b9
.Lf94_b7:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $12, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $9, %rax
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call evn_member@PLT
movq %rax, -384(%rbp)
movabsq $12, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movabsq $6, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -360(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -416(%rbp), %rax
movq %rax, -328(%rbp)
jmp .Lf94_b8
.Lf94_b6:
movq -264(%rbp), %rax
movq %rax, -328(%rbp)
movq -264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf94_b7
jmp .Lf94_b8
.Lf94_b5:
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $4, %rax
movq %rax, -288(%rbp)
movq -280(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_member@PLT
movq %rax, -296(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $6, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -296(%rbp), %rsi
movq -304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rax
movq %rax, -264(%rbp)
jmp .Lf94_b6
.Lf94_b4:
movq -192(%rbp), %rax
movq %rax, -264(%rbp)
movq -192(%rbp), %rdi
call evn_truth@PLT
movq %rax, -272(%rbp)
cmpq $0, -272(%rbp)
je .Lf94_b5
jmp .Lf94_b6
.Lf94_b3:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $11, %rax
movq %rax, -216(%rbp)
movq -208(%rbp), %rdi
movq -216(%rbp), %rsi
call evn_member@PLT
movq %rax, -224(%rbp)
movabsq $2, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movabsq $6, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
movq -224(%rbp), %rsi
movq -240(%rbp), %rdx
call evn_binary@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rax
movq %rax, -192(%rbp)
jmp .Lf94_b4
.Lf94_b2:
movq -152(%rbp), %rax
movq %rax, -192(%rbp)
movq -152(%rbp), %rdi
call evn_truth@PLT
movq %rax, -200(%rbp)
cmpq $0, -200(%rbp)
je .Lf94_b3
jmp .Lf94_b4
.Lf94_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -168(%rbp)
movabsq $7, %rax
movq %rax, -176(%rbp)
movq -168(%rbp), %rdi
movq -176(%rbp), %rsi
call evn_member@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rax
movq %rax, -152(%rbp)
jmp .Lf94_b2
.Lf94_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1312(%rbp), %rsi
leaq .Lroots_f94(%rip), %rdx
movq $164, %rcx
call evn_bind_roots@PLT
movq -1288(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -1296(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -1304(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -1312(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $8, %rax
movq %rax, -120(%rbp)
movq -112(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_member@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_unary@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
call evn_truth@PLT
movq %rax, -160(%rbp)
cmpq $0, -160(%rbp)
je .Lf94_b1
jmp .Lf94_b2
.size f94, .-f94
.text
.p2align 4
.type f95, @function
f95:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -520(%rbp)
movq %rsi, -528(%rbp)
leaq -512(%rbp), %rdi
movq $64, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf95_b0
.Lf95_b9:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member@PLT
movq %rax, -440(%rbp)
movabsq $1, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $1, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -440(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movabsq $10, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $2, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -8(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rax
leave
ret
.Lf95_b8:
jmp .Lf95_b9
.Lf95_b7:
leaq .Ldata_54(%rip), %rax
movq %rax, -392(%rbp)
movabsq $29, %rax
movq %rax, -400(%rbp)
movq -392(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_text@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call f33@PLT
movq %rax, -416(%rbp)
jmp .Lf95_b9
.Lf95_b6:
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -384(%rbp)
cmpq $0, -384(%rbp)
je .Lf95_b8
jmp .Lf95_b7
.Lf95_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $3, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $4, %rax
movq %rax, -320(%rbp)
movq -312(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_member@PLT
movq %rax, -328(%rbp)
movabsq $10, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -328(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_binary@PLT
movq %rax, -360(%rbp)
movabsq $9, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
movq -288(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_binary@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
movq %rax, -256(%rbp)
jmp .Lf95_b6
.Lf95_b4:
movq -184(%rbp), %rax
movq %rax, -256(%rbp)
movq -184(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf95_b5
jmp .Lf95_b6
.Lf95_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_member@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $7, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -184(%rbp)
jmp .Lf95_b4
.Lf95_b2:
movq -104(%rbp), %rax
movq %rax, -184(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf95_b3
jmp .Lf95_b4
.Lf95_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $13, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movabsq $6, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -136(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf95_b2
.Lf95_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -528(%rbp), %rsi
leaq .Lroots_f95(%rip), %rdx
movq $66, %rcx
call evn_bind_roots@PLT
movq -520(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -528(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $8, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movabsq $2, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $5, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf95_b1
jmp .Lf95_b2
.size f95, .-f95
.text
.p2align 4
.type f96, @function
f96:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -520(%rbp)
movq %rsi, -528(%rbp)
leaq -512(%rbp), %rdi
movq $64, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf96_b0
.Lf96_b9:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member@PLT
movq %rax, -440(%rbp)
movabsq $1, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $1, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -440(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movabsq $4, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $2, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -8(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rax
leave
ret
.Lf96_b8:
jmp .Lf96_b9
.Lf96_b7:
leaq .Ldata_55(%rip), %rax
movq %rax, -392(%rbp)
movabsq $30, %rax
movq %rax, -400(%rbp)
movq -392(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_text@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call f33@PLT
movq %rax, -416(%rbp)
jmp .Lf96_b9
.Lf96_b6:
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -384(%rbp)
cmpq $0, -384(%rbp)
je .Lf96_b8
jmp .Lf96_b7
.Lf96_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $4, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $4, %rax
movq %rax, -320(%rbp)
movq -312(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_member@PLT
movq %rax, -328(%rbp)
movabsq $4, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -328(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_binary@PLT
movq %rax, -360(%rbp)
movabsq $9, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
movq -288(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_binary@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
movq %rax, -256(%rbp)
jmp .Lf96_b6
.Lf96_b4:
movq -184(%rbp), %rax
movq %rax, -256(%rbp)
movq -184(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf96_b5
jmp .Lf96_b6
.Lf96_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_member@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $7, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -184(%rbp)
jmp .Lf96_b4
.Lf96_b2:
movq -104(%rbp), %rax
movq %rax, -184(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf96_b3
jmp .Lf96_b4
.Lf96_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $13, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movabsq $6, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -136(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf96_b2
.Lf96_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -528(%rbp), %rsi
leaq .Lroots_f96(%rip), %rdx
movq $66, %rcx
call evn_bind_roots@PLT
movq -520(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -528(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $8, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movabsq $2, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $5, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf96_b1
jmp .Lf96_b2
.size f96, .-f96
.text
.p2align 4
.type f97, @function
f97:
pushq %rbp
movq %rsp, %rbp
subq $528, %rsp
movq %rdi, -520(%rbp)
movq %rsi, -528(%rbp)
leaq -512(%rbp), %rdi
movq $64, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf97_b0
.Lf97_b9:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $0, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member@PLT
movq %rax, -440(%rbp)
movabsq $1, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $1, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -440(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movabsq $5, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $2, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -8(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rax
leave
ret
.Lf97_b8:
jmp .Lf97_b9
.Lf97_b7:
leaq .Ldata_56(%rip), %rax
movq %rax, -392(%rbp)
movabsq $30, %rax
movq %rax, -400(%rbp)
movq -392(%rbp), %rdi
movq -400(%rbp), %rsi
call evn_text@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call f33@PLT
movq %rax, -416(%rbp)
jmp .Lf97_b9
.Lf97_b6:
movq -256(%rbp), %rdi
call evn_truth@PLT
movq %rax, -384(%rbp)
cmpq $0, -384(%rbp)
je .Lf97_b8
jmp .Lf97_b7
.Lf97_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $5, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_member@PLT
movq %rax, -312(%rbp)
movabsq $4, %rax
movq %rax, -320(%rbp)
movq -312(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_member@PLT
movq %rax, -328(%rbp)
movabsq $5, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $3, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -328(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_binary@PLT
movq %rax, -360(%rbp)
movabsq $9, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
movq -288(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_binary@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
movq %rax, -256(%rbp)
jmp .Lf97_b6
.Lf97_b4:
movq -184(%rbp), %rax
movq %rax, -256(%rbp)
movq -184(%rbp), %rdi
call evn_truth@PLT
movq %rax, -264(%rbp)
cmpq $0, -264(%rbp)
je .Lf97_b5
jmp .Lf97_b6
.Lf97_b3:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_member@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $7, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
call evn_binary@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rax
movq %rax, -184(%rbp)
jmp .Lf97_b4
.Lf97_b2:
movq -104(%rbp), %rax
movq %rax, -184(%rbp)
movq -104(%rbp), %rdi
call evn_truth@PLT
movq %rax, -192(%rbp)
cmpq $0, -192(%rbp)
je .Lf97_b3
jmp .Lf97_b4
.Lf97_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $1, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movabsq $13, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_member@PLT
movq %rax, -160(%rbp)
movabsq $6, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -136(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rax
movq %rax, -104(%rbp)
jmp .Lf97_b2
.Lf97_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -528(%rbp), %rsi
leaq .Lroots_f97(%rip), %rdx
movq $66, %rcx
call evn_bind_roots@PLT
movq -520(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -528(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $8, %rax
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_member@PLT
movq %rax, -64(%rbp)
movabsq $2, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $5, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
movq -64(%rbp), %rsi
movq -80(%rbp), %rdx
call evn_binary@PLT
movq %rax, -96(%rbp)
movq -96(%rbp), %rax
movq %rax, -104(%rbp)
movq -96(%rbp), %rdi
call evn_truth@PLT
movq %rax, -112(%rbp)
cmpq $0, -112(%rbp)
je .Lf97_b1
jmp .Lf97_b2
.size f97, .-f97
.text
.p2align 4
.type f98, @function
f98:
pushq %rbp
movq %rsp, %rbp
subq $176, %rsp
movq %rdi, -176(%rbp)
leaq -168(%rbp), %rdi
movq $21, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf98_b0
.Lf98_b3:
call evn_void@PLT
movq %rax, -160(%rbp)
movq -8(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -168(%rbp)
movq -168(%rbp), %rax
leave
ret
.Lf98_b2:
jmp .Lf98_b3
.Lf98_b1:
leaq .Ldata_57(%rip), %rax
movq %rax, -128(%rbp)
movabsq $35, %rax
movq %rax, -136(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_text@PLT
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call f33@PLT
movq %rax, -152(%rbp)
jmp .Lf98_b3
.Lf98_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -176(%rbp), %rsi
leaq .Lroots_f98(%rip), %rdx
movq $22, %rcx
call evn_bind_roots@PLT
movq -176(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movabsq $10, %rax
movq %rax, -40(%rbp)
movq -32(%rbp), %rdi
movq -40(%rbp), %rsi
call evn_member@PLT
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call f9@PLT
movq %rax, -56(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -64(%rbp)
movabsq $8, %rax
movq %rax, -72(%rbp)
movq -64(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_member@PLT
movq %rax, -80(%rbp)
movabsq $0, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movabsq $6, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call evn_binary@PLT
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_truth@PLT
movq %rax, -120(%rbp)
cmpq $0, -120(%rbp)
je .Lf98_b2
jmp .Lf98_b1
.size f98, .-f98
.text
.p2align 4
.type f99, @function
f99:
pushq %rbp
movq %rsp, %rbp
subq $496, %rsp
leaq -488(%rbp), %rdi
movq $61, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf99_b0
.Lf99_b7:
movq -80(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -464(%rbp)
ud2
.Lf99_b6:
movq -80(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_error@PLT
movq %rax, -312(%rbp)
movq -24(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_store@PLT
movq %rax, -320(%rbp)
leaq .Ldata_58(%rip), %rax
movq %rax, -328(%rbp)
movabsq $6, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_text@PLT
movq %rax, -344(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $0, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movabsq $0, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
movq -344(%rbp), %rsi
movq -368(%rbp), %rdx
call evn_binary@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_output@PLT
movq %rax, -392(%rbp)
call evn_void@PLT
movq %rax, -400(%rbp)
movabsq $1, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
leaq .Ldata_59(%rip), %rax
movq %rax, -424(%rbp)
movabsq $5, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_builtin1@PLT
movq %rax, -440(%rbp)
call evn_void@PLT
movq %rax, -448(%rbp)
movq -8(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -456(%rbp)
movq -456(%rbp), %rax
leave
ret
.Lf99_b5:
movabsq $41, %rax
movq %rax, -296(%rbp)
movq -80(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_match@PLT
movq %rax, -304(%rbp)
cmpq $0, -304(%rbp)
je .Lf99_b7
jmp .Lf99_b6
.Lf99_b4:
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_error@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -120(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_member@PLT
movq %rax, -136(%rbp)
leaq .Ldata_60(%rip), %rax
movq %rax, -144(%rbp)
movabsq $1, %rax
movq %rax, -152(%rbp)
movq -144(%rbp), %rdi
movq -152(%rbp), %rsi
call evn_text@PLT
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
movq -136(%rbp), %rsi
movq -160(%rbp), %rdx
call evn_binary@PLT
movq %rax, -176(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $3, %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_member@PLT
movq %rax, -200(%rbp)
movabsq $0, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
movq -176(%rbp), %rsi
movq -200(%rbp), %rdx
call evn_binary@PLT
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_output@PLT
movq %rax, -224(%rbp)
call evn_void@PLT
movq %rax, -232(%rbp)
movabsq $1, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
leaq .Ldata_61(%rip), %rax
movq %rax, -256(%rbp)
movabsq $5, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
movq -248(%rbp), %rdx
call evn_builtin1@PLT
movq %rax, -272(%rbp)
call evn_void@PLT
movq %rax, -280(%rbp)
movq -8(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
leave
ret
.Lf99_b3:
movq -32(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_store@PLT
movq %rax, -472(%rbp)
call evn_void@PLT
movq %rax, -480(%rbp)
movq -8(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
leave
ret
.Lf99_b2:
movq -40(%rbp), %rdi
call evn_pop@PLT
movq %rax, -72(%rbp)
call evn_saved@PLT
movq %rax, -80(%rbp)
movabsq $9, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_match@PLT
movq %rax, -96(%rbp)
cmpq $0, -96(%rbp)
je .Lf99_b5
jmp .Lf99_b4
.Lf99_b1:
call f100@PLT
movq %rax, -56(%rbp)
movq -56(%rbp), %rax
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
call evn_pop@PLT
movq %rax, -64(%rbp)
jmp .Lf99_b3
.Lf99_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -488(%rbp), %rsi
leaq .Lroots_f99(%rip), %rdx
movq $61, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_frame@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf99_b2
jmp .Lf99_b1
.size f99, .-f99
.text
.p2align 4
.type f100, @function
f100:
pushq %rbp
movq %rsp, %rbp
subq $160, %rsp
leaq -152(%rbp), %rdi
movq $19, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf100_b0
.Lf100_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -152(%rbp), %rsi
leaq .Lroots_f100(%rip), %rdx
movq $19, %rcx
call evn_bind_roots@PLT
call f115@PLT
movq %rax, -16(%rbp)
call f114@PLT
movq %rax, -24(%rbp)
call f113@PLT
movq %rax, -32(%rbp)
call f112@PLT
movq %rax, -40(%rbp)
call f111@PLT
movq %rax, -48(%rbp)
call f110@PLT
movq %rax, -56(%rbp)
call f109@PLT
movq %rax, -64(%rbp)
call f108@PLT
movq %rax, -72(%rbp)
call f107@PLT
movq %rax, -80(%rbp)
call f106@PLT
movq %rax, -88(%rbp)
call f105@PLT
movq %rax, -96(%rbp)
call f104@PLT
movq %rax, -104(%rbp)
call f103@PLT
movq %rax, -112(%rbp)
call f102@PLT
movq %rax, -120(%rbp)
call f101@PLT
movq %rax, -128(%rbp)
movabsq $1, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_bool@PLT
movq %rax, -144(%rbp)
movq -8(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
leave
ret
.size f100, .-f100
.text
.p2align 4
.type f101, @function
f101:
pushq %rbp
movq %rsp, %rbp
subq $4704, %rsp
leaq -4704(%rbp), %rdi
movq $588, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf101_b0
.Lf101_b15:
leaq .Ldata_62(%rip), %rax
movq %rax, -4344(%rbp)
movabsq $31, %rax
movq %rax, -4352(%rbp)
movq -4344(%rbp), %rdi
movq -4352(%rbp), %rsi
call evn_text@PLT
movq %rax, -4360(%rbp)
movq -4272(%rbp), %rdi
movq -4360(%rbp), %rsi
call f123@PLT
movq %rax, -4368(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4376(%rbp)
movq -4376(%rbp), %rdi
call f8@PLT
movq %rax, -4384(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4392(%rbp)
movq -4392(%rbp), %rdi
call f8@PLT
movq %rax, -4400(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4408(%rbp)
movq -4408(%rbp), %rdi
call f8@PLT
movq %rax, -4416(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4424(%rbp)
movq -4424(%rbp), %rdi
call f8@PLT
movq %rax, -4432(%rbp)
leaq .Ldata_63(%rip), %rax
movq %rax, -4440(%rbp)
movabsq $11, %rax
movq %rax, -4448(%rbp)
movq -4440(%rbp), %rdi
movq -4448(%rbp), %rsi
call evn_text@PLT
movq %rax, -4456(%rbp)
movq -4456(%rbp), %rdi
call evn_output@PLT
movq %rax, -4464(%rbp)
call evn_void@PLT
movq %rax, -4472(%rbp)
leaq .Ldata_64(%rip), %rax
movq %rax, -4480(%rbp)
movabsq $10, %rax
movq %rax, -4488(%rbp)
movq -4480(%rbp), %rdi
movq -4488(%rbp), %rsi
call evn_text@PLT
movq %rax, -4496(%rbp)
movq -4496(%rbp), %rdi
call evn_output@PLT
movq %rax, -4504(%rbp)
call evn_void@PLT
movq %rax, -4512(%rbp)
leaq .Ldata_65(%rip), %rax
movq %rax, -4520(%rbp)
movabsq $13, %rax
movq %rax, -4528(%rbp)
movq -4520(%rbp), %rdi
movq -4528(%rbp), %rsi
call evn_text@PLT
movq %rax, -4536(%rbp)
movq -4536(%rbp), %rdi
call evn_output@PLT
movq %rax, -4544(%rbp)
call evn_void@PLT
movq %rax, -4552(%rbp)
leaq .Ldata_66(%rip), %rax
movq %rax, -4560(%rbp)
movabsq $13, %rax
movq %rax, -4568(%rbp)
movq -4560(%rbp), %rdi
movq -4568(%rbp), %rsi
call evn_text@PLT
movq %rax, -4576(%rbp)
movq -4576(%rbp), %rdi
call evn_output@PLT
movq %rax, -4584(%rbp)
call evn_void@PLT
movq %rax, -4592(%rbp)
call evn_void@PLT
movq %rax, -4600(%rbp)
movq -8(%rbp), %rdi
movq -4600(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -4608(%rbp)
movq -4608(%rbp), %rax
leave
ret
.Lf101_b14:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4288(%rbp)
movabsq $5, %rax
movq %rax, -4296(%rbp)
movq -4288(%rbp), %rdi
movq -4296(%rbp), %rsi
call evn_member@PLT
movq %rax, -4304(%rbp)
movabsq $0, %rax
movq %rax, -4312(%rbp)
movq -4312(%rbp), %rdi
call evn_int@PLT
movq %rax, -4320(%rbp)
movabsq $5, %rax
movq %rax, -4328(%rbp)
movq -4328(%rbp), %rdi
movq -4304(%rbp), %rsi
movq -4320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -4336(%rbp)
movq -4336(%rbp), %rax
movq %rax, -4272(%rbp)
jmp .Lf101_b15
.Lf101_b13:
movq -4032(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -4616(%rbp)
ud2
.Lf101_b12:
movq -4032(%rbp), %rdi
movq -4040(%rbp), %rsi
call evn_error@PLT
movq %rax, -4056(%rbp)
movq -264(%rbp), %rdi
movq -4056(%rbp), %rsi
call evn_store@PLT
movq %rax, -4064(%rbp)
movq -264(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4072(%rbp)
movabsq $2, %rax
movq %rax, -4080(%rbp)
movq -4072(%rbp), %rdi
movq -4080(%rbp), %rsi
call evn_member@PLT
movq %rax, -4088(%rbp)
leaq .Ldata_67(%rip), %rax
movq %rax, -4096(%rbp)
movabsq $13, %rax
movq %rax, -4104(%rbp)
movq -4096(%rbp), %rdi
movq -4104(%rbp), %rsi
call evn_text@PLT
movq %rax, -4112(%rbp)
movabsq $5, %rax
movq %rax, -4120(%rbp)
movq -4120(%rbp), %rdi
movq -4088(%rbp), %rsi
movq -4112(%rbp), %rdx
call evn_binary@PLT
movq %rax, -4128(%rbp)
leaq .Ldata_68(%rip), %rax
movq %rax, -4136(%rbp)
movabsq $22, %rax
movq %rax, -4144(%rbp)
movq -4136(%rbp), %rdi
movq -4144(%rbp), %rsi
call evn_text@PLT
movq %rax, -4152(%rbp)
movq -4128(%rbp), %rdi
movq -4152(%rbp), %rsi
call f123@PLT
movq %rax, -4160(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4168(%rbp)
movq -4168(%rbp), %rdi
call f74@PLT
movq %rax, -4176(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4184(%rbp)
movq -4184(%rbp), %rdi
call f74@PLT
movq %rax, -4192(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4200(%rbp)
movq -4200(%rbp), %rdi
call f52@PLT
movq %rax, -4208(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4216(%rbp)
movabsq $6, %rax
movq %rax, -4224(%rbp)
movq -4216(%rbp), %rdi
movq -4224(%rbp), %rsi
call evn_member@PLT
movq %rax, -4232(%rbp)
movabsq $0, %rax
movq %rax, -4240(%rbp)
movq -4240(%rbp), %rdi
call evn_int@PLT
movq %rax, -4248(%rbp)
movabsq $5, %rax
movq %rax, -4256(%rbp)
movq -4256(%rbp), %rdi
movq -4232(%rbp), %rsi
movq -4248(%rbp), %rdx
call evn_binary@PLT
movq %rax, -4264(%rbp)
movq -4264(%rbp), %rax
movq %rax, -4272(%rbp)
movq -4264(%rbp), %rdi
call evn_truth@PLT
movq %rax, -4280(%rbp)
cmpq $0, -4280(%rbp)
je .Lf101_b15
jmp .Lf101_b14
.Lf101_b11:
movq -272(%rbp), %rdi
movq -3984(%rbp), %rsi
call evn_store@PLT
movq %rax, -4624(%rbp)
movabsq $41, %rax
movq %rax, -4632(%rbp)
movabsq $1, %rax
movq %rax, -4640(%rbp)
movq -4632(%rbp), %rdi
movq -4640(%rbp), %rsi
call evn_object@PLT
movq %rax, -4648(%rbp)
leaq .Ldata_69(%rip), %rax
movq %rax, -4656(%rbp)
movabsq $27, %rax
movq %rax, -4664(%rbp)
movq -4656(%rbp), %rdi
movq -4664(%rbp), %rsi
call evn_text@PLT
movq %rax, -4672(%rbp)
movabsq $0, %rax
movq %rax, -4680(%rbp)
movq -4648(%rbp), %rdi
movq -4680(%rbp), %rsi
movq -4672(%rbp), %rdx
call evn_init@PLT
movq %rax, -4688(%rbp)
movabsq $0, %rax
movq %rax, -4696(%rbp)
movq -4648(%rbp), %rdi
movq -4696(%rbp), %rsi
call evn_fail@PLT
movq %rax, -4704(%rbp)
ud2
.Lf101_b10:
movq -3976(%rbp), %rdi
call evn_pop@PLT
movq %rax, -4024(%rbp)
call evn_saved@PLT
movq %rax, -4032(%rbp)
movabsq $9, %rax
movq %rax, -4040(%rbp)
movq -4032(%rbp), %rdi
movq -4040(%rbp), %rsi
call evn_match@PLT
movq %rax, -4048(%rbp)
cmpq $0, -4048(%rbp)
je .Lf101_b13
jmp .Lf101_b12
.Lf101_b9:
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3992(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -4000(%rbp)
movq -3992(%rbp), %rdi
movq -4000(%rbp), %rsi
call f93@PLT
movq %rax, -4008(%rbp)
movq -4008(%rbp), %rax
movq %rax, -3984(%rbp)
movq -3976(%rbp), %rdi
call evn_pop@PLT
movq %rax, -4016(%rbp)
jmp .Lf101_b11
.Lf101_b8:
leaq .Ldata_70(%rip), %rax
movq %rax, -3944(%rbp)
movabsq $23, %rax
movq %rax, -3952(%rbp)
movq -3944(%rbp), %rdi
movq -3952(%rbp), %rsi
call evn_text@PLT
movq %rax, -3960(%rbp)
movq -3824(%rbp), %rdi
movq -3960(%rbp), %rsi
call f123@PLT
movq %rax, -3968(%rbp)
call evn_frame@PLT
movq %rax, -3976(%rbp)
movq -3976(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf101_b10
jmp .Lf101_b9
.Lf101_b7:
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3840(%rbp)
movabsq $2, %rax
movq %rax, -3848(%rbp)
movq -3848(%rbp), %rdi
call evn_int@PLT
movq %rax, -3856(%rbp)
movabsq $1, %rax
movq %rax, -3864(%rbp)
movq -3864(%rbp), %rdi
call evn_int@PLT
movq %rax, -3872(%rbp)
movq -3840(%rbp), %rdi
movq -3856(%rbp), %rsi
movq -3872(%rbp), %rdx
call f76@PLT
movq %rax, -3880(%rbp)
movabsq $0, %rax
movq %rax, -3888(%rbp)
movq -3880(%rbp), %rdi
movq -3888(%rbp), %rsi
call evn_member@PLT
movq %rax, -3896(%rbp)
movq -248(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3904(%rbp)
movabsq $0, %rax
movq %rax, -3912(%rbp)
movq -3904(%rbp), %rdi
movq -3912(%rbp), %rsi
call evn_member@PLT
movq %rax, -3920(%rbp)
movabsq $5, %rax
movq %rax, -3928(%rbp)
movq -3928(%rbp), %rdi
movq -3896(%rbp), %rsi
movq -3920(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3936(%rbp)
movq -3936(%rbp), %rax
movq %rax, -3824(%rbp)
jmp .Lf101_b8
.Lf101_b6:
leaq .Ldata_71(%rip), %rax
movq %rax, -2616(%rbp)
movabsq $36, %rax
movq %rax, -2624(%rbp)
movq -2616(%rbp), %rdi
movq -2624(%rbp), %rsi
call evn_text@PLT
movq %rax, -2632(%rbp)
movq -2496(%rbp), %rdi
movq -2632(%rbp), %rsi
call f123@PLT
movq %rax, -2640(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2648(%rbp)
movabsq $1, %rax
movq %rax, -2656(%rbp)
movq -2656(%rbp), %rdi
call evn_bool@PLT
movq %rax, -2664(%rbp)
movq -2648(%rbp), %rdi
movq -2664(%rbp), %rsi
call f26@PLT
movq %rax, -2672(%rbp)
movq -176(%rbp), %rdi
movq -2672(%rbp), %rsi
call evn_store@PLT
movq %rax, -2680(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2688(%rbp)
movabsq $16777216, %rax
movq %rax, -2696(%rbp)
movq -2696(%rbp), %rdi
call evn_int@PLT
movq %rax, -2704(%rbp)
movq -2688(%rbp), %rdi
movq -2704(%rbp), %rsi
call f14@PLT
movq %rax, -2712(%rbp)
movq -184(%rbp), %rdi
movq -2712(%rbp), %rsi
call evn_store@PLT
movq %rax, -2720(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2728(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2736(%rbp)
movq -176(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2744(%rbp)
movq -184(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2752(%rbp)
movq -2728(%rbp), %rdi
movq -2736(%rbp), %rsi
movq -2744(%rbp), %rdx
movq -2752(%rbp), %rcx
call f94@PLT
movq %rax, -2760(%rbp)
movq -192(%rbp), %rdi
movq -2760(%rbp), %rsi
call evn_store@PLT
movq %rax, -2768(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2776(%rbp)
movabsq $32, %rax
movq %rax, -2784(%rbp)
movabsq $3, %rax
movq %rax, -2792(%rbp)
movq -2784(%rbp), %rdi
movq -2792(%rbp), %rsi
call evn_object@PLT
movq %rax, -2800(%rbp)
call f71@PLT
movq %rax, -2808(%rbp)
movabsq $0, %rax
movq %rax, -2816(%rbp)
movq -2800(%rbp), %rdi
movq -2816(%rbp), %rsi
movq -2808(%rbp), %rdx
call evn_init@PLT
movq %rax, -2824(%rbp)
call f71@PLT
movq %rax, -2832(%rbp)
movabsq $1, %rax
movq %rax, -2840(%rbp)
movq -2800(%rbp), %rdi
movq -2840(%rbp), %rsi
movq -2832(%rbp), %rdx
call evn_init@PLT
movq %rax, -2848(%rbp)
call f72@PLT
movq %rax, -2856(%rbp)
movabsq $2, %rax
movq %rax, -2864(%rbp)
movq -2800(%rbp), %rdi
movq -2864(%rbp), %rsi
movq -2856(%rbp), %rdx
call evn_init@PLT
movq %rax, -2872(%rbp)
movq -2776(%rbp), %rdi
movq -2800(%rbp), %rsi
call f92@PLT
movq %rax, -2880(%rbp)
movq -200(%rbp), %rdi
movq -2880(%rbp), %rsi
call evn_store@PLT
movq %rax, -2888(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2896(%rbp)
movabsq $32, %rax
movq %rax, -2904(%rbp)
movabsq $2, %rax
movq %rax, -2912(%rbp)
movq -2904(%rbp), %rdi
movq -2912(%rbp), %rsi
call evn_object@PLT
movq %rax, -2920(%rbp)
call f71@PLT
movq %rax, -2928(%rbp)
movabsq $0, %rax
movq %rax, -2936(%rbp)
movq -2920(%rbp), %rdi
movq -2936(%rbp), %rsi
movq -2928(%rbp), %rdx
call evn_init@PLT
movq %rax, -2944(%rbp)
call f71@PLT
movq %rax, -2952(%rbp)
movabsq $1, %rax
movq %rax, -2960(%rbp)
movq -2920(%rbp), %rdi
movq -2960(%rbp), %rsi
movq -2952(%rbp), %rdx
call evn_init@PLT
movq %rax, -2968(%rbp)
movq -2896(%rbp), %rdi
movq -2920(%rbp), %rsi
call f92@PLT
movq %rax, -2976(%rbp)
movq -208(%rbp), %rdi
movq -2976(%rbp), %rsi
call evn_store@PLT
movq %rax, -2984(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2992(%rbp)
movabsq $32, %rax
movq %rax, -3000(%rbp)
movabsq $1, %rax
movq %rax, -3008(%rbp)
movq -3000(%rbp), %rdi
movq -3008(%rbp), %rsi
call evn_object@PLT
movq %rax, -3016(%rbp)
call f71@PLT
movq %rax, -3024(%rbp)
movabsq $0, %rax
movq %rax, -3032(%rbp)
movq -3016(%rbp), %rdi
movq -3032(%rbp), %rsi
movq -3024(%rbp), %rdx
call evn_init@PLT
movq %rax, -3040(%rbp)
movq -2992(%rbp), %rdi
movq -3016(%rbp), %rsi
call f92@PLT
movq %rax, -3048(%rbp)
movq -216(%rbp), %rdi
movq -3048(%rbp), %rsi
call evn_store@PLT
movq %rax, -3056(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3064(%rbp)
movq -200(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3072(%rbp)
movabsq $0, %rax
movq %rax, -3080(%rbp)
movq -3080(%rbp), %rdi
call evn_int@PLT
movq %rax, -3088(%rbp)
movq -3064(%rbp), %rdi
movq -3072(%rbp), %rsi
movq -3088(%rbp), %rdx
call f91@PLT
movq %rax, -3096(%rbp)
movq -224(%rbp), %rdi
movq -3096(%rbp), %rsi
call evn_store@PLT
movq %rax, -3104(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3112(%rbp)
movq -200(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3120(%rbp)
movabsq $1, %rax
movq %rax, -3128(%rbp)
movq -3128(%rbp), %rdi
call evn_int@PLT
movq %rax, -3136(%rbp)
movq -3112(%rbp), %rdi
movq -3120(%rbp), %rsi
movq -3136(%rbp), %rdx
call f91@PLT
movq %rax, -3144(%rbp)
movq -232(%rbp), %rdi
movq -3144(%rbp), %rsi
call evn_store@PLT
movq %rax, -3152(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3160(%rbp)
movq -200(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3168(%rbp)
movabsq $2, %rax
movq %rax, -3176(%rbp)
movq -3176(%rbp), %rdi
call evn_int@PLT
movq %rax, -3184(%rbp)
movq -3160(%rbp), %rdi
movq -3168(%rbp), %rsi
movq -3184(%rbp), %rdx
call f91@PLT
movq %rax, -3192(%rbp)
movq -240(%rbp), %rdi
movq -3192(%rbp), %rsi
call evn_store@PLT
movq %rax, -3200(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3208(%rbp)
movq -208(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3216(%rbp)
movabsq $0, %rax
movq %rax, -3224(%rbp)
movq -3224(%rbp), %rdi
call evn_int@PLT
movq %rax, -3232(%rbp)
movq -3208(%rbp), %rdi
movq -3216(%rbp), %rsi
movq -3232(%rbp), %rdx
call f91@PLT
movq %rax, -3240(%rbp)
movq -248(%rbp), %rdi
movq -3240(%rbp), %rsi
call evn_store@PLT
movq %rax, -3248(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3256(%rbp)
movq -208(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3264(%rbp)
movabsq $1, %rax
movq %rax, -3272(%rbp)
movq -3272(%rbp), %rdi
call evn_int@PLT
movq %rax, -3280(%rbp)
movq -3256(%rbp), %rdi
movq -3264(%rbp), %rsi
movq -3280(%rbp), %rdx
call f91@PLT
movq %rax, -3288(%rbp)
movq -256(%rbp), %rdi
movq -3288(%rbp), %rsi
call evn_store@PLT
movq %rax, -3296(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3304(%rbp)
movq -200(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3312(%rbp)
movq -208(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3320(%rbp)
movabsq $38, %rax
movq %rax, -3328(%rbp)
movabsq $2, %rax
movq %rax, -3336(%rbp)
movq -3328(%rbp), %rdi
movq -3336(%rbp), %rsi
call evn_object@PLT
movq %rax, -3344(%rbp)
movq -224(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3352(%rbp)
movabsq $0, %rax
movq %rax, -3360(%rbp)
movq -3344(%rbp), %rdi
movq -3360(%rbp), %rsi
movq -3352(%rbp), %rdx
call evn_init@PLT
movq %rax, -3368(%rbp)
movq -232(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3376(%rbp)
movabsq $1, %rax
movq %rax, -3384(%rbp)
movq -3344(%rbp), %rdi
movq -3384(%rbp), %rsi
movq -3376(%rbp), %rdx
call evn_init@PLT
movq %rax, -3392(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3400(%rbp)
movq -3304(%rbp), %rdi
movq -3312(%rbp), %rsi
movq -3320(%rbp), %rdx
movq -3344(%rbp), %rcx
movq -3400(%rbp), %r8
call f79@PLT
movq %rax, -3408(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3416(%rbp)
movq -208(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3424(%rbp)
movq -240(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3432(%rbp)
movq -208(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3440(%rbp)
movabsq $38, %rax
movq %rax, -3448(%rbp)
movabsq $2, %rax
movq %rax, -3456(%rbp)
movq -3448(%rbp), %rdi
movq -3456(%rbp), %rsi
call evn_object@PLT
movq %rax, -3464(%rbp)
movq -256(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3472(%rbp)
movabsq $0, %rax
movq %rax, -3480(%rbp)
movq -3464(%rbp), %rdi
movq -3480(%rbp), %rsi
movq -3472(%rbp), %rdx
call evn_init@PLT
movq %rax, -3488(%rbp)
movq -248(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3496(%rbp)
movabsq $1, %rax
movq %rax, -3504(%rbp)
movq -3464(%rbp), %rdi
movq -3504(%rbp), %rsi
movq -3496(%rbp), %rdx
call evn_init@PLT
movq %rax, -3512(%rbp)
movq -216(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3520(%rbp)
movabsq $38, %rax
movq %rax, -3528(%rbp)
movabsq $1, %rax
movq %rax, -3536(%rbp)
movq -3528(%rbp), %rdi
movq -3536(%rbp), %rsi
call evn_object@PLT
movq %rax, -3544(%rbp)
movq -248(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3552(%rbp)
movabsq $0, %rax
movq %rax, -3560(%rbp)
movq -3544(%rbp), %rdi
movq -3560(%rbp), %rsi
movq -3552(%rbp), %rdx
call evn_init@PLT
movq %rax, -3568(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3576(%rbp)
movq -3416(%rbp), %rdi
movq -3424(%rbp), %rsi
movq -3432(%rbp), %rdx
movq -3440(%rbp), %rcx
movq -3464(%rbp), %r8
movq -3520(%rbp), %r9
pushq -3576(%rbp)
pushq -3544(%rbp)
call f78@PLT
addq $16, %rsp
movq %rax, -3584(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3592(%rbp)
movq -216(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3600(%rbp)
movabsq $38, %rax
movq %rax, -3608(%rbp)
movabsq $1, %rax
movq %rax, -3616(%rbp)
movq -3608(%rbp), %rdi
movq -3616(%rbp), %rsi
call evn_object@PLT
movq %rax, -3624(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3632(%rbp)
movq -216(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3640(%rbp)
movabsq $0, %rax
movq %rax, -3648(%rbp)
movq -3648(%rbp), %rdi
call evn_int@PLT
movq %rax, -3656(%rbp)
movq -3632(%rbp), %rdi
movq -3640(%rbp), %rsi
movq -3656(%rbp), %rdx
call f91@PLT
movq %rax, -3664(%rbp)
movabsq $0, %rax
movq %rax, -3672(%rbp)
movq -3624(%rbp), %rdi
movq -3672(%rbp), %rsi
movq -3664(%rbp), %rdx
call evn_init@PLT
movq %rax, -3680(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3688(%rbp)
movq -3592(%rbp), %rdi
movq -3600(%rbp), %rsi
movq -3624(%rbp), %rdx
movq -3688(%rbp), %rcx
call f77@PLT
movq %rax, -3696(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3704(%rbp)
movq -3704(%rbp), %rdi
call f75@PLT
movq %rax, -3712(%rbp)
movq -192(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3720(%rbp)
movabsq $2, %rax
movq %rax, -3728(%rbp)
movq -3728(%rbp), %rdi
call evn_int@PLT
movq %rax, -3736(%rbp)
movabsq $0, %rax
movq %rax, -3744(%rbp)
movq -3744(%rbp), %rdi
call evn_int@PLT
movq %rax, -3752(%rbp)
movq -3720(%rbp), %rdi
movq -3736(%rbp), %rsi
movq -3752(%rbp), %rdx
call f76@PLT
movq %rax, -3760(%rbp)
movabsq $0, %rax
movq %rax, -3768(%rbp)
movq -3760(%rbp), %rdi
movq -3768(%rbp), %rsi
call evn_member@PLT
movq %rax, -3776(%rbp)
movq -256(%rbp), %rdi
call evn_copy@PLT
movq %rax, -3784(%rbp)
movabsq $0, %rax
movq %rax, -3792(%rbp)
movq -3784(%rbp), %rdi
movq -3792(%rbp), %rsi
call evn_member@PLT
movq %rax, -3800(%rbp)
movabsq $5, %rax
movq %rax, -3808(%rbp)
movq -3808(%rbp), %rdi
movq -3776(%rbp), %rsi
movq -3800(%rbp), %rdx
call evn_binary@PLT
movq %rax, -3816(%rbp)
movq -3816(%rbp), %rax
movq %rax, -3824(%rbp)
movq -3816(%rbp), %rdi
call evn_truth@PLT
movq %rax, -3832(%rbp)
cmpq $0, -3832(%rbp)
je .Lf101_b8
jmp .Lf101_b7
.Lf101_b5:
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2512(%rbp)
movabsq $3, %rax
movq %rax, -2520(%rbp)
movq -2512(%rbp), %rdi
movq -2520(%rbp), %rsi
call evn_member@PLT
movq %rax, -2528(%rbp)
movabsq $4, %rax
movq %rax, -2536(%rbp)
movq -2528(%rbp), %rdi
movq -2536(%rbp), %rsi
call evn_member@PLT
movq %rax, -2544(%rbp)
movabsq $10, %rax
movq %rax, -2552(%rbp)
movq -2552(%rbp), %rdi
call evn_int@PLT
movq %rax, -2560(%rbp)
movabsq $3, %rax
movq %rax, -2568(%rbp)
movq -2568(%rbp), %rdi
movq -2544(%rbp), %rsi
movq -2560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2576(%rbp)
movabsq $4, %rax
movq %rax, -2584(%rbp)
movq -2584(%rbp), %rdi
call evn_int@PLT
movq %rax, -2592(%rbp)
movabsq $5, %rax
movq %rax, -2600(%rbp)
movq -2600(%rbp), %rdi
movq -2576(%rbp), %rsi
movq -2592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2608(%rbp)
movq -2608(%rbp), %rax
movq %rax, -2496(%rbp)
jmp .Lf101_b6
.Lf101_b4:
movq -2376(%rbp), %rax
movq %rax, -2496(%rbp)
movq -2376(%rbp), %rdi
call evn_truth@PLT
movq %rax, -2504(%rbp)
cmpq $0, -2504(%rbp)
je .Lf101_b6
jmp .Lf101_b5
.Lf101_b3:
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2392(%rbp)
movabsq $4, %rax
movq %rax, -2400(%rbp)
movq -2392(%rbp), %rdi
movq -2400(%rbp), %rsi
call evn_member@PLT
movq %rax, -2408(%rbp)
movabsq $4, %rax
movq %rax, -2416(%rbp)
movq -2408(%rbp), %rdi
movq -2416(%rbp), %rsi
call evn_member@PLT
movq %rax, -2424(%rbp)
movabsq $4, %rax
movq %rax, -2432(%rbp)
movq -2432(%rbp), %rdi
call evn_int@PLT
movq %rax, -2440(%rbp)
movabsq $3, %rax
movq %rax, -2448(%rbp)
movq -2448(%rbp), %rdi
movq -2424(%rbp), %rsi
movq -2440(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2456(%rbp)
movabsq $5, %rax
movq %rax, -2464(%rbp)
movq -2464(%rbp), %rdi
call evn_int@PLT
movq %rax, -2472(%rbp)
movabsq $5, %rax
movq %rax, -2480(%rbp)
movq -2480(%rbp), %rdi
movq -2456(%rbp), %rsi
movq -2472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2488(%rbp)
movq -2488(%rbp), %rax
movq %rax, -2376(%rbp)
jmp .Lf101_b4
.Lf101_b2:
leaq .Ldata_72(%rip), %rax
movq %rax, -864(%rbp)
movabsq $19, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_text@PLT
movq %rax, -880(%rbp)
movq -776(%rbp), %rdi
movq -880(%rbp), %rsi
call f123@PLT
movq %rax, -888(%rbp)
call f70@PLT
movq %rax, -896(%rbp)
movabsq $0, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_int@PLT
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
call evn_truth@PLT
movq %rax, -920(%rbp)
movq -48(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_index_ref@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
movq -896(%rbp), %rsi
call evn_store@PLT
movq %rax, -936(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -952(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movabsq $0, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
call evn_int@PLT
movq %rax, -976(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
movq -960(%rbp), %rdx
movq -976(%rbp), %rcx
call f63@PLT
movq %rax, -984(%rbp)
movabsq $0, %rax
movq %rax, -992(%rbp)
movq -984(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_member@PLT
movq %rax, -1000(%rbp)
movabsq $2, %rax
movq %rax, -1008(%rbp)
movq -1008(%rbp), %rdi
call evn_int@PLT
movq %rax, -1016(%rbp)
movabsq $5, %rax
movq %rax, -1024(%rbp)
movq -1024(%rbp), %rdi
movq -1000(%rbp), %rsi
movq -1016(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1032(%rbp)
leaq .Ldata_73(%rip), %rax
movq %rax, -1040(%rbp)
movabsq $30, %rax
movq %rax, -1048(%rbp)
movq -1040(%rbp), %rdi
movq -1048(%rbp), %rsi
call evn_text@PLT
movq %rax, -1056(%rbp)
movq -1032(%rbp), %rdi
movq -1056(%rbp), %rsi
call f123@PLT
movq %rax, -1064(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1072(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1080(%rbp)
movabsq $32, %rax
movq %rax, -1088(%rbp)
movabsq $3, %rax
movq %rax, -1096(%rbp)
movq -1088(%rbp), %rdi
movq -1096(%rbp), %rsi
call evn_object@PLT
movq %rax, -1104(%rbp)
call f71@PLT
movq %rax, -1112(%rbp)
movabsq $0, %rax
movq %rax, -1120(%rbp)
movq -1104(%rbp), %rdi
movq -1120(%rbp), %rsi
movq -1112(%rbp), %rdx
call evn_init@PLT
movq %rax, -1128(%rbp)
call f71@PLT
movq %rax, -1136(%rbp)
movabsq $1, %rax
movq %rax, -1144(%rbp)
movq -1104(%rbp), %rdi
movq -1144(%rbp), %rsi
movq -1136(%rbp), %rdx
call evn_init@PLT
movq %rax, -1152(%rbp)
call f72@PLT
movq %rax, -1160(%rbp)
movabsq $2, %rax
movq %rax, -1168(%rbp)
movq -1104(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1160(%rbp), %rdx
call evn_init@PLT
movq %rax, -1176(%rbp)
movabsq $32, %rax
movq %rax, -1184(%rbp)
movabsq $1, %rax
movq %rax, -1192(%rbp)
movq -1184(%rbp), %rdi
movq -1192(%rbp), %rsi
call evn_object@PLT
movq %rax, -1200(%rbp)
call f71@PLT
movq %rax, -1208(%rbp)
movabsq $0, %rax
movq %rax, -1216(%rbp)
movq -1200(%rbp), %rdi
movq -1216(%rbp), %rsi
movq -1208(%rbp), %rdx
call evn_init@PLT
movq %rax, -1224(%rbp)
movq -1072(%rbp), %rdi
movq -1080(%rbp), %rsi
movq -1104(%rbp), %rdx
movq -1200(%rbp), %rcx
call f59@PLT
movq %rax, -1232(%rbp)
movq -80(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_store@PLT
movq %rax, -1240(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1248(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1256(%rbp)
leaq .Ldata_74(%rip), %rax
movq %rax, -1264(%rbp)
movabsq $5, %rax
movq %rax, -1272(%rbp)
movq -1264(%rbp), %rdi
movq -1272(%rbp), %rsi
call evn_text@PLT
movq %rax, -1280(%rbp)
leaq .Ldata_75(%rip), %rax
movq %rax, -1288(%rbp)
movabsq $64, %rax
movq %rax, -1296(%rbp)
movq -1288(%rbp), %rdi
movq -1296(%rbp), %rsi
call evn_text@PLT
movq %rax, -1304(%rbp)
movabsq $128, %rax
movq %rax, -1312(%rbp)
movq -1312(%rbp), %rdi
call evn_int@PLT
movq %rax, -1320(%rbp)
movq -1248(%rbp), %rdi
movq -1256(%rbp), %rsi
movq -1280(%rbp), %rdx
movq -1304(%rbp), %rcx
movq -1320(%rbp), %r8
call f56@PLT
movq %rax, -1328(%rbp)
movq -88(%rbp), %rdi
movq -1328(%rbp), %rsi
call evn_store@PLT
movq %rax, -1336(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1344(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1352(%rbp)
leaq .Ldata_76(%rip), %rax
movq %rax, -1360(%rbp)
movabsq $5, %rax
movq %rax, -1368(%rbp)
movq -1360(%rbp), %rdi
movq -1368(%rbp), %rsi
call evn_text@PLT
movq %rax, -1376(%rbp)
leaq .Ldata_77(%rip), %rax
movq %rax, -1384(%rbp)
movabsq $64, %rax
movq %rax, -1392(%rbp)
movq -1384(%rbp), %rdi
movq -1392(%rbp), %rsi
call evn_text@PLT
movq %rax, -1400(%rbp)
movabsq $128, %rax
movq %rax, -1408(%rbp)
movq -1408(%rbp), %rdi
call evn_int@PLT
movq %rax, -1416(%rbp)
movq -1344(%rbp), %rdi
movq -1352(%rbp), %rsi
movq -1376(%rbp), %rdx
movq -1400(%rbp), %rcx
movq -1416(%rbp), %r8
call f56@PLT
movq %rax, -1424(%rbp)
movq -96(%rbp), %rdi
movq -1424(%rbp), %rsi
call evn_store@PLT
movq %rax, -1432(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1440(%rbp)
movabsq $0, %rax
movq %rax, -1448(%rbp)
movq -1440(%rbp), %rdi
movq -1448(%rbp), %rsi
call evn_member@PLT
movq %rax, -1456(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1464(%rbp)
movabsq $0, %rax
movq %rax, -1472(%rbp)
movq -1464(%rbp), %rdi
movq -1472(%rbp), %rsi
call evn_member@PLT
movq %rax, -1480(%rbp)
movabsq $5, %rax
movq %rax, -1488(%rbp)
movq -1488(%rbp), %rdi
movq -1456(%rbp), %rsi
movq -1480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1496(%rbp)
leaq .Ldata_78(%rip), %rax
movq %rax, -1504(%rbp)
movabsq $25, %rax
movq %rax, -1512(%rbp)
movq -1504(%rbp), %rdi
movq -1512(%rbp), %rsi
call evn_text@PLT
movq %rax, -1520(%rbp)
movq -1496(%rbp), %rdi
movq -1520(%rbp), %rsi
call f123@PLT
movq %rax, -1528(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1536(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1544(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1552(%rbp)
movabsq $0, %rax
movq %rax, -1560(%rbp)
movq -1560(%rbp), %rdi
call evn_int@PLT
movq %rax, -1568(%rbp)
movabsq $10, %rax
movq %rax, -1576(%rbp)
movq -1576(%rbp), %rdi
call evn_int@PLT
movq %rax, -1584(%rbp)
movabsq $2, %rax
movq %rax, -1592(%rbp)
movq -1592(%rbp), %rdi
call evn_int@PLT
movq %rax, -1600(%rbp)
movabsq $1, %rax
movq %rax, -1608(%rbp)
movq -1608(%rbp), %rdi
call evn_int@PLT
movq %rax, -1616(%rbp)
movabsq $3, %rax
movq %rax, -1624(%rbp)
movq -1624(%rbp), %rdi
call evn_int@PLT
movq %rax, -1632(%rbp)
movq -1536(%rbp), %rdi
movq -1544(%rbp), %rsi
movq -1552(%rbp), %rdx
movq -1568(%rbp), %rcx
movq -1584(%rbp), %r8
movq -1600(%rbp), %r9
pushq -1632(%rbp)
pushq -1616(%rbp)
call f55@PLT
addq $16, %rsp
movq %rax, -1640(%rbp)
movq -104(%rbp), %rdi
movq -1640(%rbp), %rsi
call evn_store@PLT
movq %rax, -1648(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1656(%rbp)
movq -1656(%rbp), %rdi
call f53@PLT
movq %rax, -1664(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1672(%rbp)
movabsq $1, %rax
movq %rax, -1680(%rbp)
movq -1680(%rbp), %rdi
call evn_bool@PLT
movq %rax, -1688(%rbp)
movq -1672(%rbp), %rdi
movq -1688(%rbp), %rsi
call f26@PLT
movq %rax, -1696(%rbp)
movq -112(%rbp), %rdi
movq -1696(%rbp), %rsi
call evn_store@PLT
movq %rax, -1704(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1712(%rbp)
movabsq $16777216, %rax
movq %rax, -1720(%rbp)
movq -1720(%rbp), %rdi
call evn_int@PLT
movq %rax, -1728(%rbp)
movq -1712(%rbp), %rdi
movq -1728(%rbp), %rsi
call f14@PLT
movq %rax, -1736(%rbp)
movq -120(%rbp), %rdi
movq -1736(%rbp), %rsi
call evn_store@PLT
movq %rax, -1744(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1752(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1760(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1768(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1776(%rbp)
movq -1752(%rbp), %rdi
movq -1760(%rbp), %rsi
movq -1768(%rbp), %rdx
movq -1776(%rbp), %rcx
call f94@PLT
movq %rax, -1784(%rbp)
movq -128(%rbp), %rdi
movq -1784(%rbp), %rsi
call evn_store@PLT
movq %rax, -1792(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1800(%rbp)
movabsq $32, %rax
movq %rax, -1808(%rbp)
movabsq $2, %rax
movq %rax, -1816(%rbp)
movq -1808(%rbp), %rdi
movq -1816(%rbp), %rsi
call evn_object@PLT
movq %rax, -1824(%rbp)
call f71@PLT
movq %rax, -1832(%rbp)
movabsq $0, %rax
movq %rax, -1840(%rbp)
movq -1824(%rbp), %rdi
movq -1840(%rbp), %rsi
movq -1832(%rbp), %rdx
call evn_init@PLT
movq %rax, -1848(%rbp)
call f71@PLT
movq %rax, -1856(%rbp)
movabsq $1, %rax
movq %rax, -1864(%rbp)
movq -1824(%rbp), %rdi
movq -1864(%rbp), %rsi
movq -1856(%rbp), %rdx
call evn_init@PLT
movq %rax, -1872(%rbp)
movq -1800(%rbp), %rdi
movq -1824(%rbp), %rsi
call f92@PLT
movq %rax, -1880(%rbp)
movq -136(%rbp), %rdi
movq -1880(%rbp), %rsi
call evn_store@PLT
movq %rax, -1888(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1896(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1904(%rbp)
movabsq $0, %rax
movq %rax, -1912(%rbp)
movq -1912(%rbp), %rdi
call evn_int@PLT
movq %rax, -1920(%rbp)
movq -1896(%rbp), %rdi
movq -1904(%rbp), %rsi
movq -1920(%rbp), %rdx
call f91@PLT
movq %rax, -1928(%rbp)
movq -144(%rbp), %rdi
movq -1928(%rbp), %rsi
call evn_store@PLT
movq %rax, -1936(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1944(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1952(%rbp)
movabsq $1, %rax
movq %rax, -1960(%rbp)
movq -1960(%rbp), %rdi
call evn_int@PLT
movq %rax, -1968(%rbp)
movq -1944(%rbp), %rdi
movq -1952(%rbp), %rsi
movq -1968(%rbp), %rdx
call f91@PLT
movq %rax, -1976(%rbp)
movq -152(%rbp), %rdi
movq -1976(%rbp), %rsi
call evn_store@PLT
movq %rax, -1984(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1992(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2000(%rbp)
movq -144(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2008(%rbp)
movq -152(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2016(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2024(%rbp)
movq -1992(%rbp), %rdi
movq -2000(%rbp), %rsi
movq -2008(%rbp), %rdx
movq -2016(%rbp), %rcx
movq -2024(%rbp), %r8
call f82@PLT
movq %rax, -2032(%rbp)
movq -160(%rbp), %rdi
movq -2032(%rbp), %rsi
call evn_store@PLT
movq %rax, -2040(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2048(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2056(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2064(%rbp)
movabsq $0, %rax
movq %rax, -2072(%rbp)
movq -2064(%rbp), %rdi
movq -2072(%rbp), %rsi
call evn_member@PLT
movq %rax, -2080(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2088(%rbp)
movq -2048(%rbp), %rdi
movq -2056(%rbp), %rsi
movq -2080(%rbp), %rdx
movq -2088(%rbp), %rcx
call f81@PLT
movq %rax, -2096(%rbp)
movq -168(%rbp), %rdi
movq -2096(%rbp), %rsi
call evn_store@PLT
movq %rax, -2104(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2112(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2120(%rbp)
movq -168(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2128(%rbp)
movabsq $1, %rax
movq %rax, -2136(%rbp)
movq -2136(%rbp), %rdi
call evn_int@PLT
movq %rax, -2144(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2152(%rbp)
movq -2112(%rbp), %rdi
movq -2120(%rbp), %rsi
movq -2128(%rbp), %rdx
movq -2144(%rbp), %rcx
movq -2152(%rbp), %r8
call f80@PLT
movq %rax, -2160(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2168(%rbp)
movq -136(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2176(%rbp)
movabsq $38, %rax
movq %rax, -2184(%rbp)
movabsq $2, %rax
movq %rax, -2192(%rbp)
movq -2184(%rbp), %rdi
movq -2192(%rbp), %rsi
call evn_object@PLT
movq %rax, -2200(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2208(%rbp)
movabsq $1, %rax
movq %rax, -2216(%rbp)
movq -2208(%rbp), %rdi
movq -2216(%rbp), %rsi
call evn_member@PLT
movq %rax, -2224(%rbp)
movabsq $0, %rax
movq %rax, -2232(%rbp)
movq -2200(%rbp), %rdi
movq -2232(%rbp), %rsi
movq -2224(%rbp), %rdx
call evn_init@PLT
movq %rax, -2240(%rbp)
movq -160(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2248(%rbp)
movabsq $0, %rax
movq %rax, -2256(%rbp)
movq -2248(%rbp), %rdi
movq -2256(%rbp), %rsi
call evn_member@PLT
movq %rax, -2264(%rbp)
movabsq $1, %rax
movq %rax, -2272(%rbp)
movq -2200(%rbp), %rdi
movq -2272(%rbp), %rsi
movq -2264(%rbp), %rdx
call evn_init@PLT
movq %rax, -2280(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2288(%rbp)
movq -2168(%rbp), %rdi
movq -2176(%rbp), %rsi
movq -2200(%rbp), %rdx
movq -2288(%rbp), %rcx
call f77@PLT
movq %rax, -2296(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2304(%rbp)
movq -2304(%rbp), %rdi
call f75@PLT
movq %rax, -2312(%rbp)
movq -128(%rbp), %rdi
call evn_copy@PLT
movq %rax, -2320(%rbp)
movabsq $8, %rax
movq %rax, -2328(%rbp)
movq -2320(%rbp), %rdi
movq -2328(%rbp), %rsi
call evn_member@PLT
movq %rax, -2336(%rbp)
movabsq $1, %rax
movq %rax, -2344(%rbp)
movq -2344(%rbp), %rdi
call evn_int@PLT
movq %rax, -2352(%rbp)
movabsq $5, %rax
movq %rax, -2360(%rbp)
movq -2360(%rbp), %rdi
movq -2336(%rbp), %rsi
movq -2352(%rbp), %rdx
call evn_binary@PLT
movq %rax, -2368(%rbp)
movq -2368(%rbp), %rax
movq %rax, -2376(%rbp)
movq -2368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -2384(%rbp)
cmpq $0, -2384(%rbp)
je .Lf101_b4
jmp .Lf101_b3
.Lf101_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -792(%rbp)
movabsq $5, %rax
movq %rax, -800(%rbp)
movq -792(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_member@PLT
movq %rax, -808(%rbp)
movabsq $4, %rax
movq %rax, -816(%rbp)
movq -808(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_member@PLT
movq %rax, -824(%rbp)
movabsq $6, %rax
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
call evn_int@PLT
movq %rax, -840(%rbp)
movabsq $5, %rax
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
movq -824(%rbp), %rsi
movq -840(%rbp), %rdx
call evn_binary@PLT
movq %rax, -856(%rbp)
movq -856(%rbp), %rax
movq %rax, -776(%rbp)
jmp .Lf101_b2
.Lf101_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -4704(%rbp), %rsi
leaq .Lroots_f101(%rip), %rdx
movq $588, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
call evn_void@PLT
movq %rax, -88(%rbp)
call evn_void@PLT
movq %rax, -96(%rbp)
call evn_void@PLT
movq %rax, -104(%rbp)
call evn_void@PLT
movq %rax, -112(%rbp)
call evn_void@PLT
movq %rax, -120(%rbp)
call evn_void@PLT
movq %rax, -128(%rbp)
call evn_void@PLT
movq %rax, -136(%rbp)
call evn_void@PLT
movq %rax, -144(%rbp)
call evn_void@PLT
movq %rax, -152(%rbp)
call evn_void@PLT
movq %rax, -160(%rbp)
call evn_void@PLT
movq %rax, -168(%rbp)
call evn_void@PLT
movq %rax, -176(%rbp)
call evn_void@PLT
movq %rax, -184(%rbp)
call evn_void@PLT
movq %rax, -192(%rbp)
call evn_void@PLT
movq %rax, -200(%rbp)
call evn_void@PLT
movq %rax, -208(%rbp)
call evn_void@PLT
movq %rax, -216(%rbp)
call evn_void@PLT
movq %rax, -224(%rbp)
call evn_void@PLT
movq %rax, -232(%rbp)
call evn_void@PLT
movq %rax, -240(%rbp)
call evn_void@PLT
movq %rax, -248(%rbp)
call evn_void@PLT
movq %rax, -256(%rbp)
call evn_void@PLT
movq %rax, -264(%rbp)
call evn_void@PLT
movq %rax, -272(%rbp)
call f28@PLT
movq %rax, -280(%rbp)
movq -16(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_store@PLT
movq %rax, -288(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movabsq $1, %rax
movq %rax, -304(%rbp)
movq -304(%rbp), %rdi
call evn_int@PLT
movq %rax, -312(%rbp)
movabsq $134217728, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movabsq $2147483648, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $268435456, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_int@PLT
movq %rax, -360(%rbp)
movq -296(%rbp), %rdi
movq -312(%rbp), %rsi
movq -328(%rbp), %rdx
movq -344(%rbp), %rcx
movq -360(%rbp), %r8
call f27@PLT
movq %rax, -368(%rbp)
movq -24(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_store@PLT
movq %rax, -376(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $16777216, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
call evn_int@PLT
movq %rax, -400(%rbp)
movq -384(%rbp), %rdi
movq -400(%rbp), %rsi
call f14@PLT
movq %rax, -408(%rbp)
movq -32(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_store@PLT
movq %rax, -416(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call f67@PLT
movq %rax, -440(%rbp)
movq -40(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_store@PLT
movq %rax, -448(%rbp)
movabsq $32, %rax
movq %rax, -456(%rbp)
movabsq $2, %rax
movq %rax, -464(%rbp)
movq -456(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_object@PLT
movq %rax, -472(%rbp)
call f71@PLT
movq %rax, -480(%rbp)
movabsq $0, %rax
movq %rax, -488(%rbp)
movq -472(%rbp), %rdi
movq -488(%rbp), %rsi
movq -480(%rbp), %rdx
call evn_init@PLT
movq %rax, -496(%rbp)
call f71@PLT
movq %rax, -504(%rbp)
movabsq $1, %rax
movq %rax, -512(%rbp)
movq -472(%rbp), %rdi
movq -512(%rbp), %rsi
movq -504(%rbp), %rdx
call evn_init@PLT
movq %rax, -520(%rbp)
movq -48(%rbp), %rdi
movq -472(%rbp), %rsi
call evn_store@PLT
movq %rax, -528(%rbp)
movabsq $32, %rax
movq %rax, -536(%rbp)
movabsq $2, %rax
movq %rax, -544(%rbp)
movq -536(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_object@PLT
movq %rax, -552(%rbp)
call f71@PLT
movq %rax, -560(%rbp)
movabsq $0, %rax
movq %rax, -568(%rbp)
movq -552(%rbp), %rdi
movq -568(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_init@PLT
movq %rax, -576(%rbp)
call f72@PLT
movq %rax, -584(%rbp)
movabsq $1, %rax
movq %rax, -592(%rbp)
movq -552(%rbp), %rdi
movq -592(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_init@PLT
movq %rax, -600(%rbp)
movq -56(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_store@PLT
movq %rax, -608(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -640(%rbp)
movq -616(%rbp), %rdi
movq -624(%rbp), %rsi
movq -632(%rbp), %rdx
movq -640(%rbp), %rcx
call f59@PLT
movq %rax, -648(%rbp)
movq -64(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_store@PLT
movq %rax, -656(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -672(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -680(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movq -664(%rbp), %rdi
movq -672(%rbp), %rsi
movq -680(%rbp), %rdx
movq -688(%rbp), %rcx
call f59@PLT
movq %rax, -696(%rbp)
movq -72(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_store@PLT
movq %rax, -704(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movabsq $0, %rax
movq %rax, -720(%rbp)
movq -712(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_member@PLT
movq %rax, -728(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $0, %rax
movq %rax, -744(%rbp)
movq -736(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member@PLT
movq %rax, -752(%rbp)
movabsq $5, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
movq -728(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_binary@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rax
movq %rax, -776(%rbp)
movq -768(%rbp), %rdi
call evn_truth@PLT
movq %rax, -784(%rbp)
cmpq $0, -784(%rbp)
je .Lf101_b2
jmp .Lf101_b1
.size f101, .-f101
.text
.p2align 4
.type f102, @function
f102:
pushq %rbp
movq %rsp, %rbp
subq $1888, %rsp
leaq -1888(%rbp), %rdi
movq $236, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf102_b0
.Lf102_b21:
leaq .Ldata_79(%rip), %rax
movq %rax, -1680(%rbp)
movabsq $24, %rax
movq %rax, -1688(%rbp)
movq -1680(%rbp), %rdi
movq -1688(%rbp), %rsi
call evn_text@PLT
movq %rax, -1696(%rbp)
movq -1608(%rbp), %rdi
movq -1696(%rbp), %rsi
call f123@PLT
movq %rax, -1704(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1712(%rbp)
movq -1712(%rbp), %rdi
call f8@PLT
movq %rax, -1720(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1728(%rbp)
movq -1728(%rbp), %rdi
call f8@PLT
movq %rax, -1736(%rbp)
leaq .Ldata_80(%rip), %rax
movq %rax, -1744(%rbp)
movabsq $8, %rax
movq %rax, -1752(%rbp)
movq -1744(%rbp), %rdi
movq -1752(%rbp), %rsi
call evn_text@PLT
movq %rax, -1760(%rbp)
movq -1760(%rbp), %rdi
call evn_output@PLT
movq %rax, -1768(%rbp)
call evn_void@PLT
movq %rax, -1776(%rbp)
call evn_void@PLT
movq %rax, -1784(%rbp)
movq -8(%rbp), %rdi
movq -1784(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1792(%rbp)
movq -1792(%rbp), %rax
leave
ret
.Lf102_b20:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1624(%rbp)
movabsq $5, %rax
movq %rax, -1632(%rbp)
movq -1624(%rbp), %rdi
movq -1632(%rbp), %rsi
call evn_member@PLT
movq %rax, -1640(%rbp)
movabsq $0, %rax
movq %rax, -1648(%rbp)
movq -1648(%rbp), %rdi
call evn_int@PLT
movq %rax, -1656(%rbp)
movabsq $5, %rax
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rdi
movq -1640(%rbp), %rsi
movq -1656(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1672(%rbp)
movq -1672(%rbp), %rax
movq %rax, -1608(%rbp)
jmp .Lf102_b21
.Lf102_b19:
leaq .Ldata_81(%rip), %rax
movq %rax, -1504(%rbp)
movabsq $14, %rax
movq %rax, -1512(%rbp)
movq -1504(%rbp), %rdi
movq -1512(%rbp), %rsi
call evn_text@PLT
movq %rax, -1520(%rbp)
movq -1416(%rbp), %rdi
movq -1520(%rbp), %rsi
call f123@PLT
movq %rax, -1528(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1536(%rbp)
movq -1536(%rbp), %rdi
call f35@PLT
movq %rax, -1544(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1552(%rbp)
movabsq $6, %rax
movq %rax, -1560(%rbp)
movq -1552(%rbp), %rdi
movq -1560(%rbp), %rsi
call evn_member@PLT
movq %rax, -1568(%rbp)
movabsq $0, %rax
movq %rax, -1576(%rbp)
movq -1576(%rbp), %rdi
call evn_int@PLT
movq %rax, -1584(%rbp)
movabsq $5, %rax
movq %rax, -1592(%rbp)
movq -1592(%rbp), %rdi
movq -1568(%rbp), %rsi
movq -1584(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1600(%rbp)
movq -1600(%rbp), %rax
movq %rax, -1608(%rbp)
movq -1600(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1616(%rbp)
cmpq $0, -1616(%rbp)
je .Lf102_b21
jmp .Lf102_b20
.Lf102_b18:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1432(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1440(%rbp)
movabsq $0, %rax
movq %rax, -1448(%rbp)
movq -1448(%rbp), %rdi
call evn_int@PLT
movq %rax, -1456(%rbp)
movq -1432(%rbp), %rdi
movq -1440(%rbp), %rsi
movq -1456(%rbp), %rdx
call f40@PLT
movq %rax, -1464(%rbp)
movabsq $0, %rax
movq %rax, -1472(%rbp)
movq -1472(%rbp), %rdi
call evn_int@PLT
movq %rax, -1480(%rbp)
movabsq $5, %rax
movq %rax, -1488(%rbp)
movq -1488(%rbp), %rdi
movq -1464(%rbp), %rsi
movq -1480(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1496(%rbp)
movq -1496(%rbp), %rax
movq %rax, -1416(%rbp)
jmp .Lf102_b19
.Lf102_b17:
movq -1312(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -1800(%rbp)
ud2
.Lf102_b16:
movq -1312(%rbp), %rdi
movq -1320(%rbp), %rsi
call evn_error@PLT
movq %rax, -1336(%rbp)
movq -64(%rbp), %rdi
movq -1336(%rbp), %rsi
call evn_store@PLT
movq %rax, -1344(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1352(%rbp)
movabsq $2, %rax
movq %rax, -1360(%rbp)
movq -1352(%rbp), %rdi
movq -1360(%rbp), %rsi
call evn_member@PLT
movq %rax, -1368(%rbp)
leaq .Ldata_82(%rip), %rax
movq %rax, -1376(%rbp)
movabsq $13, %rax
movq %rax, -1384(%rbp)
movq -1376(%rbp), %rdi
movq -1384(%rbp), %rsi
call evn_text@PLT
movq %rax, -1392(%rbp)
movabsq $5, %rax
movq %rax, -1400(%rbp)
movq -1400(%rbp), %rdi
movq -1368(%rbp), %rsi
movq -1392(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1408(%rbp)
movq -1408(%rbp), %rax
movq %rax, -1416(%rbp)
movq -1408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1424(%rbp)
cmpq $0, -1424(%rbp)
je .Lf102_b19
jmp .Lf102_b18
.Lf102_b15:
movq -72(%rbp), %rdi
movq -1264(%rbp), %rsi
call evn_store@PLT
movq %rax, -1808(%rbp)
movabsq $41, %rax
movq %rax, -1816(%rbp)
movabsq $1, %rax
movq %rax, -1824(%rbp)
movq -1816(%rbp), %rdi
movq -1824(%rbp), %rsi
call evn_object@PLT
movq %rax, -1832(%rbp)
leaq .Ldata_83(%rip), %rax
movq %rax, -1840(%rbp)
movabsq $24, %rax
movq %rax, -1848(%rbp)
movq -1840(%rbp), %rdi
movq -1848(%rbp), %rsi
call evn_text@PLT
movq %rax, -1856(%rbp)
movabsq $0, %rax
movq %rax, -1864(%rbp)
movq -1832(%rbp), %rdi
movq -1864(%rbp), %rsi
movq -1856(%rbp), %rdx
call evn_init@PLT
movq %rax, -1872(%rbp)
movabsq $0, %rax
movq %rax, -1880(%rbp)
movq -1832(%rbp), %rdi
movq -1880(%rbp), %rsi
call evn_fail@PLT
movq %rax, -1888(%rbp)
ud2
.Lf102_b14:
movq -1256(%rbp), %rdi
call evn_pop@PLT
movq %rax, -1304(%rbp)
call evn_saved@PLT
movq %rax, -1312(%rbp)
movabsq $9, %rax
movq %rax, -1320(%rbp)
movq -1312(%rbp), %rdi
movq -1320(%rbp), %rsi
call evn_match@PLT
movq %rax, -1328(%rbp)
cmpq $0, -1328(%rbp)
je .Lf102_b17
jmp .Lf102_b16
.Lf102_b13:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1272(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1280(%rbp)
movq -1272(%rbp), %rdi
movq -1280(%rbp), %rsi
call f118@PLT
movq %rax, -1288(%rbp)
movq -1288(%rbp), %rax
movq %rax, -1264(%rbp)
movq -1256(%rbp), %rdi
call evn_pop@PLT
movq %rax, -1296(%rbp)
jmp .Lf102_b15
.Lf102_b12:
leaq .Ldata_84(%rip), %rax
movq %rax, -1208(%rbp)
movabsq $15, %rax
movq %rax, -1216(%rbp)
movq -1208(%rbp), %rdi
movq -1216(%rbp), %rsi
call evn_text@PLT
movq %rax, -1224(%rbp)
movq -1120(%rbp), %rdi
movq -1224(%rbp), %rsi
call f123@PLT
movq %rax, -1232(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1240(%rbp)
movq -1240(%rbp), %rdi
call f37@PLT
movq %rax, -1248(%rbp)
call evn_frame@PLT
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf102_b14
jmp .Lf102_b13
.Lf102_b11:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1136(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1144(%rbp)
movabsq $256, %rax
movq %rax, -1152(%rbp)
movq -1152(%rbp), %rdi
call evn_int@PLT
movq %rax, -1160(%rbp)
movq -1136(%rbp), %rdi
movq -1144(%rbp), %rsi
movq -1160(%rbp), %rdx
call f40@PLT
movq %rax, -1168(%rbp)
movabsq $404, %rax
movq %rax, -1176(%rbp)
movq -1176(%rbp), %rdi
call evn_int@PLT
movq %rax, -1184(%rbp)
movabsq $5, %rax
movq %rax, -1192(%rbp)
movq -1192(%rbp), %rdi
movq -1168(%rbp), %rsi
movq -1184(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rax
movq %rax, -1120(%rbp)
jmp .Lf102_b12
.Lf102_b10:
movq -1032(%rbp), %rax
movq %rax, -1120(%rbp)
movq -1032(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1128(%rbp)
cmpq $0, -1128(%rbp)
je .Lf102_b12
jmp .Lf102_b11
.Lf102_b9:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1048(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1056(%rbp)
movabsq $255, %rax
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call evn_int@PLT
movq %rax, -1072(%rbp)
movq -1048(%rbp), %rdi
movq -1056(%rbp), %rsi
movq -1072(%rbp), %rdx
call f40@PLT
movq %rax, -1080(%rbp)
movabsq $303, %rax
movq %rax, -1088(%rbp)
movq -1088(%rbp), %rdi
call evn_int@PLT
movq %rax, -1096(%rbp)
movabsq $5, %rax
movq %rax, -1104(%rbp)
movq -1104(%rbp), %rdi
movq -1080(%rbp), %rsi
movq -1096(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rax
movq %rax, -1032(%rbp)
jmp .Lf102_b10
.Lf102_b8:
movq -944(%rbp), %rax
movq %rax, -1032(%rbp)
movq -944(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1040(%rbp)
cmpq $0, -1040(%rbp)
je .Lf102_b10
jmp .Lf102_b9
.Lf102_b7:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -968(%rbp)
movabsq $16, %rax
movq %rax, -976(%rbp)
movq -976(%rbp), %rdi
call evn_int@PLT
movq %rax, -984(%rbp)
movq -960(%rbp), %rdi
movq -968(%rbp), %rsi
movq -984(%rbp), %rdx
call f40@PLT
movq %rax, -992(%rbp)
movabsq $202, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
call evn_int@PLT
movq %rax, -1008(%rbp)
movabsq $5, %rax
movq %rax, -1016(%rbp)
movq -1016(%rbp), %rdi
movq -992(%rbp), %rsi
movq -1008(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1024(%rbp)
movq -1024(%rbp), %rax
movq %rax, -944(%rbp)
jmp .Lf102_b8
.Lf102_b6:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -648(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -656(%rbp)
movabsq $15, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
call evn_int@PLT
movq %rax, -672(%rbp)
movabsq $101, %rax
movq %rax, -680(%rbp)
movq -680(%rbp), %rdi
call evn_int@PLT
movq %rax, -688(%rbp)
movq -648(%rbp), %rdi
movq -656(%rbp), %rsi
movq -672(%rbp), %rdx
movq -688(%rbp), %rcx
call f39@PLT
movq %rax, -696(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -712(%rbp)
movabsq $16, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_int@PLT
movq %rax, -728(%rbp)
movabsq $202, %rax
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
call evn_int@PLT
movq %rax, -744(%rbp)
movq -704(%rbp), %rdi
movq -712(%rbp), %rsi
movq -728(%rbp), %rdx
movq -744(%rbp), %rcx
call f39@PLT
movq %rax, -752(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -768(%rbp)
movabsq $255, %rax
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
call evn_int@PLT
movq %rax, -784(%rbp)
movabsq $303, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movq -760(%rbp), %rdi
movq -768(%rbp), %rsi
movq -784(%rbp), %rdx
movq -800(%rbp), %rcx
call f39@PLT
movq %rax, -808(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -824(%rbp)
movabsq $256, %rax
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
call evn_int@PLT
movq %rax, -840(%rbp)
movabsq $404, %rax
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
call evn_int@PLT
movq %rax, -856(%rbp)
movq -816(%rbp), %rdi
movq -824(%rbp), %rsi
movq -840(%rbp), %rdx
movq -856(%rbp), %rcx
call f39@PLT
movq %rax, -864(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -880(%rbp)
movabsq $15, %rax
movq %rax, -888(%rbp)
movq -888(%rbp), %rdi
call evn_int@PLT
movq %rax, -896(%rbp)
movq -872(%rbp), %rdi
movq -880(%rbp), %rsi
movq -896(%rbp), %rdx
call f40@PLT
movq %rax, -904(%rbp)
movabsq $101, %rax
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
call evn_int@PLT
movq %rax, -920(%rbp)
movabsq $5, %rax
movq %rax, -928(%rbp)
movq -928(%rbp), %rdi
movq -904(%rbp), %rsi
movq -920(%rbp), %rdx
call evn_binary@PLT
movq %rax, -936(%rbp)
movq -936(%rbp), %rax
movq %rax, -944(%rbp)
movq -936(%rbp), %rdi
call evn_truth@PLT
movq %rax, -952(%rbp)
cmpq $0, -952(%rbp)
je .Lf102_b8
jmp .Lf102_b7
.Lf102_b5:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -480(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -496(%rbp)
movq -480(%rbp), %rdi
movq -488(%rbp), %rsi
movq -496(%rbp), %rdx
call f40@PLT
movq %rax, -504(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movabsq $3, %rax
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call evn_int@PLT
movq %rax, -528(%rbp)
movabsq $2, %rax
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
movq -512(%rbp), %rsi
movq -528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -544(%rbp)
movabsq $5, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
movq -504(%rbp), %rsi
movq -544(%rbp), %rdx
call evn_binary@PLT
movq %rax, -560(%rbp)
leaq .Ldata_85(%rip), %rax
movq %rax, -568(%rbp)
movabsq $19, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_text@PLT
movq %rax, -584(%rbp)
movq -560(%rbp), %rdi
movq -584(%rbp), %rsi
call f123@PLT
movq %rax, -592(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $1, %rax
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call evn_int@PLT
movq %rax, -616(%rbp)
movabsq $0, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
movq -600(%rbp), %rsi
movq -616(%rbp), %rdx
call evn_binary@PLT
movq %rax, -632(%rbp)
movq -48(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_store@PLT
movq %rax, -640(%rbp)
jmp .Lf102_b4
.Lf102_b4:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $300, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movabsq $7, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_truth@PLT
movq %rax, -472(%rbp)
cmpq $0, -472(%rbp)
je .Lf102_b6
jmp .Lf102_b5
.Lf102_b3:
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movq -48(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_store@PLT
movq %rax, -424(%rbp)
jmp .Lf102_b4
.Lf102_b2:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -296(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $3, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movabsq $2, %rax
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
movq -304(%rbp), %rsi
movq -320(%rbp), %rdx
call evn_binary@PLT
movq %rax, -336(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
movq -336(%rbp), %rdx
call f38@PLT
movq %rax, -344(%rbp)
movq -56(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $1, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movabsq $0, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -48(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_store@PLT
movq %rax, -400(%rbp)
jmp .Lf102_b1
.Lf102_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $300, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_int@PLT
movq %rax, -256(%rbp)
movabsq $7, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
movq -240(%rbp), %rsi
movq -256(%rbp), %rdx
call evn_binary@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_truth@PLT
movq %rax, -280(%rbp)
cmpq $0, -280(%rbp)
je .Lf102_b3
jmp .Lf102_b2
.Lf102_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1888(%rbp), %rsi
leaq .Lroots_f102(%rip), %rdx
movq $236, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call f28@PLT
movq %rax, -80(%rbp)
movq -16(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_store@PLT
movq %rax, -88(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -96(%rbp)
movabsq $1, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_bool@PLT
movq %rax, -112(%rbp)
movq -96(%rbp), %rdi
movq -112(%rbp), %rsi
call f26@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $16777216, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movq -136(%rbp), %rdi
movq -152(%rbp), %rsi
call f14@PLT
movq %rax, -160(%rbp)
movq -32(%rbp), %rdi
movq -160(%rbp), %rsi
call evn_store@PLT
movq %rax, -168(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $400, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -176(%rbp), %rdi
movq -192(%rbp), %rsi
call f50@PLT
movq %rax, -200(%rbp)
movq -40(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
movabsq $0, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movq -48(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
jmp .Lf102_b1
.size f102, .-f102
.text
.p2align 4
.type f103, @function
f103:
pushq %rbp
movq %rsp, %rbp
subq $688, %rsp
leaq -680(%rbp), %rdi
movq $85, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf103_b0
.Lf103_b9:
leaq .Ldata_86(%rip), %rax
movq %rax, -472(%rbp)
movabsq $26, %rax
movq %rax, -480(%rbp)
movq -472(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_text@PLT
movq %rax, -488(%rbp)
movq -400(%rbp), %rdi
movq -488(%rbp), %rsi
call f123@PLT
movq %rax, -496(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call f17@PLT
movq %rax, -512(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -520(%rbp)
movq -520(%rbp), %rdi
call f8@PLT
movq %rax, -528(%rbp)
leaq .Ldata_87(%rip), %rax
movq %rax, -536(%rbp)
movabsq $19, %rax
movq %rax, -544(%rbp)
movq -536(%rbp), %rdi
movq -544(%rbp), %rsi
call evn_text@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_output@PLT
movq %rax, -560(%rbp)
call evn_void@PLT
movq %rax, -568(%rbp)
call evn_void@PLT
movq %rax, -576(%rbp)
movq -8(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -584(%rbp)
movq -584(%rbp), %rax
leave
ret
.Lf103_b8:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $6, %rax
movq %rax, -424(%rbp)
movq -416(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_member@PLT
movq %rax, -432(%rbp)
movabsq $9223372036854775807, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movabsq $5, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
movq %rax, -400(%rbp)
jmp .Lf103_b9
.Lf103_b7:
movq -328(%rbp), %rax
movq %rax, -400(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -408(%rbp)
cmpq $0, -408(%rbp)
je .Lf103_b9
jmp .Lf103_b8
.Lf103_b6:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $0, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movabsq $0, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movabsq $5, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rax
movq %rax, -328(%rbp)
jmp .Lf103_b7
.Lf103_b5:
movq -224(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -592(%rbp)
ud2
.Lf103_b4:
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_error@PLT
movq %rax, -248(%rbp)
movq -32(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_store@PLT
movq %rax, -256(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $2, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
leaq .Ldata_88(%rip), %rax
movq %rax, -288(%rbp)
movabsq $14, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_text@PLT
movq %rax, -304(%rbp)
movabsq $5, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -280(%rbp), %rsi
movq -304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf103_b7
jmp .Lf103_b6
.Lf103_b3:
movq -40(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_store@PLT
movq %rax, -600(%rbp)
movabsq $41, %rax
movq %rax, -608(%rbp)
movabsq $1, %rax
movq %rax, -616(%rbp)
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
call evn_object@PLT
movq %rax, -624(%rbp)
leaq .Ldata_89(%rip), %rax
movq %rax, -632(%rbp)
movabsq $20, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_text@PLT
movq %rax, -648(%rbp)
movabsq $0, %rax
movq %rax, -656(%rbp)
movq -624(%rbp), %rdi
movq -656(%rbp), %rsi
movq -648(%rbp), %rdx
call evn_init@PLT
movq %rax, -664(%rbp)
movabsq $0, %rax
movq %rax, -672(%rbp)
movq -624(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_fail@PLT
movq %rax, -680(%rbp)
ud2
.Lf103_b2:
movq -160(%rbp), %rdi
call evn_pop@PLT
movq %rax, -216(%rbp)
call evn_saved@PLT
movq %rax, -224(%rbp)
movabsq $9, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_match@PLT
movq %rax, -240(%rbp)
cmpq $0, -240(%rbp)
je .Lf103_b5
jmp .Lf103_b4
.Lf103_b1:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -176(%rbp)
movabsq $1, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -176(%rbp), %rdi
movq -192(%rbp), %rsi
call f22@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
call evn_pop@PLT
movq %rax, -208(%rbp)
jmp .Lf103_b3
.Lf103_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -680(%rbp), %rsi
leaq .Lroots_f103(%rip), %rdx
movq $85, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movabsq $9223372036854775807, %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_int@PLT
movq %rax, -56(%rbp)
movabsq $9223372036854775807, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $100, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movq -56(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call f29@PLT
movq %rax, -96(%rbp)
movq -16(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $9223372036854775807, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movq -112(%rbp), %rdi
movq -128(%rbp), %rsi
call f22@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call f20@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_store@PLT
movq %rax, -152(%rbp)
call evn_frame@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf103_b2
jmp .Lf103_b1
.size f103, .-f103
.text
.p2align 4
.type f104, @function
f104:
pushq %rbp
movq %rsp, %rbp
subq $1072, %rsp
leaq -1064(%rbp), %rdi
movq $133, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf104_b0
.Lf104_b11:
movq -768(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -976(%rbp)
ud2
.Lf104_b10:
movq -768(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_error@PLT
movq %rax, -792(%rbp)
movq -56(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_store@PLT
movq %rax, -800(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movabsq $2, %rax
movq %rax, -816(%rbp)
movq -808(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_member@PLT
movq %rax, -824(%rbp)
leaq .Ldata_90(%rip), %rax
movq %rax, -832(%rbp)
movabsq $13, %rax
movq %rax, -840(%rbp)
movq -832(%rbp), %rdi
movq -840(%rbp), %rsi
call evn_text@PLT
movq %rax, -848(%rbp)
movabsq $5, %rax
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
movq -824(%rbp), %rsi
movq -848(%rbp), %rdx
call evn_binary@PLT
movq %rax, -864(%rbp)
leaq .Ldata_91(%rip), %rax
movq %rax, -872(%rbp)
movabsq $22, %rax
movq %rax, -880(%rbp)
movq -872(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_text@PLT
movq %rax, -888(%rbp)
movq -864(%rbp), %rdi
movq -888(%rbp), %rsi
call f123@PLT
movq %rax, -896(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call f8@PLT
movq %rax, -912(%rbp)
leaq .Ldata_92(%rip), %rax
movq %rax, -920(%rbp)
movabsq $10, %rax
movq %rax, -928(%rbp)
movq -920(%rbp), %rdi
movq -928(%rbp), %rsi
call evn_text@PLT
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
call evn_output@PLT
movq %rax, -944(%rbp)
call evn_void@PLT
movq %rax, -952(%rbp)
call evn_void@PLT
movq %rax, -960(%rbp)
movq -8(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -968(%rbp)
movq -968(%rbp), %rax
leave
ret
.Lf104_b9:
movq -64(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_store@PLT
movq %rax, -984(%rbp)
movabsq $41, %rax
movq %rax, -992(%rbp)
movabsq $1, %rax
movq %rax, -1000(%rbp)
movq -992(%rbp), %rdi
movq -1000(%rbp), %rsi
call evn_object@PLT
movq %rax, -1008(%rbp)
leaq .Ldata_93(%rip), %rax
movq %rax, -1016(%rbp)
movabsq $28, %rax
movq %rax, -1024(%rbp)
movq -1016(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_text@PLT
movq %rax, -1032(%rbp)
movabsq $0, %rax
movq %rax, -1040(%rbp)
movq -1008(%rbp), %rdi
movq -1040(%rbp), %rsi
movq -1032(%rbp), %rdx
call evn_init@PLT
movq %rax, -1048(%rbp)
movabsq $0, %rax
movq %rax, -1056(%rbp)
movq -1008(%rbp), %rdi
movq -1056(%rbp), %rsi
call evn_fail@PLT
movq %rax, -1064(%rbp)
ud2
.Lf104_b8:
movq -720(%rbp), %rdi
call evn_pop@PLT
movq %rax, -760(%rbp)
call evn_saved@PLT
movq %rax, -768(%rbp)
movabsq $9, %rax
movq %rax, -776(%rbp)
movq -768(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_match@PLT
movq %rax, -784(%rbp)
cmpq $0, -784(%rbp)
je .Lf104_b11
jmp .Lf104_b10
.Lf104_b7:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
call f120@PLT
movq %rax, -744(%rbp)
movq -744(%rbp), %rax
movq %rax, -728(%rbp)
movq -720(%rbp), %rdi
call evn_pop@PLT
movq %rax, -752(%rbp)
jmp .Lf104_b9
.Lf104_b6:
leaq .Ldata_94(%rip), %rax
movq %rax, -688(%rbp)
movabsq $32, %rax
movq %rax, -696(%rbp)
movq -688(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_text@PLT
movq %rax, -704(%rbp)
movq -616(%rbp), %rdi
movq -704(%rbp), %rsi
call f123@PLT
movq %rax, -712(%rbp)
call evn_frame@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf104_b8
jmp .Lf104_b7
.Lf104_b5:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $0, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_member@PLT
movq %rax, -648(%rbp)
movabsq $5, %rax
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_int@PLT
movq %rax, -664(%rbp)
movabsq $5, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
movq -648(%rbp), %rsi
movq -664(%rbp), %rdx
call evn_binary@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
movq %rax, -616(%rbp)
jmp .Lf104_b6
.Lf104_b4:
movq -544(%rbp), %rax
movq %rax, -616(%rbp)
movq -544(%rbp), %rdi
call evn_truth@PLT
movq %rax, -624(%rbp)
cmpq $0, -624(%rbp)
je .Lf104_b6
jmp .Lf104_b5
.Lf104_b3:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $2, %rax
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_member@PLT
movq %rax, -576(%rbp)
movabsq $8, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $5, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rax
movq %rax, -544(%rbp)
jmp .Lf104_b4
.Lf104_b2:
movq -472(%rbp), %rax
movq %rax, -544(%rbp)
movq -472(%rbp), %rdi
call evn_truth@PLT
movq %rax, -552(%rbp)
cmpq $0, -552(%rbp)
je .Lf104_b4
jmp .Lf104_b3
.Lf104_b1:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $5, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movabsq $0, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_int@PLT
movq %rax, -520(%rbp)
movabsq $5, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
movq -504(%rbp), %rsi
movq -520(%rbp), %rdx
call evn_binary@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
movq %rax, -472(%rbp)
jmp .Lf104_b2
.Lf104_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1064(%rbp), %rsi
leaq .Lroots_f104(%rip), %rdx
movq $133, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
movabsq $100, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $100, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movabsq $100, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movq -80(%rbp), %rdi
movq -96(%rbp), %rsi
movq -112(%rbp), %rdx
call f29@PLT
movq %rax, -120(%rbp)
movq -16(%rbp), %rdi
movq -120(%rbp), %rsi
call evn_store@PLT
movq %rax, -128(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movabsq $2, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $100, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $100, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $100, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movq -136(%rbp), %rdi
movq -152(%rbp), %rsi
movq -168(%rbp), %rdx
movq -184(%rbp), %rcx
movq -200(%rbp), %r8
call f27@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_store@PLT
movq %rax, -216(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -224(%rbp)
movabsq $8, %rax
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call evn_int@PLT
movq %rax, -240(%rbp)
movq -224(%rbp), %rdi
movq -240(%rbp), %rsi
call f22@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call f20@PLT
movq %rax, -256(%rbp)
movq -32(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $4, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movq -272(%rbp), %rdi
movq -288(%rbp), %rsi
call f22@PLT
movq %rax, -296(%rbp)
movq -40(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_store@PLT
movq %rax, -304(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movabsq $100, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
call evn_int@PLT
movq %rax, -328(%rbp)
movq -312(%rbp), %rdi
movq -328(%rbp), %rsi
call f14@PLT
movq %rax, -336(%rbp)
movq -48(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_store@PLT
movq %rax, -344(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $5, %rax
movq %rax, -360(%rbp)
movq -360(%rbp), %rdi
call evn_int@PLT
movq %rax, -368(%rbp)
movq -352(%rbp), %rdi
movq -368(%rbp), %rsi
call f11@PLT
movq %rax, -376(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call f10@PLT
movq %rax, -392(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
call f6@PLT
movq %rax, -408(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $6, %rax
movq %rax, -424(%rbp)
movq -416(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_member@PLT
movq %rax, -432(%rbp)
movabsq $0, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movabsq $5, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
movq %rax, -472(%rbp)
movq -464(%rbp), %rdi
call evn_truth@PLT
movq %rax, -480(%rbp)
cmpq $0, -480(%rbp)
je .Lf104_b2
jmp .Lf104_b1
.size f104, .-f104
.text
.p2align 4
.type f105, @function
f105:
pushq %rbp
movq %rsp, %rbp
subq $784, %rsp
leaq -784(%rbp), %rdi
movq $98, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf105_b0
.Lf105_b9:
leaq .Ldata_95(%rip), %rax
movq %rax, -560(%rbp)
movabsq $20, %rax
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_text@PLT
movq %rax, -576(%rbp)
movq -488(%rbp), %rdi
movq -576(%rbp), %rsi
call f123@PLT
movq %rax, -584(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
call f18@PLT
movq %rax, -600(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rdi
call f8@PLT
movq %rax, -616(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
call f8@PLT
movq %rax, -632(%rbp)
leaq .Ldata_96(%rip), %rax
movq %rax, -640(%rbp)
movabsq $9, %rax
movq %rax, -648(%rbp)
movq -640(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_text@PLT
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_output@PLT
movq %rax, -664(%rbp)
call evn_void@PLT
movq %rax, -672(%rbp)
call evn_void@PLT
movq %rax, -680(%rbp)
movq -8(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -688(%rbp)
movq -688(%rbp), %rax
leave
ret
.Lf105_b8:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movabsq $5, %rax
movq %rax, -512(%rbp)
movq -504(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_member@PLT
movq %rax, -520(%rbp)
movabsq $8, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call evn_int@PLT
movq %rax, -536(%rbp)
movabsq $5, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
movq -520(%rbp), %rsi
movq -536(%rbp), %rdx
call evn_binary@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rax
movq %rax, -488(%rbp)
jmp .Lf105_b9
.Lf105_b7:
movq -416(%rbp), %rax
movq %rax, -488(%rbp)
movq -416(%rbp), %rdi
call evn_truth@PLT
movq %rax, -496(%rbp)
cmpq $0, -496(%rbp)
je .Lf105_b9
jmp .Lf105_b8
.Lf105_b6:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $6, %rax
movq %rax, -440(%rbp)
movq -432(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_member@PLT
movq %rax, -448(%rbp)
movabsq $0, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
movq -448(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_binary@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
movq %rax, -416(%rbp)
jmp .Lf105_b7
.Lf105_b5:
movq -312(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -696(%rbp)
ud2
.Lf105_b4:
movq -312(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_error@PLT
movq %rax, -336(%rbp)
movq -40(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_store@PLT
movq %rax, -344(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $2, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
leaq .Ldata_97(%rip), %rax
movq %rax, -376(%rbp)
movabsq $9, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_text@PLT
movq %rax, -392(%rbp)
movabsq $5, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -368(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_binary@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -424(%rbp)
cmpq $0, -424(%rbp)
je .Lf105_b7
jmp .Lf105_b6
.Lf105_b3:
movq -48(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_store@PLT
movq %rax, -704(%rbp)
movabsq $41, %rax
movq %rax, -712(%rbp)
movabsq $1, %rax
movq %rax, -720(%rbp)
movq -712(%rbp), %rdi
movq -720(%rbp), %rsi
call evn_object@PLT
movq %rax, -728(%rbp)
leaq .Ldata_98(%rip), %rax
movq %rax, -736(%rbp)
movabsq $28, %rax
movq %rax, -744(%rbp)
movq -736(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_text@PLT
movq %rax, -752(%rbp)
movabsq $0, %rax
movq %rax, -760(%rbp)
movq -728(%rbp), %rdi
movq -760(%rbp), %rsi
movq -752(%rbp), %rdx
call evn_init@PLT
movq %rax, -768(%rbp)
movabsq $0, %rax
movq %rax, -776(%rbp)
movq -728(%rbp), %rdi
movq -776(%rbp), %rsi
call evn_fail@PLT
movq %rax, -784(%rbp)
ud2
.Lf105_b2:
movq -264(%rbp), %rdi
call evn_pop@PLT
movq %rax, -304(%rbp)
call evn_saved@PLT
movq %rax, -312(%rbp)
movabsq $9, %rax
movq %rax, -320(%rbp)
movq -312(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_match@PLT
movq %rax, -328(%rbp)
cmpq $0, -328(%rbp)
je .Lf105_b5
jmp .Lf105_b4
.Lf105_b1:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call f121@PLT
movq %rax, -288(%rbp)
movq -288(%rbp), %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
call evn_pop@PLT
movq %rax, -296(%rbp)
jmp .Lf105_b3
.Lf105_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -784(%rbp), %rsi
leaq .Lroots_f105(%rip), %rdx
movq $98, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movabsq $100, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $100, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $100, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call f29@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $100, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $100, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $100, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movq -120(%rbp), %rdi
movq -136(%rbp), %rsi
movq -152(%rbp), %rdx
movq -168(%rbp), %rcx
movq -184(%rbp), %r8
call f27@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_store@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $8, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movq -208(%rbp), %rdi
movq -224(%rbp), %rsi
call f22@PLT
movq %rax, -232(%rbp)
movq -32(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -240(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call f10@PLT
movq %rax, -256(%rbp)
call evn_frame@PLT
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf105_b2
jmp .Lf105_b1
.size f105, .-f105
.text
.p2align 4
.type f106, @function
f106:
pushq %rbp
movq %rsp, %rbp
subq $1248, %rsp
leaq -1240(%rbp), %rdi
movq $155, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf106_b0
.Lf106_b9:
leaq .Ldata_99(%rip), %rax
movq %rax, -752(%rbp)
movabsq $36, %rax
movq %rax, -760(%rbp)
movq -752(%rbp), %rdi
movq -760(%rbp), %rsi
call evn_text@PLT
movq %rax, -768(%rbp)
movq -680(%rbp), %rdi
movq -768(%rbp), %rsi
call f123@PLT
movq %rax, -776(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -784(%rbp)
movabsq $2, %rax
movq %rax, -792(%rbp)
movq -792(%rbp), %rdi
call evn_int@PLT
movq %rax, -800(%rbp)
movabsq $100, %rax
movq %rax, -808(%rbp)
movq -808(%rbp), %rdi
call evn_int@PLT
movq %rax, -816(%rbp)
movabsq $100, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call evn_int@PLT
movq %rax, -832(%rbp)
movabsq $100, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
call evn_int@PLT
movq %rax, -848(%rbp)
movq -784(%rbp), %rdi
movq -800(%rbp), %rsi
movq -816(%rbp), %rdx
movq -832(%rbp), %rcx
movq -848(%rbp), %r8
call f27@PLT
movq %rax, -856(%rbp)
movq -64(%rbp), %rdi
movq -856(%rbp), %rsi
call evn_store@PLT
movq %rax, -864(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movabsq $100, %rax
movq %rax, -880(%rbp)
movq -880(%rbp), %rdi
call evn_int@PLT
movq %rax, -888(%rbp)
movq -872(%rbp), %rdi
movq -888(%rbp), %rsi
call f14@PLT
movq %rax, -896(%rbp)
movq -72(%rbp), %rdi
movq -896(%rbp), %rsi
call evn_store@PLT
movq %rax, -904(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -912(%rbp)
movabsq $2, %rax
movq %rax, -920(%rbp)
movq -920(%rbp), %rdi
call evn_int@PLT
movq %rax, -928(%rbp)
movq -912(%rbp), %rdi
movq -928(%rbp), %rsi
call f11@PLT
movq %rax, -936(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -944(%rbp)
movabsq $0, %rax
movq %rax, -952(%rbp)
movq -944(%rbp), %rdi
movq -952(%rbp), %rsi
call evn_member@PLT
movq %rax, -960(%rbp)
movabsq $5, %rax
movq %rax, -968(%rbp)
movq -968(%rbp), %rdi
call evn_int@PLT
movq %rax, -976(%rbp)
movabsq $5, %rax
movq %rax, -984(%rbp)
movq -984(%rbp), %rdi
movq -960(%rbp), %rsi
movq -976(%rbp), %rdx
call evn_binary@PLT
movq %rax, -992(%rbp)
leaq .Ldata_100(%rip), %rax
movq %rax, -1000(%rbp)
movabsq $37, %rax
movq %rax, -1008(%rbp)
movq -1000(%rbp), %rdi
movq -1008(%rbp), %rsi
call evn_text@PLT
movq %rax, -1016(%rbp)
movq -992(%rbp), %rdi
movq -1016(%rbp), %rsi
call f123@PLT
movq %rax, -1024(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1032(%rbp)
movq -1032(%rbp), %rdi
call f8@PLT
movq %rax, -1040(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1048(%rbp)
movq -1048(%rbp), %rdi
call f8@PLT
movq %rax, -1056(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1064(%rbp)
movq -1064(%rbp), %rdi
call f8@PLT
movq %rax, -1072(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rdi
call f8@PLT
movq %rax, -1088(%rbp)
leaq .Ldata_101(%rip), %rax
movq %rax, -1096(%rbp)
movabsq $15, %rax
movq %rax, -1104(%rbp)
movq -1096(%rbp), %rdi
movq -1104(%rbp), %rsi
call evn_text@PLT
movq %rax, -1112(%rbp)
movq -1112(%rbp), %rdi
call evn_output@PLT
movq %rax, -1120(%rbp)
call evn_void@PLT
movq %rax, -1128(%rbp)
call evn_void@PLT
movq %rax, -1136(%rbp)
movq -8(%rbp), %rdi
movq -1136(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1144(%rbp)
movq -1144(%rbp), %rax
leave
ret
.Lf106_b8:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -696(%rbp)
movabsq $0, %rax
movq %rax, -704(%rbp)
movq -696(%rbp), %rdi
movq -704(%rbp), %rsi
call evn_member@PLT
movq %rax, -712(%rbp)
movabsq $0, %rax
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call evn_int@PLT
movq %rax, -728(%rbp)
movabsq $5, %rax
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
movq -712(%rbp), %rsi
movq -728(%rbp), %rdx
call evn_binary@PLT
movq %rax, -744(%rbp)
movq -744(%rbp), %rax
movq %rax, -680(%rbp)
jmp .Lf106_b9
.Lf106_b7:
movq -608(%rbp), %rax
movq %rax, -680(%rbp)
movq -608(%rbp), %rdi
call evn_truth@PLT
movq %rax, -688(%rbp)
cmpq $0, -688(%rbp)
je .Lf106_b9
jmp .Lf106_b8
.Lf106_b6:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -624(%rbp)
movabsq $0, %rax
movq %rax, -632(%rbp)
movq -624(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_member@PLT
movq %rax, -640(%rbp)
movabsq $3, %rax
movq %rax, -648(%rbp)
movq -648(%rbp), %rdi
call evn_int@PLT
movq %rax, -656(%rbp)
movabsq $5, %rax
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
movq -640(%rbp), %rsi
movq -656(%rbp), %rdx
call evn_binary@PLT
movq %rax, -672(%rbp)
movq -672(%rbp), %rax
movq %rax, -608(%rbp)
jmp .Lf106_b7
.Lf106_b5:
movq -504(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -1152(%rbp)
ud2
.Lf106_b4:
movq -504(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_error@PLT
movq %rax, -528(%rbp)
movq -56(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_store@PLT
movq %rax, -536(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -544(%rbp)
movabsq $2, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_member@PLT
movq %rax, -560(%rbp)
leaq .Ldata_102(%rip), %rax
movq %rax, -568(%rbp)
movabsq $14, %rax
movq %rax, -576(%rbp)
movq -568(%rbp), %rdi
movq -576(%rbp), %rsi
call evn_text@PLT
movq %rax, -584(%rbp)
movabsq $5, %rax
movq %rax, -592(%rbp)
movq -592(%rbp), %rdi
movq -560(%rbp), %rsi
movq -584(%rbp), %rdx
call evn_binary@PLT
movq %rax, -600(%rbp)
movq -600(%rbp), %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
call evn_truth@PLT
movq %rax, -616(%rbp)
cmpq $0, -616(%rbp)
je .Lf106_b7
jmp .Lf106_b6
.Lf106_b3:
movq -80(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_store@PLT
movq %rax, -1160(%rbp)
movabsq $41, %rax
movq %rax, -1168(%rbp)
movabsq $1, %rax
movq %rax, -1176(%rbp)
movq -1168(%rbp), %rdi
movq -1176(%rbp), %rsi
call evn_object@PLT
movq %rax, -1184(%rbp)
leaq .Ldata_103(%rip), %rax
movq %rax, -1192(%rbp)
movabsq $24, %rax
movq %rax, -1200(%rbp)
movq -1192(%rbp), %rdi
movq -1200(%rbp), %rsi
call evn_text@PLT
movq %rax, -1208(%rbp)
movabsq $0, %rax
movq %rax, -1216(%rbp)
movq -1184(%rbp), %rdi
movq -1216(%rbp), %rsi
movq -1208(%rbp), %rdx
call evn_init@PLT
movq %rax, -1224(%rbp)
movabsq $0, %rax
movq %rax, -1232(%rbp)
movq -1184(%rbp), %rdi
movq -1232(%rbp), %rsi
call evn_fail@PLT
movq %rax, -1240(%rbp)
ud2
.Lf106_b2:
movq -440(%rbp), %rdi
call evn_pop@PLT
movq %rax, -496(%rbp)
call evn_saved@PLT
movq %rax, -504(%rbp)
movabsq $9, %rax
movq %rax, -512(%rbp)
movq -504(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_match@PLT
movq %rax, -520(%rbp)
cmpq $0, -520(%rbp)
je .Lf106_b5
jmp .Lf106_b4
.Lf106_b1:
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $3, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_int@PLT
movq %rax, -472(%rbp)
movq -456(%rbp), %rdi
movq -472(%rbp), %rsi
call f119@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
movq %rax, -448(%rbp)
movq -440(%rbp), %rdi
call evn_pop@PLT
movq %rax, -488(%rbp)
jmp .Lf106_b3
.Lf106_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1240(%rbp), %rsi
leaq .Lroots_f106(%rip), %rdx
movq $155, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
call evn_void@PLT
movq %rax, -64(%rbp)
call evn_void@PLT
movq %rax, -72(%rbp)
call evn_void@PLT
movq %rax, -80(%rbp)
movabsq $100, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movabsq $100, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_int@PLT
movq %rax, -112(%rbp)
movabsq $5, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movq -96(%rbp), %rdi
movq -112(%rbp), %rsi
movq -128(%rbp), %rdx
call f29@PLT
movq %rax, -136(%rbp)
movq -16(%rbp), %rdi
movq -136(%rbp), %rsi
call evn_store@PLT
movq %rax, -144(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $2, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $100, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movabsq $100, %rax
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call evn_int@PLT
movq %rax, -200(%rbp)
movabsq $100, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movq -152(%rbp), %rdi
movq -168(%rbp), %rsi
movq -184(%rbp), %rdx
movq -200(%rbp), %rcx
movq -216(%rbp), %r8
call f27@PLT
movq %rax, -224(%rbp)
movq -24(%rbp), %rdi
movq -224(%rbp), %rsi
call evn_store@PLT
movq %rax, -232(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movabsq $2, %rax
movq %rax, -248(%rbp)
movq -248(%rbp), %rdi
call evn_int@PLT
movq %rax, -256(%rbp)
movabsq $100, %rax
movq %rax, -264(%rbp)
movq -264(%rbp), %rdi
call evn_int@PLT
movq %rax, -272(%rbp)
movabsq $100, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movabsq $100, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movq -240(%rbp), %rdi
movq -256(%rbp), %rsi
movq -272(%rbp), %rdx
movq -288(%rbp), %rcx
movq -304(%rbp), %r8
call f27@PLT
movq %rax, -312(%rbp)
movq -32(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_store@PLT
movq %rax, -320(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $100, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movq -328(%rbp), %rdi
movq -344(%rbp), %rsi
call f14@PLT
movq %rax, -352(%rbp)
movq -40(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_store@PLT
movq %rax, -360(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movabsq $3, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movq -368(%rbp), %rdi
movq -384(%rbp), %rsi
call f11@PLT
movq %rax, -392(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $100, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movq -400(%rbp), %rdi
movq -416(%rbp), %rsi
call f14@PLT
movq %rax, -424(%rbp)
movq -48(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_store@PLT
movq %rax, -432(%rbp)
call evn_frame@PLT
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf106_b2
jmp .Lf106_b1
.size f106, .-f106
.text
.p2align 4
.type f107, @function
f107:
pushq %rbp
movq %rsp, %rbp
subq $1136, %rsp
leaq -1136(%rbp), %rdi
movq $142, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf107_b0
.Lf107_b15:
leaq .Ldata_104(%rip), %rax
movq %rax, -928(%rbp)
movabsq $24, %rax
movq %rax, -936(%rbp)
movq -928(%rbp), %rdi
movq -936(%rbp), %rsi
call evn_text@PLT
movq %rax, -944(%rbp)
movq -856(%rbp), %rdi
movq -944(%rbp), %rsi
call f123@PLT
movq %rax, -952(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movq -960(%rbp), %rdi
call f8@PLT
movq %rax, -968(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -976(%rbp)
movq -976(%rbp), %rdi
call f8@PLT
movq %rax, -984(%rbp)
leaq .Ldata_105(%rip), %rax
movq %rax, -992(%rbp)
movabsq $7, %rax
movq %rax, -1000(%rbp)
movq -992(%rbp), %rdi
movq -1000(%rbp), %rsi
call evn_text@PLT
movq %rax, -1008(%rbp)
movq -1008(%rbp), %rdi
call evn_output@PLT
movq %rax, -1016(%rbp)
call evn_void@PLT
movq %rax, -1024(%rbp)
call evn_void@PLT
movq %rax, -1032(%rbp)
movq -8(%rbp), %rdi
movq -1032(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1040(%rbp)
movq -1040(%rbp), %rax
leave
ret
.Lf107_b14:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movabsq $1, %rax
movq %rax, -880(%rbp)
movq -872(%rbp), %rdi
movq -880(%rbp), %rsi
call evn_member@PLT
movq %rax, -888(%rbp)
movabsq $5, %rax
movq %rax, -896(%rbp)
movq -896(%rbp), %rdi
call evn_int@PLT
movq %rax, -904(%rbp)
movabsq $5, %rax
movq %rax, -912(%rbp)
movq -912(%rbp), %rdi
movq -888(%rbp), %rsi
movq -904(%rbp), %rdx
call evn_binary@PLT
movq %rax, -920(%rbp)
movq -920(%rbp), %rax
movq %rax, -856(%rbp)
jmp .Lf107_b15
.Lf107_b13:
movq -784(%rbp), %rax
movq %rax, -856(%rbp)
movq -784(%rbp), %rdi
call evn_truth@PLT
movq %rax, -864(%rbp)
cmpq $0, -864(%rbp)
je .Lf107_b15
jmp .Lf107_b14
.Lf107_b12:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -800(%rbp)
movabsq $2, %rax
movq %rax, -808(%rbp)
movq -800(%rbp), %rdi
movq -808(%rbp), %rsi
call evn_member@PLT
movq %rax, -816(%rbp)
movabsq $3, %rax
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call evn_int@PLT
movq %rax, -832(%rbp)
movabsq $5, %rax
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
movq -816(%rbp), %rsi
movq -832(%rbp), %rdx
call evn_binary@PLT
movq %rax, -848(%rbp)
movq -848(%rbp), %rax
movq %rax, -784(%rbp)
jmp .Lf107_b13
.Lf107_b11:
movq -712(%rbp), %rax
movq %rax, -784(%rbp)
movq -712(%rbp), %rdi
call evn_truth@PLT
movq %rax, -792(%rbp)
cmpq $0, -792(%rbp)
je .Lf107_b13
jmp .Lf107_b12
.Lf107_b10:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -728(%rbp)
movabsq $0, %rax
movq %rax, -736(%rbp)
movq -728(%rbp), %rdi
movq -736(%rbp), %rsi
call evn_member@PLT
movq %rax, -744(%rbp)
movabsq $8, %rax
movq %rax, -752(%rbp)
movq -752(%rbp), %rdi
call evn_int@PLT
movq %rax, -760(%rbp)
movabsq $5, %rax
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
movq -744(%rbp), %rsi
movq -760(%rbp), %rdx
call evn_binary@PLT
movq %rax, -776(%rbp)
movq -776(%rbp), %rax
movq %rax, -712(%rbp)
jmp .Lf107_b11
.Lf107_b9:
movq -608(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -1048(%rbp)
ud2
.Lf107_b8:
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
call evn_error@PLT
movq %rax, -632(%rbp)
movq -40(%rbp), %rdi
movq -632(%rbp), %rsi
call evn_store@PLT
movq %rax, -640(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -648(%rbp)
movabsq $2, %rax
movq %rax, -656(%rbp)
movq -648(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_member@PLT
movq %rax, -664(%rbp)
leaq .Ldata_106(%rip), %rax
movq %rax, -672(%rbp)
movabsq $14, %rax
movq %rax, -680(%rbp)
movq -672(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_text@PLT
movq %rax, -688(%rbp)
movabsq $5, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
movq -664(%rbp), %rsi
movq -688(%rbp), %rdx
call evn_binary@PLT
movq %rax, -704(%rbp)
movq -704(%rbp), %rax
movq %rax, -712(%rbp)
movq -704(%rbp), %rdi
call evn_truth@PLT
movq %rax, -720(%rbp)
cmpq $0, -720(%rbp)
je .Lf107_b11
jmp .Lf107_b10
.Lf107_b7:
movq -48(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_store@PLT
movq %rax, -1056(%rbp)
movabsq $41, %rax
movq %rax, -1064(%rbp)
movabsq $1, %rax
movq %rax, -1072(%rbp)
movq -1064(%rbp), %rdi
movq -1072(%rbp), %rsi
call evn_object@PLT
movq %rax, -1080(%rbp)
leaq .Ldata_107(%rip), %rax
movq %rax, -1088(%rbp)
movabsq $22, %rax
movq %rax, -1096(%rbp)
movq -1088(%rbp), %rdi
movq -1096(%rbp), %rsi
call evn_text@PLT
movq %rax, -1104(%rbp)
movabsq $0, %rax
movq %rax, -1112(%rbp)
movq -1080(%rbp), %rdi
movq -1112(%rbp), %rsi
movq -1104(%rbp), %rdx
call evn_init@PLT
movq %rax, -1120(%rbp)
movabsq $0, %rax
movq %rax, -1128(%rbp)
movq -1080(%rbp), %rdi
movq -1128(%rbp), %rsi
call evn_fail@PLT
movq %rax, -1136(%rbp)
ud2
.Lf107_b6:
movq -544(%rbp), %rdi
call evn_pop@PLT
movq %rax, -600(%rbp)
call evn_saved@PLT
movq %rax, -608(%rbp)
movabsq $9, %rax
movq %rax, -616(%rbp)
movq -608(%rbp), %rdi
movq -616(%rbp), %rsi
call evn_match@PLT
movq %rax, -624(%rbp)
cmpq $0, -624(%rbp)
je .Lf107_b9
jmp .Lf107_b8
.Lf107_b5:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $4, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
call evn_int@PLT
movq %rax, -576(%rbp)
movq -560(%rbp), %rdi
movq -576(%rbp), %rsi
call f119@PLT
movq %rax, -584(%rbp)
movq -584(%rbp), %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
call evn_pop@PLT
movq %rax, -592(%rbp)
jmp .Lf107_b7
.Lf107_b4:
leaq .Ldata_108(%rip), %rax
movq %rax, -512(%rbp)
movabsq $25, %rax
movq %rax, -520(%rbp)
movq -512(%rbp), %rdi
movq -520(%rbp), %rsi
call evn_text@PLT
movq %rax, -528(%rbp)
movq -440(%rbp), %rdi
movq -528(%rbp), %rsi
call f123@PLT
movq %rax, -536(%rbp)
call evn_frame@PLT
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf107_b6
jmp .Lf107_b5
.Lf107_b3:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $0, %rax
movq %rax, -464(%rbp)
movq -456(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_member@PLT
movq %rax, -472(%rbp)
movabsq $8, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $5, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rax
movq %rax, -440(%rbp)
jmp .Lf107_b4
.Lf107_b2:
movq -368(%rbp), %rax
movq %rax, -440(%rbp)
movq -368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -448(%rbp)
cmpq $0, -448(%rbp)
je .Lf107_b4
jmp .Lf107_b3
.Lf107_b1:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $1, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movabsq $5, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movabsq $5, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -400(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_binary@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rax
movq %rax, -368(%rbp)
jmp .Lf107_b2
.Lf107_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1136(%rbp), %rsi
leaq .Lroots_f107(%rip), %rdx
movq $142, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movabsq $100, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $100, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $100, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call f29@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $100, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $100, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $100, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movq -120(%rbp), %rdi
movq -136(%rbp), %rsi
movq -152(%rbp), %rdx
movq -168(%rbp), %rcx
movq -184(%rbp), %r8
call f27@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_store@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $10, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movq -208(%rbp), %rdi
movq -224(%rbp), %rsi
call f14@PLT
movq %rax, -232(%rbp)
movq -32(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_store@PLT
movq %rax, -240(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -248(%rbp)
movabsq $8, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movq -248(%rbp), %rdi
movq -264(%rbp), %rsi
call f13@PLT
movq %rax, -272(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -280(%rbp)
movabsq $3, %rax
movq %rax, -288(%rbp)
movq -288(%rbp), %rdi
call evn_int@PLT
movq %rax, -296(%rbp)
movq -280(%rbp), %rdi
movq -296(%rbp), %rsi
call f12@PLT
movq %rax, -304(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -312(%rbp)
movabsq $2, %rax
movq %rax, -320(%rbp)
movq -312(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_member@PLT
movq %rax, -328(%rbp)
movabsq $3, %rax
movq %rax, -336(%rbp)
movq -336(%rbp), %rdi
call evn_int@PLT
movq %rax, -344(%rbp)
movabsq $5, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -328(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_binary@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
call evn_truth@PLT
movq %rax, -376(%rbp)
cmpq $0, -376(%rbp)
je .Lf107_b2
jmp .Lf107_b1
.size f107, .-f107
.text
.p2align 4
.type f108, @function
f108:
pushq %rbp
movq %rsp, %rbp
subq $672, %rsp
leaq -664(%rbp), %rdi
movq $83, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf108_b0
.Lf108_b9:
leaq .Ldata_109(%rip), %rax
movq %rax, -472(%rbp)
movabsq $18, %rax
movq %rax, -480(%rbp)
movq -472(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_text@PLT
movq %rax, -488(%rbp)
movq -400(%rbp), %rdi
movq -488(%rbp), %rsi
call f123@PLT
movq %rax, -496(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rdi
call f8@PLT
movq %rax, -512(%rbp)
leaq .Ldata_110(%rip), %rax
movq %rax, -520(%rbp)
movabsq $15, %rax
movq %rax, -528(%rbp)
movq -520(%rbp), %rdi
movq -528(%rbp), %rsi
call evn_text@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rdi
call evn_output@PLT
movq %rax, -544(%rbp)
call evn_void@PLT
movq %rax, -552(%rbp)
call evn_void@PLT
movq %rax, -560(%rbp)
movq -8(%rbp), %rdi
movq -560(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -568(%rbp)
movq -568(%rbp), %rax
leave
ret
.Lf108_b8:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -416(%rbp)
movabsq $2, %rax
movq %rax, -424(%rbp)
movq -416(%rbp), %rdi
movq -424(%rbp), %rsi
call evn_member@PLT
movq %rax, -432(%rbp)
movabsq $8, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
call evn_int@PLT
movq %rax, -448(%rbp)
movabsq $5, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
movq -432(%rbp), %rsi
movq -448(%rbp), %rdx
call evn_binary@PLT
movq %rax, -464(%rbp)
movq -464(%rbp), %rax
movq %rax, -400(%rbp)
jmp .Lf108_b9
.Lf108_b7:
movq -328(%rbp), %rax
movq %rax, -400(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -408(%rbp)
cmpq $0, -408(%rbp)
je .Lf108_b9
jmp .Lf108_b8
.Lf108_b6:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movabsq $6, %rax
movq %rax, -352(%rbp)
movq -344(%rbp), %rdi
movq -352(%rbp), %rsi
call evn_member@PLT
movq %rax, -360(%rbp)
movabsq $0, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
call evn_int@PLT
movq %rax, -376(%rbp)
movabsq $5, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
movq -360(%rbp), %rsi
movq -376(%rbp), %rdx
call evn_binary@PLT
movq %rax, -392(%rbp)
movq -392(%rbp), %rax
movq %rax, -328(%rbp)
jmp .Lf108_b7
.Lf108_b5:
movq -224(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -576(%rbp)
ud2
.Lf108_b4:
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_error@PLT
movq %rax, -248(%rbp)
movq -32(%rbp), %rdi
movq -248(%rbp), %rsi
call evn_store@PLT
movq %rax, -256(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -264(%rbp)
movabsq $2, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_member@PLT
movq %rax, -280(%rbp)
leaq .Ldata_111(%rip), %rax
movq %rax, -288(%rbp)
movabsq $13, %rax
movq %rax, -296(%rbp)
movq -288(%rbp), %rdi
movq -296(%rbp), %rsi
call evn_text@PLT
movq %rax, -304(%rbp)
movabsq $5, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
movq -280(%rbp), %rsi
movq -304(%rbp), %rdx
call evn_binary@PLT
movq %rax, -320(%rbp)
movq -320(%rbp), %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
call evn_truth@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf108_b7
jmp .Lf108_b6
.Lf108_b3:
movq -40(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -584(%rbp)
movabsq $41, %rax
movq %rax, -592(%rbp)
movabsq $1, %rax
movq %rax, -600(%rbp)
movq -592(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_object@PLT
movq %rax, -608(%rbp)
leaq .Ldata_112(%rip), %rax
movq %rax, -616(%rbp)
movabsq $29, %rax
movq %rax, -624(%rbp)
movq -616(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_text@PLT
movq %rax, -632(%rbp)
movabsq $0, %rax
movq %rax, -640(%rbp)
movq -608(%rbp), %rdi
movq -640(%rbp), %rsi
movq -632(%rbp), %rdx
call evn_init@PLT
movq %rax, -648(%rbp)
movabsq $0, %rax
movq %rax, -656(%rbp)
movq -608(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_fail@PLT
movq %rax, -664(%rbp)
ud2
.Lf108_b2:
movq -176(%rbp), %rdi
call evn_pop@PLT
movq %rax, -216(%rbp)
call evn_saved@PLT
movq %rax, -224(%rbp)
movabsq $9, %rax
movq %rax, -232(%rbp)
movq -224(%rbp), %rdi
movq -232(%rbp), %rsi
call evn_match@PLT
movq %rax, -240(%rbp)
cmpq $0, -240(%rbp)
je .Lf108_b5
jmp .Lf108_b4
.Lf108_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -192(%rbp)
movq -192(%rbp), %rdi
call f120@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rax
movq %rax, -184(%rbp)
movq -176(%rbp), %rdi
call evn_pop@PLT
movq %rax, -208(%rbp)
jmp .Lf108_b3
.Lf108_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -664(%rbp), %rsi
leaq .Lroots_f108(%rip), %rdx
movq $83, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movabsq $100, %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_int@PLT
movq %rax, -56(%rbp)
movabsq $100, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $100, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movq -56(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call f29@PLT
movq %rax, -96(%rbp)
movq -16(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $8, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movq -112(%rbp), %rdi
movq -128(%rbp), %rsi
call f22@PLT
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call f20@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_store@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call f17@PLT
movq %rax, -168(%rbp)
call evn_frame@PLT
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf108_b2
jmp .Lf108_b1
.size f108, .-f108
.text
.p2align 4
.type f109, @function
f109:
pushq %rbp
movq %rsp, %rbp
subq $688, %rsp
leaq -688(%rbp), %rdi
movq $86, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf109_b0
.Lf109_b9:
leaq .Ldata_113(%rip), %rax
movq %rax, -480(%rbp)
movabsq $17, %rax
movq %rax, -488(%rbp)
movq -480(%rbp), %rdi
movq -488(%rbp), %rsi
call evn_text@PLT
movq %rax, -496(%rbp)
movq -408(%rbp), %rdi
movq -496(%rbp), %rsi
call f123@PLT
movq %rax, -504(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call f17@PLT
movq %rax, -520(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call f8@PLT
movq %rax, -536(%rbp)
leaq .Ldata_114(%rip), %rax
movq %rax, -544(%rbp)
movabsq $14, %rax
movq %rax, -552(%rbp)
movq -544(%rbp), %rdi
movq -552(%rbp), %rsi
call evn_text@PLT
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
call evn_output@PLT
movq %rax, -568(%rbp)
call evn_void@PLT
movq %rax, -576(%rbp)
call evn_void@PLT
movq %rax, -584(%rbp)
movq -8(%rbp), %rdi
movq -584(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -592(%rbp)
movq -592(%rbp), %rax
leave
ret
.Lf109_b8:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -424(%rbp)
movabsq $2, %rax
movq %rax, -432(%rbp)
movq -424(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_member@PLT
movq %rax, -440(%rbp)
movabsq $8, %rax
movq %rax, -448(%rbp)
movq -448(%rbp), %rdi
call evn_int@PLT
movq %rax, -456(%rbp)
movabsq $5, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
movq -440(%rbp), %rsi
movq -456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -472(%rbp)
movq -472(%rbp), %rax
movq %rax, -408(%rbp)
jmp .Lf109_b9
.Lf109_b7:
movq -336(%rbp), %rax
movq %rax, -408(%rbp)
movq -336(%rbp), %rdi
call evn_truth@PLT
movq %rax, -416(%rbp)
cmpq $0, -416(%rbp)
je .Lf109_b9
jmp .Lf109_b8
.Lf109_b6:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -352(%rbp)
movabsq $6, %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_member@PLT
movq %rax, -368(%rbp)
movabsq $8, %rax
movq %rax, -376(%rbp)
movq -376(%rbp), %rdi
call evn_int@PLT
movq %rax, -384(%rbp)
movabsq $5, %rax
movq %rax, -392(%rbp)
movq -392(%rbp), %rdi
movq -368(%rbp), %rsi
movq -384(%rbp), %rdx
call evn_binary@PLT
movq %rax, -400(%rbp)
movq -400(%rbp), %rax
movq %rax, -336(%rbp)
jmp .Lf109_b7
.Lf109_b5:
movq -232(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -600(%rbp)
ud2
.Lf109_b4:
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_error@PLT
movq %rax, -256(%rbp)
movq -40(%rbp), %rdi
movq -256(%rbp), %rsi
call evn_store@PLT
movq %rax, -264(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $2, %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_member@PLT
movq %rax, -288(%rbp)
leaq .Ldata_115(%rip), %rax
movq %rax, -296(%rbp)
movabsq $13, %rax
movq %rax, -304(%rbp)
movq -296(%rbp), %rdi
movq -304(%rbp), %rsi
call evn_text@PLT
movq %rax, -312(%rbp)
movabsq $5, %rax
movq %rax, -320(%rbp)
movq -320(%rbp), %rdi
movq -288(%rbp), %rsi
movq -312(%rbp), %rdx
call evn_binary@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
call evn_truth@PLT
movq %rax, -344(%rbp)
cmpq $0, -344(%rbp)
je .Lf109_b7
jmp .Lf109_b6
.Lf109_b3:
movq -48(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_store@PLT
movq %rax, -608(%rbp)
movabsq $41, %rax
movq %rax, -616(%rbp)
movabsq $1, %rax
movq %rax, -624(%rbp)
movq -616(%rbp), %rdi
movq -624(%rbp), %rsi
call evn_object@PLT
movq %rax, -632(%rbp)
leaq .Ldata_116(%rip), %rax
movq %rax, -640(%rbp)
movabsq $28, %rax
movq %rax, -648(%rbp)
movq -640(%rbp), %rdi
movq -648(%rbp), %rsi
call evn_text@PLT
movq %rax, -656(%rbp)
movabsq $0, %rax
movq %rax, -664(%rbp)
movq -632(%rbp), %rdi
movq -664(%rbp), %rsi
movq -656(%rbp), %rdx
call evn_init@PLT
movq %rax, -672(%rbp)
movabsq $0, %rax
movq %rax, -680(%rbp)
movq -632(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_fail@PLT
movq %rax, -688(%rbp)
ud2
.Lf109_b2:
movq -184(%rbp), %rdi
call evn_pop@PLT
movq %rax, -224(%rbp)
call evn_saved@PLT
movq %rax, -232(%rbp)
movabsq $9, %rax
movq %rax, -240(%rbp)
movq -232(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_match@PLT
movq %rax, -248(%rbp)
cmpq $0, -248(%rbp)
je .Lf109_b5
jmp .Lf109_b4
.Lf109_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call f121@PLT
movq %rax, -208(%rbp)
movq -208(%rbp), %rax
movq %rax, -192(%rbp)
movq -184(%rbp), %rdi
call evn_pop@PLT
movq %rax, -216(%rbp)
jmp .Lf109_b3
.Lf109_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -688(%rbp), %rsi
leaq .Lroots_f109(%rip), %rdx
movq $86, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movabsq $100, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $100, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $100, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call f29@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $8, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movq -120(%rbp), %rdi
movq -136(%rbp), %rsi
call f22@PLT
movq %rax, -144(%rbp)
movq -24(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_store@PLT
movq %rax, -152(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call f20@PLT
movq %rax, -168(%rbp)
movq -32(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_store@PLT
movq %rax, -176(%rbp)
call evn_frame@PLT
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf109_b2
jmp .Lf109_b1
.size f109, .-f109
.text
.p2align 4
.type f110, @function
f110:
pushq %rbp
movq %rsp, %rbp
subq $1040, %rsp
leaq -1032(%rbp), %rdi
movq $129, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf110_b0
.Lf110_b13:
leaq .Ldata_117(%rip), %rax
movq %rax, -792(%rbp)
movabsq $25, %rax
movq %rax, -800(%rbp)
movq -792(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_text@PLT
movq %rax, -808(%rbp)
movq -720(%rbp), %rdi
movq -808(%rbp), %rsi
call f123@PLT
movq %rax, -816(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -824(%rbp)
movq -824(%rbp), %rdi
call f17@PLT
movq %rax, -832(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -840(%rbp)
movq -840(%rbp), %rdi
call f8@PLT
movq %rax, -848(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -856(%rbp)
movq -856(%rbp), %rdi
call f8@PLT
movq %rax, -864(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -872(%rbp)
movq -872(%rbp), %rdi
call f8@PLT
movq %rax, -880(%rbp)
leaq .Ldata_118(%rip), %rax
movq %rax, -888(%rbp)
movabsq $18, %rax
movq %rax, -896(%rbp)
movq -888(%rbp), %rdi
movq -896(%rbp), %rsi
call evn_text@PLT
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_output@PLT
movq %rax, -912(%rbp)
call evn_void@PLT
movq %rax, -920(%rbp)
call evn_void@PLT
movq %rax, -928(%rbp)
movq -8(%rbp), %rdi
movq -928(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -936(%rbp)
movq -936(%rbp), %rax
leave
ret
.Lf110_b12:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $6, %rax
movq %rax, -744(%rbp)
movq -736(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member@PLT
movq %rax, -752(%rbp)
movabsq $8, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_int@PLT
movq %rax, -768(%rbp)
movabsq $5, %rax
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
movq -752(%rbp), %rsi
movq -768(%rbp), %rdx
call evn_binary@PLT
movq %rax, -784(%rbp)
movq -784(%rbp), %rax
movq %rax, -720(%rbp)
jmp .Lf110_b13
.Lf110_b11:
movq -648(%rbp), %rax
movq %rax, -720(%rbp)
movq -648(%rbp), %rdi
call evn_truth@PLT
movq %rax, -728(%rbp)
cmpq $0, -728(%rbp)
je .Lf110_b13
jmp .Lf110_b12
.Lf110_b10:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -664(%rbp)
movabsq $6, %rax
movq %rax, -672(%rbp)
movq -664(%rbp), %rdi
movq -672(%rbp), %rsi
call evn_member@PLT
movq %rax, -680(%rbp)
movabsq $0, %rax
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
call evn_int@PLT
movq %rax, -696(%rbp)
movabsq $5, %rax
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
movq -680(%rbp), %rsi
movq -696(%rbp), %rdx
call evn_binary@PLT
movq %rax, -712(%rbp)
movq -712(%rbp), %rax
movq %rax, -648(%rbp)
jmp .Lf110_b11
.Lf110_b9:
movq -576(%rbp), %rax
movq %rax, -648(%rbp)
movq -576(%rbp), %rdi
call evn_truth@PLT
movq %rax, -656(%rbp)
cmpq $0, -656(%rbp)
je .Lf110_b11
jmp .Lf110_b10
.Lf110_b8:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -592(%rbp)
movabsq $6, %rax
movq %rax, -600(%rbp)
movq -592(%rbp), %rdi
movq -600(%rbp), %rsi
call evn_member@PLT
movq %rax, -608(%rbp)
movabsq $8, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call evn_int@PLT
movq %rax, -624(%rbp)
movabsq $5, %rax
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
movq -608(%rbp), %rsi
movq -624(%rbp), %rdx
call evn_binary@PLT
movq %rax, -640(%rbp)
movq -640(%rbp), %rax
movq %rax, -576(%rbp)
jmp .Lf110_b9
.Lf110_b7:
movq -512(%rbp), %rax
movq %rax, -576(%rbp)
movq -512(%rbp), %rdi
call evn_truth@PLT
movq %rax, -584(%rbp)
cmpq $0, -584(%rbp)
je .Lf110_b9
jmp .Lf110_b8
.Lf110_b6:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $2, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -552(%rbp)
movabsq $5, %rax
movq %rax, -560(%rbp)
movq -560(%rbp), %rdi
movq -544(%rbp), %rsi
movq -552(%rbp), %rdx
call evn_binary@PLT
movq %rax, -568(%rbp)
movq -568(%rbp), %rax
movq %rax, -512(%rbp)
jmp .Lf110_b7
.Lf110_b5:
movq -408(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -944(%rbp)
ud2
.Lf110_b4:
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_error@PLT
movq %rax, -432(%rbp)
movq -48(%rbp), %rdi
movq -432(%rbp), %rsi
call evn_store@PLT
movq %rax, -440(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -448(%rbp)
movabsq $2, %rax
movq %rax, -456(%rbp)
movq -448(%rbp), %rdi
movq -456(%rbp), %rsi
call evn_member@PLT
movq %rax, -464(%rbp)
leaq .Ldata_119(%rip), %rax
movq %rax, -472(%rbp)
movabsq $14, %rax
movq %rax, -480(%rbp)
movq -472(%rbp), %rdi
movq -480(%rbp), %rsi
call evn_text@PLT
movq %rax, -488(%rbp)
movabsq $5, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -464(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rax
movq %rax, -512(%rbp)
movq -504(%rbp), %rdi
call evn_truth@PLT
movq %rax, -520(%rbp)
cmpq $0, -520(%rbp)
je .Lf110_b7
jmp .Lf110_b6
.Lf110_b3:
movq -56(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_store@PLT
movq %rax, -952(%rbp)
movabsq $41, %rax
movq %rax, -960(%rbp)
movabsq $1, %rax
movq %rax, -968(%rbp)
movq -960(%rbp), %rdi
movq -968(%rbp), %rsi
call evn_object@PLT
movq %rax, -976(%rbp)
leaq .Ldata_120(%rip), %rax
movq %rax, -984(%rbp)
movabsq $20, %rax
movq %rax, -992(%rbp)
movq -984(%rbp), %rdi
movq -992(%rbp), %rsi
call evn_text@PLT
movq %rax, -1000(%rbp)
movabsq $0, %rax
movq %rax, -1008(%rbp)
movq -976(%rbp), %rdi
movq -1008(%rbp), %rsi
movq -1000(%rbp), %rdx
call evn_init@PLT
movq %rax, -1016(%rbp)
movabsq $0, %rax
movq %rax, -1024(%rbp)
movq -976(%rbp), %rdi
movq -1024(%rbp), %rsi
call evn_fail@PLT
movq %rax, -1032(%rbp)
ud2
.Lf110_b2:
movq -352(%rbp), %rdi
call evn_pop@PLT
movq %rax, -400(%rbp)
call evn_saved@PLT
movq %rax, -408(%rbp)
movabsq $9, %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
movq -416(%rbp), %rsi
call evn_match@PLT
movq %rax, -424(%rbp)
cmpq $0, -424(%rbp)
je .Lf110_b5
jmp .Lf110_b4
.Lf110_b1:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -368(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movq -368(%rbp), %rdi
movq -376(%rbp), %rsi
call f122@PLT
movq %rax, -384(%rbp)
movq -384(%rbp), %rax
movq %rax, -360(%rbp)
movq -352(%rbp), %rdi
call evn_pop@PLT
movq %rax, -392(%rbp)
jmp .Lf110_b3
.Lf110_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1032(%rbp), %rsi
leaq .Lroots_f110(%rip), %rdx
movq $129, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movabsq $100, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $100, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movabsq $100, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movq -72(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call f29@PLT
movq %rax, -112(%rbp)
movq -16(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -120(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $2, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $50, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $50, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $50, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -128(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
movq -176(%rbp), %rcx
movq -192(%rbp), %r8
call f27@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $1, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $4, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
movabsq $50, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movabsq $50, %rax
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call evn_int@PLT
movq %rax, -280(%rbp)
movq -216(%rbp), %rdi
movq -232(%rbp), %rsi
movq -248(%rbp), %rdx
movq -264(%rbp), %rcx
movq -280(%rbp), %r8
call f27@PLT
movq %rax, -288(%rbp)
movq -32(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $8, %rax
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call evn_int@PLT
movq %rax, -320(%rbp)
movq -304(%rbp), %rdi
movq -320(%rbp), %rsi
call f22@PLT
movq %rax, -328(%rbp)
movq -328(%rbp), %rdi
call f20@PLT
movq %rax, -336(%rbp)
movq -40(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_store@PLT
movq %rax, -344(%rbp)
call evn_frame@PLT
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf110_b2
jmp .Lf110_b1
.size f110, .-f110
.text
.p2align 4
.type f111, @function
f111:
pushq %rbp
movq %rsp, %rbp
subq $928, %rsp
leaq -928(%rbp), %rdi
movq $116, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf111_b0
.Lf111_b8:
leaq .Ldata_121(%rip), %rax
movq %rax, -704(%rbp)
movabsq $16, %rax
movq %rax, -712(%rbp)
movq -704(%rbp), %rdi
movq -712(%rbp), %rsi
call evn_text@PLT
movq %rax, -720(%rbp)
movq -632(%rbp), %rdi
movq -720(%rbp), %rsi
call f123@PLT
movq %rax, -728(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $2, %rax
movq %rax, -744(%rbp)
movq -736(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member@PLT
movq %rax, -752(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -760(%rbp)
movabsq $5, %rax
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
movq -752(%rbp), %rsi
movq -760(%rbp), %rdx
call evn_binary@PLT
movq %rax, -776(%rbp)
leaq .Ldata_122(%rip), %rax
movq %rax, -784(%rbp)
movabsq $25, %rax
movq %rax, -792(%rbp)
movq -784(%rbp), %rdi
movq -792(%rbp), %rsi
call evn_text@PLT
movq %rax, -800(%rbp)
movq -776(%rbp), %rdi
movq -800(%rbp), %rsi
call f123@PLT
movq %rax, -808(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -816(%rbp)
movq -816(%rbp), %rdi
call f17@PLT
movq %rax, -824(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
call f8@PLT
movq %rax, -840(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
call f8@PLT
movq %rax, -856(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movq -864(%rbp), %rdi
call f8@PLT
movq %rax, -872(%rbp)
leaq .Ldata_123(%rip), %rax
movq %rax, -880(%rbp)
movabsq $11, %rax
movq %rax, -888(%rbp)
movq -880(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_text@PLT
movq %rax, -896(%rbp)
movq -896(%rbp), %rdi
call evn_output@PLT
movq %rax, -904(%rbp)
call evn_void@PLT
movq %rax, -912(%rbp)
call evn_void@PLT
movq %rax, -920(%rbp)
movq -8(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rax
leave
ret
.Lf111_b7:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -648(%rbp)
movabsq $2, %rax
movq %rax, -656(%rbp)
movq -648(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_member@PLT
movq %rax, -664(%rbp)
movabsq $0, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
call evn_int@PLT
movq %rax, -680(%rbp)
movabsq $5, %rax
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
movq -664(%rbp), %rsi
movq -680(%rbp), %rdx
call evn_binary@PLT
movq %rax, -696(%rbp)
movq -696(%rbp), %rax
movq %rax, -632(%rbp)
jmp .Lf111_b8
.Lf111_b6:
movq -560(%rbp), %rax
movq %rax, -632(%rbp)
movq -560(%rbp), %rdi
call evn_truth@PLT
movq %rax, -640(%rbp)
cmpq $0, -640(%rbp)
je .Lf111_b8
jmp .Lf111_b7
.Lf111_b5:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -576(%rbp)
movabsq $2, %rax
movq %rax, -584(%rbp)
movq -576(%rbp), %rdi
movq -584(%rbp), %rsi
call evn_member@PLT
movq %rax, -592(%rbp)
movabsq $8, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
call evn_int@PLT
movq %rax, -608(%rbp)
movabsq $5, %rax
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
movq -592(%rbp), %rsi
movq -608(%rbp), %rdx
call evn_binary@PLT
movq %rax, -624(%rbp)
movq -624(%rbp), %rax
movq %rax, -560(%rbp)
jmp .Lf111_b6
.Lf111_b4:
movq -488(%rbp), %rax
movq %rax, -560(%rbp)
movq -488(%rbp), %rdi
call evn_truth@PLT
movq %rax, -568(%rbp)
cmpq $0, -568(%rbp)
je .Lf111_b6
jmp .Lf111_b5
.Lf111_b3:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -504(%rbp)
movabsq $6, %rax
movq %rax, -512(%rbp)
movq -504(%rbp), %rdi
movq -512(%rbp), %rsi
call evn_member@PLT
movq %rax, -520(%rbp)
movabsq $8, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
call evn_int@PLT
movq %rax, -536(%rbp)
movabsq $5, %rax
movq %rax, -544(%rbp)
movq -544(%rbp), %rdi
movq -520(%rbp), %rsi
movq -536(%rbp), %rdx
call evn_binary@PLT
movq %rax, -552(%rbp)
movq -552(%rbp), %rax
movq %rax, -488(%rbp)
jmp .Lf111_b4
.Lf111_b2:
movq -416(%rbp), %rax
movq %rax, -488(%rbp)
movq -416(%rbp), %rdi
call evn_truth@PLT
movq %rax, -496(%rbp)
cmpq $0, -496(%rbp)
je .Lf111_b4
jmp .Lf111_b3
.Lf111_b1:
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -432(%rbp)
movabsq $6, %rax
movq %rax, -440(%rbp)
movq -432(%rbp), %rdi
movq -440(%rbp), %rsi
call evn_member@PLT
movq %rax, -448(%rbp)
movabsq $8, %rax
movq %rax, -456(%rbp)
movq -456(%rbp), %rdi
call evn_int@PLT
movq %rax, -464(%rbp)
movabsq $5, %rax
movq %rax, -472(%rbp)
movq -472(%rbp), %rdi
movq -448(%rbp), %rsi
movq -464(%rbp), %rdx
call evn_binary@PLT
movq %rax, -480(%rbp)
movq -480(%rbp), %rax
movq %rax, -416(%rbp)
jmp .Lf111_b2
.Lf111_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -928(%rbp), %rsi
leaq .Lroots_f111(%rip), %rdx
movq $116, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movabsq $100, %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_int@PLT
movq %rax, -56(%rbp)
movabsq $100, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $100, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movq -56(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call f29@PLT
movq %rax, -96(%rbp)
movq -16(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $2, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $50, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $50, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $50, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movq -112(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
movq -160(%rbp), %rcx
movq -176(%rbp), %r8
call f27@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -192(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -200(%rbp)
movabsq $1, %rax
movq %rax, -208(%rbp)
movq -208(%rbp), %rdi
call evn_int@PLT
movq %rax, -216(%rbp)
movabsq $50, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movabsq $50, %rax
movq %rax, -240(%rbp)
movq -240(%rbp), %rdi
call evn_int@PLT
movq %rax, -248(%rbp)
movabsq $50, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_int@PLT
movq %rax, -264(%rbp)
movq -200(%rbp), %rdi
movq -216(%rbp), %rsi
movq -232(%rbp), %rdx
movq -248(%rbp), %rcx
movq -264(%rbp), %r8
call f27@PLT
movq %rax, -272(%rbp)
movq -32(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_store@PLT
movq %rax, -280(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $8, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movq -288(%rbp), %rdi
movq -304(%rbp), %rsi
call f22@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rdi
call f20@PLT
movq %rax, -320(%rbp)
movq -40(%rbp), %rdi
movq -320(%rbp), %rsi
call evn_store@PLT
movq %rax, -328(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -336(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call f16@PLT
movq %rax, -352(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $6, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_member@PLT
movq %rax, -376(%rbp)
movabsq $0, %rax
movq %rax, -384(%rbp)
movq -384(%rbp), %rdi
call evn_int@PLT
movq %rax, -392(%rbp)
movabsq $5, %rax
movq %rax, -400(%rbp)
movq -400(%rbp), %rdi
movq -376(%rbp), %rsi
movq -392(%rbp), %rdx
call evn_binary@PLT
movq %rax, -408(%rbp)
movq -408(%rbp), %rax
movq %rax, -416(%rbp)
movq -408(%rbp), %rdi
call evn_truth@PLT
movq %rax, -424(%rbp)
cmpq $0, -424(%rbp)
je .Lf111_b2
jmp .Lf111_b1
.size f111, .-f111
.text
.p2align 4
.type f112, @function
f112:
pushq %rbp
movq %rsp, %rbp
subq $864, %rsp
leaq -864(%rbp), %rdi
movq $108, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf112_b0
.Lf112_b11:
leaq .Ldata_124(%rip), %rax
movq %rax, -656(%rbp)
movabsq $27, %rax
movq %rax, -664(%rbp)
movq -656(%rbp), %rdi
movq -664(%rbp), %rsi
call evn_text@PLT
movq %rax, -672(%rbp)
movq -584(%rbp), %rdi
movq -672(%rbp), %rsi
call f123@PLT
movq %rax, -680(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -688(%rbp)
movq -688(%rbp), %rdi
call f8@PLT
movq %rax, -696(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -704(%rbp)
movq -704(%rbp), %rdi
call f8@PLT
movq %rax, -712(%rbp)
leaq .Ldata_125(%rip), %rax
movq %rax, -720(%rbp)
movabsq $10, %rax
movq %rax, -728(%rbp)
movq -720(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_text@PLT
movq %rax, -736(%rbp)
movq -736(%rbp), %rdi
call evn_output@PLT
movq %rax, -744(%rbp)
call evn_void@PLT
movq %rax, -752(%rbp)
call evn_void@PLT
movq %rax, -760(%rbp)
movq -8(%rbp), %rdi
movq -760(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -768(%rbp)
movq -768(%rbp), %rax
leave
ret
.Lf112_b10:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $2, %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_member@PLT
movq %rax, -616(%rbp)
movabsq $12, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
call evn_int@PLT
movq %rax, -632(%rbp)
movabsq $5, %rax
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
movq -616(%rbp), %rsi
movq -632(%rbp), %rdx
call evn_binary@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
movq %rax, -584(%rbp)
jmp .Lf112_b11
.Lf112_b9:
movq -512(%rbp), %rax
movq %rax, -584(%rbp)
movq -512(%rbp), %rdi
call evn_truth@PLT
movq %rax, -592(%rbp)
cmpq $0, -592(%rbp)
je .Lf112_b11
jmp .Lf112_b10
.Lf112_b8:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $5, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movabsq $0, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $5, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -544(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movq -576(%rbp), %rax
movq %rax, -512(%rbp)
jmp .Lf112_b9
.Lf112_b7:
movq -440(%rbp), %rax
movq %rax, -512(%rbp)
movq -440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -520(%rbp)
cmpq $0, -520(%rbp)
je .Lf112_b9
jmp .Lf112_b8
.Lf112_b6:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $6, %rax
movq %rax, -464(%rbp)
movq -456(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_member@PLT
movq %rax, -472(%rbp)
movabsq $0, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $5, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rax
movq %rax, -440(%rbp)
jmp .Lf112_b7
.Lf112_b5:
movq -336(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -776(%rbp)
ud2
.Lf112_b4:
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_error@PLT
movq %rax, -360(%rbp)
movq -40(%rbp), %rdi
movq -360(%rbp), %rsi
call evn_store@PLT
movq %rax, -368(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -376(%rbp)
movabsq $2, %rax
movq %rax, -384(%rbp)
movq -376(%rbp), %rdi
movq -384(%rbp), %rsi
call evn_member@PLT
movq %rax, -392(%rbp)
leaq .Ldata_126(%rip), %rax
movq %rax, -400(%rbp)
movabsq $14, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_text@PLT
movq %rax, -416(%rbp)
movabsq $5, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -392(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_binary@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rax
movq %rax, -440(%rbp)
movq -432(%rbp), %rdi
call evn_truth@PLT
movq %rax, -448(%rbp)
cmpq $0, -448(%rbp)
je .Lf112_b7
jmp .Lf112_b6
.Lf112_b3:
movq -48(%rbp), %rdi
movq -280(%rbp), %rsi
call evn_store@PLT
movq %rax, -784(%rbp)
movabsq $41, %rax
movq %rax, -792(%rbp)
movabsq $1, %rax
movq %rax, -800(%rbp)
movq -792(%rbp), %rdi
movq -800(%rbp), %rsi
call evn_object@PLT
movq %rax, -808(%rbp)
leaq .Ldata_127(%rip), %rax
movq %rax, -816(%rbp)
movabsq $19, %rax
movq %rax, -824(%rbp)
movq -816(%rbp), %rdi
movq -824(%rbp), %rsi
call evn_text@PLT
movq %rax, -832(%rbp)
movabsq $0, %rax
movq %rax, -840(%rbp)
movq -808(%rbp), %rdi
movq -840(%rbp), %rsi
movq -832(%rbp), %rdx
call evn_init@PLT
movq %rax, -848(%rbp)
movabsq $0, %rax
movq %rax, -856(%rbp)
movq -808(%rbp), %rdi
movq -856(%rbp), %rsi
call evn_fail@PLT
movq %rax, -864(%rbp)
ud2
.Lf112_b2:
movq -272(%rbp), %rdi
call evn_pop@PLT
movq %rax, -328(%rbp)
call evn_saved@PLT
movq %rax, -336(%rbp)
movabsq $9, %rax
movq %rax, -344(%rbp)
movq -336(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_match@PLT
movq %rax, -352(%rbp)
cmpq $0, -352(%rbp)
je .Lf112_b5
jmp .Lf112_b4
.Lf112_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -288(%rbp)
movabsq $1, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
call evn_int@PLT
movq %rax, -304(%rbp)
movq -288(%rbp), %rdi
movq -304(%rbp), %rsi
call f22@PLT
movq %rax, -312(%rbp)
movq -312(%rbp), %rax
movq %rax, -280(%rbp)
movq -272(%rbp), %rdi
call evn_pop@PLT
movq %rax, -320(%rbp)
jmp .Lf112_b3
.Lf112_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -864(%rbp), %rsi
leaq .Lroots_f112(%rip), %rdx
movq $108, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movabsq $100, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $12, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $100, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call f29@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $100, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $100, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $100, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movq -120(%rbp), %rdi
movq -136(%rbp), %rsi
movq -152(%rbp), %rdx
movq -168(%rbp), %rcx
movq -184(%rbp), %r8
call f27@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_store@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $12, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movq -208(%rbp), %rdi
movq -224(%rbp), %rsi
call f22@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call f20@PLT
movq %rax, -240(%rbp)
movq -32(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call f17@PLT
movq %rax, -264(%rbp)
call evn_frame@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf112_b2
jmp .Lf112_b1
.size f112, .-f112
.text
.p2align 4
.type f113, @function
f113:
pushq %rbp
movq %rsp, %rbp
subq $800, %rsp
leaq -792(%rbp), %rdi
movq $99, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf113_b0
.Lf113_b11:
leaq .Ldata_128(%rip), %rax
movq %rax, -584(%rbp)
movabsq $26, %rax
movq %rax, -592(%rbp)
movq -584(%rbp), %rdi
movq -592(%rbp), %rsi
call evn_text@PLT
movq %rax, -600(%rbp)
movq -512(%rbp), %rdi
movq -600(%rbp), %rsi
call f123@PLT
movq %rax, -608(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -616(%rbp)
movq -616(%rbp), %rdi
call f8@PLT
movq %rax, -624(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movq -632(%rbp), %rdi
call f8@PLT
movq %rax, -640(%rbp)
leaq .Ldata_129(%rip), %rax
movq %rax, -648(%rbp)
movabsq $9, %rax
movq %rax, -656(%rbp)
movq -648(%rbp), %rdi
movq -656(%rbp), %rsi
call evn_text@PLT
movq %rax, -664(%rbp)
movq -664(%rbp), %rdi
call evn_output@PLT
movq %rax, -672(%rbp)
call evn_void@PLT
movq %rax, -680(%rbp)
call evn_void@PLT
movq %rax, -688(%rbp)
movq -8(%rbp), %rdi
movq -688(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -696(%rbp)
movq -696(%rbp), %rax
leave
ret
.Lf113_b10:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $5, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movabsq $0, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $5, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -544(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movq -576(%rbp), %rax
movq %rax, -512(%rbp)
jmp .Lf113_b11
.Lf113_b9:
movq -440(%rbp), %rax
movq %rax, -512(%rbp)
movq -440(%rbp), %rdi
call evn_truth@PLT
movq %rax, -520(%rbp)
cmpq $0, -520(%rbp)
je .Lf113_b11
jmp .Lf113_b10
.Lf113_b8:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -456(%rbp)
movabsq $5, %rax
movq %rax, -464(%rbp)
movq -456(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_member@PLT
movq %rax, -472(%rbp)
movabsq $0, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
call evn_int@PLT
movq %rax, -488(%rbp)
movabsq $5, %rax
movq %rax, -496(%rbp)
movq -496(%rbp), %rdi
movq -472(%rbp), %rsi
movq -488(%rbp), %rdx
call evn_binary@PLT
movq %rax, -504(%rbp)
movq -504(%rbp), %rax
movq %rax, -440(%rbp)
jmp .Lf113_b9
.Lf113_b7:
movq -368(%rbp), %rax
movq %rax, -440(%rbp)
movq -368(%rbp), %rdi
call evn_truth@PLT
movq %rax, -448(%rbp)
cmpq $0, -448(%rbp)
je .Lf113_b9
jmp .Lf113_b8
.Lf113_b6:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -384(%rbp)
movabsq $6, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_member@PLT
movq %rax, -400(%rbp)
movabsq $0, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
call evn_int@PLT
movq %rax, -416(%rbp)
movabsq $5, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
movq -400(%rbp), %rsi
movq -416(%rbp), %rdx
call evn_binary@PLT
movq %rax, -432(%rbp)
movq -432(%rbp), %rax
movq %rax, -368(%rbp)
jmp .Lf113_b7
.Lf113_b5:
movq -264(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -704(%rbp)
ud2
.Lf113_b4:
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_error@PLT
movq %rax, -288(%rbp)
movq -32(%rbp), %rdi
movq -288(%rbp), %rsi
call evn_store@PLT
movq %rax, -296(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -304(%rbp)
movabsq $2, %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
movq -312(%rbp), %rsi
call evn_member@PLT
movq %rax, -320(%rbp)
leaq .Ldata_130(%rip), %rax
movq %rax, -328(%rbp)
movabsq $14, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_text@PLT
movq %rax, -344(%rbp)
movabsq $5, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
movq -320(%rbp), %rsi
movq -344(%rbp), %rdx
call evn_binary@PLT
movq %rax, -360(%rbp)
movq -360(%rbp), %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
call evn_truth@PLT
movq %rax, -376(%rbp)
cmpq $0, -376(%rbp)
je .Lf113_b7
jmp .Lf113_b6
.Lf113_b3:
movq -40(%rbp), %rdi
movq -208(%rbp), %rsi
call evn_store@PLT
movq %rax, -712(%rbp)
movabsq $41, %rax
movq %rax, -720(%rbp)
movabsq $1, %rax
movq %rax, -728(%rbp)
movq -720(%rbp), %rdi
movq -728(%rbp), %rsi
call evn_object@PLT
movq %rax, -736(%rbp)
leaq .Ldata_131(%rip), %rax
movq %rax, -744(%rbp)
movabsq $18, %rax
movq %rax, -752(%rbp)
movq -744(%rbp), %rdi
movq -752(%rbp), %rsi
call evn_text@PLT
movq %rax, -760(%rbp)
movabsq $0, %rax
movq %rax, -768(%rbp)
movq -736(%rbp), %rdi
movq -768(%rbp), %rsi
movq -760(%rbp), %rdx
call evn_init@PLT
movq %rax, -776(%rbp)
movabsq $0, %rax
movq %rax, -784(%rbp)
movq -736(%rbp), %rdi
movq -784(%rbp), %rsi
call evn_fail@PLT
movq %rax, -792(%rbp)
ud2
.Lf113_b2:
movq -200(%rbp), %rdi
call evn_pop@PLT
movq %rax, -256(%rbp)
call evn_saved@PLT
movq %rax, -264(%rbp)
movabsq $9, %rax
movq %rax, -272(%rbp)
movq -264(%rbp), %rdi
movq -272(%rbp), %rsi
call evn_match@PLT
movq %rax, -280(%rbp)
cmpq $0, -280(%rbp)
je .Lf113_b5
jmp .Lf113_b4
.Lf113_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $11, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movq -216(%rbp), %rdi
movq -232(%rbp), %rsi
call f22@PLT
movq %rax, -240(%rbp)
movq -240(%rbp), %rax
movq %rax, -208(%rbp)
movq -200(%rbp), %rdi
call evn_pop@PLT
movq %rax, -248(%rbp)
jmp .Lf113_b3
.Lf113_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -792(%rbp), %rsi
leaq .Lroots_f113(%rip), %rdx
movq $99, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
movabsq $10, %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_int@PLT
movq %rax, -56(%rbp)
movabsq $100, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $100, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movq -56(%rbp), %rdi
movq -72(%rbp), %rsi
movq -88(%rbp), %rdx
call f29@PLT
movq %rax, -96(%rbp)
movq -16(%rbp), %rdi
movq -96(%rbp), %rsi
call evn_store@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -112(%rbp)
movabsq $2, %rax
movq %rax, -120(%rbp)
movq -120(%rbp), %rdi
call evn_int@PLT
movq %rax, -128(%rbp)
movabsq $100, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $100, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $100, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movq -112(%rbp), %rdi
movq -128(%rbp), %rsi
movq -144(%rbp), %rdx
movq -160(%rbp), %rcx
movq -176(%rbp), %r8
call f27@PLT
movq %rax, -184(%rbp)
movq -24(%rbp), %rdi
movq -184(%rbp), %rsi
call evn_store@PLT
movq %rax, -192(%rbp)
call evn_frame@PLT
movq %rax, -200(%rbp)
movq -200(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf113_b2
jmp .Lf113_b1
.size f113, .-f113
.text
.p2align 4
.type f114, @function
f114:
pushq %rbp
movq %rsp, %rbp
subq $1024, %rsp
leaq -1024(%rbp), %rdi
movq $128, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf114_b0
.Lf114_b13:
leaq .Ldata_132(%rip), %rax
movq %rax, -800(%rbp)
movabsq $28, %rax
movq %rax, -808(%rbp)
movq -800(%rbp), %rdi
movq -808(%rbp), %rsi
call evn_text@PLT
movq %rax, -816(%rbp)
movq -728(%rbp), %rdi
movq -816(%rbp), %rsi
call f123@PLT
movq %rax, -824(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
call f17@PLT
movq %rax, -840(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
call f8@PLT
movq %rax, -856(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -864(%rbp)
movq -864(%rbp), %rdi
call f8@PLT
movq %rax, -872(%rbp)
leaq .Ldata_133(%rip), %rax
movq %rax, -880(%rbp)
movabsq $11, %rax
movq %rax, -888(%rbp)
movq -880(%rbp), %rdi
movq -888(%rbp), %rsi
call evn_text@PLT
movq %rax, -896(%rbp)
movq -896(%rbp), %rdi
call evn_output@PLT
movq %rax, -904(%rbp)
call evn_void@PLT
movq %rax, -912(%rbp)
call evn_void@PLT
movq %rax, -920(%rbp)
movq -8(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -928(%rbp)
movq -928(%rbp), %rax
leave
ret
.Lf114_b12:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -744(%rbp)
movabsq $10, %rax
movq %rax, -752(%rbp)
movq -744(%rbp), %rdi
movq -752(%rbp), %rsi
call evn_member@PLT
movq %rax, -760(%rbp)
movabsq $1, %rax
movq %rax, -768(%rbp)
movq -768(%rbp), %rdi
call evn_int@PLT
movq %rax, -776(%rbp)
movabsq $5, %rax
movq %rax, -784(%rbp)
movq -784(%rbp), %rdi
movq -760(%rbp), %rsi
movq -776(%rbp), %rdx
call evn_binary@PLT
movq %rax, -792(%rbp)
movq -792(%rbp), %rax
movq %rax, -728(%rbp)
jmp .Lf114_b13
.Lf114_b11:
movq -656(%rbp), %rax
movq %rax, -728(%rbp)
movq -656(%rbp), %rdi
call evn_truth@PLT
movq %rax, -736(%rbp)
cmpq $0, -736(%rbp)
je .Lf114_b13
jmp .Lf114_b12
.Lf114_b10:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -672(%rbp)
movabsq $2, %rax
movq %rax, -680(%rbp)
movq -672(%rbp), %rdi
movq -680(%rbp), %rsi
call evn_member@PLT
movq %rax, -688(%rbp)
movabsq $12, %rax
movq %rax, -696(%rbp)
movq -696(%rbp), %rdi
call evn_int@PLT
movq %rax, -704(%rbp)
movabsq $5, %rax
movq %rax, -712(%rbp)
movq -712(%rbp), %rdi
movq -688(%rbp), %rsi
movq -704(%rbp), %rdx
call evn_binary@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rax
movq %rax, -656(%rbp)
jmp .Lf114_b11
.Lf114_b9:
movq -584(%rbp), %rax
movq %rax, -656(%rbp)
movq -584(%rbp), %rdi
call evn_truth@PLT
movq %rax, -664(%rbp)
cmpq $0, -664(%rbp)
je .Lf114_b11
jmp .Lf114_b10
.Lf114_b8:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -600(%rbp)
movabsq $5, %rax
movq %rax, -608(%rbp)
movq -600(%rbp), %rdi
movq -608(%rbp), %rsi
call evn_member@PLT
movq %rax, -616(%rbp)
movabsq $0, %rax
movq %rax, -624(%rbp)
movq -624(%rbp), %rdi
call evn_int@PLT
movq %rax, -632(%rbp)
movabsq $5, %rax
movq %rax, -640(%rbp)
movq -640(%rbp), %rdi
movq -616(%rbp), %rsi
movq -632(%rbp), %rdx
call evn_binary@PLT
movq %rax, -648(%rbp)
movq -648(%rbp), %rax
movq %rax, -584(%rbp)
jmp .Lf114_b9
.Lf114_b7:
leaq .Ldata_134(%rip), %rax
movq %rax, -496(%rbp)
movabsq $21, %rax
movq %rax, -504(%rbp)
movq -496(%rbp), %rdi
movq -504(%rbp), %rsi
call evn_text@PLT
movq %rax, -512(%rbp)
movq -424(%rbp), %rdi
movq -512(%rbp), %rsi
call f123@PLT
movq %rax, -520(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -528(%rbp)
movabsq $6, %rax
movq %rax, -536(%rbp)
movq -528(%rbp), %rdi
movq -536(%rbp), %rsi
call evn_member@PLT
movq %rax, -544(%rbp)
movabsq $12, %rax
movq %rax, -552(%rbp)
movq -552(%rbp), %rdi
call evn_int@PLT
movq %rax, -560(%rbp)
movabsq $5, %rax
movq %rax, -568(%rbp)
movq -568(%rbp), %rdi
movq -544(%rbp), %rsi
movq -560(%rbp), %rdx
call evn_binary@PLT
movq %rax, -576(%rbp)
movq -576(%rbp), %rax
movq %rax, -584(%rbp)
movq -576(%rbp), %rdi
call evn_truth@PLT
movq %rax, -592(%rbp)
cmpq $0, -592(%rbp)
je .Lf114_b9
jmp .Lf114_b8
.Lf114_b6:
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -440(%rbp)
movabsq $0, %rax
movq %rax, -448(%rbp)
movq -440(%rbp), %rdi
movq -448(%rbp), %rsi
call evn_member@PLT
movq %rax, -456(%rbp)
movabsq $4, %rax
movq %rax, -464(%rbp)
movq -464(%rbp), %rdi
call evn_int@PLT
movq %rax, -472(%rbp)
movabsq $5, %rax
movq %rax, -480(%rbp)
movq -480(%rbp), %rdi
movq -456(%rbp), %rsi
movq -472(%rbp), %rdx
call evn_binary@PLT
movq %rax, -488(%rbp)
movq -488(%rbp), %rax
movq %rax, -424(%rbp)
jmp .Lf114_b7
.Lf114_b5:
movq -320(%rbp), %rdi
call evn_propagate@PLT
movq %rax, -936(%rbp)
ud2
.Lf114_b4:
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_error@PLT
movq %rax, -344(%rbp)
movq -40(%rbp), %rdi
movq -344(%rbp), %rsi
call evn_store@PLT
movq %rax, -352(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -360(%rbp)
movabsq $2, %rax
movq %rax, -368(%rbp)
movq -360(%rbp), %rdi
movq -368(%rbp), %rsi
call evn_member@PLT
movq %rax, -376(%rbp)
leaq .Ldata_135(%rip), %rax
movq %rax, -384(%rbp)
movabsq $14, %rax
movq %rax, -392(%rbp)
movq -384(%rbp), %rdi
movq -392(%rbp), %rsi
call evn_text@PLT
movq %rax, -400(%rbp)
movabsq $5, %rax
movq %rax, -408(%rbp)
movq -408(%rbp), %rdi
movq -376(%rbp), %rsi
movq -400(%rbp), %rdx
call evn_binary@PLT
movq %rax, -416(%rbp)
movq -416(%rbp), %rax
movq %rax, -424(%rbp)
movq -416(%rbp), %rdi
call evn_truth@PLT
movq %rax, -432(%rbp)
cmpq $0, -432(%rbp)
je .Lf114_b7
jmp .Lf114_b6
.Lf114_b3:
movq -48(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_store@PLT
movq %rax, -944(%rbp)
movabsq $41, %rax
movq %rax, -952(%rbp)
movabsq $1, %rax
movq %rax, -960(%rbp)
movq -952(%rbp), %rdi
movq -960(%rbp), %rsi
call evn_object@PLT
movq %rax, -968(%rbp)
leaq .Ldata_136(%rip), %rax
movq %rax, -976(%rbp)
movabsq $20, %rax
movq %rax, -984(%rbp)
movq -976(%rbp), %rdi
movq -984(%rbp), %rsi
call evn_text@PLT
movq %rax, -992(%rbp)
movabsq $0, %rax
movq %rax, -1000(%rbp)
movq -968(%rbp), %rdi
movq -1000(%rbp), %rsi
movq -992(%rbp), %rdx
call evn_init@PLT
movq %rax, -1008(%rbp)
movabsq $0, %rax
movq %rax, -1016(%rbp)
movq -968(%rbp), %rdi
movq -1016(%rbp), %rsi
call evn_fail@PLT
movq %rax, -1024(%rbp)
ud2
.Lf114_b2:
movq -256(%rbp), %rdi
call evn_pop@PLT
movq %rax, -312(%rbp)
call evn_saved@PLT
movq %rax, -320(%rbp)
movabsq $9, %rax
movq %rax, -328(%rbp)
movq -320(%rbp), %rdi
movq -328(%rbp), %rsi
call evn_match@PLT
movq %rax, -336(%rbp)
cmpq $0, -336(%rbp)
je .Lf114_b5
jmp .Lf114_b4
.Lf114_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -272(%rbp)
movabsq $8, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movq -272(%rbp), %rdi
movq -288(%rbp), %rsi
call f22@PLT
movq %rax, -296(%rbp)
movq -296(%rbp), %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
call evn_pop@PLT
movq %rax, -304(%rbp)
jmp .Lf114_b3
.Lf114_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1024(%rbp), %rsi
leaq .Lroots_f114(%rip), %rdx
movq $128, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
movabsq $100, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
call evn_int@PLT
movq %rax, -64(%rbp)
movabsq $100, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_int@PLT
movq %rax, -80(%rbp)
movabsq $100, %rax
movq %rax, -88(%rbp)
movq -88(%rbp), %rdi
call evn_int@PLT
movq %rax, -96(%rbp)
movq -64(%rbp), %rdi
movq -80(%rbp), %rsi
movq -96(%rbp), %rdx
call f29@PLT
movq %rax, -104(%rbp)
movq -16(%rbp), %rdi
movq -104(%rbp), %rsi
call evn_store@PLT
movq %rax, -112(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movabsq $2, %rax
movq %rax, -128(%rbp)
movq -128(%rbp), %rdi
call evn_int@PLT
movq %rax, -136(%rbp)
movabsq $16, %rax
movq %rax, -144(%rbp)
movq -144(%rbp), %rdi
call evn_int@PLT
movq %rax, -152(%rbp)
movabsq $100, %rax
movq %rax, -160(%rbp)
movq -160(%rbp), %rdi
call evn_int@PLT
movq %rax, -168(%rbp)
movabsq $100, %rax
movq %rax, -176(%rbp)
movq -176(%rbp), %rdi
call evn_int@PLT
movq %rax, -184(%rbp)
movq -120(%rbp), %rdi
movq -136(%rbp), %rsi
movq -152(%rbp), %rdx
movq -168(%rbp), %rcx
movq -184(%rbp), %r8
call f27@PLT
movq %rax, -192(%rbp)
movq -24(%rbp), %rdi
movq -192(%rbp), %rsi
call evn_store@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -208(%rbp)
movabsq $12, %rax
movq %rax, -216(%rbp)
movq -216(%rbp), %rdi
call evn_int@PLT
movq %rax, -224(%rbp)
movq -208(%rbp), %rdi
movq -224(%rbp), %rsi
call f22@PLT
movq %rax, -232(%rbp)
movq -232(%rbp), %rdi
call f20@PLT
movq %rax, -240(%rbp)
movq -32(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
call evn_frame@PLT
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call setjmp@PLT
testl %eax, %eax
jne .Lf114_b2
jmp .Lf114_b1
.size f114, .-f114
.text
.p2align 4
.type f115, @function
f115:
pushq %rbp
movq %rsp, %rbp
subq $1664, %rsp
leaq -1664(%rbp), %rdi
movq $208, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf115_b0
.Lf115_b18:
leaq .Ldata_137(%rip), %rax
movq %rax, -1552(%rbp)
movabsq $34, %rax
movq %rax, -1560(%rbp)
movq -1552(%rbp), %rdi
movq -1560(%rbp), %rsi
call evn_text@PLT
movq %rax, -1568(%rbp)
movq -1480(%rbp), %rdi
movq -1568(%rbp), %rsi
call f123@PLT
movq %rax, -1576(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1584(%rbp)
movq -1584(%rbp), %rdi
call f8@PLT
movq %rax, -1592(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1600(%rbp)
movq -1600(%rbp), %rdi
call f8@PLT
movq %rax, -1608(%rbp)
leaq .Ldata_138(%rip), %rax
movq %rax, -1616(%rbp)
movabsq $15, %rax
movq %rax, -1624(%rbp)
movq -1616(%rbp), %rdi
movq -1624(%rbp), %rsi
call evn_text@PLT
movq %rax, -1632(%rbp)
movq -1632(%rbp), %rdi
call evn_output@PLT
movq %rax, -1640(%rbp)
call evn_void@PLT
movq %rax, -1648(%rbp)
call evn_void@PLT
movq %rax, -1656(%rbp)
movq -8(%rbp), %rdi
movq -1656(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -1664(%rbp)
movq -1664(%rbp), %rax
leave
ret
.Lf115_b17:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1496(%rbp)
movabsq $2, %rax
movq %rax, -1504(%rbp)
movq -1496(%rbp), %rdi
movq -1504(%rbp), %rsi
call evn_member@PLT
movq %rax, -1512(%rbp)
movabsq $30, %rax
movq %rax, -1520(%rbp)
movq -1520(%rbp), %rdi
call evn_int@PLT
movq %rax, -1528(%rbp)
movabsq $5, %rax
movq %rax, -1536(%rbp)
movq -1536(%rbp), %rdi
movq -1512(%rbp), %rsi
movq -1528(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1544(%rbp)
movq -1544(%rbp), %rax
movq %rax, -1480(%rbp)
jmp .Lf115_b18
.Lf115_b16:
leaq .Ldata_139(%rip), %rax
movq %rax, -1360(%rbp)
movabsq $14, %rax
movq %rax, -1368(%rbp)
movq -1360(%rbp), %rdi
movq -1368(%rbp), %rsi
call evn_text@PLT
movq %rax, -1376(%rbp)
movq -1288(%rbp), %rdi
movq -1376(%rbp), %rsi
call f123@PLT
movq %rax, -1384(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1392(%rbp)
movq -1392(%rbp), %rdi
call f17@PLT
movq %rax, -1400(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1408(%rbp)
movq -1408(%rbp), %rdi
call f17@PLT
movq %rax, -1416(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1424(%rbp)
movabsq $6, %rax
movq %rax, -1432(%rbp)
movq -1424(%rbp), %rdi
movq -1432(%rbp), %rsi
call evn_member@PLT
movq %rax, -1440(%rbp)
movabsq $0, %rax
movq %rax, -1448(%rbp)
movq -1448(%rbp), %rdi
call evn_int@PLT
movq %rax, -1456(%rbp)
movabsq $5, %rax
movq %rax, -1464(%rbp)
movq -1464(%rbp), %rdi
movq -1440(%rbp), %rsi
movq -1456(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1472(%rbp)
movq -1472(%rbp), %rax
movq %rax, -1480(%rbp)
movq -1472(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1488(%rbp)
cmpq $0, -1488(%rbp)
je .Lf115_b18
jmp .Lf115_b17
.Lf115_b15:
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1304(%rbp)
movabsq $1, %rax
movq %rax, -1312(%rbp)
movq -1304(%rbp), %rdi
movq -1312(%rbp), %rsi
call evn_member@PLT
movq %rax, -1320(%rbp)
movabsq $7, %rax
movq %rax, -1328(%rbp)
movq -1328(%rbp), %rdi
call evn_int@PLT
movq %rax, -1336(%rbp)
movabsq $5, %rax
movq %rax, -1344(%rbp)
movq -1344(%rbp), %rdi
movq -1320(%rbp), %rsi
movq -1336(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1352(%rbp)
movq -1352(%rbp), %rax
movq %rax, -1288(%rbp)
jmp .Lf115_b16
.Lf115_b14:
leaq .Ldata_140(%rip), %rax
movq %rax, -1160(%rbp)
movabsq $20, %rax
movq %rax, -1168(%rbp)
movq -1160(%rbp), %rdi
movq -1168(%rbp), %rsi
call evn_text@PLT
movq %rax, -1176(%rbp)
movq -1088(%rbp), %rdi
movq -1176(%rbp), %rsi
call f123@PLT
movq %rax, -1184(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1192(%rbp)
movabsq $7, %rax
movq %rax, -1200(%rbp)
movq -1200(%rbp), %rdi
call evn_int@PLT
movq %rax, -1208(%rbp)
movq -1192(%rbp), %rdi
movq -1208(%rbp), %rsi
call f15@PLT
movq %rax, -1216(%rbp)
movq -56(%rbp), %rdi
movq -1216(%rbp), %rsi
call evn_store@PLT
movq %rax, -1224(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1232(%rbp)
movabsq $1, %rax
movq %rax, -1240(%rbp)
movq -1232(%rbp), %rdi
movq -1240(%rbp), %rsi
call evn_member@PLT
movq %rax, -1248(%rbp)
movabsq $23, %rax
movq %rax, -1256(%rbp)
movq -1256(%rbp), %rdi
call evn_int@PLT
movq %rax, -1264(%rbp)
movabsq $5, %rax
movq %rax, -1272(%rbp)
movq -1272(%rbp), %rdi
movq -1248(%rbp), %rsi
movq -1264(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1280(%rbp)
movq -1280(%rbp), %rax
movq %rax, -1288(%rbp)
movq -1280(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1296(%rbp)
cmpq $0, -1296(%rbp)
je .Lf115_b16
jmp .Lf115_b15
.Lf115_b13:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1104(%rbp)
movabsq $2, %rax
movq %rax, -1112(%rbp)
movq -1104(%rbp), %rdi
movq -1112(%rbp), %rsi
call evn_member@PLT
movq %rax, -1120(%rbp)
movabsq $30, %rax
movq %rax, -1128(%rbp)
movq -1128(%rbp), %rdi
call evn_int@PLT
movq %rax, -1136(%rbp)
movabsq $5, %rax
movq %rax, -1144(%rbp)
movq -1144(%rbp), %rdi
movq -1120(%rbp), %rsi
movq -1136(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1152(%rbp)
movq -1152(%rbp), %rax
movq %rax, -1088(%rbp)
jmp .Lf115_b14
.Lf115_b12:
movq -1016(%rbp), %rax
movq %rax, -1088(%rbp)
movq -1016(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1096(%rbp)
cmpq $0, -1096(%rbp)
je .Lf115_b14
jmp .Lf115_b13
.Lf115_b11:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -1032(%rbp)
movabsq $6, %rax
movq %rax, -1040(%rbp)
movq -1032(%rbp), %rdi
movq -1040(%rbp), %rsi
call evn_member@PLT
movq %rax, -1048(%rbp)
movabsq $30, %rax
movq %rax, -1056(%rbp)
movq -1056(%rbp), %rdi
call evn_int@PLT
movq %rax, -1064(%rbp)
movabsq $5, %rax
movq %rax, -1072(%rbp)
movq -1072(%rbp), %rdi
movq -1048(%rbp), %rsi
movq -1064(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1080(%rbp)
movq -1080(%rbp), %rax
movq %rax, -1016(%rbp)
jmp .Lf115_b12
.Lf115_b10:
leaq .Ldata_141(%rip), %rax
movq %rax, -864(%rbp)
movabsq $47, %rax
movq %rax, -872(%rbp)
movq -864(%rbp), %rdi
movq -872(%rbp), %rsi
call evn_text@PLT
movq %rax, -880(%rbp)
movq -792(%rbp), %rdi
movq -880(%rbp), %rsi
call f123@PLT
movq %rax, -888(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -896(%rbp)
movabsq $30, %rax
movq %rax, -904(%rbp)
movq -904(%rbp), %rdi
call evn_int@PLT
movq %rax, -912(%rbp)
movq -896(%rbp), %rdi
movq -912(%rbp), %rsi
call f22@PLT
movq %rax, -920(%rbp)
movq -40(%rbp), %rdi
movq -920(%rbp), %rsi
call evn_store@PLT
movq %rax, -928(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -936(%rbp)
movq -936(%rbp), %rdi
call f20@PLT
movq %rax, -944(%rbp)
movq -48(%rbp), %rdi
movq -944(%rbp), %rsi
call evn_store@PLT
movq %rax, -952(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -960(%rbp)
movabsq $6, %rax
movq %rax, -968(%rbp)
movq -960(%rbp), %rdi
movq -968(%rbp), %rsi
call evn_member@PLT
movq %rax, -976(%rbp)
movabsq $30, %rax
movq %rax, -984(%rbp)
movq -984(%rbp), %rdi
call evn_int@PLT
movq %rax, -992(%rbp)
movabsq $5, %rax
movq %rax, -1000(%rbp)
movq -1000(%rbp), %rdi
movq -976(%rbp), %rsi
movq -992(%rbp), %rdx
call evn_binary@PLT
movq %rax, -1008(%rbp)
movq -1008(%rbp), %rax
movq %rax, -1016(%rbp)
movq -1008(%rbp), %rdi
call evn_truth@PLT
movq %rax, -1024(%rbp)
cmpq $0, -1024(%rbp)
je .Lf115_b12
jmp .Lf115_b11
.Lf115_b9:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -808(%rbp)
movabsq $2, %rax
movq %rax, -816(%rbp)
movq -808(%rbp), %rdi
movq -816(%rbp), %rsi
call evn_member@PLT
movq %rax, -824(%rbp)
movabsq $0, %rax
movq %rax, -832(%rbp)
movq -832(%rbp), %rdi
call evn_int@PLT
movq %rax, -840(%rbp)
movabsq $5, %rax
movq %rax, -848(%rbp)
movq -848(%rbp), %rdi
movq -824(%rbp), %rsi
movq -840(%rbp), %rdx
call evn_binary@PLT
movq %rax, -856(%rbp)
movq -856(%rbp), %rax
movq %rax, -792(%rbp)
jmp .Lf115_b10
.Lf115_b8:
leaq .Ldata_142(%rip), %rax
movq %rax, -688(%rbp)
movabsq $29, %rax
movq %rax, -696(%rbp)
movq -688(%rbp), %rdi
movq -696(%rbp), %rsi
call evn_text@PLT
movq %rax, -704(%rbp)
movq -616(%rbp), %rdi
movq -704(%rbp), %rsi
call f123@PLT
movq %rax, -712(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -720(%rbp)
movq -720(%rbp), %rdi
call f18@PLT
movq %rax, -728(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -736(%rbp)
movabsq $5, %rax
movq %rax, -744(%rbp)
movq -736(%rbp), %rdi
movq -744(%rbp), %rsi
call evn_member@PLT
movq %rax, -752(%rbp)
movabsq $0, %rax
movq %rax, -760(%rbp)
movq -760(%rbp), %rdi
call evn_int@PLT
movq %rax, -768(%rbp)
movabsq $5, %rax
movq %rax, -776(%rbp)
movq -776(%rbp), %rdi
movq -752(%rbp), %rsi
movq -768(%rbp), %rdx
call evn_binary@PLT
movq %rax, -784(%rbp)
movq -784(%rbp), %rax
movq %rax, -792(%rbp)
movq -784(%rbp), %rdi
call evn_truth@PLT
movq %rax, -800(%rbp)
cmpq $0, -800(%rbp)
je .Lf115_b10
jmp .Lf115_b9
.Lf115_b7:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -632(%rbp)
movabsq $3, %rax
movq %rax, -640(%rbp)
movq -632(%rbp), %rdi
movq -640(%rbp), %rsi
call evn_member@PLT
movq %rax, -648(%rbp)
movabsq $20, %rax
movq %rax, -656(%rbp)
movq -656(%rbp), %rdi
call evn_int@PLT
movq %rax, -664(%rbp)
movabsq $5, %rax
movq %rax, -672(%rbp)
movq -672(%rbp), %rdi
movq -648(%rbp), %rsi
movq -664(%rbp), %rdx
call evn_binary@PLT
movq %rax, -680(%rbp)
movq -680(%rbp), %rax
movq %rax, -616(%rbp)
jmp .Lf115_b8
.Lf115_b6:
movq -544(%rbp), %rax
movq %rax, -616(%rbp)
movq -544(%rbp), %rdi
call evn_truth@PLT
movq %rax, -624(%rbp)
cmpq $0, -624(%rbp)
je .Lf115_b8
jmp .Lf115_b7
.Lf115_b5:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -560(%rbp)
movabsq $4, %rax
movq %rax, -568(%rbp)
movq -560(%rbp), %rdi
movq -568(%rbp), %rsi
call evn_member@PLT
movq %rax, -576(%rbp)
movabsq $0, %rax
movq %rax, -584(%rbp)
movq -584(%rbp), %rdi
call evn_int@PLT
movq %rax, -592(%rbp)
movabsq $5, %rax
movq %rax, -600(%rbp)
movq -600(%rbp), %rdi
movq -576(%rbp), %rsi
movq -592(%rbp), %rdx
call evn_binary@PLT
movq %rax, -608(%rbp)
movq -608(%rbp), %rax
movq %rax, -544(%rbp)
jmp .Lf115_b6
.Lf115_b4:
leaq .Ldata_143(%rip), %rax
movq %rax, -456(%rbp)
movabsq $17, %rax
movq %rax, -464(%rbp)
movq -456(%rbp), %rdi
movq -464(%rbp), %rsi
call evn_text@PLT
movq %rax, -472(%rbp)
movq -384(%rbp), %rdi
movq -472(%rbp), %rsi
call f123@PLT
movq %rax, -480(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -488(%rbp)
movabsq $2, %rax
movq %rax, -496(%rbp)
movq -488(%rbp), %rdi
movq -496(%rbp), %rsi
call evn_member@PLT
movq %rax, -504(%rbp)
movabsq $0, %rax
movq %rax, -512(%rbp)
movq -512(%rbp), %rdi
call evn_int@PLT
movq %rax, -520(%rbp)
movabsq $5, %rax
movq %rax, -528(%rbp)
movq -528(%rbp), %rdi
movq -504(%rbp), %rsi
movq -520(%rbp), %rdx
call evn_binary@PLT
movq %rax, -536(%rbp)
movq -536(%rbp), %rax
movq %rax, -544(%rbp)
movq -536(%rbp), %rdi
call evn_truth@PLT
movq %rax, -552(%rbp)
cmpq $0, -552(%rbp)
je .Lf115_b6
jmp .Lf115_b5
.Lf115_b3:
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -400(%rbp)
movabsq $5, %rax
movq %rax, -408(%rbp)
movq -400(%rbp), %rdi
movq -408(%rbp), %rsi
call evn_member@PLT
movq %rax, -416(%rbp)
movabsq $20, %rax
movq %rax, -424(%rbp)
movq -424(%rbp), %rdi
call evn_int@PLT
movq %rax, -432(%rbp)
movabsq $5, %rax
movq %rax, -440(%rbp)
movq -440(%rbp), %rdi
movq -416(%rbp), %rsi
movq -432(%rbp), %rdx
call evn_binary@PLT
movq %rax, -448(%rbp)
movq -448(%rbp), %rax
movq %rax, -384(%rbp)
jmp .Lf115_b4
.Lf115_b2:
movq -312(%rbp), %rax
movq %rax, -384(%rbp)
movq -312(%rbp), %rdi
call evn_truth@PLT
movq %rax, -392(%rbp)
cmpq $0, -392(%rbp)
je .Lf115_b4
jmp .Lf115_b3
.Lf115_b1:
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -328(%rbp)
movabsq $5, %rax
movq %rax, -336(%rbp)
movq -328(%rbp), %rdi
movq -336(%rbp), %rsi
call evn_member@PLT
movq %rax, -344(%rbp)
movabsq $20, %rax
movq %rax, -352(%rbp)
movq -352(%rbp), %rdi
call evn_int@PLT
movq %rax, -360(%rbp)
movabsq $5, %rax
movq %rax, -368(%rbp)
movq -368(%rbp), %rdi
movq -344(%rbp), %rsi
movq -360(%rbp), %rdx
call evn_binary@PLT
movq %rax, -376(%rbp)
movq -376(%rbp), %rax
movq %rax, -312(%rbp)
jmp .Lf115_b2
.Lf115_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -1664(%rbp), %rsi
leaq .Lroots_f115(%rip), %rdx
movq $208, %rcx
call evn_bind_roots@PLT
call evn_void@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
call evn_void@PLT
movq %rax, -40(%rbp)
call evn_void@PLT
movq %rax, -48(%rbp)
call evn_void@PLT
movq %rax, -56(%rbp)
movabsq $100, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $100, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movabsq $100, %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_int@PLT
movq %rax, -104(%rbp)
movq -72(%rbp), %rdi
movq -88(%rbp), %rsi
movq -104(%rbp), %rdx
call f29@PLT
movq %rax, -112(%rbp)
movq -16(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_store@PLT
movq %rax, -120(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movabsq $2, %rax
movq %rax, -136(%rbp)
movq -136(%rbp), %rdi
call evn_int@PLT
movq %rax, -144(%rbp)
movabsq $80, %rax
movq %rax, -152(%rbp)
movq -152(%rbp), %rdi
call evn_int@PLT
movq %rax, -160(%rbp)
movabsq $80, %rax
movq %rax, -168(%rbp)
movq -168(%rbp), %rdi
call evn_int@PLT
movq %rax, -176(%rbp)
movabsq $80, %rax
movq %rax, -184(%rbp)
movq -184(%rbp), %rdi
call evn_int@PLT
movq %rax, -192(%rbp)
movq -128(%rbp), %rdi
movq -144(%rbp), %rsi
movq -160(%rbp), %rdx
movq -176(%rbp), %rcx
movq -192(%rbp), %r8
call f27@PLT
movq %rax, -200(%rbp)
movq -24(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_store@PLT
movq %rax, -208(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $20, %rax
movq %rax, -224(%rbp)
movq -224(%rbp), %rdi
call evn_int@PLT
movq %rax, -232(%rbp)
movq -216(%rbp), %rdi
movq -232(%rbp), %rsi
call f22@PLT
movq %rax, -240(%rbp)
movq -32(%rbp), %rdi
movq -240(%rbp), %rsi
call evn_store@PLT
movq %rax, -248(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -256(%rbp)
movabsq $6, %rax
movq %rax, -264(%rbp)
movq -256(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_member@PLT
movq %rax, -272(%rbp)
movabsq $0, %rax
movq %rax, -280(%rbp)
movq -280(%rbp), %rdi
call evn_int@PLT
movq %rax, -288(%rbp)
movabsq $5, %rax
movq %rax, -296(%rbp)
movq -296(%rbp), %rdi
movq -272(%rbp), %rsi
movq -288(%rbp), %rdx
call evn_binary@PLT
movq %rax, -304(%rbp)
movq -304(%rbp), %rax
movq %rax, -312(%rbp)
movq -304(%rbp), %rdi
call evn_truth@PLT
movq %rax, -320(%rbp)
cmpq $0, -320(%rbp)
je .Lf115_b2
jmp .Lf115_b1
.size f115, .-f115
.text
.p2align 4
.type f116, @function
f116:
pushq %rbp
movq %rsp, %rbp
subq $336, %rsp
movq %rdi, -280(%rbp)
movq %rsi, -288(%rbp)
movq %rdx, -296(%rbp)
movq %rcx, -304(%rbp)
movq %r8, -312(%rbp)
movq %r9, -320(%rbp)
movq 16(%rbp), %rax
movq %rax, -328(%rbp)
leaq -272(%rbp), %rdi
movq $34, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf116_b0
.Lf116_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -328(%rbp), %rsi
leaq .Lroots_f116(%rip), %rdx
movq $41, %rcx
call evn_bind_roots@PLT
movq -280(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -288(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -296(%rbp), %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -304(%rbp), %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_copy@PLT
movq %rax, -72(%rbp)
movq -312(%rbp), %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_copy@PLT
movq %rax, -88(%rbp)
movq -320(%rbp), %rax
movq %rax, -96(%rbp)
movq -96(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movq -328(%rbp), %rax
movq %rax, -112(%rbp)
movq -112(%rbp), %rdi
call evn_copy@PLT
movq %rax, -120(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -128(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -136(%rbp)
movq -56(%rbp), %rdi
call evn_copy@PLT
movq %rax, -144(%rbp)
movq -72(%rbp), %rdi
call evn_copy@PLT
movq %rax, -152(%rbp)
movabsq $38, %rax
movq %rax, -160(%rbp)
movabsq $0, %rax
movq %rax, -168(%rbp)
movq -160(%rbp), %rdi
movq -168(%rbp), %rsi
call evn_object@PLT
movq %rax, -176(%rbp)
movq -88(%rbp), %rdi
call evn_copy@PLT
movq %rax, -184(%rbp)
movabsq $38, %rax
movq %rax, -192(%rbp)
movabsq $1, %rax
movq %rax, -200(%rbp)
movq -192(%rbp), %rdi
movq -200(%rbp), %rsi
call evn_object@PLT
movq %rax, -208(%rbp)
movq -104(%rbp), %rdi
call evn_copy@PLT
movq %rax, -216(%rbp)
movabsq $0, %rax
movq %rax, -224(%rbp)
movq -208(%rbp), %rdi
movq -224(%rbp), %rsi
movq -216(%rbp), %rdx
call evn_init@PLT
movq %rax, -232(%rbp)
movq -120(%rbp), %rdi
call evn_copy@PLT
movq %rax, -240(%rbp)
movq -128(%rbp), %rdi
movq -136(%rbp), %rsi
movq -144(%rbp), %rdx
movq -152(%rbp), %rcx
movq -176(%rbp), %r8
movq -184(%rbp), %r9
pushq -240(%rbp)
pushq -208(%rbp)
call f78@PLT
addq $16, %rsp
movq %rax, -248(%rbp)
movabsq $0, %rax
movq %rax, -256(%rbp)
movq -256(%rbp), %rdi
call evn_bool@PLT
movq %rax, -264(%rbp)
movq -8(%rbp), %rdi
movq -264(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -272(%rbp)
movq -272(%rbp), %rax
leave
ret
.size f116, .-f116
.text
.p2align 4
.type f117, @function
f117:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
movq %rdi, -72(%rbp)
leaq -64(%rbp), %rdi
movq $8, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf117_b0
.Lf117_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f117(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movq -72(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call f75@PLT
movq %rax, -40(%rbp)
movabsq $0, %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_bool@PLT
movq %rax, -56(%rbp)
movq -8(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
leave
ret
.size f117, .-f117
.text
.p2align 4
.type f118, @function
f118:
pushq %rbp
movq %rsp, %rbp
subq $144, %rsp
movq %rdi, -128(%rbp)
movq %rsi, -136(%rbp)
leaq -120(%rbp), %rdi
movq $15, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf118_b0
.Lf118_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -136(%rbp), %rsi
leaq .Lroots_f118(%rip), %rdx
movq $17, %rcx
call evn_bind_roots@PLT
movq -128(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -136(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movabsq $0, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_int@PLT
movq %rax, -72(%rbp)
movabsq $9, %rax
movq %rax, -80(%rbp)
movq -80(%rbp), %rdi
call evn_int@PLT
movq %rax, -88(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
movq -72(%rbp), %rdx
movq -88(%rbp), %rcx
call f39@PLT
movq %rax, -96(%rbp)
movabsq $0, %rax
movq %rax, -104(%rbp)
movq -104(%rbp), %rdi
call evn_bool@PLT
movq %rax, -112(%rbp)
movq -8(%rbp), %rdi
movq -112(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -120(%rbp)
movq -120(%rbp), %rax
leave
ret
.size f118, .-f118
.text
.p2align 4
.type f119, @function
f119:
pushq %rbp
movq %rsp, %rbp
subq $112, %rsp
movq %rdi, -96(%rbp)
movq %rsi, -104(%rbp)
leaq -88(%rbp), %rdi
movq $11, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf119_b0
.Lf119_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -104(%rbp), %rsi
leaq .Lroots_f119(%rip), %rdx
movq $13, %rcx
call evn_bind_roots@PLT
movq -96(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -104(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call f13@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_bool@PLT
movq %rax, -80(%rbp)
movq -8(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rax
leave
ret
.size f119, .-f119
.text
.p2align 4
.type f120, @function
f120:
pushq %rbp
movq %rsp, %rbp
subq $80, %rsp
movq %rdi, -72(%rbp)
leaq -64(%rbp), %rdi
movq $8, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf120_b0
.Lf120_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -72(%rbp), %rsi
leaq .Lroots_f120(%rip), %rdx
movq $9, %rcx
call evn_bind_roots@PLT
movq -72(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call f17@PLT
movq %rax, -40(%rbp)
movabsq $0, %rax
movq %rax, -48(%rbp)
movq -48(%rbp), %rdi
call evn_bool@PLT
movq %rax, -56(%rbp)
movq -8(%rbp), %rdi
movq -56(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rax
leave
ret
.size f120, .-f120
.text
.p2align 4
.type f121, @function
f121:
pushq %rbp
movq %rsp, %rbp
subq $96, %rsp
movq %rdi, -88(%rbp)
leaq -80(%rbp), %rdi
movq $10, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf121_b0
.Lf121_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -88(%rbp), %rsi
leaq .Lroots_f121(%rip), %rdx
movq $11, %rcx
call evn_bind_roots@PLT
movq -88(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
call evn_void@PLT
movq %rax, -32(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -40(%rbp), %rdi
call f20@PLT
movq %rax, -48(%rbp)
movq -32(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_store@PLT
movq %rax, -56(%rbp)
movabsq $0, %rax
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_bool@PLT
movq %rax, -72(%rbp)
movq -8(%rbp), %rdi
movq -72(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -80(%rbp)
movq -80(%rbp), %rax
leave
ret
.size f121, .-f121
.text
.p2align 4
.type f122, @function
f122:
pushq %rbp
movq %rsp, %rbp
subq $112, %rsp
movq %rdi, -96(%rbp)
movq %rsi, -104(%rbp)
leaq -88(%rbp), %rdi
movq $11, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf122_b0
.Lf122_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -104(%rbp), %rsi
leaq .Lroots_f122(%rip), %rdx
movq $13, %rcx
call evn_bind_roots@PLT
movq -96(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -104(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -56(%rbp)
movq -48(%rbp), %rdi
movq -56(%rbp), %rsi
call f16@PLT
movq %rax, -64(%rbp)
movabsq $0, %rax
movq %rax, -72(%rbp)
movq -72(%rbp), %rdi
call evn_bool@PLT
movq %rax, -80(%rbp)
movq -8(%rbp), %rdi
movq -80(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -88(%rbp)
movq -88(%rbp), %rax
leave
ret
.size f122, .-f122
.text
.p2align 4
.type f123, @function
f123:
pushq %rbp
movq %rsp, %rbp
subq $176, %rsp
movq %rdi, -160(%rbp)
movq %rsi, -168(%rbp)
leaq -152(%rbp), %rdi
movq $19, %rcx
xorl %eax, %eax
rep stosq
jmp .Lf123_b0
.Lf123_b3:
call evn_void@PLT
movq %rax, -144(%rbp)
movq -8(%rbp), %rdi
movq -144(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -152(%rbp)
movq -152(%rbp), %rax
leave
ret
.Lf123_b2:
jmp .Lf123_b3
.Lf123_b1:
movabsq $41, %rax
movq %rax, -80(%rbp)
movabsq $1, %rax
movq %rax, -88(%rbp)
movq -80(%rbp), %rdi
movq -88(%rbp), %rsi
call evn_object@PLT
movq %rax, -96(%rbp)
movq -40(%rbp), %rdi
call evn_copy@PLT
movq %rax, -104(%rbp)
movabsq $0, %rax
movq %rax, -112(%rbp)
movq -96(%rbp), %rdi
movq -112(%rbp), %rsi
movq -104(%rbp), %rdx
call evn_init@PLT
movq %rax, -120(%rbp)
movabsq $0, %rax
movq %rax, -128(%rbp)
movq -96(%rbp), %rdi
movq -128(%rbp), %rsi
call evn_fail@PLT
movq %rax, -136(%rbp)
ud2
.Lf123_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -168(%rbp), %rsi
leaq .Lroots_f123(%rip), %rdx
movq $21, %rcx
call evn_bind_roots@PLT
movq -160(%rbp), %rax
movq %rax, -16(%rbp)
movq -16(%rbp), %rdi
call evn_copy@PLT
movq %rax, -24(%rbp)
movq -168(%rbp), %rax
movq %rax, -32(%rbp)
movq -32(%rbp), %rdi
call evn_copy@PLT
movq %rax, -40(%rbp)
movq -24(%rbp), %rdi
call evn_copy@PLT
movq %rax, -48(%rbp)
movabsq $1, %rax
movq %rax, -56(%rbp)
movq -56(%rbp), %rdi
movq -48(%rbp), %rsi
call evn_unary@PLT
movq %rax, -64(%rbp)
movq -64(%rbp), %rdi
call evn_truth@PLT
movq %rax, -72(%rbp)
cmpq $0, -72(%rbp)
je .Lf123_b2
jmp .Lf123_b1
.size f123, .-f123
.text
.p2align 4
.type erist_entry, @function
erist_entry:
pushq %rbp
movq %rsp, %rbp
subq $32, %rsp
leaq -32(%rbp), %rdi
movq $4, %rcx
xorl %eax, %eax
rep stosq
jmp .Lerist_entry_b0
.Lerist_entry_b0:
call evn_scope_enter@PLT
movq %rax, -8(%rbp)
movq %rax, %rdi
leaq -32(%rbp), %rsi
leaq .Lroots_erist_entry(%rip), %rdx
movq $4, %rcx
call evn_bind_roots@PLT
call f99@PLT
movq %rax, -16(%rbp)
call evn_void@PLT
movq %rax, -24(%rbp)
movq -8(%rbp), %rdi
movq -24(%rbp), %rsi
call evn_scope_leave@PLT
movq %rax, -32(%rbp)
movq -32(%rbp), %rax
leave
ret
.size erist_entry, .-erist_entry
.section .rodata
.Lroots_f0:
.byte 1,1,1,1,2,1,1,2,2,1,2,1,2,1,1,1,2,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f1:
.byte 1,1,1,1,2,1,1,2,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f2:
.byte 1,1,1,2,1,1,2,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,2,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f3:
.byte 1,1,1,2,1,1,2,1,2,2,1,2,1,2,1,1,1,2,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,2,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f4:
.byte 1,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f5:
.byte 1,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f6:
.byte 1,1,1,0,1,2,1,2,0,1,2,1,2,0,1,2,1,2,0,1,2,1,2,1,1,1,1,2,1,2,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,6,0
.section .rodata
.Lroots_f7:
.byte 1,1,1,1,0,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f8:
.byte 1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Lroots_f9:
.byte 1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f10:
.byte 1,1,1,0,1,2,1,2,1,1,6,0
.section .rodata
.Lroots_f11:
.byte 1,1,1,1,1,1,1,1,1,2,1,2,1,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f12:
.byte 1,1,1,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f13:
.byte 1,1,1,1,0,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,1,2,1,2,1,1,1,2,1,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,0,1,2,1,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,1,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f14:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,1,2,2,1,2,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f15:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,0,2,1,2,1,1,2,2,0,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f16:
.byte 1,1,1,1,0,1,2,1,0,1,2,1,2,1,2,1,2,1,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,2,1,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,0,1,2,1,0,1,2,1,1,1,2,1,2,1,1,1,1,1,1,0,1,2,1,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f17:
.byte 1,1,1,0,1,2,1,2,0,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,0,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f18:
.byte 1,1,1,0,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,0,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f19:
.byte 1,1,1,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f20:
.byte 1,1,1,2,0,2,1,2,0,2,1,2,1,0,2,1,1,2,2,0,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f21:
.byte 1,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f22:
.byte 1,1,1,1,2,0,2,1,2,0,2,1,0,2,1,1,2,2,1,1,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f23:
.byte 1,1,1,1,1,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,2,1,2,1,0,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f24:
.byte 1,1,1,1,0,1,2,1,2,1,2,1,2,1,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,0,1,2,1,2,1,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f25:
.byte 1,1,1,1,2,1,1,2,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,2,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f26:
.byte 1,1,1,1,1,2,1,2,1,2,1,2,1,1,1,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f27:
.byte 1,1,1,1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,0,2,1,0,2,1,2,0,2,1,0,2,1,2,1,1,2,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f28:
.byte 1,1,1,2,1,2,1,2,6,0
.section .rodata
.Lroots_f29:
.byte 1,1,1,1,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,0,2,1,0,2,1,2,0,2,1,2,0,2,1,2,1,2,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f30:
.byte 1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f31:
.byte 1,1,1,0,2,0,2,1,0,2,1,0,2,1,2,3,0,2,1,2,3,1,2,2,0,1,2,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_0:
.byte 85,49,97,32,114,101,115,111,117,114,99,101,32,108,105,109,105,116,32,101,120,99,101,101,100,101,100,0
.section .rodata
.Ldata_1:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Lroots_f32:
.byte 1,1,1,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,2,3,1,2,2,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,0,1,2,1,0,1,1,1,1,1,6,0
.section .rodata
.Ldata_2:
.byte 85,49,97,32,97,116,116,101,109,112,116,32,99,97,110,99,101,108,108,101,100,0
.section .rodata
.Ldata_3:
.byte 99,97,110,99,101,108,108,101,100,0
.section .rodata
.Lroots_f33:
.byte 1,0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,1,2,2,1,1,6,0
.section .rodata
.Ldata_4:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Lroots_f34:
.byte 0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,2,3,1,2,2,6,0
.section .rodata
.Ldata_5:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,97,99,99,111,117,110,116,105,110,103,32,115,116,97,116,101,0
.section .rodata
.Ldata_6:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Lroots_f35:
.byte 1,1,1,1,1,2,1,1,1,2,1,1,2,1,2,1,2,1,0,1,2,1,2,0,1,2,1,2,0,1,2,1,0,1,2,1,2,1,1,2,3,2,1,2,1,1,1,1,6,0
.section .rodata
.Ldata_7:
.byte 100,111,117,98,108,101,32,99,108,111,115,101,32,111,102,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Lroots_f36:
.byte 1,1,1,1,1,1,1,2,1,2,1,2,1,0,1,2,1,2,0,1,2,1,1,1,1,2,1,2,1,2,1,0,1,2,1,1,2,0,1,2,1,1,2,1,2,1,2,1,0,1,2,1,2,0,1,2,1,0,1,2,1,2,1,1,1,2,1,2,1,1,1,2,1,2,1,2,1,0,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,0,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f37:
.byte 1,1,1,0,1,2,1,2,1,1,2,3,2,1,2,1,1,1,2,1,1,1,6,0
.section .rodata
.Ldata_8:
.byte 99,108,111,115,101,100,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Lroots_f38:
.byte 1,1,1,1,1,0,1,2,1,2,1,2,1,1,1,1,2,1,2,1,1,0,1,1,2,1,1,1,0,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,1,2,1,1,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f39:
.byte 1,1,1,1,1,1,1,1,1,2,1,2,1,1,0,1,1,2,1,1,1,1,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,1,2,1,2,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_9:
.byte 85,49,97,32,119,111,114,100,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Lroots_f40:
.byte 1,1,1,1,1,1,2,1,2,1,1,0,1,1,2,1,1,1,1,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,1,2,1,2,1,1,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_10:
.byte 85,49,97,32,119,111,114,100,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Lroots_f41:
.byte 1,1,1,1,1,1,1,2,1,0,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,0,1,2,1,2,1,0,1,1,0,1,2,1,1,1,1,1,0,1,1,1,2,1,2,1,2,1,1,2,1,2,1,0,1,1,1,0,1,2,1,2,1,2,1,1,1,1,2,1,2,1,2,1,2,1,0,1,2,1,2,1,0,1,2,0,1,1,2,1,0,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f42:
.byte 1,1,1,1,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f43:
.byte 1,1,1,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f44:
.byte 1,1,1,1,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,0,1,2,1,1,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f45:
.byte 1,1,1,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_f46:
.byte 1,0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,2,3,1,2,2,1,1,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Ldata_11:
.byte 109,105,115,115,105,110,103,32,85,49,97,32,119,111,114,100,32,112,97,103,101,0
.section .rodata
.Ldata_12:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Lroots_f47:
.byte 1,0,2,0,2,1,2,0,2,1,2,0,2,1,2,3,0,2,1,2,3,1,2,2,1,1,1,2,1,2,1,2,1,1,1,6,0
.section .rodata
.Ldata_13:
.byte 109,105,115,115,105,110,103,32,85,49,97,32,114,97,100,105,120,32,110,111,100,101,0
.section .rodata
.Ldata_14:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Lroots_f48:
.byte 1,1,1,1,0,1,2,1,2,1,1,0,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,1,2,2,0,1,1,2,1,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f49:
.byte 1,1,1,1,0,1,2,1,2,1,1,0,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,2,1,2,2,0,1,1,2,1,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f50:
.byte 1,1,1,1,0,1,2,0,2,1,1,0,2,1,2,0,2,1,2,0,2,1,0,2,1,2,0,2,1,2,0,2,1,1,2,2,0,1,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_15:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,119,111,114,100,32,108,105,109,105,116,0
.section .rodata
.Lroots_f51:
.byte 1,1,1,1,1,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,1,2,3,2,1,2,1,1,1,2,1,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_16:
.byte 102,111,114,101,105,103,110,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Ldata_17:
.byte 105,109,109,117,116,97,98,108,101,32,111,114,32,102,111,114,101,105,103,110,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Ldata_18:
.byte 99,108,111,115,101,100,32,85,49,97,32,119,111,114,100,32,115,116,111,114,101,0
.section .rodata
.Lroots_f52:
.byte 1,1,1,1,1,1,2,1,2,1,2,1,0,1,2,1,2,0,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,0,1,2,1,2,1,1,2,3,2,1,2,1,1,1,1,6,0
.section .rodata
.Ldata_19:
.byte 100,111,117,98,108,101,32,99,108,111,115,101,32,111,102,32,85,49,97,32,109,101,116,97,100,97,116,97,0
.section .rodata
.Lroots_f53:
.byte 1,1,1,0,1,2,1,2,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,3,2,1,2,1,1,1,2,1,1,1,6,0
.section .rodata
.Ldata_20:
.byte 99,108,111,115,101,100,32,85,49,97,32,109,101,116,97,100,97,116,97,0
.section .rodata
.Lroots_f54:
.byte 1,1,1,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_21:
.byte 102,111,114,101,105,103,110,32,111,114,32,105,110,118,97,108,105,100,32,85,49,97,32,76,111,99,73,100,0
.section .rodata
.Lroots_f55:
.byte 1,1,1,1,1,1,1,1,1,1,0,1,1,2,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,2,1,1,1,2,1,0,0,2,1,2,1,2,1,2,1,2,1,2,1,2,1,0,2,1,2,1,1,2,2,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,1,2,1,1,2,1,1,2,1,1,2,1,1,2,1,1,2,1,1,2,1,1,2,1,2,1,0,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_22:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,115,111,117,114,99,101,32,115,112,97,110,0
.section .rodata
.Ldata_23:
.byte 102,111,114,101,105,103,110,32,111,114,32,105,110,118,97,108,105,100,32,85,49,97,32,83,111,117,114,99,101,73,100,0
.section .rodata
.Lroots_f56:
.byte 1,1,1,1,1,1,1,0,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,2,1,1,1,2,1,0,1,1,1,1,2,1,0,0,2,1,2,1,2,1,2,1,2,1,2,1,2,1,0,2,1,2,1,1,2,2,0,1,1,1,1,0,1,1,1,1,0,1,2,1,2,1,1,0,2,1,2,1,2,1,0,2,1,2,1,1,2,2,1,1,2,3,2,1,2,1,1,1,2,1,2,1,1,1,2,1,2,1,1,2,1,1,1,2,1,1,1,0,1,1,2,1,2,1,1,1,2,1,2,1,1,1,1,1,1,0,1,1,2,1,2,1,1,1,2,1,0,1,1,1,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,0,1,2,0,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,0,1,2,1,1,2,1,2,1,2,1,2,1,0,1,2,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_24:
.byte 99,111,110,102,108,105,99,116,105,110,103,32,115,111,117,114,99,101,32,114,101,118,105,115,105,111,110,0
.section .rodata
.Ldata_25:
.byte 115,111,117,114,99,101,32,100,105,103,101,115,116,32,109,117,115,116,32,98,101,32,108,111,119,101,114,99,97,115,101,32,83,72,65,45,50,53,54,32,104,101,120,0
.section .rodata
.Ldata_26:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,115,111,117,114,99,101,32,105,100,101,110,116,105,116,121,0
.section .rodata
.Lroots_f57:
.byte 1,1,1,1,1,1,1,2,0,1,2,1,2,1,1,1,2,2,1,2,1,2,1,1,2,1,1,1,2,1,1,1,1,2,1,2,1,2,1,1,0,1,2,1,1,2,2,1,2,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f58:
.byte 1,1,1,1,1,0,1,2,1,2,1,0,1,1,2,1,1,2,1,1,1,2,1,2,1,2,1,1,2,1,1,0,1,2,0,1,2,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f59:
.byte 1,1,1,1,1,1,1,1,2,1,1,1,1,2,1,0,1,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,1,2,1,0,1,1,1,1,2,1,0,0,2,1,2,1,2,1,2,1,2,1,2,1,2,1,0,2,1,2,1,1,2,2,0,1,2,1,2,1,0,1,1,2,1,1,1,2,1,1,1,0,1,2,1,1,2,1,2,1,1,1,0,1,2,0,1,2,1,2,1,0,1,2,1,2,1,0,1,1,2,1,1,1,2,1,1,1,0,1,2,1,1,2,1,2,1,1,1,0,1,2,0,1,2,1,2,1,0,1,1,2,1,2,1,1,1,2,1,1,1,2,1,1,1,1,1,2,1,1,1,1,1,1,0,1,1,2,1,2,1,1,1,2,1,0,1,1,2,1,2,1,1,1,2,1,2,1,2,1,1,1,1,1,1,2,1,1,2,1,1,1,1,1,1,2,1,2,1,1,1,1,1,2,1,0,1,1,1,0,0,2,1,0,2,1,2,1,1,2,2,2,1,2,1,2,1,0,1,1,1,1,2,1,0,1,2,1,2,1,0,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f60:
.byte 1,1,1,1,1,1,2,0,1,2,1,2,1,1,1,2,2,1,2,1,2,1,1,1,2,1,1,1,1,2,1,1,1,0,1,2,1,1,2,1,2,1,1,1,0,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f61:
.byte 1,1,1,1,1,2,1,2,1,2,1,1,1,2,1,2,1,0,1,2,1,2,1,0,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,0,1,2,1,1,1,1,2,1,2,1,2,1,1,1,0,1,2,0,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f62:
.byte 1,1,1,1,1,1,1,1,2,1,1,1,1,2,1,0,1,1,2,1,2,1,1,1,2,1,1,1,2,3,2,1,2,1,1,2,1,1,2,1,2,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_27:
.byte 85,49,97,32,114,101,115,117,108,116,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Lroots_f63:
.byte 1,1,1,1,1,1,1,1,2,1,1,1,1,2,1,0,1,1,2,1,2,1,1,1,2,1,1,1,2,3,2,1,2,1,1,2,1,1,2,1,2,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_28:
.byte 85,49,97,32,112,97,114,97,109,101,116,101,114,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Lroots_f64:
.byte 1,1,1,1,1,1,2,1,2,1,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f65:
.byte 1,1,1,1,1,1,2,1,2,1,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f66:
.byte 1,1,1,1,2,1,2,1,2,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_29:
.byte 102,111,114,101,105,103,110,32,111,114,32,105,110,118,97,108,105,100,32,85,49,97,32,83,105,103,110,97,116,117,114,101,73,100,0
.section .rodata
.Lroots_f67:
.byte 1,1,1,1,0,1,2,1,2,1,1,0,1,2,1,2,1,0,1,1,2,1,1,2,1,2,1,2,1,2,1,0,1,2,0,1,2,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,2,0,2,1,2,1,2,2,1,2,2,0,1,1,2,1,1,1,2,1,1,1,0,1,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_30:
.byte 109,101,116,97,100,97,116,97,32,114,101,113,117,105,114,101,115,32,97,32,102,114,101,115,104,32,115,104,97,114,101,100,32,112,104,97,115,101,0
.section .rodata
.Lroots_f68:
.byte 1,1,1,1,1,1,2,3,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,1,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_31:
.byte 105,109,109,117,116,97,98,108,101,32,111,114,32,102,111,114,101,105,103,110,32,85,49,97,32,109,101,116,97,100,97,116,97,0
.section .rodata
.Lroots_f69:
.byte 1,1,1,0,1,1,2,1,1,1,1,6,0
.section .rodata
.Lroots_f70:
.byte 1,0,2,1,2,1,2,2,6,0
.section .rodata
.Lroots_f71:
.byte 1,0,2,1,2,1,2,2,6,0
.section .rodata
.Lroots_f72:
.byte 1,0,2,1,2,1,2,2,6,0
.section .rodata
.Lroots_f73:
.byte 1,1,0,2,1,1,2,2,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,1,1,6,0
.section .rodata
.Ldata_32:
.byte 117,110,115,117,112,112,111,114,116,101,100,32,85,49,97,32,116,121,112,101,0
.section .rodata
.Lroots_f74:
.byte 1,1,1,1,1,1,2,1,2,1,2,1,0,1,2,1,2,0,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,0,1,2,1,2,1,1,2,3,2,1,2,1,2,1,2,1,1,1,1,6,0
.section .rodata
.Ldata_33:
.byte 100,111,117,98,108,101,32,99,108,111,115,101,32,111,102,32,85,49,97,32,102,117,110,99,116,105,111,110,0
.section .rodata
.Lroots_f75:
.byte 1,1,1,0,1,2,1,2,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,1,1,2,1,0,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,0,1,2,0,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,1,2,1,0,1,1,1,1,1,1,2,1,2,1,1,0,1,2,1,1,2,3,2,1,2,1,1,1,2,1,2,1,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,0,2,1,2,0,2,1,2,1,1,2,2,1,1,2,3,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_34:
.byte 117,110,116,101,114,109,105,110,97,116,101,100,32,85,49,97,32,98,108,111,99,107,0
.section .rodata
.Ldata_35:
.byte 85,49,97,32,101,110,116,114,121,32,116,121,112,101,32,109,105,115,109,97,116,99,104,0
.section .rodata
.Ldata_36:
.byte 85,49,97,32,101,110,116,114,121,32,115,105,103,110,97,116,117,114,101,32,109,105,115,109,97,116,99,104,0
.section .rodata
.Ldata_37:
.byte 85,49,97,32,102,117,110,99,116,105,111,110,32,104,97,115,32,110,111,32,101,110,116,114,121,0
.section .rodata
.Lroots_f76:
.byte 1,1,1,1,0,2,1,1,2,1,1,1,2,1,1,2,1,0,2,1,2,1,1,2,2,0,1,1,2,1,2,1,1,2,1,1,2,1,1,1,2,3,2,1,2,1,1,2,1,1,2,1,2,1,0,1,1,2,1,2,1,1,2,1,1,2,1,0,1,2,1,2,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_38:
.byte 85,49,97,32,101,100,103,101,32,97,114,103,117,109,101,110,116,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Ldata_39:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,101,100,103,101,0
.section .rodata
.Lroots_f77:
.byte 1,1,1,1,1,1,0,1,1,2,1,2,1,1,1,2,1,1,0,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,1,2,1,0,1,1,2,1,1,1,2,1,2,1,1,0,1,2,1,1,2,3,2,1,2,1,1,1,0,1,1,2,1,1,2,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_40:
.byte 85,49,97,32,114,101,116,117,114,110,32,116,121,112,101,32,109,105,115,109,97,116,99,104,0
.section .rodata
.Ldata_41:
.byte 85,49,97,32,114,101,116,117,114,110,32,97,114,105,116,121,32,109,105,115,109,97,116,99,104,0
.section .rodata
.Lroots_f78:
.byte 1,1,1,1,1,1,1,1,1,1,0,1,1,1,1,0,2,1,1,2,2,1,2,1,1,0,1,1,1,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,3,2,1,2,1,2,1,2,1,0,1,1,1,1,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_42:
.byte 85,49,97,32,98,114,97,110,99,104,32,114,101,113,117,105,114,101,115,32,112,114,101,100,0
.section .rodata
.Lroots_f79:
.byte 1,1,1,1,1,1,1,0,1,1,2,1,1,1,2,2,1,2,1,1,0,1,1,1,1,1,1,1,1,1,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f80:
.byte 1,1,1,1,1,1,1,0,1,1,2,1,1,0,2,1,1,2,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f81:
.byte 1,1,1,1,1,1,1,2,1,1,2,1,2,1,0,2,1,1,2,2,1,2,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f82:
.byte 1,1,1,1,1,1,0,2,1,1,2,1,1,0,2,1,1,2,1,1,1,2,2,0,1,1,2,1,2,1,0,2,1,0,2,1,1,2,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f83:
.byte 1,1,1,1,1,1,1,2,1,1,2,1,1,1,2,2,1,2,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f84:
.byte 1,1,1,1,1,1,1,2,1,1,2,1,1,1,2,2,1,2,1,1,1,0,1,2,2,1,0,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f85:
.byte 1,1,1,1,1,1,1,2,1,1,2,1,1,1,2,2,1,2,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f86:
.byte 1,1,1,1,0,2,1,2,1,1,0,2,1,2,1,1,2,2,0,1,1,2,1,2,1,1,2,1,1,2,1,1,1,2,3,2,1,2,1,1,2,1,1,2,1,2,1,0,1,1,2,1,2,1,1,2,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_43:
.byte 85,49,97,32,105,110,115,116,114,117,99,116,105,111,110,32,114,101,115,117,108,116,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Lroots_f87:
.byte 1,1,1,1,1,1,1,1,1,0,1,2,1,2,1,2,1,2,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,2,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,1,2,1,1,2,1,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,1,0,1,1,2,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,1,1,1,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,0,1,1,1,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,0,1,2,1,2,1,0,1,1,1,2,1,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,1,1,2,1,2,1,1,2,1,0,1,1,1,1,1,2,1,1,2,1,2,1,2,1,1,1,0,1,2,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,0,1,2,0,0,2,1,2,1,2,1,2,1,2,1,2,1,2,1,0,2,1,2,1,1,2,2,0,1,2,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,1,2,1,1,2,1,2,1,1,1,0,1,2,0,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,0,1,2,1,2,1,1,1,2,3,2,1,2,1,1,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,1,1,2,1,2,1,1,1,0,1,2,1,1,2,3,2,1,2,1,1,1,2,1,1,2,1,2,1,0,1,1,1,1,2,3,2,1,2,1,1,1,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_44:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,116,114,97,112,32,99,111,100,101,0
.section .rodata
.Ldata_45:
.byte 105,110,118,97,108,105,100,32,85,49,97,32,112,114,101,100,105,99,97,116,101,32,99,111,110,115,116,97,110,116,0
.section .rodata
.Ldata_46:
.byte 85,49,97,32,111,112,101,114,97,110,100,32,116,121,112,101,32,109,105,115,109,97,116,99,104,0
.section .rodata
.Ldata_47:
.byte 85,49,97,32,105,110,115,116,114,117,99,116,105,111,110,32,97,114,105,116,121,32,109,105,115,109,97,116,99,104,0
.section .rodata
.Ldata_48:
.byte 117,110,115,117,112,112,111,114,116,101,100,32,85,49,97,32,111,112,101,114,97,116,105,111,110,0
.section .rodata
.Lroots_f88:
.byte 1,1,1,1,1,0,1,1,1,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,0,1,2,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,1,1,1,0,1,2,1,1,2,1,2,1,1,1,0,1,2,0,1,2,1,2,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f89:
.byte 1,1,1,1,1,0,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,1,2,1,0,1,1,1,1,1,1,0,1,1,2,1,1,1,2,1,2,1,1,0,1,2,1,1,2,3,2,1,2,1,1,1,0,1,1,2,1,2,1,1,2,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_49:
.byte 85,49,97,32,101,100,103,101,32,116,121,112,101,32,109,105,115,109,97,116,99,104,0
.section .rodata
.Ldata_50:
.byte 85,49,97,32,101,100,103,101,32,97,114,105,116,121,32,109,105,115,109,97,116,99,104,0
.section .rodata
.Lroots_f90:
.byte 1,1,1,1,1,1,2,3,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_51:
.byte 85,49,97,32,98,108,111,99,107,32,97,108,114,101,97,100,121,32,116,101,114,109,105,110,97,116,101,100,0
.section .rodata
.Lroots_f91:
.byte 1,1,1,1,0,2,1,2,1,1,0,2,1,2,1,1,2,2,0,1,1,1,2,1,1,2,1,1,1,2,3,2,1,2,1,1,2,1,1,2,1,2,1,0,1,1,2,1,2,1,1,2,1,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_52:
.byte 85,49,97,32,98,108,111,99,107,32,112,97,114,97,109,101,116,101,114,32,105,110,100,101,120,32,111,117,116,32,111,102,32,114,97,110,103,101,0
.section .rodata
.Lroots_f92:
.byte 1,1,1,1,0,1,2,1,2,1,2,1,2,1,0,1,2,1,2,1,0,1,1,1,2,1,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,1,1,2,1,2,1,1,2,1,0,1,1,2,1,1,2,1,1,2,1,0,1,2,1,1,2,1,2,1,1,1,0,1,2,0,1,1,2,1,2,1,1,2,1,0,1,1,2,1,2,1,1,2,1,0,1,1,2,1,2,1,1,2,1,0,1,1,1,1,2,1,1,2,1,0,1,1,1,2,1,1,2,1,0,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,0,1,2,0,0,2,1,2,1,2,1,2,1,2,1,2,1,2,1,0,2,1,2,1,1,2,2,0,1,2,1,2,1,1,1,2,1,1,2,1,2,1,1,1,0,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f93:
.byte 1,1,1,1,1,1,1,2,1,1,2,1,0,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f94:
.byte 1,1,1,1,1,1,0,1,2,1,2,1,1,0,1,2,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,1,2,1,0,2,1,2,0,2,1,2,0,2,1,2,0,2,1,0,2,1,0,2,1,0,2,1,0,2,1,2,0,2,1,2,1,2,2,1,2,2,0,1,1,2,1,1,1,0,1,1,2,1,0,1,1,1,1,1,1,2,3,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_53:
.byte 85,49,97,32,102,117,110,99,116,105,111,110,32,114,101,113,117,105,114,101,115,32,105,109,109,117,116,97,98,108,101,32,109,101,116,97,100,97,116,97,32,97,110,100,32,105,116,115,32,111,119,110,32,112,104,97,115,101,0
.section .rodata
.Lroots_f95:
.byte 1,1,1,1,2,1,2,1,2,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_54:
.byte 102,111,114,101,105,103,110,32,111,114,32,105,110,118,97,108,105,100,32,85,49,97,32,73,110,115,116,73,100,0
.section .rodata
.Lroots_f96:
.byte 1,1,1,1,2,1,2,1,2,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_55:
.byte 102,111,114,101,105,103,110,32,111,114,32,105,110,118,97,108,105,100,32,85,49,97,32,86,97,108,117,101,73,100,0
.section .rodata
.Lroots_f97:
.byte 1,1,1,1,2,1,2,1,2,1,2,1,2,1,1,1,2,3,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_56:
.byte 102,111,114,101,105,103,110,32,111,114,32,105,110,118,97,108,105,100,32,85,49,97,32,66,108,111,99,107,73,100,0
.section .rodata
.Lroots_f98:
.byte 1,1,1,1,1,2,3,2,1,2,1,2,1,2,1,1,1,2,1,1,1,6,0
.section .rodata
.Ldata_57:
.byte 85,49,97,32,102,117,110,99,116,105,111,110,32,99,111,110,115,116,114,117,99,116,105,111,110,32,105,115,32,99,108,111,115,101,100,0
.section .rodata
.Lroots_f99:
.byte 1,1,0,0,1,1,1,2,3,1,2,1,0,1,2,1,2,1,1,2,3,0,1,2,2,1,1,1,2,3,1,2,1,0,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,4,1,1,1,6,0
.section .rodata
.Ldata_58:
.byte 112,114,111,98,101,58,0
.section .rodata
.Ldata_59:
.byte 115,116,100,46,112,114,111,99,101,115,115,46,115,101,116,69,120,105,116,67,111,100,101,0
.section .rodata
.Ldata_60:
.byte 58,0
.section .rodata
.Ldata_61:
.byte 115,116,100,46,112,114,111,99,101,115,115,46,115,101,116,69,120,105,116,67,111,100,101,0
.section .rodata
.Lroots_f100:
.byte 1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f101:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,0,1,2,3,1,0,1,2,3,1,0,1,2,3,1,1,1,1,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,2,3,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,1,1,4,1,1,2,3,1,2,1,2,1,1,2,1,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,1,2,1,2,1,1,1,1,1,0,2,1,1,2,1,1,1,2,2,1,1,1,1,0,2,1,1,2,2,1,0,2,1,0,2,1,1,2,2,1,1,1,1,1,1,0,2,1,0,2,1,1,2,2,1,1,1,0,1,1,2,1,1,0,1,1,2,1,1,0,1,1,2,1,1,0,1,1,2,1,1,0,1,1,2,1,1,0,1,0,2,1,1,2,2,1,0,1,0,2,1,0,2,1,1,2,2,1,0,1,0,2,1,0,2,1,0,2,1,1,2,2,1,0,1,1,1,1,1,0,1,1,2,1,0,1,1,2,1,1,1,2,3,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,0,2,1,2,1,0,2,1,2,1,1,2,2,1,1,1,1,1,2,1,1,1,0,1,1,1,2,1,1,1,0,1,1,1,1,1,1,0,1,1,2,1,1,0,1,1,2,1,1,0,1,0,2,1,0,2,1,1,2,2,1,0,1,1,1,1,1,0,1,1,2,1,0,1,1,2,1,1,1,0,1,1,2,1,2,1,2,1,2,1,2,1,1,1,1,1,2,3,1,2,1,2,1,1,2,1,0,1,1,2,1,2,3,1,2,3,1,1,0,1,1,2,1,2,3,1,2,3,1,1,0,1,0,2,1,1,2,2,0,2,1,0,2,1,0,2,1,1,2,2,1,1,1,1,2,3,1,2,1,2,1,2,1,1,2,1,1,1,0,1,2,1,2,1,1,1,2,3,1,2,1,2,1,2,1,2,1,2,1,1,2,1,2,1,1,2,1,0,1,1,1,1,1,0,1,1,1,1,1,0,0,2,1,0,2,1,1,2,2,0,0,2,1,0,2,1,1,2,2,0,1,1,1,0,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_62:
.byte 97,108,108,32,116,114,97,99,107,101,100,32,99,97,112,97,99,105,116,105,101,115,32,114,101,108,101,97,115,101,100,0
.section .rodata
.Ldata_63:
.byte 109,101,116,97,100,97,116,97,58,111,107,0
.section .rodata
.Ldata_64:
.byte 98,117,105,108,100,101,114,58,111,107,0
.section .rodata
.Ldata_65:
.byte 108,111,111,112,45,101,100,103,101,115,58,111,107,0
.section .rodata
.Ldata_66:
.byte 102,111,114,101,105,103,110,45,105,100,58,111,107,0
.section .rodata
.Ldata_67:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Ldata_68:
.byte 99,114,111,115,115,45,102,117,110,99,116,105,111,110,32,86,97,108,117,101,73,100,0
.section .rodata
.Ldata_69:
.byte 102,111,114,101,105,103,110,32,86,97,108,117,101,73,100,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Ldata_70:
.byte 112,97,114,97,108,108,101,108,32,108,111,111,112,32,97,114,103,117,109,101,110,116,115,0
.section .rodata
.Ldata_71:
.byte 109,117,108,116,105,45,114,101,115,117,108,116,32,97,110,100,32,110,111,32,102,97,107,101,32,118,111,105,100,32,118,97,108,117,101,115,0
.section .rodata
.Ldata_72:
.byte 99,97,110,111,110,105,99,97,108,32,115,105,103,110,97,116,117,114,101,0
.section .rodata
.Ldata_73:
.byte 115,105,103,110,97,116,117,114,101,32,111,119,110,115,32,99,111,112,105,101,100,32,116,121,112,101,32,105,100,115,0
.section .rodata
.Ldata_74:
.byte 112,114,111,98,101,0
.section .rodata
.Ldata_75:
.byte 48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,0
.section .rodata
.Ldata_76:
.byte 112,114,111,98,101,0
.section .rodata
.Ldata_77:
.byte 48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,48,0
.section .rodata
.Ldata_78:
.byte 99,97,110,111,110,105,99,97,108,32,115,111,117,114,99,101,32,114,101,118,105,115,105,111,110,0
.section .rodata
.Lroots_f102:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,2,3,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,1,1,4,1,1,1,1,2,3,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,1,2,1,1,2,1,1,2,1,2,1,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,2,1,1,1,1,2,1,2,1,1,0,1,2,1,2,1,1,1,2,3,1,2,1,2,1,2,1,1,1,1,1,2,1,2,1,2,1,0,1,2,0,1,2,1,2,1,0,1,1,2,1,2,1,1,1,2,1,2,1,2,1,0,1,2,0,1,1,2,1,0,1,1,2,1,0,1,1,2,1,0,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_79:
.byte 115,116,111,114,97,103,101,32,99,104,97,114,103,101,115,32,114,101,108,101,97,115,101,100,0
.section .rodata
.Ldata_80:
.byte 112,97,103,101,115,58,111,107,0
.section .rodata
.Ldata_81:
.byte 102,114,111,122,101,110,32,115,116,111,114,97,103,101,0
.section .rodata
.Ldata_82:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Ldata_83:
.byte 102,114,111,122,101,110,32,115,116,111,114,101,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Ldata_84:
.byte 112,97,103,101,32,98,111,117,110,100,97,114,105,101,115,0
.section .rodata
.Ldata_85:
.byte 114,97,100,105,120,32,112,97,103,101,32,99,111,110,116,101,110,116,115,0
.section .rodata
.Lroots_f103:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,2,1,1,4,0,1,1,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,6,0
.section .rodata
.Ldata_86:
.byte 110,111,32,115,105,103,110,101,100,32,99,111,117,110,116,101,114,32,111,118,101,114,102,108,111,119,0
.section .rodata
.Ldata_87:
.byte 99,111,117,110,116,101,114,45,98,111,117,110,100,97,114,121,58,111,107,0
.section .rodata
.Ldata_88:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Ldata_89:
.byte 98,111,117,110,100,97,114,121,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f104:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,2,3,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,1,4,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,1,1,2,1,0,1,1,2,1,0,1,1,2,1,0,1,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_90:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Ldata_91:
.byte 115,116,97,108,101,32,97,98,97,110,100,111,110,101,100,32,104,97,110,100,108,101,0
.section .rodata
.Ldata_92:
.byte 97,98,97,110,100,111,110,58,111,107,0
.section .rodata
.Ldata_93:
.byte 97,98,97,110,100,111,110,101,100,32,104,97,110,100,108,101,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Ldata_94:
.byte 97,98,97,110,100,111,110,32,107,101,101,112,115,32,104,105,115,116,111,114,105,99,97,108,32,99,104,97,114,103,101,115,0
.section .rodata
.Lroots_f105:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,1,4,1,1,0,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_95:
.byte 99,97,110,99,101,108,32,98,108,111,99,107,115,32,99,111,109,109,105,116,0
.section .rodata
.Ldata_96:
.byte 99,97,110,99,101,108,58,111,107,0
.section .rodata
.Ldata_97:
.byte 99,97,110,99,101,108,108,101,100,0
.section .rodata
.Ldata_98:
.byte 99,97,110,99,101,108,108,101,100,32,99,111,109,109,105,116,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f106:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,1,1,2,1,0,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,2,1,1,4,0,1,1,2,1,1,1,2,1,0,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_99:
.byte 114,101,113,117,101,115,116,32,119,111,114,107,32,115,117,114,118,105,118,101,115,32,99,104,105,108,100,32,97,116,116,101,109,112,116,115,0
.section .rodata
.Ldata_100:
.byte 114,101,116,114,121,32,99,111,110,115,117,109,101,115,32,114,101,109,97,105,110,105,110,103,32,114,101,113,117,101,115,116,32,119,111,114,107,0
.section .rodata
.Ldata_101:
.byte 114,101,113,117,101,115,116,45,119,111,114,107,58,111,107,0
.section .rodata
.Ldata_102:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Ldata_103:
.byte 114,101,113,117,101,115,116,32,119,111,114,107,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f107:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,2,1,1,4,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,2,1,1,1,2,1,0,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_104:
.byte 119,111,114,107,32,97,100,109,105,115,115,105,111,110,32,97,116,111,109,105,99,105,116,121,0
.section .rodata
.Ldata_105:
.byte 119,111,114,107,58,111,107,0
.section .rodata
.Ldata_106:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Ldata_107:
.byte 119,111,114,107,32,108,105,109,105,116,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Ldata_108:
.byte 99,111,110,115,117,109,101,100,32,97,110,100,32,112,114,101,112,97,105,100,32,119,111,114,107,0
.section .rodata
.Lroots_f108:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,1,4,1,1,0,1,1,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,6,0
.section .rodata
.Ldata_109:
.byte 115,105,110,103,108,101,45,117,115,101,32,114,101,108,101,97,115,101,0
.section .rodata
.Ldata_110:
.byte 114,101,108,101,97,115,101,45,111,110,99,101,58,111,107,0
.section .rodata
.Ldata_111:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Ldata_112:
.byte 100,117,112,108,105,99,97,116,101,32,114,101,108,101,97,115,101,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f109:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,1,4,0,1,1,0,1,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_113:
.byte 115,105,110,103,108,101,45,117,115,101,32,99,111,109,109,105,116,0
.section .rodata
.Ldata_114:
.byte 99,111,109,109,105,116,45,111,110,99,101,58,111,107,0
.section .rodata
.Ldata_115:
.byte 105,110,118,97,108,105,100,45,115,116,97,116,101,0
.section .rodata
.Ldata_116:
.byte 100,117,112,108,105,99,97,116,101,32,99,111,109,109,105,116,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f110:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,1,1,4,0,1,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_117:
.byte 102,97,105,108,101,100,32,116,114,97,110,115,102,101,114,32,105,115,32,97,116,111,109,105,99,0
.section .rodata
.Ldata_118:
.byte 116,114,97,110,115,102,101,114,45,114,101,106,101,99,116,58,111,107,0
.section .rodata
.Ldata_119:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Ldata_120:
.byte 116,114,97,110,115,102,101,114,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f111:
.byte 1,1,1,0,1,2,3,1,1,1,1,1,1,1,1,1,1,2,3,1,2,1,1,2,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,0,1,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,6,0
.section .rodata
.Ldata_121:
.byte 115,105,98,108,105,110,103,32,116,114,97,110,115,102,101,114,0
.section .rodata
.Ldata_122:
.byte 97,108,108,111,99,97,116,105,111,110,32,111,119,110,101,114,32,116,114,97,110,115,102,101,114,0
.section .rodata
.Ldata_123:
.byte 116,114,97,110,115,102,101,114,58,111,107,0
.section .rodata
.Lroots_f112:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,2,1,1,4,1,1,0,1,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_124:
.byte 116,114,97,102,102,105,99,32,99,97,110,110,111,116,32,98,101,32,114,101,99,108,97,105,109,101,100,0
.section .rodata
.Ldata_125:
.byte 116,114,97,102,102,105,99,58,111,107,0
.section .rodata
.Ldata_126:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Ldata_127:
.byte 116,114,97,102,102,105,99,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f113:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,2,1,1,4,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,6,0
.section .rodata
.Ldata_128:
.byte 112,97,114,101,110,116,32,97,100,109,105,115,115,105,111,110,32,105,115,32,97,116,111,109,105,99,0
.section .rodata
.Ldata_129:
.byte 112,97,114,101,110,116,58,111,107,0
.section .rodata
.Ldata_130:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Ldata_131:
.byte 112,97,114,101,110,116,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f114:
.byte 0,2,0,2,1,2,3,1,2,2,0,0,1,1,1,0,1,2,3,1,1,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,3,1,2,1,0,1,2,2,5,0,0,1,1,2,1,1,4,0,1,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Ldata_132:
.byte 110,111,32,112,97,114,116,105,97,108,32,97,110,99,101,115,116,111,114,32,109,117,116,97,116,105,111,110,0
.section .rodata
.Ldata_133:
.byte 99,97,112,97,99,105,116,121,58,111,107,0
.section .rodata
.Ldata_134:
.byte 99,97,112,97,99,105,116,121,32,101,114,114,111,114,32,100,101,116,97,105,108,0
.section .rodata
.Ldata_135:
.byte 114,101,115,111,117,114,99,101,45,108,105,109,105,116,0
.section .rodata
.Ldata_136:
.byte 99,97,112,97,99,105,116,121,32,109,117,115,116,32,114,101,106,101,99,116,0
.section .rodata
.Lroots_f115:
.byte 1,1,1,0,1,2,3,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,0,1,1,2,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,0,1,1,0,1,1,2,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,1,1,2,3,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,2,1,1,2,1,2,1,2,1,0,1,1,2,1,0,1,1,2,1,2,1,2,1,2,1,0,1,1,2,1,2,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Ldata_137:
.byte 114,101,108,101,97,115,101,32,114,101,116,97,105,110,115,32,97,108,108,111,99,97,116,105,111,110,32,116,114,97,102,102,105,99,0
.section .rodata
.Ldata_138:
.byte 114,101,115,101,114,118,97,116,105,111,110,115,58,111,107,0
.section .rodata
.Ldata_139:
.byte 115,112,108,105,116,32,99,97,112,97,99,105,116,121,0
.section .rodata
.Ldata_140:
.byte 99,111,109,109,105,116,116,101,100,32,97,108,108,111,99,97,116,105,111,110,0
.section .rodata
.Ldata_141:
.byte 99,97,110,99,101,108,108,101,100,32,114,101,115,101,114,118,97,116,105,111,110,32,105,115,32,110,111,116,32,97,108,108,111,99,97,116,105,111,110,32,116,114,97,102,102,105,99,0
.section .rodata
.Ldata_142:
.byte 112,101,110,100,105,110,103,32,118,101,114,115,117,115,32,99,111,109,109,105,116,116,101,100,32,112,101,97,107,0
.section .rodata
.Ldata_143:
.byte 112,101,110,100,105,110,103,32,97,100,109,105,115,115,105,111,110,0
.section .rodata
.Lroots_f116:
.byte 1,1,1,1,1,1,1,1,1,2,1,1,0,2,1,1,2,2,1,1,2,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f117:
.byte 1,1,1,2,1,1,1,1,6,0
.section .rodata
.Lroots_f118:
.byte 1,1,1,1,2,1,1,2,1,2,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f119:
.byte 1,1,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f120:
.byte 1,1,1,2,1,1,1,1,6,0
.section .rodata
.Lroots_f121:
.byte 1,1,1,2,0,1,1,1,1,1,6,0
.section .rodata
.Lroots_f122:
.byte 1,1,1,1,2,1,1,1,1,1,1,1,6,0
.section .rodata
.Lroots_f123:
.byte 1,1,1,1,0,2,0,2,1,1,2,2,2,1,2,1,1,1,1,1,6,0
.section .rodata
.Lroots_erist_entry:
.byte 1,1,1,6,0
.section .data.rel.ro
.p2align 3
.globl ev_types
ev_types:
.long 0,0
.quad .Ltype_name_0
.quad 0
.quad 0
.long 1,0
.quad .Ltype_name_1
.quad 0
.quad 0
.long 2,0
.quad .Ltype_name_2
.quad 0
.quad 0
.long 3,0
.quad .Ltype_name_3
.quad 0
.quad 0
.long 4,0
.quad .Ltype_name_4
.quad 0
.quad 0
.long 5,0
.quad .Ltype_name_5
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_6
.quad 13
.quad .Ltype_fields_6
.long 9,6
.quad .Ltype_name_7
.quad 0
.quad 0
.long 8,7
.quad .Ltype_name_8
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_9
.quad 4
.quad .Ltype_fields_9
.long 6,-1
.quad .Ltype_name_10
.quad 5
.quad .Ltype_fields_10
.long 9,10
.quad .Ltype_name_11
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_12
.quad 3
.quad .Ltype_fields_12
.long 9,12
.quad .Ltype_name_13
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_14
.quad 3
.quad .Ltype_fields_14
.long 9,14
.quad .Ltype_name_15
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_16
.quad 7
.quad .Ltype_fields_16
.long 6,-1
.quad .Ltype_name_17
.quad 18
.quad .Ltype_fields_17
.long 8,13
.quad .Ltype_name_18
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_19
.quad 17
.quad .Ltype_fields_19
.long 9,19
.quad .Ltype_name_20
.quad 0
.quad 0
.long 8,20
.quad .Ltype_name_21
.quad 0
.quad 0
.long 9,17
.quad .Ltype_name_22
.quad 0
.quad 0
.long 8,22
.quad .Ltype_name_23
.quad 0
.quad 0
.long 9,16
.quad .Ltype_name_24
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_25
.quad 11
.quad .Ltype_fields_25
.long 6,-1
.quad .Ltype_name_26
.quad 1
.quad .Ltype_fields_26
.long 9,26
.quad .Ltype_name_27
.quad 0
.quad 0
.long 9,25
.quad .Ltype_name_28
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_29
.quad 2
.quad .Ltype_fields_29
.long 6,-1
.quad .Ltype_name_30
.quad 2
.quad .Ltype_fields_30
.long 6,-1
.quad .Ltype_name_31
.quad 1
.quad .Ltype_fields_31
.long 7,31
.quad .Ltype_name_32
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_33
.quad 2
.quad .Ltype_fields_33
.long 6,-1
.quad .Ltype_name_34
.quad 14
.quad .Ltype_fields_34
.long 9,34
.quad .Ltype_name_35
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_36
.quad 2
.quad .Ltype_fields_36
.long 6,-1
.quad .Ltype_name_37
.quad 2
.quad .Ltype_fields_37
.long 7,36
.quad .Ltype_name_38
.quad 0
.quad 0
.long 6,-1
.quad .Ltype_name_39
.quad 2
.quad .Ltype_fields_39
.long 6,-1
.quad .Ltype_name_40
.quad 2
.quad .Ltype_fields_40
.long 6,-1
.quad .Ltype_name_41
.quad 1
.quad .Ltype_fields_41
.long 12,-1
.quad .Ltype_name_42
.quad 0
.quad 0
.globl ev_types_end
ev_types_end:
.Ltype_name_0:
.byte 0
.Ltype_name_1:
.byte 0
.Ltype_name_2:
.byte 0
.Ltype_name_3:
.byte 0
.Ltype_name_4:
.byte 0
.Ltype_name_5:
.byte 0
.Ltype_name_6:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,79,119,110,101,114,0
.p2align 2
.Ltype_fields_6:
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 8
.Ltype_name_7:
.byte 0
.Ltype_name_8:
.byte 0
.Ltype_name_9:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,76,105,109,105,116,69,114,114,111,114,0
.p2align 2
.Ltype_fields_9:
.long 1
.long 1
.long 4
.long 4
.Ltype_name_10:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,80,104,97,115,101,0
.p2align 2
.Ltype_fields_10:
.long 1
.long 1
.long 1
.long 1
.long 7
.Ltype_name_11:
.byte 0
.Ltype_name_12:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,65,108,108,111,99,97,116,105,111,110,0
.p2align 2
.Ltype_fields_12:
.long 1
.long 1
.long 7
.Ltype_name_13:
.byte 0
.Ltype_name_14:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,100,103,101,116,46,82,101,115,101,114,118,97,116,105,111,110,0
.p2align 2
.Ltype_fields_14:
.long 1
.long 1
.long 7
.Ltype_name_15:
.byte 0
.Ltype_name_16:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,119,111,114,100,115,46,87,111,114,100,115,0
.p2align 2
.Ltype_fields_16:
.long 13
.long 3
.long 3
.long 1
.long 1
.long 23
.long 7
.Ltype_name_17:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,119,111,114,100,115,46,78,111,100,101,0
.p2align 2
.Ltype_fields_17:
.long 18
.long 21
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.long 23
.Ltype_name_18:
.byte 0
.Ltype_name_19:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,119,111,114,100,115,46,80,97,103,101,0
.p2align 2
.Ltype_fields_19:
.long 18
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.long 1
.Ltype_name_20:
.byte 0
.Ltype_name_21:
.byte 0
.Ltype_name_22:
.byte 0
.Ltype_name_23:
.byte 0
.Ltype_name_24:
.byte 0
.Ltype_name_25:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,109,101,116,97,46,77,101,116,97,100,97,116,97,0
.p2align 2
.Ltype_fields_25:
.long 24
.long 24
.long 24
.long 24
.long 24
.long 24
.long 18
.long 3
.long 3
.long 7
.long 27
.Ltype_name_26:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,109,101,116,97,46,75,101,121,0
.p2align 2
.Ltype_fields_26:
.long 1
.Ltype_name_27:
.byte 0
.Ltype_name_28:
.byte 0
.Ltype_name_29:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,109,101,116,97,46,76,111,99,73,100,0
.p2align 2
.Ltype_fields_29:
.long 1
.long 27
.Ltype_name_30:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,109,101,116,97,46,83,111,117,114,99,101,73,100,0
.p2align 2
.Ltype_fields_30:
.long 1
.long 27
.Ltype_name_31:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,109,101,116,97,46,84,121,112,101,73,100,0
.p2align 2
.Ltype_fields_31:
.long 1
.Ltype_name_32:
.byte 0
.Ltype_name_33:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,109,101,116,97,46,83,105,103,110,97,116,117,114,101,73,100,0
.p2align 2
.Ltype_fields_33:
.long 1
.long 27
.Ltype_name_34:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,105,108,100,101,114,46,70,117,110,99,116,105,111,110,0
.p2align 2
.Ltype_fields_34:
.long 24
.long 24
.long 24
.long 24
.long 24
.long 24
.long 18
.long 1
.long 1
.long 11
.long 7
.long 33
.long 28
.long 27
.Ltype_name_35:
.byte 0
.Ltype_name_36:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,105,108,100,101,114,46,86,97,108,117,101,73,100,0
.p2align 2
.Ltype_fields_36:
.long 1
.long 27
.Ltype_name_37:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,105,108,100,101,114,46,66,108,111,99,107,73,100,0
.p2align 2
.Ltype_fields_37:
.long 1
.long 27
.Ltype_name_38:
.byte 0
.Ltype_name_39:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,105,108,100,101,114,46,80,97,105,114,0
.p2align 2
.Ltype_fields_39:
.long 36
.long 36
.Ltype_name_40:
.byte 99,111,109,112,105,108,101,114,46,117,49,95,98,117,105,108,100,101,114,46,73,110,115,116,73,100,0
.p2align 2
.Ltype_fields_40:
.long 1
.long 27
.Ltype_name_41:
.byte 112,114,111,98,101,46,80,114,111,98,101,69,114,114,111,114,0
.p2align 2
.Ltype_fields_41:
.long 4
.Ltype_name_42:
.byte 98,121,116,101,115,0
.section .note.GNU-stack,"",@progbits

