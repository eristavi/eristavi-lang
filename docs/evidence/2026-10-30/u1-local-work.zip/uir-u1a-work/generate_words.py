from pathlib import Path
r=Path('/workspace/scratch/1848da8b628a/eristavi-u1a/src/compiler')
fields='; '.join(f'w{i} Int' for i in range(16))
children='; '.join(f'c{i} maybe identity Node' for i in range(16))
initial='; '.join(f'w{i}=0' for i in range(16))
empty='; '.join(f'c{i}=none' for i in range(16))
def tree(lo,hi,read,write):
 if hi-lo==1:return write.format(i=lo) if write else read.format(i=lo)
 mid=(lo+hi)//2
 return f'if offset < {mid} {{ {tree(lo,mid,read,write)} }} else {{ {tree(mid,hi,read,write)} }}'
s='''// Bootstrap storage adapter: dense append-only indices, radix-16 directory,
// 16-word pages, fixed maximum depth 6. No List field/copy-on-write dependency.
// These are safe ordinary Eristavi objects, not packed machine buffers.
// Charges are conservative adapter capacities; allocator/GC overhead is separate.
import compiler.u1_budget as budget;
public type Page { FIELDS; charge maybe identity budget.Allocation; }
public type Node { CHILDREN; page maybe identity Page; charge maybe identity budget.Allocation; }
public type Words { owner identity budget.Owner; root maybe identity Node; length Int; limit Int; closed Bool; frozen Bool; control identity budget.Allocation; }
function context(words identity Words,phase identity budget.Phase,write Bool) fails budget.LimitError {
    try budget.poll(words.owner); try budget.poll(phase.owner);
    if words.closed { try budget.reject("closed U1a word store"); }
    if write { if words.frozen or words.owner != phase.owner { try budget.reject("immutable or foreign U1a word store"); } }
    else { if words.owner != phase.owner { if words.owner.kind != 1 or words.owner.parent != phase.owner.parent { try budget.reject("foreign U1a word store"); } } }
}
public function create(owner identity budget.Owner,limit Int) returns identity Words fails budget.LimitError {
    if limit < 0 or limit > 33554432 { try budget.reject("invalid U1a word limit"); }
    let pending be try budget.reserve(owner,512);
    let words be identity Words { owner=owner; root=none; length=0; limit=limit; closed=false; frozen=false; control=try budget.commit(pending); };
    return words;
}
function newNode(owner identity budget.Owner,phase identity budget.Phase) returns identity Node fails budget.LimitError {
    try budget.work(phase,18); let pending be try budget.reserve(owner,800);
    let node be identity Node { EMPTY; page=none; charge=none; };
    node.charge=try budget.commit(pending); return node;
}
function newPage(owner identity budget.Owner,phase identity budget.Phase) returns identity Page fails budget.LimitError {
    try budget.work(phase,17); let pending be try budget.reserve(owner,768);
    let page be identity Page { INITIAL; charge=none; };
    page.charge=try budget.commit(pending); return page;
}
function needNode(node maybe identity Node) returns identity Node fails budget.LimitError {
    if node != none { return node; }
    fail budget.LimitError { message="missing U1a radix node"; category="invalid-state"; requested=0; remaining=0; };
}
function needPage(page maybe identity Page) returns identity Page fails budget.LimitError {
    if page != none { return page; }
    fail budget.LimitError { message="missing U1a word page"; category="invalid-state"; requested=0; remaining=0; };
}
'''.replace('FIELDS',fields).replace('CHILDREN',children).replace('EMPTY',empty).replace('INITIAL',initial)
s+='function readPage(page identity Page,offset Int) returns Int { '+tree(0,16,'return page.w{i};',None)+' }\n'
s+='function writePage(page identity Page,offset Int,value Int) { '+tree(0,16,None,'page.w{i}=value; return;')+' }\n'
s+='function readChild(node identity Node,offset Int) returns maybe identity Node { '+tree(0,16,'return node.c{i};',None)+' }\n'
s+='function writeChild(node identity Node,offset Int,value identity Node) { '+tree(0,16,None,'node.c{i}=value; return;')+' }\n'
s+='''
function pageAt(words identity Words,phase identity budget.Phase,index Int,create Bool) returns identity Page fails budget.LimitError {
    if create and words.root == none { words.root=try newNode(words.owner,phase); }
    let node be try needNode(words.root); let divisor be 1048576; let pageIndex be index/16;
    while divisor >= 1 {
        try budget.work(phase,1); let offset be pageIndex/divisor%16; let next be readChild(node,offset);
        if next == none and create { let fresh be try newNode(words.owner,phase); writeChild(node,offset,fresh); next=fresh; }
        node=try needNode(next); divisor=divisor/16;
    }
    if create and node.page == none { node.page=try newPage(words.owner,phase); }
    return try needPage(node.page);
}
public function get(words identity Words,phase identity budget.Phase,index Int) returns Int fails budget.LimitError {
    try context(words,phase,false); if index < 0 or index >= words.length { try budget.reject("U1a word index out of range"); }
    try budget.work(phase,1); let page be try pageAt(words,phase,index,false); return readPage(page,index%16);
}
public function set(words identity Words,phase identity budget.Phase,index Int,value Int) fails budget.LimitError {
    try context(words,phase,true); if index < 0 or index >= words.length { try budget.reject("U1a word index out of range"); }
    try budget.work(phase,1); let page be try pageAt(words,phase,index,false); writePage(page,index%16,value);
}
public function push(words identity Words,phase identity budget.Phase,value Int) returns Int fails budget.LimitError {
    try context(words,phase,true); try budget.work(phase,1);
    if words.length >= words.limit { try budget.reject("U1a word count ceiling"); }
    let index be words.length; let page be try pageAt(words,phase,index,true);
    writePage(page,index%16,value); words.length=index+1; return index;
}
public function freeze(words identity Words) fails budget.LimitError {
    try budget.poll(words.owner); if words.closed { try budget.reject("closed U1a word store"); } words.frozen=true;
}
function closeNode(node identity Node,depth Int) fails budget.LimitError {
    // Storage depth is fixed at six; this is not recursion over a program CFG.
    let offset be 0;
    if depth > 0 { while offset < 16 { let child be readChild(node,offset); if child != none { try closeNode(child,depth-1); } offset=offset+1; } }
    let page be node.page; node.page=none;
    if page != none { let allocation be page.charge; page.charge=none; if allocation != none { try budget.release(allocation); } }
    let allocation be node.charge; node.charge=none; if allocation != none { try budget.release(allocation); }
}
public function close(words identity Words) fails budget.LimitError {
    if words.closed { try budget.reject("double close of U1a word store"); }
    words.closed=true; let root be words.root; words.root=none; words.length=0;
    if root != none { try closeNode(root,6); } try budget.release(words.control);
    // No further use of backing is possible through this store. Managed garbage
    // may remain until the runtime collects it; this is not a physical-free API.
}
'''
(r/'u1_words.eri').write_text(s)
print('Generated u1_words.eri',len(s),'bytes')
