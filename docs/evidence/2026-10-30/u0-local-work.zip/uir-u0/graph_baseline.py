"""Vary CFG size with one mutable local, independently of the local-width sweep."""
import json,statistics,sys
import baseline as b

rows=[];fixtures=[]
for n in [8,32,128]:
    name=f'cfg_{n}';path=b.HERE/'fixtures'/f'{name}.eri'
    source='function work(flag Bool) returns Int { let x be 0;\n'
    source+='if flag { x=x+1; } else { x=x+2; }\n'*n
    source+='return x; } output(work(true)); output(work(false));\n'
    path.write_text(source)
    fixtures.append({'name':name,'family':'cfg','size':n,'file':path.name,
                     'source_sha256':b.sha(path),'bytes':len(source.encode()),'expected':f'{n}\n{2*n}\n'})
for round_ in range(5):
    for f in (fixtures if round_%2==0 else list(reversed(fixtures))):
        stem=f"graph_{f['name']}_{round_}";output=b.HERE/'results'/f'{stem}.json'
        r=b.measured_run([sys.executable,b.HERE/'baseline.py','worker',f['name'],output],stem)
        assert r['returncode']==0,(stem,r)
        rows.append(json.loads(output.read_text()))
    print(f'CFG scaling round {round_+1}/5 completed.',flush=True)
summary=[]
for f in fixtures:
    rs=[r for r in rows if r['fixture']==f['name']]
    assert len({r['assembly_sha256'] for r in rs})==1
    assert len({r['uir_sha256'] for r in rs})==1
    summary.append({'fixture':f['name'],'median_pipeline_ms':statistics.median(r['pipeline_ns'] for r in rs)/1e6,
                    'median_lower_ms':statistics.median(r['compile_lower_ns'] for r in rs)/1e6,
                    'median_backend_ms':statistics.median(r['backend_emit_ns'] for r in rs)/1e6,
                    'min_pipeline_ms':min(r['pipeline_ns'] for r in rs)/1e6,
                    'max_pipeline_ms':max(r['pipeline_ns'] for r in rs)/1e6,
                    'median_rss_kib':statistics.median(r['maxrss_kib'] for r in rs),
                    'structure':rs[0]['structure'],'operations':rs[0]['operations'],
                    'exclusive_phase_median_ms':{k:statistics.median(r['exclusive_phase_ns'].get(k,0) for r in rs)/1e6 for k in rs[0]['exclusive_phase_ns']}})
    binary=b.HERE/'build'/f"native_{f['name']}"
    r=b.measured_run(['cc',b.HERE/'build'/f"{f['name']}.bootstrap.s",'-o',binary],f"native_{f['name']}_link",30)
    assert r['returncode']==0
    r=b.measured_run([binary],f"native_{f['name']}_run",10)
    assert r['returncode']==0
    assert (b.HERE/'results'/r['stdout']).read_text()==f['expected']
b.write(b.HERE/'graph-summary.json',summary)
b.write(b.HERE/'graph-fixtures.json',fixtures)
print('All 3 CFG fixtures produced expected native results.',flush=True)
