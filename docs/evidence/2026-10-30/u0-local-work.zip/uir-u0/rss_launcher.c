#define _GNU_SOURCE
#include <sys/resource.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

/* A small post-exec parent avoids inheriting the Python launcher's resident set
 * at the measured child's fork. It is measurement infrastructure, not compiler
 * or runtime code, and does not alter the executable being measured. */
int main(int argc, char **argv) {
    if (argc < 3) return 125;
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    pid_t child = fork();
    if (child < 0) return 125;
    if (child == 0) { execvp(argv[2], &argv[2]); _exit(127); }
    int status;
    struct rusage use;
    while (wait4(child, &status, 0, &use) < 0) {
        if (errno != EINTR) return 125;
    }
    clock_gettime(CLOCK_MONOTONIC, &end);
    FILE *out = fopen(argv[1], "w");
    if (!out) return 125;
    double cpu = use.ru_utime.tv_sec + use.ru_utime.tv_usec/1000000.0
               + use.ru_stime.tv_sec + use.ru_stime.tv_usec/1000000.0;
    double wall = end.tv_sec-start.tv_sec+(end.tv_nsec-start.tv_nsec)/1000000000.0;
    int code = WIFEXITED(status) ? WEXITSTATUS(status) : 128+WTERMSIG(status);
    fprintf(out,"{\"cpu_s\":%.9f,\"wall_s\":%.9f,\"maxrss_kib\":%ld,\"returncode\":%d}\n",
            cpu, wall, use.ru_maxrss, code);
    if (fclose(out)) return 125;
    return code;
}
