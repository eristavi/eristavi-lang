"""Canonical native measurements from a small native fork/exec parent."""
import json,statistics
from pathlib import Path
import baseline as b

results=[]
for round_ in range(5):
    for width in [128,512,2000]:
        profiles=['bootstrap','owned'] if round_%2==0 else ['owned','bootstrap']
        for profile in profiles:
            stem=f'corrected_verifier_{profile}_{width}_{round_}'
            measurement=b.HERE/'results'/f'{stem}.target.json'
            r=b.measured_run([b.HERE/'build/rss-launcher',measurement,
                             b.HERE/'build'/f'probe-{profile}',str(width)],stem,30)
            assert r['returncode']==0,(stem,r)
            assert (b.HERE/'results'/r['stdout']).read_text()=='8\n'
            assert not (b.HERE/'results'/r['stderr']).read_text()
            target=json.loads(measurement.read_text())
            target.update(profile=profile,width=width,round=round_,chains=16,verifier_rounds=8)
            results.append(target)
        print(f'Corrected native paired round {round_+1}/5 width {width} completed.',flush=True)

summary=[]
for profile in ['bootstrap','owned']:
    for width in [128,512,2000]:
        rows=[x for x in results if x['profile']==profile and x['width']==width]
        summary.append({'profile':profile,'width':width,'chains':16,'verifier_rounds':8,
                        'median_wall_ms':1000*statistics.median(x['wall_s'] for x in rows),
                        'median_cpu_ms':1000*statistics.median(x['cpu_s'] for x in rows),
                        'min_cpu_ms':1000*min(x['cpu_s'] for x in rows),
                        'max_cpu_ms':1000*max(x['cpu_s'] for x in rows),
                        'median_rss_kib':statistics.median(x['maxrss_kib'] for x in rows),
                        'rss_observed_samples':len(rows),'rss_method':'wait4 from small native post-exec parent; inherited Python RSS control verified'})
b.write(b.HERE/'native-corrected-summary.json',summary)
b.write(b.HERE/'native-corrected-samples.json',results)
print('Corrected native CPU, wall time and memory batch complete.',flush=True)
