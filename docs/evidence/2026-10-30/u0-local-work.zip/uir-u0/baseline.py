#!/usr/bin/env python3
"""U0 measurement driver; uses the unchanged pinned compiler, not a new IR."""
from __future__ import annotations
import argparse, collections, hashlib, json, os, platform, resource, signal
import statistics, subprocess, sys, time, shutil
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'eristavi-audit'
PIN = '8af0ffe3350c737550c3ab0e6c3fa89f60f6f091'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def proc_hwm(pid):
    try:
        for line in Path(f'/proc/{pid}/status').read_text().splitlines():
            if line.startswith('VmHWM:'): return int(line.split()[1])
    except (OSError,ValueError): pass
    return None
def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')

def prepare():
    for name in ['fixtures','results','build']: (HERE/name).mkdir(exist_ok=True)
    fixtures=[]
    for family in ['diamond','loop','calls']:
        for n in [8,32,128]:
            if family=='calls':
                body='function step(x Int) returns Int { return x+1; }\nlet x be 0;\n'
                body+='x=step(x);\n'*n+'output(x);\n'
                expected=f'{n}\n'
            else:
                args='flag Bool' if family=='diamond' else ''
                body=f'function work({args}) returns Int {{\n'
                body+=''.join(f'let x{i} be {i};\n' for i in range(n))
                if family=='diamond':
                    body+='if flag {\n'+''.join(f'x{i}=x{i}+1;\n' for i in range(n))
                    body+='} else {\n'+''.join(f'x{i}=x{i}+2;\n' for i in range(n))+'}\n'
                else:
                    body+='let index be 0; while index<8 {\n'
                    body+=''.join(f'x{i}=x{i}+index;\n' for i in range(n))+'index=index+1; }\n'
                body+='return '+'+'.join(f'x{i}' for i in range(n))+';\n}\n'
                initial=n*(n-1)//2
                if family=='diamond':
                    body+='output(work(true)); output(work(false));\n'
                    expected=f'{initial+n}\n{initial+2*n}\n'
                else:
                    body+='output(work());\n';expected=f'{initial+28*n}\n'
            name=f'{family}_{n}';path=HERE/'fixtures'/f'{name}.eri';path.write_text(body)
            fixtures.append({'name':name,'family':family,'size':n,'file':path.name,
                             'source_sha256':sha(path),'bytes':len(body.encode()),'expected':expected})
    write(HERE/'fixtures.json',fixtures)
    tree=json.loads((HERE/'source-tree.json').read_text());bad=[];sources=[]
    for e in tree['tree']:
        if e['type']!='blob':continue
        b=(REPO/e['path']).read_bytes()
        actual=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
        if actual!=e['sha']:bad.append(e['path'])
        sources.append({'path':e['path'],'git_blob':actual,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
    assert not bad and not tree.get('truncated'),bad
    import regex, unicodedata2
    info={'baseline_commit':PIN,'source_manifest':sources,'source_files':len(sources),
          'source_bytes':sum(x['bytes'] for x in sources),'mismatches':bad,
          'python':sys.version,'python_executable':sys.executable,'host':platform.platform(),
          'machine':platform.machine(),'cpu_count':os.cpu_count(),
          'cpu_model':next((s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),None),
          'regex_version':regex.__version__,'unicodedata_version':unicodedata2.unidata_version,
          'cache_state':'fresh processes; warm filesystem/page cache; no artifact cache; no cache flushing',
          'candidate_present':False,'rounds':5,'measurement_script_sha256':sha(__file__),
          'environment_flags':{k:os.environ.get(k) for k in ['CC','CFLAGS','PYTHONHASHSEED']}}
    write(HERE/'environment.json',info)
    return fixtures

def setup_path():
    sys.dont_write_bytecode=True
    sys.path[:0]=[str(HERE/'deps'),str(REPO)]

def bootstrap_worker(fixture, output):
    setup_path()
    import compiler.erist.project as project
    import compiler.erist.direct_project as direct
    import compiler.erist.universal_passes as passes
    from compiler.erist.universal_resources import ResourceUniversalLowerer
    from compiler.erist.universal_ir import format_program, UBranch, UJump
    from compiler.erist.x86_64_gc_precise import X86_64PreciseRootGCLinuxBackend
    events=[];stack=[]
    def hook(owner,name,label):
        original=getattr(owner,name)
        def timed(*args,**kw):
            frame=[time.perf_counter_ns(),0];stack.append(frame)
            try:return original(*args,**kw)
            finally:
                elapsed=time.perf_counter_ns()-frame[0];stack.pop()
                if stack:stack[-1][1]+=elapsed
                events.append({'phase':label,'inclusive_ns':elapsed,'exclusive_ns':elapsed-frame[1]})
        setattr(owner,name,timed)
    for owner,name,label in [
        (project.Lexer,'lex','lex'),(project.Parser,'parse','parse'),
        (project.Analyzer,'analyze','semantic'),(direct,'compile_entry','project'),
        (direct,'typed_source_project','typed_lower'),
        (ResourceUniversalLowerer,'lower','universal_lower'),
        (passes,'verify_program','universal_verify'),(passes,'fold_constants','constant_fold'),
        (passes,'eliminate_unreachable_blocks','dead_blocks')]:hook(owner,name,label)
    source=HERE/'fixtures'/f'{fixture}.eri'
    started=time.perf_counter_ns();program=direct.lower_direct_entry(source,source.parent)
    lowered=time.perf_counter_ns();assembly=X86_64PreciseRootGCLinuxBackend().emit(program)
    emitted=time.perf_counter_ns()
    text=format_program(program)
    ops=collections.Counter();counts=collections.Counter()
    for fn in program.functions:
        counts['functions']+=1;counts['locals']+=len(fn.locals);counts['values']+=fn.value_count
        for block in fn.blocks:
            counts['blocks']+=1;counts['instructions']+=len(block.instructions)
            if isinstance(block.terminator,UBranch):counts['edges']+=2
            elif isinstance(block.terminator,UJump):counts['edges']+=1
            for ins in block.instructions:
                ops[ins.op]+=1;counts['operands']+=len(ins.args)
    (HERE/'build'/f'{fixture}.bootstrap.s').write_text(assembly)
    exclusive=collections.Counter();inclusive=collections.Counter();calls=collections.Counter()
    for e in events:
        exclusive[e['phase']]+=e['exclusive_ns'];inclusive[e['phase']]+=e['inclusive_ns'];calls[e['phase']]+=1
    write(output,{'profile':'python-bootstrap-direct-x86_64','fixture':fixture,
                  'source_sha256':sha(source),'compile_lower_ns':lowered-started,
                  'backend_emit_ns':emitted-lowered,'pipeline_ns':emitted-started,
                  'exclusive_phase_ns':dict(exclusive),'inclusive_phase_ns':dict(inclusive),'phase_calls':dict(calls),
                  'maxrss_kib':proc_hwm('self'),'ru_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
                  'structure':dict(counts),'operations':dict(ops),'uir_sha256':hashlib.sha256(text.encode()).hexdigest(),
                  'assembly_sha256':hashlib.sha256(assembly.encode()).hexdigest(),'assembly_bytes':len(assembly.encode()),
                  'instrumentation':'in-memory timing wrappers; original compiler functions unchanged; module imports and report formatting outside pipeline timer'})

def measured_run(argv, stem, timeout=60):
    start=time.perf_counter()
    expected_exe=Path(shutil.which(str(argv[0])) or str(argv[0])).resolve()
    out=HERE/'results'/f'{stem}.stdout';err=HERE/'results'/f'{stem}.stderr'
    with out.open('wb') as of,err.open('wb') as ef:
        p=subprocess.Popen(list(map(str,argv)),stdout=of,stderr=ef,start_new_session=True,
                           env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','PYTHONHASHSEED':'0'})
        timed_out=False;observed_hwm=None
        while True:
            try:
                if Path(f'/proc/{p.pid}/exe').resolve()==expected_exe:
                    hwm=proc_hwm(p.pid)
                    if hwm is not None:observed_hwm=max(observed_hwm or 0,hwm)
            except OSError:pass
            pid,status,usage=os.wait4(p.pid,os.WNOHANG)
            if pid:break
            if time.perf_counter()-start>timeout:
                timed_out=True;os.killpg(p.pid,signal.SIGKILL);pid,status,usage=os.wait4(p.pid,0);break
            time.sleep(0.001)
        p.returncode=os.waitstatus_to_exitcode(status)
    record={'argv':list(map(str,argv)),'wall_s':time.perf_counter()-start,
            'cpu_s':usage.ru_utime+usage.ru_stime,'maxrss_kib':observed_hwm,'ru_maxrss_kib':usage.ru_maxrss,
            'rss_method':'post-exec /proc VmHWM sampling; null if process ended before observation; ru_maxrss retained only as contaminated raw evidence',
            'returncode':p.returncode,'timed_out':timed_out,'stdout':out.name,'stderr':err.name,
            'stdout_sha256':sha(out),'stderr_sha256':sha(err)}
    write(HERE/'results'/f'{stem}.process.json',record)
    return record

def run_bootstrap():
    setup_path();fixtures=prepare();results=[]
    for round_ in range(5):
        order=fixtures if round_%2==0 else list(reversed(fixtures))
        for f in order:
            stem=f"bootstrap_{f['name']}_{round_}";output=HERE/'results'/f'{stem}.json'
            r=measured_run([sys.executable,__file__,'worker',f['name'],output],stem)
            if r['returncode']!=0:raise RuntimeError(f"{stem}: {r}")
            results.append(json.loads(output.read_text()))
        print(f'Bootstrap baseline round {round_+1}/5 completed.',flush=True)
    summary=[]
    for f in fixtures:
        rows=[x for x in results if x['fixture']==f['name']]
        assert len({x['uir_sha256'] for x in rows})==1
        assert len({x['assembly_sha256'] for x in rows})==1
        phases={k:statistics.median(x['exclusive_phase_ns'].get(k,0) for x in rows)/1e6
                for k in set().union(*(x['exclusive_phase_ns'] for x in rows))}
        summary.append({'fixture':f['name'],'median_pipeline_ms':statistics.median(x['pipeline_ns'] for x in rows)/1e6,
                        'min_pipeline_ms':min(x['pipeline_ns'] for x in rows)/1e6,'max_pipeline_ms':max(x['pipeline_ns'] for x in rows)/1e6,
                        'median_lower_ms':statistics.median(x['compile_lower_ns'] for x in rows)/1e6,
                        'median_backend_ms':statistics.median(x['backend_emit_ns'] for x in rows)/1e6,
                        'median_rss_kib':statistics.median(x['maxrss_kib'] for x in rows),
                        'exclusive_phase_median_ms':phases,'structure':rows[0]['structure'],'operations':rows[0]['operations']})
    write(HERE/'bootstrap-summary.json',summary)
    for f in fixtures:
        stem=f"native_{f['name']}";binary=HERE/'build'/stem
        r=measured_run(['cc',HERE/'build'/f"{f['name']}.bootstrap.s",'-o',binary],stem+'_link',30)
        if r['returncode']!=0:raise RuntimeError(f'link failed: {stem}')
        r=measured_run([binary],stem+'_run',10)
        actual=(HERE/'results'/r['stdout']).read_text()
        assert r['returncode']==0 and actual==f['expected'],(stem,actual,f['expected'])
    print('All 9 bootstrap-generated native fixture outputs matched independent expected values.',flush=True)

if __name__=='__main__':
    setup_path()
    if sys.argv[1]=='worker':bootstrap_worker(sys.argv[2],sys.argv[3])
    elif sys.argv[1]=='bootstrap':run_bootstrap()
    elif sys.argv[1]=='prepare':prepare()
    else:raise SystemExit('use prepare|bootstrap|worker')
