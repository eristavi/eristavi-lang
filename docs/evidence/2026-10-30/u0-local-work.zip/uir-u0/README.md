# U0 evidence reproduction

This is measurement infrastructure for unchanged Eristavi source, not a UIR implementation.
Use Linux x86-64 and the pinned eristavi-lang source at commit
8af0ffe3350c737550c3ab0e6c3fa89f60f6f091 in a sibling directory named eristavi-audit.
Put this directory beside it as uir-u0. Install requirements.txt into uir-u0/deps.
All source-tree.json Git blob identities are checked by baseline.py prepare.

Set PYTHONDONTWRITEBYTECODE=1 and PYTHONHASHSEED=0. Run baseline.py bootstrap for
the nine width/call cases, then graph_baseline.py for the three CFG cases.
Never run benchmark drivers concurrently. They overwrite matching result names;
copy the archive first if retaining a previous run.

For native setup, the archived build/frontend-seed.c is generated from unchanged
src/frontend.eri with CBackend().emit(lower_project(compile_entry(path, src_root)))
using the Python bootstrap. Build it with cc -std=c11 -O1 ... -lm -o build/frontend-seed.
Then run native_baseline.py setup. It emits/audits both runtime profiles without
changing compiler sources. Compile rss_launcher.c with cc -std=c11 -O2 to
build/rss-launcher, then run memory_baseline.py for authoritative five paired native
CPU/wall/RSS samples. native_baseline.py measure is the initial launcher cohort;
its ru_maxrss data is not authoritative. No script performs a compiler self-build.

The report gives limitations and semantics of every metric. Native probe elapsed
time includes construction plus eight verification rounds; it is not isolated
verifier time. All required stdout/stderr, return-code and expected-output checks
are in the scripts. Regenerate compiler source/products from the pinned tree when
changing environments; binary hashes describe this exact archived run only.
